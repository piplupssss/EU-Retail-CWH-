@echo off
cd /d %~dp0\..
start "" EUCWH-VN64.exe
