    // ===== 全局状态 =====
    const API = '';
    let currentFilterType = '';
    let currentFilterDs = '';
    let currentFilterCountry = '';
    let currentFilterWarehouse = '';
    let currentFilterVerify = '';
    let currentFilterMonth = '';
    let currentFilterPickupMonth = '';
    let currentFilterActualDeliveryMonth = '';
    let shipmentSortBy = '';
    let shipmentSortDir = 'desc';
    let currentEditShipment = null;
    let currentPage = 1;
    let shipmentPerPage = Number(localStorage.getItem('vn22_shipment_per_page') || 20);
    let charts = {};

    // WMS state
    let currentWarehouse = 'Lodz warehouse', currentOrderStatus = '', currentOrderConfirmId = null;
    let pendingImageFiles = [];

    // ===== API 请求包装（统一错误处理） =====
    // ===== Token 认证 =====
    const AUTH_TOKEN_KEY = 'claw_auth_token';
    const AUTH_USER_KEY = 'claw_auth_user';
    const AUTH_ENABLED = true;

    function getAuthToken() {
        return localStorage.getItem(AUTH_TOKEN_KEY) || '';
    }
    function setAuthToken(token) {
        localStorage.setItem(AUTH_TOKEN_KEY, token);
    }
    function setAuthUser(user) {
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user || {}));
    }
    function getAuthUser() {
        try { return JSON.parse(localStorage.getItem(AUTH_USER_KEY) || '{}'); } catch { return {}; }
    }
    function isAdminUser() {
        return getAuthUser().role === 'admin';
    }
    function clearAuthToken() {
        localStorage.removeItem(AUTH_TOKEN_KEY);
        localStorage.removeItem(AUTH_USER_KEY);
    }
    function askMaintenancePassword(promptText = '请输入操作密码：', allowAdminBypass = true) {
        if (allowAdminBypass && isAdminUser()) return '';
        return prompt(promptText);
    }
    function showLogin() {
        document.getElementById('login-overlay').classList.remove('hidden');
    }
    function hideLogin() {
        document.getElementById('login-overlay').classList.add('hidden');
    }

    async function doLogin() {
        const user = document.getElementById('login-user').value.trim();
        const pass = document.getElementById('login-pass').value;
        const btn = document.getElementById('login-btn');
        const errEl = document.getElementById('login-error');
        if (!user || !pass) { errEl.textContent = '请输入用户名和密码'; return; }
        btn.disabled = true;
        errEl.textContent = '';
        try {
            const res = await fetch(API + '/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: user, password: pass })
            });
            const data = await res.json();
            if (data.success && data.token) {
                setAuthToken(data.token);
                setAuthUser(data.user || {});
                hideLogin();
                initApp();
            } else {
                errEl.textContent = data.error || '登录失败';
            }
        } catch (e) {
            errEl.textContent = '网络错误，请重试';
        } finally {
            btn.disabled = false;
        }
    }

    // 回车键登录
	    document.addEventListener('keydown', e => {
	        if (e.key === 'Escape' && document.getElementById('imgModal')?.classList.contains('show')) {
	            closeImageModal();
	            return;
	        }
	        if (e.key === 'Escape' && document.getElementById('invoice-detail-modal')?.style.display === 'flex') {
	            closeInvoiceDetail();
	            return;
	        }
	        if (e.key === 'Escape' && document.getElementById('budget-invoice-detail-modal')?.style.display === 'flex') {
	            closeBudgetInvoiceDetail();
	            return;
	        }
	        if (e.key === 'Enter' && !document.getElementById('login-overlay').classList.contains('hidden')) {
	            doLogin();
	        }
	    });

    // 页面加载时检查 Token
    async function checkAuth() {
        const token = getAuthToken();
        if (!token) { showLogin(); return; }
        try {
            const res = await fetch(API + '/api/auth/check', {
                headers: { 'Authorization': 'Bearer ' + token }
            });
            if (res.ok) {
                const data = await res.json().catch(() => ({}));
                setAuthUser(data.user || getAuthUser());
                hideLogin();
            } else {
                clearAuthToken();
                showLogin();
            }
        } catch {
            hideLogin();
        }
    }

    async function apiFetch(url, options = {}) {
        options.credentials = 'same-origin';
        const token = getAuthToken();
        if (token) {
            if (!options.headers) options.headers = {};
            options.headers['Authorization'] = 'Bearer ' + token;
        }
        const res = await fetch(url, options);
        if (res.status === 401) {
            clearAuthToken();
            showLogin();
            throw new Error('登录已过期，请重新登录');
        }
        if (!res.ok) {
            const text = await res.text().catch(() => '');
            throw new Error(`API 请求失败 (${res.status}): ${text}`);
        }
        return res.json();
    }
    function uploadFormWithProgress(url, formData, progressId) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const progress = document.getElementById(progressId);
            const fill = progress ? progress.querySelector('.upload-progress-fill') : null;
            if (progress && fill) {
                progress.style.display = 'block';
                fill.style.width = '0%';
            }
            xhr.open('POST', url);
            const token = getAuthToken();
            if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);
            xhr.upload.onprogress = (evt) => {
                if (!evt.lengthComputable || !fill) return;
                fill.style.width = Math.max(3, Math.round(evt.loaded / evt.total * 100)) + '%';
            };
            xhr.onload = () => {
                if (fill) fill.style.width = '100%';
                setTimeout(() => { if (progress) progress.style.display = 'none'; }, 700);
                let data = {};
                try { data = JSON.parse(xhr.responseText || '{}'); } catch { data = { error: xhr.responseText || '上传失败' }; }
                if (xhr.status >= 200 && xhr.status < 300) resolve(data);
                else reject(new Error(data.error || `上传失败 (${xhr.status})`));
            };
            xhr.onerror = () => {
                if (progress) progress.style.display = 'none';
                reject(new Error('网络连接失败'));
            };
            xhr.send(formData);
        });
    }

    // WMS API helpers (compatible with old merged style)
    function apiHeaders() { const t = getAuthToken(); return t ? { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + t } : { 'Content-Type': 'application/json' }; }
    function apiGet(url) { return fetch(API + url, { headers: apiHeaders() }).then(r => r.json()); }
    function apiPost(url, data) { return fetch(API + url, { method: 'POST', headers: apiHeaders(), body: JSON.stringify(data) }).then(r => r.json()); }
    function apiPut(url, data) { return fetch(API + url, { method: 'PUT', headers: apiHeaders(), body: JSON.stringify(data) }).then(r => r.json()); }
    function apiDelete(url) { return fetch(API + url, { method: 'DELETE', headers: apiHeaders() }).then(r => r.json()); }

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, ch => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[ch]));
    }
    function jsArg(value) {
        return JSON.stringify(String(value ?? ''));
    }
    function demandCountryOfShipment(s) {
        return String(s?.demand_country || s?.consignee_country_code || '').trim().toUpperCase();
    }
    function consigneeCountryOfShipment(s) {
        return String(s?.consignee_country_code || '').trim().toUpperCase();
    }
    function shipmentCountryDisplay(s) {
        const demand = demandCountryOfShipment(s);
        const consignee = consigneeCountryOfShipment(s);
        if (demand && consignee && demand !== consignee) {
            return `<span class="country-override" title="需求国家：${escapeHtml(demand)}；收货国家：${escapeHtml(consignee)}">${escapeHtml(demand)} → ${escapeHtml(consignee)} 收货</span>`;
        }
        return escapeHtml(demand || consignee || '');
    }

    const LANG_KEY = 'vn8_lang';
    const THEME_KEY = 'vn12_theme';
    const APP_VERSION = 'VN64';
    const APP_VERSION_FULL = 'VN64 · 2026-07-06 00:58 CEST';
    const APP_BUILD_TIME = '2026-07-06 00:58 CEST';
    let currentLang = 'zh';
    const THEME_LIGHT_DEFAULT_KEY = 'vn52_apple_light_default_applied';
    let storedTheme = localStorage.getItem(THEME_KEY);
    if (localStorage.getItem(THEME_LIGHT_DEFAULT_KEY) !== '1' && (!storedTheme || storedTheme === 'dark')) {
        storedTheme = 'light';
        localStorage.setItem(THEME_KEY, storedTheme);
        localStorage.setItem(THEME_LIGHT_DEFAULT_KEY, '1');
    }
    let currentTheme = storedTheme || 'light';
    const I18N = {
        zh: {
            appName: '欧洲地区部零售物料管理系统',
            versionLine: '版本号：VN64 - 2026-07-06<br>00:58 CEST',
            topbarSubtitle: 'VN64 - 2026-07-06 00:58 CEST · 由Qiteng Liu 84405995 提供',
            providedByPenguin: 'Qiteng Liu 84405995 提供',
            footerCredit: 'Qiteng Liu 84405995 提供',
            username: '用户名',
            password: '密码',
            login: '登 录',
            navMain: '工作台',
            navLogistics: '物流看板',
            navInventory: '库存看板',
            navBudget: '发票看板',
            navDetails: '清单',
            navShipments: '物流清单',
            navStockList: '库存清单',
            navMovements: '出入流水',
            navAcceptanceList: '验收清单',
            navCostList: '费用列表',
            navReportsGroup: '报告',
            navReports: '报告中心',
            navImport: '数据',
            navDataCenter: '数据管理中心',
            navLogisticsImport: '物流数据维护',
            navInventoryImport: '库存数据维护',
            navInvoiceImport: '发票数据维护',
            navOther: '系统',
            navOrders: '发货管理',
            navOperations: '操作记录',
            navSettings: '系统设置',
            navVersionInfo: '版本信息',
            logisticsDashboard: '物流看板',
            logisticsSubtitle: '实时运单数据概览 · 数据更新至',
            trackPlaceholder: '输入 STT Number 或 Booking ID 追踪...',
            track: '追踪',
            inventoryOverview: '库存看板',
            inventorySubtitle: '库存数据分析 · SKU / 货值 / 库龄 / 静置',
            ordersTitle: '发货指令',
            ordersSubtitle: '创建和管理发货指令',
            backToDashboard: '← 返回看板',
            allShipments: '物流清单',
            shipmentSearchPlaceholder: '搜索 Booking / 国家...',
            clearFilters: '清除筛选',
            batchVerify: '批量核实',
            dataImportTitle: '数据管理中心',
            dataImportSubtitle: '集中导入、导出、备份和源文件',
            costListTitle: '费用列表',
            costListSubtitle: '物流费用与仓储操作费用明细',
            stockListTitle: '库存清单',
            stockListSubtitle: '全部 SKU 库存明细',
            movementsListTitle: '出入流水',
            acceptanceListTitle: '验收清单',
            stockSearchPlaceholder: '搜索产品 / 描述...',
            export: '导出',
            operationsTitle: '库存操作',
            operationsSubtitle: '库存调整 · 报废出库 · 变动记录',
            settingsTitle: '系统设置',
            settingsSubtitle: '系统管理与版本维护',
            versionInfoTitle: '版本信息',
            versionInfoSubtitle: '当前版本 · 数据规则 · 更新纪要',
            inventoryImportTitle: '库存数据维护',
            inventoryImportSubtitle: '上传 Excel 库存清单 & SKU 产品图片',
            budgetTitle: '发票看板',
            invoiceImportTitle: '发票数据维护',
            invoiceImportSubtitle: '物流费用发票上传与验收 · 仓储操作费用（开发中）',
            statusDistribution: '运单状态分布',
            typeDistribution: '运单类型分布',
            countryInfoOverview: '各国订单信息一览（按取货月份）',
            monthLabel: '月份：',
            all: '全部',
            less: '少',
            more: '多',
            countryDemandDistribution: '各国要货量分布',
            monthlyShipmentTrend: '月度运单趋势',
            clickToView: '点击查看',
            clickCountryToView: '点击国家查看',
            totalShipments: '总运单数',
            viewAll: '点击查看全部',
            delivered: '已交付',
            pendingVerify: '待核实',
            inTransit: '运输中',
            exception: '异常单',
            deliveredShipments: '已交付运单',
            pendingVerifyShipments: '待核实运单',
            inTransitShipments: '运输中运单',
            exceptionShipments: '异常运单',
            ratioClick: '占比 {pct}% · 点击查看',
            etaReached: 'ETA 已到需人工确认 · 点击查看',
            shipOverdue: '发货超 10 工作日未签收 · 点击查看',
            orderUnit: '单',
            weightLabel: '重量',
            avgDelivery: '平均交付',
            workdays: '工作日',
            shipmentCount: '运单数',
            weightKg: '重量(kg)',
            noData: '暂无数据',
            centralWarehouseOutbound: '中央仓发出',
            furnitureWarehouseOutbound: '家具仓发出',
            directShipment: '调拨',
            shipToCountry: '发货至 {country}',
            warehouseOutbound: '{warehouse} 发货'
        },
        en: {
            appName: 'EU RHQ Retail Materials Management System',
            versionLine: 'Version: VN64 - 2026-07-06<br>00:58 CEST',
            topbarSubtitle: 'VN64 - 2026-07-06 00:58 CEST · Provided by Qiteng Liu 84405995',
            providedByPenguin: 'Provided by Qiteng Liu 84405995',
            footerCredit: 'Provided by Qiteng Liu 84405995',
            username: 'Username',
            password: 'Password',
            login: 'Log In',
            navMain: 'Workspace',
            navLogistics: 'Logistics Dashboard',
            navInventory: 'Inventory Dashboard',
            navBudget: 'Invoice Dashboard',
            navDetails: 'Lists',
            navShipments: 'Shipment List',
            navStockList: 'Inventory List',
            navMovements: 'Movement List',
            navAcceptanceList: 'Acceptance List',
            navCostList: 'Cost List',
            navReportsGroup: 'Reports',
            navReports: 'Report Center',
            navImport: 'Data',
            navDataCenter: 'Data Center',
            navLogisticsImport: 'Logistics Data',
            navInventoryImport: 'Inventory Data',
            navInvoiceImport: 'Invoice Data',
            navOther: 'System',
            navOrders: 'Delivery Orders',
            navOperations: 'Operations Log',
            navSettings: 'Settings',
            navVersionInfo: 'Version Info',
            logisticsDashboard: 'Logistics Dashboard',
            logisticsSubtitle: 'Live shipment overview · Data updated to',
            trackPlaceholder: 'Track by STT Number or Booking ID...',
            track: 'Track',
            inventoryOverview: 'Inventory Overview',
            inventorySubtitle: 'Inventory analytics · SKU / Value / Age / Idle',
            ordersTitle: 'Delivery Orders',
            ordersSubtitle: 'Create and manage delivery orders',
            backToDashboard: '← Back to Dashboard',
            allShipments: 'All Shipments',
            shipmentSearchPlaceholder: 'Search booking / country...',
            clearFilters: 'Clear Filters',
            batchVerify: 'Batch Verify',
            dataImportTitle: 'Data Center',
            dataImportSubtitle: 'Centralized import, export, backup, and source files.',
            costListTitle: 'Cost List',
            costListSubtitle: 'Logistics and warehouse operation cost details',
            stockListTitle: 'Inventory List',
            stockListSubtitle: 'All SKU inventory details',
            stockSearchPlaceholder: 'Search product / description...',
            export: 'Export',
            operationsTitle: 'Inventory Operations',
            operationsSubtitle: 'Inventory adjustment · Scrap outbound · Transaction history',
            settingsTitle: 'Settings',
            settingsSubtitle: 'Classification scan · thresholds · display preferences',
            versionInfoTitle: 'Version Info',
            versionInfoSubtitle: 'Current version · data rules · changelog',
            inventoryImportTitle: 'Inventory Data',
            inventoryImportSubtitle: 'Upload Excel inventory lists and SKU product images',
            budgetTitle: 'Invoice Dashboard',
            invoiceImportTitle: 'Invoice Data',
            invoiceImportSubtitle: 'Logistics invoice upload and acceptance · Warehouse operation cost in development',
            statusDistribution: 'Shipment Status Distribution',
            typeDistribution: 'Shipment Type Distribution',
            countryInfoOverview: 'Country Order Overview (Pickup Month)',
            monthLabel: 'Month:',
            all: 'All',
            less: 'Low',
            more: 'High',
            countryDemandDistribution: 'Country Demand Distribution',
            monthlyShipmentTrend: 'Monthly Shipment Trend',
            clickToView: 'Click to view',
            clickCountryToView: 'Click country to view',
            totalShipments: 'Total Shipments',
            viewAll: 'Click to view all',
            delivered: 'Delivered',
            pendingVerify: 'Pending Check',
            inTransit: 'In Transit',
            exception: 'Exceptions',
            deliveredShipments: 'Delivered Shipments',
            pendingVerifyShipments: 'Pending Check Shipments',
            inTransitShipments: 'In-Transit Shipments',
            exceptionShipments: 'Exception Shipments',
            ratioClick: 'Share {pct}% · click to view',
            etaReached: 'ETA reached, manual check needed · click to view',
            shipOverdue: 'No POD after 10 workdays · click to view',
            orderUnit: 'orders',
            weightLabel: 'Weight',
            avgDelivery: 'Avg delivery',
            workdays: 'workdays',
            shipmentCount: 'Shipments',
            weightKg: 'Weight (kg)',
            noData: 'No data',
            centralWarehouseOutbound: 'Central Warehouse',
            furnitureWarehouseOutbound: 'Furniture Warehouse',
            directShipment: 'Transfer',
            shipToCountry: 'Ship to {country}',
            warehouseOutbound: '{warehouse} outbound'
        }
    };

    function t(key) {
        return (I18N[currentLang] && I18N[currentLang][key]) || I18N.zh[key] || key;
    }
    function tf(key, vars = {}) {
        return t(key).replace(/\{(\w+)\}/g, (_, name) => vars[name] ?? '');
    }
    function tx(zh, en) {
        return currentLang === 'en' ? en : zh;
    }
    const UI_EN_TEXT = {
        '夜间': 'Dark',
        '白天': 'Light',
        '工作台': 'Workspace',
        '列表详情': 'Details',
        '数据': 'Data',
        '系统': 'System',
        '全部': 'All',
        '全部仓库': 'All warehouses',
        'Lodz 仓库': 'Lodz warehouse',
        'Bydgoszcz 仓库': 'Bydgoszcz warehouse',
        '库存范围': 'Inventory scope',
        '切换后同步刷新看板与清单入口': 'Switch warehouse scope for dashboards and lists',
        '库存健康': 'Inventory health',
        'DOS 超期': 'DOS overdue',
        '长期未使用': 'Long idle',
        '分析维度': 'Primary dimension',
        '拆分维度': 'Breakdown dimension',
        '物料品类': 'Category',
        '适用产品': 'Category 2',
        '归属国家': 'Instruction',
        '纵坐标': 'Y axis',
        '运单数': 'Shipments',
        '重量': 'Weight',
        '费用': 'Cost',
        '发票验收': 'Invoice Acceptance',
        '平均交付': 'Avg delivery',
        '排序方式': 'Sort mode',
        '全部国家': 'All countries',
        '按代表处排列': 'By office',
        '筛选单个代表处': 'Single office',
        '代表处': 'Office',
        '波兰代表处': 'Poland office',
        '德国代表处': 'Germany office',
        '法国代表处': 'France office',
        '南欧代表处': 'South Europe office',
        '东欧多国代表处': 'Eastern Europe office',
        '代表处内部订单对比': 'Office internal order split',
        '体积': 'Volume',
        '发货指令': 'Delivery orders',
        '开发中': 'In development',
        '待确认': 'Pending',
        '已确认': 'Confirmed',
        '已发货': 'Shipped',
        '已签收': 'Received',
        '+ 新建指令': '+ New order',
        '指令单号': 'Order No.',
        '目的国家': 'Destination',
        '请求数量': 'Requested qty',
        '实际数量': 'Actual qty',
        '状态': 'Status',
        '创建时间': 'Created at',
        '操作': 'Action',
        '全部物流查询与筛选 · 从看板点击可自动筛选': 'Search and filter all logistics records · dashboard clicks apply filters automatically',
        '20 条/页': '20 / page',
        '50 条/页': '50 / page',
        '100 条/页': '100 / page',
        '显示/隐藏详细列': 'Show/hide detail columns',
        '详细列': 'Detail columns',
        '一键导出物流清单': 'Export logistics list',
        '维护所选': 'Maintain selected',
        '点击 STT / Booking 查看详情和追踪；勾选后做批量维护': 'Click STT / Booking for details and tracking; select rows for batch maintenance',
        '回收站': 'Recycle bin',
        '移入回收站': 'Move to recycle bin',
        '点击 STT / Booking 查看详情和追踪；勾选后可批量核实或移入回收站': 'Click STT / Booking for details and tracking; selected rows can be batch verified or recycled',
        '物流状态': 'Shipment status',
        '类型': 'Type',
        '国家': 'Country',
        '城市': 'City',
        '地址信息': 'Address',
        '发货日期': 'Pickup date',
        '预计收货': 'ETA',
        '交付(工作日)': 'Delivery days',
        '实际交付': 'Actual delivery',
        '重量(kg)': 'Weight (kg)',
        '验收状态': 'Acceptance status',
        '验收金额': 'Accepted amount',
        '数据管理中心': 'Data Center',
        '物流数据': 'Logistics data',
        '库存数据': 'Inventory data',
        '发票数据': 'Invoice data',
        '数据校准&备份': 'Calibration & backup',
        '常用': 'Common',
        '非常用': 'Rare use',
        '谨慎操作': 'Caution',
        '选择文件': 'Choose file',
        '导入物流': 'Import logistics',
        '导入校准': 'Import calibration',
        '导入发票': 'Import invoice',
        '供应商库存刷新': 'Supplier inventory refresh',
        '图片管理': 'Image management',
        '上传图片': 'Upload images',
        '物流费用发票': 'Logistics invoice',
        '仓储操作费用发票': 'Warehouse operation invoice',
        '发票验收校准 Excel': 'Invoice calibration Excel',
        '恢复完整包': 'Restore full package',
        '导出全部仓库完整包': 'Export all-warehouse full package',
        '报告中心': 'Report Center',
        '生成 / 导出报告': 'Generate / export report',
        '系统设置': 'Settings',
        '版本信息': 'Version Info',
        '仓库库存': 'Warehouse inventory',
        '仓库': 'Warehouse',
        '库存': 'Inventory',
        '全部 SKU 库存明细': 'All SKU inventory details',
        '点击 Product No 查看详情 / 维护 SKU': 'Click Product No for details / SKU maintenance',
        '库存更新时间：-': 'Inventory updated: -',
        'Product No 详情': 'Product No Details',
        'BOM 编号': 'BOM Code',
        '图': 'Image',
        '一键导出库存清单': 'Export inventory list',
        '点击查看 Product No 明细': 'Click to view Product No details',
        '点击或双击查看大图': 'Click or double-click to view large image',
        '加载中...': 'Loading...',
        '上一页': 'Previous',
        '下一页': 'Next',
        '最近入库': 'Last inbound',
        '最近出库': 'Last outbound',
        '备注': 'Comment',
        '近期出入流水（按 DATA RUCHU）': 'Recent inbound/outbound records (by DATA RUCHU)',
        '入库': 'Inbound',
        '出库': 'Outbound',
        '订单类型': 'Order type',
        '对象/国家城市': 'Target / country or city',
        '数量': 'Qty',
        '暂无 Specyfikacja 流水': 'No Specyfikacja records',
        '暂无库存': 'No inventory',
        '维护 SKU': 'Maintain SKU',
        '单价': 'Unit price',
        '单击背景关闭': 'Click background to close',
        '取消': 'Cancel',
        '确认': 'Confirm',
        '导出': 'Export',
        '清除筛选': 'Clear filters',
        '中央仓发出': 'Central warehouse',
        '家具仓发出': 'Furniture warehouse',
        '调拨': 'Transfer',
        '已交付': 'Delivered',
        '运输中': 'In transit',
        '待核实': 'Pending check',
        '异常单': 'Exception',
        '已验收': 'Accepted',
        '待验收': 'Pending acceptance',
        '未关联': 'Unmatched',
        '已拒绝': 'Rejected'
    };
    function applyFallbackEnglish(root = document.body) {
        if (currentLang !== 'en' || !root) return;
        const shouldSkip = node => {
            const parent = node.parentElement;
            return !parent || ['SCRIPT', 'STYLE', 'TEXTAREA'].includes(parent.tagName);
        };
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                if (shouldSkip(node)) return NodeFilter.FILTER_REJECT;
                const trimmed = node.nodeValue.trim();
                return UI_EN_TEXT[trimmed] ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        nodes.forEach(node => {
            const raw = node.nodeValue;
            const leading = raw.match(/^\s*/)?.[0] || '';
            const trailing = raw.match(/\s*$/)?.[0] || '';
            node.nodeValue = leading + UI_EN_TEXT[raw.trim()] + trailing;
        });
        root.querySelectorAll?.('[title]').forEach(el => {
            const title = (el.getAttribute('title') || '').trim();
            if (UI_EN_TEXT[title]) el.setAttribute('title', UI_EN_TEXT[title]);
        });
    }

    function setLanguage(lang) {
        currentLang = lang === 'en' ? 'en' : 'zh';
        applyLanguage();
    }

    function applyLanguage() {
        document.documentElement.lang = currentLang === 'en' ? 'en' : 'zh-CN';
        document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
        document.querySelectorAll('[data-i18n-html]').forEach(el => { el.innerHTML = t(el.dataset.i18nHtml); });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
        document.querySelectorAll('.lang-btn[data-lang]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === currentLang);
        });
        document.title = t('appName');
        applyFallbackEnglish();
        updateClock();
        if (document.getElementById('page-logistics')?.classList.contains('active') && getAuthToken()) {
            loadDashboard();
        }
    }

    function setThemeMode(mode) {
        currentTheme = mode === 'light' ? 'light' : 'dark';
        localStorage.setItem(THEME_KEY, currentTheme);
        applyTheme();
    }

    function applyTheme() {
        document.documentElement.dataset.theme = currentTheme;
        document.querySelectorAll('[data-theme-option]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.themeOption === currentTheme);
        });
    }

    const SIDEBAR_COLLAPSE_KEY = 'vn60_sidebar_collapsed';
    function applySidebarCollapse(forceCollapsed = null) {
        const collapsed = forceCollapsed === null ? localStorage.getItem(SIDEBAR_COLLAPSE_KEY) === '1' : forceCollapsed === true;
        document.body.classList.toggle('sidebar-collapsed', collapsed);
        const btn = document.getElementById('sidebarToggleBtn');
        if (btn) {
            btn.textContent = collapsed ? '›' : '☰';
            btn.title = collapsed ? '展开导航' : '折叠导航';
            btn.setAttribute('aria-label', btn.title);
        }
    }
    function toggleSidebarCollapse() {
        const next = document.body.classList.contains('sidebar-collapsed') ? '0' : '1';
        localStorage.setItem(SIDEBAR_COLLAPSE_KEY, next);
        applySidebarCollapse();
        setTimeout(() => {
            if (document.getElementById('page-logistics')?.classList.contains('active')) {
                Object.values(charts || {}).forEach(chart => chart?.resize?.());
            }
        }, 180);
    }
    function expandSidebarOnEntry() {
        localStorage.setItem(SIDEBAR_COLLAPSE_KEY, '0');
        applySidebarCollapse(false);
    }

    function showToast(msg, type = 'error') {
        toast(msg, type === 'success' ? 'success' : type === 'error' ? 'error' : 'info');
    }

    function toast(msg, type = 'success') { const t = document.getElementById('toast'); t.textContent = msg; t.className = 'toast toast-' + type + ' show'; setTimeout(() => t.classList.remove('show'), 3000); }
    function openModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.style.display = '';
        el.classList.add('show');
        applyFallbackEnglish(el);
    }
    function closeModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('show');
        el.style.display = '';
    }
    function applyUnifiedUi(scope = document) {
        const root = scope && scope.querySelectorAll ? scope : document;
        root.querySelectorAll('div[style*="overflow-x:auto"], div[style*="overflow-x: auto"]').forEach(div => {
            if (div.querySelector(':scope > table')) div.classList.add('ui-table-scroll');
        });
        root.querySelectorAll('.table-section > table').forEach(table => {
            if (table.parentElement?.classList.contains('ui-table-scroll')) return;
            const wrap = document.createElement('div');
            wrap.className = 'ui-table-scroll';
            table.parentNode.insertBefore(wrap, table);
            wrap.appendChild(table);
        });
        root.querySelectorAll('.table-section, .chart-card, .stat-card, .settings-panel, .report-card, .import-section').forEach(el => {
            el.classList.add('ui-surface');
        });
    }
    function imageUrl(path) {
        if (!path) return '';
        const clean = String(path).replace(/^\/+/, '');
        return window.location.protocol === 'file:' ? 'images/' + clean : '/static/images/' + clean;
    }
    function isLocalBomCode(value) {
        const text = String(value || '').trim().toUpperCase();
        const compact = text.replace(/[\s/_-]+/g, '');
        return ['/', '／'].includes(text) || ['本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', 'NOBOM', 'NOBOMCODE'].includes(compact);
    }
    function displayBomCode(value) {
        const text = String(value || '').trim();
        return (!text || isLocalBomCode(text)) ? '/' : text;
    }
    function showImage(path, remark = '') {
        if (!path) return;
        hideImagePopover();
        const img = document.getElementById('imgModalSrc');
        img.classList.remove('zoomed');
        img.src = imageUrl(path);
        document.getElementById('imgModalHint').textContent = remark ? `备注：${remark}` : '单击背景关闭';
        document.getElementById('imgModal').classList.add('show');
    }
    document.addEventListener('click', (evt) => {
        const img = evt.target.closest('[data-detail-image]');
        if (!img) return;
        evt.preventDefault();
        evt.stopPropagation();
        if (evt.stopImmediatePropagation) evt.stopImmediatePropagation();
        showImage(img.dataset.imagePath || '', img.dataset.remark || '');
    }, true);
    function closeImageModal() { document.getElementById('imgModal').classList.remove('show'); document.getElementById('imgModalSrc').classList.remove('zoomed'); }
    function showImagePopover(evt, path, remark = '') {
        if (!path) return;
        const pop = document.getElementById('imagePopover');
        const img = document.getElementById('imagePopoverSrc');
        const remarkEl = document.getElementById('imagePopoverRemark');
        img.src = imageUrl(path);
        remarkEl.textContent = remark || '无备注';
        pop.classList.add('show');
        moveImagePopover(evt);
    }
    function moveImagePopover(evt) {
        const pop = document.getElementById('imagePopover');
        if (!pop.classList.contains('show')) return;
        const margin = 18;
        let left = evt.clientX + margin;
        let top = evt.clientY + margin;
        const rect = pop.getBoundingClientRect();
        if (left + rect.width > window.innerWidth - 12) left = evt.clientX - rect.width - margin;
        if (top + rect.height > window.innerHeight - 12) top = window.innerHeight - rect.height - 12;
        pop.style.left = Math.max(12, left) + 'px';
        pop.style.top = Math.max(12, top) + 'px';
    }
    function hideImagePopover() {
        const pop = document.getElementById('imagePopover');
        if (pop) pop.classList.remove('show');
    }
    function bindStockImagePreviewEvents() {
        const containers = [
            document.getElementById('stockTableBody'),
            document.getElementById('invDashContent')
        ].filter(Boolean);
        containers.forEach(container => {
            if (container.dataset.previewBound === '1') return;
            container.dataset.previewBound = '1';
            container.addEventListener('mouseover', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                showImagePopover(evt, img.dataset.imagePath, img.dataset.remark || '');
            });
            container.addEventListener('mousemove', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                moveImagePopover(evt);
            });
            container.addEventListener('mouseout', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                const next = evt.relatedTarget;
                if (next && img.contains(next)) return;
                hideImagePopover();
            });
            container.addEventListener('click', (evt) => {
                const productTarget = evt.target.closest('[data-product-detail]');
                if (productTarget && container.contains(productTarget)) {
                    evt.preventDefault();
                    evt.stopPropagation();
                    openProductDetail(productTarget.dataset.productDetail || '');
                    return;
                }
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                evt.preventDefault();
                showImage(img.dataset.imagePath, img.dataset.remark || '');
            });
            container.addEventListener('dblclick', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                evt.preventDefault();
                showImage(img.dataset.imagePath, img.dataset.remark || '');
            });
        });
    }

    function bindStockListImagePreviewEvents() {
        const tbody = document.getElementById('stockTableBody');
        if (!tbody || tbody.dataset.stockListPreviewBound === '1') return;
        tbody.dataset.stockListPreviewBound = '1';
        tbody.addEventListener('mouseover', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            showImagePopover(evt, img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('mousemove', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            moveImagePopover(evt);
        });
        tbody.addEventListener('mouseout', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            const next = evt.relatedTarget;
            if (next && img.contains(next)) return;
            hideImagePopover();
        });
        tbody.addEventListener('click', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            evt.preventDefault();
            showImage(img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('dblclick', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            evt.preventDefault();
            showImage(img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('click', (evt) => {
            const target = evt.target.closest('[data-product-detail]');
            if (!target || !tbody.contains(target)) return;
            const productNumber = target.dataset.productDetail || '';
            evt.preventDefault();
            evt.stopPropagation();
            openProductDetail(productNumber);
        });
    }
    document.addEventListener('click', (evt) => {
        const target = evt.target.closest('[data-product-detail]');
        if (!target) return;
        if (target.closest('#stockTableBody') || target.closest('#invDashContent')) return;
        const productNumber = target.dataset.productDetail || '';
        if (!productNumber) return;
        evt.preventDefault();
        openProductDetail(productNumber);
    });
    function fmt$(v) { return v != null ? '$' + Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '$0'; }
    function fmtPct(v, total) { return total > 0 ? (v / total * 100).toFixed(1) + '%' : '-'; }

    // ===== 时钟 =====
    function updateClock() {
        const now = new Date();
        const opts = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZoneName: 'short' };
        document.getElementById('clock').textContent = now.toLocaleString(currentLang === 'en' ? 'en-GB' : 'zh-CN', opts);
    }
    setInterval(updateClock, 1000);
    document.addEventListener('DOMContentLoaded', () => { applyTheme(); applyLanguage(); expandSidebarOnEntry(); });

    // ===== 页面切换 =====
    function switchPage(page, filters) {
        const legacyPageAliases = {
            invoice: 'import',
            uploadlist: 'import',
            uploadimages: 'import',
            costlist: 'acceptance-list',
            reports: 'logistics',
            orders: 'versioninfo',
            settings: 'versioninfo'
        };
        if (legacyPageAliases[page]) {
            const sourcePage = page;
            const targetPage = legacyPageAliases[page];
            switchPage(targetPage, filters);
            if (sourcePage === 'reports') {
                setTimeout(() => openReportOptionsModal(), 0);
            }
            return;
        }
        document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const pageEl = document.getElementById('page-' + page);
        if (!pageEl) {
            switchPage('logistics');
            return;
        }
        pageEl.classList.add('active');
        const navItem = document.querySelector(`.nav-item[data-page="${page}"]`);
        if (navItem) navItem.classList.add('active');
        const mobileSelect = document.getElementById('mobilePageSelect');
        if (mobileSelect && Array.from(mobileSelect.options).some(opt => opt.value === page)) {
            mobileSelect.value = page;
        }
        if (page === 'logistics') loadDashboard();
        if (page === 'shipments') {
            if (filters) {
                currentFilterDs = filters.ds || '';
                currentFilterType = filters.type || '';
                currentFilterCountry = filters.country || '';
                currentFilterWarehouse = filters.warehouse || '';
                currentFilterMonth = filters.month || '';
                currentFilterPickupMonth = filters.pickup_month || filters.month || '';
                currentFilterActualDeliveryMonth = filters.actual_delivery_month || '';
                shipmentSortBy = filters.sort_by || '';
                shipmentSortDir = filters.sort_dir || 'desc';
                currentPage = 1;
            }
            loadShipments();
            updateShipmentFiltersUI();
        }
        if (page === 'inventory') loadInvDashboard();
        if (page === 'stocklist') {
            loadStockFilters().then(() => {
                applyPendingStockListFilters();
                loadStockList();
            });
        }
        if (page === 'import') { assembleImportCenter(); loadInvoicePage(); loadUploadRecords(); }
        if (page === 'budget') { loadBudgetPage(); }
        if (page === 'movements') { loadMovementList(); }
        if (page === 'acceptance-list') { loadAcceptanceList(); }
        if (page === 'operations') { switchOpsTab(document.querySelector('#opsTabs .tab[data-otab="adjust"]')); }
        if (page === 'orders') loadOrders();
        if (page === 'settings') initSettings();
        if (page === 'versioninfo') loadVersionChangelog();
        setTimeout(() => applyUnifiedUi(document.getElementById('page-' + page) || document), 0);
    }

    function assembleImportCenter() {
        const commonGrid = document.getElementById('commonDataGrid');
        const backupGrid = document.getElementById('backupRestoreGrid');
        const moveCard = (card, target) => {
            if (card && target && card.parentElement !== target) target.appendChild(card);
        };
        const setCardOrder = (card, order) => {
            if (card) card.style.order = String(order);
        };
        const inventoryMount = document.getElementById('import-section-inventory');
        const inventoryPage = document.getElementById('page-uploadlist');
        const commonBlock = document.querySelector('#page-import .maintenance-common');
        if (inventoryMount && inventoryPage && !inventoryMount.dataset.mounted) {
            const inventoryGrid = inventoryPage.querySelector('.import-grid');
            const importReport = inventoryPage.querySelector('#supplierImportReport');
            const dangerZone = inventoryPage.querySelector('.danger-zone');
            if (inventoryGrid) inventoryMount.appendChild(inventoryGrid);
            if (importReport && commonBlock) commonBlock.appendChild(importReport);
            if (dangerZone) inventoryMount.appendChild(dangerZone);
            inventoryMount.dataset.mounted = '1';
        }
        moveCard(document.getElementById('import-logistics_auto'), commonGrid);
        moveCard(document.getElementById('supplierInventoryFile')?.closest('.import-section'), commonGrid);
        moveCard(document.getElementById('specyfikacjaFile')?.closest('.import-section'), commonGrid);
        moveCard(document.getElementById('import-logistics-invoice'), commonGrid);
        moveCard(document.getElementById('imageFileInput')?.closest('.import-section'), commonGrid);
        setCardOrder(document.getElementById('import-logistics_auto'), 1);
        setCardOrder(document.getElementById('supplierInventoryFile')?.closest('.import-section'), 2);
        setCardOrder(document.getElementById('specyfikacjaFile')?.closest('.import-section'), 3);
        setCardOrder(document.getElementById('import-logistics-invoice'), 4);
        setCardOrder(document.getElementById('imageFileInput')?.closest('.import-section'), 5);
        moveCard(document.getElementById('fullPackageExportCard'), backupGrid);
        moveCard(document.getElementById('coreBackupImportCard'), backupGrid);
    }

    function focusImportCard(cardId) {
        const card = document.getElementById(cardId);
        if (!card) return;
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        card.classList.add('focus-pulse');
        setTimeout(() => card.classList.remove('focus-pulse'), 1600);
    }

    function openInvoiceDataManagement() {
        switchPage('import');
        setTimeout(() => {
            assembleImportCenter();
            focusImportCard('import-logistics-invoice');
        }, 80);
    }

    function openBackupRestoreManagement() {
        switchPage('import');
        setTimeout(() => {
            assembleImportCenter();
            focusImportCard('coreBackupImportCard');
        }, 80);
    }

    function formatFileSize(bytes) {
        const n = Number(bytes || 0);
        if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
        if (n >= 1024) return (n / 1024).toFixed(1) + ' KB';
        return n + ' B';
    }

    function uploadTypeLabel(types) {
        const set = new Set(types || []);
        const labels = [];
        if (set.has('logistics')) labels.push('物流源文件');
        if (set.has('invoice')) labels.push('发票源文件');
        if (!labels.length && set.has('file')) labels.push('其他源文件');
        return labels.join(' / ') || '-';
    }

    let uploadRecordSortBy = 'modified_at';
    let uploadRecordSortDir = 'desc';

    function setUploadRecordSort(field) {
        if (uploadRecordSortBy === field) {
            uploadRecordSortDir = uploadRecordSortDir === 'asc' ? 'desc' : 'asc';
        } else {
            uploadRecordSortBy = field;
            uploadRecordSortDir = field === 'filename' || field === 'type' ? 'asc' : 'desc';
        }
        loadUploadRecords();
    }

    function clearUploadRecordFilters() {
        const typeFilter = document.getElementById('uploadRecordTypeFilter');
        if (typeFilter) typeFilter.value = '';
        uploadRecordSortBy = 'modified_at';
        uploadRecordSortDir = 'desc';
        loadUploadRecords();
    }

    function uploadRecordSortValue(file, field) {
        if (field === 'type') return uploadTypeLabel(file.types).toUpperCase();
        if (field === 'size') return Number(file.size || 0);
        if (field === 'shipment_records') return Number(file.shipment_records || 0);
        if (field === 'invoice_records') return Number(file.invoice_records || 0);
        if (field === 'modified_at') return file.modified_at || '';
        return String(file.filename || '').toUpperCase();
    }

    function updateUploadRecordSortHeaders() {
        document.querySelectorAll('[data-upload-sort]').forEach(th => {
            const active = th.dataset.uploadSort === uploadRecordSortBy;
            th.classList.toggle('active', active);
            const base = th.textContent.replace(/\s*[↑↓]$/, '');
            th.textContent = active ? `${base} ${uploadRecordSortDir === 'asc' ? '↑' : '↓'}` : base;
        });
    }

    async function loadUploadRecords() {
        const body = document.getElementById('uploadRecordsBody');
        if (!body) return;
        body.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        const data = await apiGet('/api/uploads').catch(e => ({ error: e.message }));
        if (data.error) {
            body.innerHTML = `<tr><td colspan="8" style="text-align:center;color:var(--danger);padding:24px">${escapeHtml(data.error)}</td></tr>`;
            return;
        }
        const typeFilter = document.getElementById('uploadRecordTypeFilter')?.value || '';
        const files = (data.files || [])
            .filter(f => {
                const types = new Set(f.types || []);
                if (!typeFilter) return true;
                if (typeFilter === 'unlinked') return types.has('file') && !types.has('logistics') && !types.has('invoice');
                return types.has(typeFilter);
            })
            .sort((a, b) => {
                const av = uploadRecordSortValue(a, uploadRecordSortBy);
                const bv = uploadRecordSortValue(b, uploadRecordSortBy);
                const result = typeof av === 'number' && typeof bv === 'number'
                    ? av - bv
                    : String(av).localeCompare(String(bv), 'zh-Hans-CN', { numeric: true, sensitivity: 'base' });
                return uploadRecordSortDir === 'asc' ? result : -result;
            });
        updateUploadRecordSortHeaders();
        body.innerHTML = files.length ? files.map(f => `
            <tr>
                <td style="font-weight:500;max-width:360px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${escapeHtml(f.filename)}">${escapeHtml(f.filename)}</td>
                <td>${escapeHtml(uploadTypeLabel(f.types))}</td>
                <td style="text-align:right">${f.exists ? formatFileSize(f.size) : '-'}</td>
                <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(f.modified_at || '-')}</td>
                <td style="text-align:right">${f.shipment_records || 0}</td>
                <td style="text-align:right">${f.invoice_records || 0}</td>
                <td>${f.exists ? '<span class="badge badge-delivered">源文件存在</span>' : '<span class="badge badge-pending">源文件已清理</span>'}</td>
                <td>${f.exists ? `<button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="deleteUploadedFile(${jsArg(f.filename)})">删除源文件</button>` : '-'}</td>
            </tr>
        `).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">暂无源文件记录</td></tr>';
    }

    async function deleteUploadedFile(filename) {
        const password = askMaintenancePassword(`请输入删除密码，确认删除源文件：\\n${filename}\\n\\n此操作只释放文件体积，不撤销已导入的物流、发票或库存数据。`);
        if (password == null) return;
        const data = await apiFetch(API + '/api/uploads/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename, password })
        }).catch(e => ({ error: e.message }));
        if (data.success) {
            toast('源文件已删除，业务数据未撤销');
            loadUploadRecords();
        } else {
            toast(data.error || '删除失败', 'error');
        }
    }

    function switchImportCenterSection(el) {
        document.querySelectorAll('#importCenterTabs .tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
        const section = el.dataset.importSection;
        document.querySelectorAll('.import-center-section').forEach(panel => {
            panel.style.display = panel.id === 'import-section-' + section ? 'block' : 'none';
        });
        if (section === 'invoice') loadInvoicePage();
        loadUploadRecords();
    }

    // ===== 下钻：从看板跳转到物流清单 =====
    function selectedLogisticsMonth() {
        return document.getElementById('map-month-filter')?.value || '';
    }
    function drillDown(ds, title) {
        const month = selectedLogisticsMonth();
        document.getElementById('shipments-title').textContent = title || ds;
        switchPage('shipments', { ds: ds || '', month });
    }
    function drillDownType(type, title) {
        const month = selectedLogisticsMonth();
        document.getElementById('shipments-title').textContent = title || type;
        switchPage('shipments', { type: type || '', month });
    }
    function drillDownCountry(country) {
        const month = selectedLogisticsMonth();
        country = String(country || '').trim().toUpperCase();
        document.getElementById('shipments-title').textContent = month ? `${tf('shipToCountry', { country })} · ${month}` : tf('shipToCountry', { country });
        switchPage('shipments', { country: country, month });
    }
    function drillDownWarehouse(warehouse) {
        document.getElementById('shipments-title').textContent = tf('warehouseOutbound', { warehouse });
        switchPage('shipments', { warehouse: warehouse });
    }

    // ===== 物流看板 =====
    async function loadDashboard() {
        await Promise.all([
            loadSummary(),
            loadStatusChart(),
            loadTypeChart(),
            loadCountryChart(),
            loadMonthlyChart()
        ]).catch(e => console.error('Dashboard load error:', e));
    }

    let reportHeaderIconUrl = '';

    async function loadReportHeaderIcon() {
        const d = await apiFetch(API + '/api/reports/header-icon').catch(() => ({ url: '' }));
        reportHeaderIconUrl = d.url || '';
        const box = document.getElementById('reportLogoPreview');
        if (!box) return;
        box.innerHTML = reportHeaderIconUrl
            ? `<img src="${escapeHtml(reportHeaderIconUrl)}?v=${Date.now()}" alt="Report icon"><span>本地 Icon 已上传</span>`
            : '<span>未上传，使用文字抬头</span>';
    }

    async function loadReportMonths() {
        const select = document.getElementById('reportMonth');
        if (!select) return;
        const rows = await apiFetch(API + '/api/dashboard/monthly_trend').catch(() => []);
        const months = (rows || []).map(r => r.month).filter(Boolean).sort().reverse();
        select.innerHTML = months.length
            ? months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('')
            : '<option value="">暂无月份</option>';
    }

    async function uploadReportHeaderIcon(input) {
        const file = input.files && input.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append('file', file);
        const d = await apiFetch(API + '/api/reports/header-icon', { method: 'POST', body: fd }).catch(e => ({ error: e.message }));
        input.value = '';
        if (!d.success) return toast(d.error || '上传失败', 'error');
        reportHeaderIconUrl = d.url || '';
        await loadReportHeaderIcon();
        toast('报告抬头 Icon 已更新');
    }

    function reportFmtMoney(value) {
        return '$' + Number(value || 0).toLocaleString('en-US', { maximumFractionDigits: 0 });
    }

    function reportFmtNumber(value) {
        return Number(value || 0).toLocaleString();
    }

    function reportMonthLabel(month) {
        const m = String(month || '').trim();
        if (m === 'annual') return `${new Date().getFullYear()}全年`;
        const yearHit = m.match(/^year:(\d{4})$/);
        if (yearHit) return `${yearHit[1]}全年`;
        const hit = m.match(/^(\d{4})-(\d{2})$/);
        if (!hit) return m || '未选择月份';
        return `${hit[1]}年${Number(hit[2])}月`;
    }

    function updateReportTypeDescription() {
        const type = document.getElementById('reportModalType')?.value || 'monthly_ops';
        const descriptions = {
            monthly_ops: '月度经营总报告：汇总物流履约、库存健康、费用验收和关键风险，适合发给管理层做月度总览。',
            monthly_logistics: '月度物流报告：聚焦运单状态、运输类型、需求国家、代表处、重量体积和物流费用。',
            monthly_inventory: '月度库存报告：聚焦库存货值、PCS、物料品类、适用产品、归属国家和库存健康。',
            inventory_list: '库存清单：导出当前筛选范围内的 SKU 明细，适合盘点、核对和共享给业务同事。',
            monthly_acceptance: '月度验收报告：聚焦发票验收、匹配率、已验收金额、待验收金额和异常费用。',
            monthly_overdue: '月度超期物料报告：聚焦 DOS 超期和长期未使用物料，适合做月度清理跟进。',
            data_quality: '数据质量检查：检查缺图片、缺价格、缺分类、缺时间等问题，适合正式发报告前自检。'
        };
        const el = document.getElementById('reportTypeDescription');
        if (el) el.textContent = descriptions[type] || descriptions.monthly_ops;
        const monthGroup = document.getElementById('reportMonthGroup') || document.getElementById('reportModalMonth')?.closest('.form-group');
        const inventoryFilters = document.getElementById('reportInventoryFilters');
        const outputEl = document.getElementById('reportModalOutput');
        const submitBtn = document.getElementById('reportModalSubmitBtn');
        if (monthGroup) monthGroup.style.display = type === 'inventory_list' ? 'none' : '';
        if (inventoryFilters) inventoryFilters.style.display = type === 'inventory_list' ? 'block' : 'none';
        if (outputEl) {
            const current = outputEl.value;
            if (type === 'inventory_list') {
                outputEl.innerHTML = '<option value="pdf">PDF（默认，报告展示）</option><option value="excel">Excel（全量清单，不嵌入图片）</option><option value="excel_images">Excel（带图片展示，不建议回传）</option><option value="html">HTML（邮件/网页展示）</option><option value="png">长图 PNG</option>';
                outputEl.value = ['pdf', 'excel', 'excel_images', 'html', 'png'].includes(current) ? current : 'pdf';
            } else {
                outputEl.innerHTML = '<option value="preview">生成预览</option><option value="pdf">PDF</option><option value="html">HTML</option><option value="png">长图 PNG</option>';
                outputEl.value = ['preview', 'pdf', 'html', 'png'].includes(current) ? current : 'preview';
            }
        }
        if (submitBtn && outputEl) {
            submitBtn.textContent = outputEl.value === 'preview' ? '生成预览' : '导出';
        }
    }

    function openReportOptionsModal(type = '') {
        const typeEl = document.getElementById('reportModalType');
        const whEl = document.getElementById('reportModalWarehouse');
        const monthEl = document.getElementById('reportModalMonth');
        if (typeEl) typeEl.value = type || document.getElementById('reportType')?.value || 'monthly_ops';
        if (whEl) whEl.value = document.getElementById('reportWarehouse')?.value || '';
        if (monthEl) {
            const reportMonth = document.getElementById('reportMonth');
            const current = reportMonth?.value || new Date().toISOString().slice(0, 7);
            const monthValues = Array.from(reportMonth?.options || []).map(o => o.value).filter(Boolean);
            const years = [...new Set(monthValues.map(v => String(v).slice(0, 4)).filter(y => /^\d{4}$/.test(y)))].sort().reverse();
            const yearOptions = years.map(y => `<option value="year:${escapeHtml(y)}">${escapeHtml(y)}全年</option>`).join('');
            const monthOptions = Array.from(reportMonth?.options || [])
                .filter(o => o.value && o.value !== current)
                .map(o => `<option value="${escapeHtml(o.value)}">${escapeHtml(o.textContent || o.value)}</option>`)
                .join('');
            monthEl.innerHTML = `<option value="${escapeHtml(current)}">当月（${escapeHtml(reportMonthLabel(current))}）</option>${yearOptions}${monthOptions}`;
            monthEl.value = current;
        }
        fillSelectFromOptions('reportInventoryCategory', 'filterCategory', '全部物料品类');
        fillCheckMultiFromOptions('reportInventoryCategory2', 'filterCat2');
        fillSelectFromOptions('reportInventoryInstruction', 'filterInstruction', '全部归属国家');
        updateReportTypeDescription();
        openModal('reportOptionsModal');
    }

    async function runReportFromModal() {
        const type = document.getElementById('reportModalType')?.value || 'monthly_ops';
        const warehouse = document.getElementById('reportModalWarehouse')?.value || '';
        const month = document.getElementById('reportModalMonth')?.value || '';
        const output = document.getElementById('reportModalOutput')?.value || 'preview';
        if (type === 'inventory_list') {
            const filters = {
                warehouse,
                category: document.getElementById('reportInventoryCategory')?.value || '',
                category2: multiCheckValue('reportInventoryCategory2'),
                category2Label: multiCheckLabel('reportInventoryCategory2', '全部适用产品'),
                instruction: document.getElementById('reportInventoryInstruction')?.value || ''
            };
            closeModal('reportOptionsModal');
            if (output === 'excel' || output === 'excel_images') {
                await downloadInventoryExcel(filters, output);
                return;
            }
            await exportAllStockListPdf(filters, output === 'pdf');
            if (output === 'html') setTimeout(exportReportHtml, 450);
            if (output === 'png') setTimeout(exportReportPng, 450);
            return;
        }
        const effectiveType = type === 'inventory_list' || type === 'data_quality' ? 'monthly_inventory' : type;
        if (document.getElementById('reportType')) document.getElementById('reportType').value = effectiveType;
        if (document.getElementById('reportWarehouse')) document.getElementById('reportWarehouse').value = warehouse;
        const hiddenMonthEl = document.getElementById('reportMonth');
        if (hiddenMonthEl) {
            if ((month === 'annual' || /^year:\d{4}$/.test(month)) && !Array.from(hiddenMonthEl.options).some(o => o.value === month)) {
                hiddenMonthEl.insertAdjacentHTML('afterbegin', `<option value="${escapeHtml(month)}">${escapeHtml(reportMonthLabel(month))}</option>`);
            }
            hiddenMonthEl.value = month;
        }
        closeModal('reportOptionsModal');
        await generateReportPreview();
        if (output === 'pdf') setTimeout(printReportPdf, 350);
        if (output === 'html') setTimeout(exportReportHtml, 350);
        if (output === 'png') setTimeout(exportReportPng, 350);
    }

    function reportBarRows(rows, labelFn, valueFn, color = '#3b82f6', suffix = '') {
        const max = Math.max(...rows.map(r => Number(valueFn(r) || 0)), 1);
        return `<div class="report-bars">${rows.map(r => {
            const value = Number(valueFn(r) || 0);
            const pct = Math.max(2, Math.round(value / max * 100));
            return `<div class="report-bar-row">
                <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(labelFn(r))}">${escapeHtml(labelFn(r))}</div>
                <div class="report-bar-track"><div class="report-bar-fill" style="width:${pct}%;background:${color}"></div></div>
                <div style="text-align:right;font-weight:700">${reportFmtNumber(value)}${suffix}</div>
            </div>`;
        }).join('')}</div>`;
    }

    function reportTopRows(rows, kind) {
        const dayLabel = kind === 'idle' ? '未使用天数' : '库龄';
        const empty = `<tr><td colspan="6" style="text-align:center;color:#94a3b8">暂无数据</td></tr>`;
        return (rows || []).slice(0, 8).map(r => `<tr>
            <td>${escapeHtml(r.warehouse || '')}</td>
            <td>${escapeHtml(r.bom_code || '')}</td>
            <td>${escapeHtml(r.product_number || '')}</td>
            <td>${escapeHtml(r.product_description || '')}</td>
            <td style="text-align:right">${reportFmtNumber(r.inventory || 0)}</td>
            <td style="text-align:right">${reportFmtNumber(kind === 'idle' ? r.idle_days : r.dos)} 天</td>
        </tr>`).join('') || empty;
    }

    function reportInventoryTopCards(rows, kind) {
        const top = [...(rows || [])]
            .sort((a, b) => Number(b.ttl_amount || 0) - Number(a.ttl_amount || 0) || Number(b.overdue_days || 0) - Number(a.overdue_days || 0))
            .slice(0, 5);
        if (!top.length) return '<div style="color:#94a3b8;font-size:12px;padding:18px 0">暂无需要提醒的物料</div>';
        const dayField = kind === 'idle' ? 'idle_days' : 'dos';
        const dayLabel = kind === 'idle' ? '未使用' : '库龄';
        return `<div class="report-inventory-top-list">${top.map(r => {
            const img = r.image_path
                ? `<img class="report-inventory-top-thumb" src="${escapeHtml(imageUrl(r.image_path))}" alt="">`
                : '<div class="report-inventory-top-noimg">无图</div>';
            return `<div class="report-inventory-top-item">
                ${img}
                <div>
                    <div class="report-inventory-top-title">${escapeHtml(r.product_number || r.bom_code || '-')}</div>
                    <div class="report-inventory-top-desc">${escapeHtml(r.product_description || '无描述')}</div>
                    <div class="report-inventory-top-meta">${escapeHtml(r.warehouse || '-')} · BOM ${escapeHtml(displayBomCode(r.bom_code || '-'))} · ${escapeHtml(r.category || '-')}</div>
                </div>
                <div class="report-inventory-top-metric"><b>${r.unit_price != null ? '$' + Number(r.unit_price || 0).toFixed(2) : '-'}</b>单价</div>
                <div class="report-inventory-top-metric"><b>${reportFmtMoney(r.ttl_amount)}</b>货值</div>
                <div class="report-inventory-top-metric"><b>${reportFmtNumber(r.inventory)}</b>PCS</div>
                <div class="report-inventory-top-metric warn"><b>${reportFmtNumber(r[dayField])}</b>${dayLabel}天</div>
            </div>`;
        }).join('')}</div>`;
    }

    function buildReportLogisticsBreakdown(shipments) {
        const officeMap = new Map();
        const countryMap = new Map();
        shipments.forEach(s => {
            const country = demandCountryOfShipment(s) || 'N/A';
            const office = countryOfficeOf(country);
            const add = (map, key, base) => {
                const row = map.get(key) || { ...base, count: 0, weight: 0, volume: 0, price: 0 };
                row.count += 1;
                row.weight += Number(s.total_weight || 0);
                row.volume += Number(s.total_volume || 0);
                row.price += Number(s.price_without_vat || 0);
                map.set(key, row);
            };
            add(officeMap, office.key, { office: office.label, officeOrder: office.order || 99 });
            add(countryMap, country, {
                office: office.label,
                officeOrder: office.order || 99,
                country,
                countryName: ISO2_TO_NAME[country] || country
            });
        });
        const byVolume = (a, b) => (a.officeOrder - b.officeOrder) || (b.count - a.count) || String(a.countryName || a.office).localeCompare(String(b.countryName || b.office), 'zh-Hans-CN');
        return {
            offices: [...officeMap.values()].sort((a, b) => (a.officeOrder - b.officeOrder) || (b.count - a.count)),
            countries: [...countryMap.values()].sort(byVolume)
        };
    }

    function reportLogisticsRows(rows, totalOrders, showOffice = true) {
        const emptyCols = showOffice ? 7 : 6;
        if (!rows.length) return `<tr><td colspan="${emptyCols}" style="text-align:center;color:#94a3b8">暂无当月物流数据</td></tr>`;
        return rows.map(r => `<tr>
            ${showOffice ? `<td>${escapeHtml(r.office || '')}</td>` : ''}
            <td>${escapeHtml(r.countryName || r.office || '')}</td>
            <td style="text-align:right">${reportFmtNumber(r.count)}</td>
            <td style="text-align:right">${totalOrders ? (r.count / totalOrders * 100).toFixed(1) : '0.0'}%</td>
            <td style="text-align:right">${Number(r.weight || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })}</td>
            <td style="text-align:right">${Number(r.volume || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
            <td style="text-align:right">${reportFmtMoney(r.price)}</td>
        </tr>`).join('');
    }

    function reportTopCountryCards(rows, totalOrders) {
        const top = [...(rows || [])].sort((a, b) => Number(b.count || 0) - Number(a.count || 0)).slice(0, 3);
        if (!top.length) return '<div style="color:#94a3b8;font-size:12px;margin-top:10px">暂无当月国家要货数据</div>';
        return `<div class="report-top-country-list">${top.map((r, idx) => `
            <div class="report-top-country">
                <span class="rank">${idx + 1}</span>
                <div>
                    <div class="name">${escapeHtml(r.countryName || r.country || '')}</div>
                    <div class="meta">${escapeHtml(r.office || '')}</div>
                </div>
                <div class="value">${reportFmtNumber(r.count)}单<br><span class="meta">${totalOrders ? (r.count / totalOrders * 100).toFixed(1) : '0.0'}%</span></div>
            </div>
        `).join('')}</div>`;
    }

    function reportEuropeMapSvg(countryRows, geoData) {
        if (!geoData || !geoData.features || !countryRows.length) return '<div style="color:#94a3b8;font-size:12px;margin-top:12px">暂无地图数据</div>';
        const byIso3 = new Map(countryRows.map(r => [ISO2_TO_3[r.country], r]).filter(([iso3]) => iso3));
        const values = [...byIso3.values()].map(r => Number(r.count || 0));
        const max = Math.max(...values, 1);
        const width = 390, height = 245;
        const bounds = { minLon: -15, maxLon: 45, minLat: 34, maxLat: 72 };
        const project = ([lon, lat]) => {
            const x = (lon - bounds.minLon) / (bounds.maxLon - bounds.minLon) * width;
            const y = (bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat) * height;
            return [x, y];
        };
        const ringPath = ring => ring.map((pt, idx) => {
            const [x, y] = project(pt);
            return `${idx ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(' ') + ' Z';
        const featurePath = feature => {
            const geo = feature.geometry || {};
            if (geo.type === 'Polygon') return geo.coordinates.map(ringPath).join(' ');
            if (geo.type === 'MultiPolygon') return geo.coordinates.flatMap(poly => poly.map(ringPath)).join(' ');
            return '';
        };
        const colorFor = count => {
            if (!count) return '#e5e7eb';
            const ratio = Math.max(0.12, Number(count || 0) / max);
            const hue = 205 - ratio * 140;
            return `hsl(${hue},72%,${62 - ratio * 24}%)`;
        };
        const paths = geoData.features.filter(f => EUROPE_IDS.has(f.id)).map(f => {
            const row = byIso3.get(f.id);
            return `<path d="${featurePath(f)}" fill="${colorFor(row?.count || 0)}" stroke="#ffffff" stroke-width="0.8"><title>${escapeHtml(row ? `${row.countryName}: ${row.count} orders` : (f.properties?.name || f.id))}</title></path>`;
        }).join('');
        const top = [...countryRows].sort((a, b) => b.count - a.count).slice(0, 5);
        const legend = top.map(r => `<div style="display:flex;justify-content:space-between;gap:8px;font-size:10px;color:#334155"><span>${escapeHtml(r.countryName)}</span><b>${reportFmtNumber(r.count)}</b></div>`).join('');
        return `<div style="margin-top:14px;border:1px solid #e2e8f0;border-radius:8px;padding:10px;background:#f8fafc">
            <svg viewBox="0 0 ${width} ${height}" width="100%" height="245" role="img" aria-label="各国订单信息一览地图">${paths}</svg>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:start;margin-top:8px">
                <div style="font-size:10px;color:#64748b;line-height:1.5">颜色越深表示当月订单数越高，口径与右侧国家明细一致。</div>
                <div style="display:grid;gap:4px">${legend}</div>
            </div>
        </div>`;
    }

    function reportMonthlyTrendBlock(rows) {
        const data = (rows || []).slice(-6);
        if (!data.length) return '<div style="color:#94a3b8;font-size:12px">暂无月度趋势数据</div>';
        const max = Math.max(...data.map(r => Number(r.count || 0)), 1);
        const bars = data.map(r => {
            const h = Math.max(8, Number(r.count || 0) / max * 92);
            return `<div style="display:flex;flex-direction:column;align-items:center;gap:5px;justify-content:flex-end;height:132px">
                <div style="font-size:10px;color:#334155;font-weight:700">${reportFmtNumber(r.count)}</div>
                <div style="width:24px;height:${h.toFixed(0)}px;background:#3b82f6;border-radius:5px 5px 0 0"></div>
                <div style="font-size:10px;color:#64748b;white-space:nowrap">${escapeHtml(r.month || '')}</div>
            </div>`;
        }).join('');
        const table = data.map(r => `<tr>
            <td>${escapeHtml(r.month || '')}</td>
            <td style="text-align:right">${reportFmtNumber(r.count)}</td>
            <td style="text-align:right">${Number(r.weight || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })}</td>
            <td style="text-align:right">${Number(r.volume || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
            <td style="text-align:right">${reportFmtMoney(r.price)}</td>
        </tr>`).join('');
        return `<div style="display:grid;grid-template-columns:1fr 1.25fr;gap:16px;align-items:end">
            <div style="display:flex;gap:14px;align-items:flex-end;justify-content:space-around;border:1px solid #e2e8f0;border-radius:8px;background:#f8fafc;padding:10px 8px">${bars}</div>
            <table class="report-table"><thead><tr><th>月份</th><th style="text-align:right">订单数</th><th style="text-align:right">重量 kg</th><th style="text-align:right">体积 m³</th><th style="text-align:right">费用</th></tr></thead><tbody>${table}</tbody></table>
        </div>`;
    }

    let reportEuropeMap = null;
    let reportGeoJsonLayer = null;
    let reportCountryLabelLayer = null;

    function buildDashboardCountryRows(shipments) {
        const countryMap = {};
        (shipments || []).forEach(s => {
            const country = demandCountryOfShipment(s);
            if (!country) return;
            if (!countryMap[country]) countryMap[country] = { country, count: 0, weight: 0, price: 0, delivery_days: [] };
            countryMap[country].count += 1;
            countryMap[country].weight += Number(s.total_weight || 0);
            countryMap[country].price += Number(s.price_without_vat || 0);
            if (s.actual_delivery_date && s.pickup_date) {
                const days = calcWorkdays(s.pickup_date.split(' ')[0], s.actual_delivery_date.split(' ')[0]);
                if (days !== '-') countryMap[country].delivery_days.push(Number(days));
            }
        });
        return Object.values(countryMap).map(d => {
            const avg = d.delivery_days.length ? d.delivery_days.reduce((s, v) => s + v, 0) / d.delivery_days.length : null;
            return {
                country: d.country,
                count: d.count,
                weight: d.weight,
                price: d.price,
                avg_delivery_days: avg == null ? null : Math.round(avg * 10) / 10
            };
        }).sort((a, b) => String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN'));
    }

    function renderReportCountryMap(shipments, geoData) {
        const mapEl = document.getElementById('report-europe-map');
        if (!mapEl || !window.L) return;
        mapEl.innerHTML = '';
        const filtered = buildDashboardCountryRows(shipments);
        const totalCount = filtered.reduce((s, d) => s + d.count, 0);
        const maxCount = Math.max(...filtered.map(d => d.count), 1);
        const dataByISO3 = {};
        const nameByISO3 = {};
        filtered.forEach(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (iso3) {
                const existing = dataByISO3[iso3];
                if (existing) {
                    const prevCount = Number(existing.count || 0);
                    const nextCount = Number(d.count || 0);
                    const mergedCount = prevCount + nextCount;
                    existing.count = mergedCount;
                    existing.weight = Number(existing.weight || 0) + Number(d.weight || 0);
                    existing.price = Number(existing.price || 0) + Number(d.price || 0);
                    existing.avg_delivery_days = mergedCount
                        ? (((existing.avg_delivery_days || 0) * prevCount) + ((d.avg_delivery_days || 0) * nextCount)) / mergedCount
                        : null;
                    if (nextCount > prevCount) existing.clickCountry = d.country;
                } else {
                    dataByISO3[iso3] = { ...d, clickCountry: d.country };
                }
                nameByISO3[iso3] = ISO2_TO_NAME[d.country] || d.country;
            }
        });
        const sortedCounts = Object.values(dataByISO3).map(d => d.count).sort((a, b) => a - b);
        const minCount = sortedCounts[0] || 1;
        const logMin = Math.log(minCount);
        const logMax = Math.log(maxCount);
        const logRange = logMax - logMin || 1;
        const getColor = count => {
            if (!count) return '#edf2f7';
            const ratio = (Math.log(count) - logMin) / logRange;
            if (ratio > 0.78) return '#cf0a2c';
            if (ratio > 0.58) return '#d77a7d';
            if (ratio > 0.38) return '#7fa9bf';
            if (ratio > 0.18) return '#b8cdd9';
            return '#dce7ee';
        };

        if (reportEuropeMap) {
            reportEuropeMap.remove();
            reportEuropeMap = null;
            reportGeoJsonLayer = null;
            reportCountryLabelLayer = null;
        }
        reportEuropeMap = L.map('report-europe-map', {
            center: [50, 15],
            zoom: 4,
            minZoom: 3,
            maxZoom: 6,
            zoomControl: true,
            attributionControl: false,
            maxBounds: [[35, -15], [72, 45]],
        });

        const europeFeatures = (geoData?.features || []).filter(f => EUROPE_IDS.has(f.id));
        reportGeoJsonLayer = L.geoJSON({ type: 'FeatureCollection', features: europeFeatures }, {
            style: (feature) => {
                const d = dataByISO3[feature.id];
                return {
                    fillColor: getColor(d ? d.count : 0),
                    weight: 1,
                    opacity: 1,
                    color: '#ffffff',
                    fillOpacity: 0.92,
                };
            },
            onEachFeature: (feature, layer) => {
                const iso3 = feature.id;
                const d = dataByISO3[iso3];
                const count = d ? d.count : 0;
                const name = nameByISO3[iso3] || feature.properties.name || iso3;
                const pct = totalCount ? Math.round(count / totalCount * 100) : 0;
                let tooltipHtml = `<div class="tt-name">${name}</div>`;
                if (d && count > 0) {
                    tooltipHtml += `<div class="tt-count">${count} ${t('orderUnit')}</div>`;
                    tooltipHtml += `<div style="color:#64748b;font-size:11px">${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg</div>`;
                    if (d.avg_delivery_days != null) {
                        tooltipHtml += `<div style="color:#64748b;font-size:11px">${t('avgDelivery')}: ${Number(d.avg_delivery_days).toFixed(1)} ${t('workdays')}</div>`;
                    }
                    tooltipHtml += `<div class="tt-pct">${pct}%</div>`;
                } else {
                    tooltipHtml += `<div style="color:#94a3b8">${t('noData')}</div>`;
                }
                layer.bindTooltip(tooltipHtml, { className: 'map-tooltip report-map-tooltip', direction: 'auto', autoPan: true });
            }
        }).addTo(reportEuropeMap);

        reportCountryLabelLayer = L.layerGroup().addTo(reportEuropeMap);
        europeFeatures.filter(f => dataByISO3[f.id]).forEach(feature => {
            const d = dataByISO3[feature.id];
            const countryName = nameByISO3[feature.id] || feature.properties.name || feature.id;
            const layer = reportGeoJsonLayer.getLayers().find(l => l.feature && l.feature.id === feature.id);
            if (!layer) return;
            const bounds = layer.getBounds();
            if (!bounds || !bounds.isValid()) return;
            L.marker(bounds.getCenter(), {
                interactive: false,
                icon: L.divIcon({
                    className: 'map-country-label',
                    html: `${escapeHtml(countryName)} · ${d.count}单 · ${totalCount ? (d.count / totalCount * 100).toFixed(1) : '0.0'}%`,
                    iconSize: null
                })
            }).addTo(reportCountryLabelLayer);
        });
        setTimeout(() => reportEuropeMap?.invalidateSize(), 120);
    }

    function renderReportMonthlyChart(rows) {
        const canvas = document.getElementById('report-chart-monthly');
        if (!canvas || !window.Chart) return;
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        if (!selected.length) selected.push('count');
        const metricConfig = {
            count: { label: t('shipmentCount'), field: 'count', type: 'bar', yAxisID: 'y', color: 'rgba(64,111,181,0.48)', border: '#406fb5', order: 4, format: v => Number(v || 0).toLocaleString() },
            weight: { label: t('weightKg'), field: 'weight', type: 'line', yAxisID: 'y1', color: 'rgba(180,128,36,0.10)', border: '#b48024', order: 3, format: v => Number(v || 0).toLocaleString() + ' kg' },
            volume: { label: '体积 m³', field: 'volume', type: 'line', yAxisID: 'y2', color: 'rgba(42,117,129,0.10)', border: '#2a7581', order: 2, format: v => Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' m³' },
            price: { label: '费用', field: 'price', type: 'line', yAxisID: 'y3', color: 'rgba(207,10,44,0.08)', border: '#cf0a2c', order: 1, format: v => '$' + Number(v || 0).toLocaleString() }
        };
        const datasets = selected.map(key => {
            const cfg = metricConfig[key];
            return {
                label: cfg.label,
                data: (rows || []).map(d => Number(d[cfg.field] || 0)),
                type: cfg.type,
                backgroundColor: cfg.color,
                borderColor: cfg.border,
                borderWidth: cfg.type === 'line' ? 2 : 0,
                pointRadius: cfg.type === 'line' ? 4 : 0,
                pointBackgroundColor: cfg.border,
                borderRadius: cfg.type === 'bar' ? 6 : 0,
                fill: cfg.type === 'line',
                yAxisID: cfg.yAxisID,
                order: cfg.order,
                metricKey: key
            };
        });
        if (charts.reportMonthly) charts.reportMonthly.destroy();
        charts.reportMonthly = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: { labels: (rows || []).map(d => d.month), datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#334155' } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${metricConfig[ctx.dataset.metricKey]?.format(ctx.raw) || ctx.raw}` } }
                },
                scales: {
                    x: { grid: { color: '#e2e8f0' }, ticks: { color: '#64748b' } },
                    y: { display: selected.includes('count'), position: 'left', grid: { color: '#e2e8f0' }, ticks: { color: '#64748b' }, title: { display: true, text: t('shipmentCount'), color: '#64748b' } },
                    y1: { display: selected.includes('weight'), position: 'right', grid: { display: false }, ticks: { color: '#b48024', callback: v => Number(v).toLocaleString() + ' kg' }, title: { display: true, text: t('weightKg'), color: '#b48024' } },
                    y2: { display: selected.includes('volume'), position: 'right', grid: { display: false }, ticks: { color: '#2a7581', callback: v => Number(v).toLocaleString() + ' m³' }, title: { display: true, text: '体积', color: '#2a7581' } },
                    y3: { display: selected.includes('price'), position: 'right', grid: { display: false }, ticks: { color: '#cf0a2c', callback: v => '$' + Number(v).toLocaleString() }, title: { display: true, text: '费用', color: '#cf0a2c' } }
                }
            }
        });
    }

    async function generateReportPreview() {
        const type = document.getElementById('reportType')?.value || 'monthly_ops';
        const warehouse = document.getElementById('reportWarehouse')?.value || '';
        const reportMonth = document.getElementById('reportMonth')?.value || '';
        const queryMonth = reportMonth;
        const modal = document.getElementById('reportPreviewModal');
        const area = document.getElementById('reportPrintArea');
        if (modal) modal.style.display = 'flex';
        if (modal) modal.scrollTop = 0;
        if (area) area.innerHTML = '<div style="color:#64748b;padding:40px;text-align:center">正在生成报告预览...</div>';

        const [shipResp, monthlyRows, invoiceItems, invStats, dos, idle, health, reportGeoData] = await Promise.all([
            apiFetch(API + '/api/shipments?per_page=9999&month=' + encodeURIComponent(queryMonth)),
            apiFetch(API + '/api/dashboard/monthly_trend'),
            apiFetch(API + '/api/invoices/items?type=logistics').catch(() => ({ items: [], summary: {} })),
            apiGet('/api/inventory/stats?warehouse=' + encodeURIComponent(warehouse)),
            apiGet('/api/inventory/stats/dos180?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({ data: [] })),
            apiGet('/api/inventory/stats/idle180?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({ data: [] })),
            apiGet('/api/inventory/stats/health?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({})),
            fetch('/static/europe.geojson').then(r => r.json()).catch(() => null),
        ]);

        const now = new Date();
        const monthText = reportMonthLabel(reportMonth);
        const reportMeta = {
            monthly_ops: { zh: '零售中央仓月度经营总报告', en: 'Retail Central Warehouse Monthly Business Summary Report', note: '本报告用于汇总当前系统中的物流、库存与费用验收状态。' },
            monthly_logistics: { zh: '零售中央仓月度物流报告', en: 'Retail Central Warehouse Monthly Logistics Report', note: '本报告用于整理当月物流履约、国家/代表处要货、重量体积与费用趋势。' },
            monthly_inventory: { zh: '零售中央仓月度库存报告', en: 'Retail Central Warehouse Monthly Inventory Report', note: '本报告用于整理库存货值、DOS 超期、长期未使用与主数据质量。' },
            monthly_acceptance: { zh: '零售中央仓月度验收报告', en: 'Retail Central Warehouse Monthly Acceptance Report', note: '本报告用于整理物流费用发票验收、匹配率、待验收金额与异常提醒。' },
            monthly_overdue: { zh: '零售中央仓月度超期物料报告', en: 'Retail Central Warehouse Monthly Overdue Materials Report', note: '本报告用于聚焦 DOS 超期与长期未使用物料。' }
        };
        const meta = reportMeta[type] || reportMeta.monthly_ops;
        const title = meta.en;
        const zhTitle = meta.zh;
        const showLogistics = type === 'monthly_ops' || type === 'monthly_logistics';
        const showInventory = type === 'monthly_ops' || type === 'monthly_inventory' || type === 'monthly_overdue';
        const showAcceptance = type === 'monthly_ops' || type === 'monthly_acceptance';
        const whText = warehouse || '全部仓库';
        const shipments = shipResp.shipments || [];
        const reportShipments = warehouse ? shipments.filter(s => (s.warehouse || '') === warehouse) : shipments;
        const logisticsBreakdown = buildReportLogisticsBreakdown(reportShipments);
        const statusRows = ['已交付', '待核实', '运输中', '异常单'].map(status => ({ status, count: reportShipments.filter(s => s.display_status === status).length })).filter(r => r.count);
        const typeRows = Object.values(reportShipments.reduce((m, s) => {
            const key = s.shipment_type || 'unknown';
            if (!m[key]) m[key] = { shipment_type: key, label: s.shipment_type_label || key, count: 0 };
            m[key].count += 1;
            return m;
        }, {}));
        const monthlyIndex = new Map((monthlyRows || []).map(r => [r.month, r]));
        const isYearReport = reportMonth === 'annual' || /^year:\d{4}$/.test(reportMonth);
        const currentMonthRow = isYearReport
            ? { month: 'annual', count: reportShipments.length, weight: reportShipments.reduce((s, r) => s + Number(r.total_weight || 0), 0), volume: reportShipments.reduce((s, r) => s + Number(r.total_volume || 0), 0), price: reportShipments.reduce((s, r) => s + Number(r.price_without_vat || 0), 0) }
            : (monthlyIndex.get(reportMonth) || { month: reportMonth, count: reportShipments.length, weight: 0, volume: 0, price: 0 });
        const recentMonthly = (monthlyRows || []).slice(-6);
        const statusTotal = (statusRows || []).reduce((s, r) => s + Number(r.count || 0), 0);
        const typeTotal = (typeRows || []).reduce((s, r) => s + Number(r.count || 0), 0);
        const invoiceMonthItems = (invoiceItems.items || []).filter(i => !queryMonth || String(i.pickup_date || i.ref_date || i.invoice_date || '').slice(0, 7) === queryMonth);
        const verifiedItems = invoiceMonthItems.filter(i => i.invoice_status === 'verified');
        const pendingItems = invoiceMonthItems.filter(i => i.invoice_status === 'pending');
        const verifiedPln = verifiedItems.reduce((s, i) => s + Number(i.net_amount || 0), 0);
        const pendingPln = pendingItems.reduce((s, i) => s + Number(i.net_amount || 0), 0);
        const matchedCount = invoiceMonthItems.filter(i => i.matched_booking_id).length;
        const dosRows = dos.data || [];
        const idleRows = idle.data || [];
        const overdueTotalValue = dosRows.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const missingPrice = health.missing_price || {};
        const missingImage = health.missing_image || {};
        const missingInbound = health.missing_inbound || {};
        const logoHtml = reportHeaderIconUrl
            ? `<img src="${escapeHtml(reportHeaderIconUrl)}?v=${Date.now()}" alt="Report icon">`
            : `<div style="font-size:28px;font-weight:900;color:#cf0a2c;letter-spacing:1px">HUAWEI</div>`;
        let reportSectionNo = 0;
        const logisticsSection = showLogistics ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 物流概览（${escapeHtml(monthText)}）</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">当月总运单</div><div class="value">${reportFmtNumber(reportShipments.length)}</div><div class="sub">${escapeHtml(reportMonth || '-')} 取货月份</div></div>
                    <div class="report-kpi"><div class="label">已交付</div><div class="value">${reportFmtNumber(statusRows.find(r => r.status === '已交付')?.count || 0)}</div><div class="sub">${statusTotal ? Math.round((statusRows.find(r => r.status === '已交付')?.count || 0) / statusTotal * 100) : 0}% of month</div></div>
                    <div class="report-kpi"><div class="label">当月重量</div><div class="value">${reportFmtNumber(currentMonthRow.weight || reportShipments.reduce((s, r) => s + Number(r.total_weight || 0), 0))}</div><div class="sub">kg</div></div>
                    <div class="report-kpi"><div class="label">当月费用</div><div class="value">${reportFmtMoney(currentMonthRow.price || reportShipments.reduce((s, r) => s + Number(r.price_without_vat || 0), 0))}</div><div class="sub">without VAT</div></div>
                </div>
                <div class="report-two-col" style="margin-top:14px">
                    <div class="report-card-print"><h2>运单状态分布</h2>${reportBarRows(statusRows || [], r => statusLabel(r.status || ''), r => r.count, '#3b82f6')}</div>
                    <div class="report-card-print"><h2>运单类型分布</h2>${reportBarRows(typeRows || [], r => typeLabel(r.shipment_type, r.label), r => r.count, '#22c55e')}</div>
                </div>
                <div class="report-two-col report-balanced-row" style="margin-top:14px">
                    <div class="report-card-print report-balanced-card">
                        <h2>代表处维度要货汇总</h2>
                        <table class="report-table">
                            <thead><tr><th>代表处</th><th style="text-align:right">订单数</th><th style="text-align:right">占比</th><th style="text-align:right">重量 kg</th><th style="text-align:right">体积 m³</th><th style="text-align:right">费用</th></tr></thead>
                            <tbody>${reportLogisticsRows(logisticsBreakdown.offices.map(r => ({ ...r, countryName: r.office })), reportShipments.length, false)}</tbody>
                        </table>
                        <h2 style="margin-top:16px">Top3 要货国家</h2>
                        ${reportTopCountryCards(logisticsBreakdown.countries, reportShipments.length)}
                    </div>
                    <div class="report-card-print report-balanced-card report-map-card">
                        <h2>各国订单信息一览</h2>
                        <div class="report-map-frame" id="report-europe-map"></div>
                        <div class="report-map-legend" id="report-map-legend"><span>少</span><div></div><span>多</span></div>
                    </div>
                </div>
                <div class="report-card-print" style="margin-top:14px">
                    <h2>月度运单趋势</h2>
                    <div class="report-chart-note">复用物流看板当前勾选指标：运单数 / 重量 / 体积 / 费用</div>
                    <div class="chart-container" style="height:300px"><canvas id="report-chart-monthly"></canvas></div>
                </div>
            </div>` : '';
        const inventorySection = showInventory ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 库存概览</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">SKU 总数</div><div class="value">${reportFmtNumber(invStats.total_skus)}</div><div class="sub">${escapeHtml(whText)}</div></div>
                    <div class="report-kpi"><div class="label">库存总件数</div><div class="value">${reportFmtNumber(invStats.total_pcs)}</div><div class="sub">PCS</div></div>
                    <div class="report-kpi"><div class="label">库存总货值</div><div class="value">${reportFmtMoney(invStats.total_value)}</div><div class="sub">USD</div></div>
                    <div class="report-kpi"><div class="label">超期物料总货值</div><div class="value">${reportFmtMoney(overdueTotalValue)}</div><div class="sub">DOS 超期物料 USD</div></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr;gap:14px;margin-top:14px">
                    <div class="report-card-print"><h2>DOS 超期 Top 5</h2>${reportInventoryTopCards(dosRows, 'dos')}</div>
                    <div class="report-card-print"><h2>长期未使用 Top 5</h2>${reportInventoryTopCards(idleRows, 'idle')}</div>
                </div>
            </div>` : '';
        const acceptanceSection = showAcceptance ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 费用验收</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">预算</div><div class="value">${reportFmtMoney(250000)}</div><div class="sub">年度预算</div></div>
                    <div class="report-kpi"><div class="label">当月已验收物流费</div><div class="value">${reportFmtMoney(verifiedPln * 0.25)}</div><div class="sub">${Number(verifiedPln || 0).toLocaleString('pl-PL', { maximumFractionDigits: 0 })} PLN</div></div>
                    <div class="report-kpi"><div class="label">当月待验收物流费</div><div class="value">${reportFmtMoney(pendingPln * 0.25)}</div><div class="sub">需人工确认</div></div>
                    <div class="report-kpi"><div class="label">当月发票匹配率</div><div class="value">${invoiceMonthItems.length ? (matchedCount / invoiceMonthItems.length * 100).toFixed(1) : '0.0'}%</div><div class="sub">${reportFmtNumber(matchedCount)} / ${reportFmtNumber(invoiceMonthItems.length)}</div></div>
                </div>
                <div class="report-note" style="margin-top:14px">
                    建议：优先核实待验收发票与未匹配 STT；月度报告中应同步检查超期库存是否仍有业务需求，避免库存货值长期沉淀。
                </div>
            </div>` : '';

        area.innerHTML = `
            <div class="report-header">
                <div>
                    <h1 class="report-title">${zhTitle} · ${escapeHtml(monthText)}</h1>
                    <div class="report-subtitle">${title}<br>报告月份：${escapeHtml(monthText)} · 统计范围：${escapeHtml(whText)} · 生成时间：${now.toLocaleString('zh-CN', { hour12:false })} · 版本：${APP_VERSION}</div>
                </div>
                <div>${logoHtml}</div>
            </div>

            <div class="report-note">
                ${meta.note} 数据来源为本地系统数据库，所有上传文件与图片均在本机环境内处理。
            </div>
            ${logisticsSection}
            ${inventorySection}
            ${acceptanceSection}

            <div class="report-footer"><span>Generated by ${APP_VERSION}</span><span>Local offline report preview</span></div>
        `;
        if (showLogistics) {
            renderReportCountryMap(reportShipments, reportGeoData);
            renderReportMonthlyChart(monthlyRows || []);
        }
    }

    function closeReportPreview() {
        document.getElementById('reportPreviewModal').style.display = 'none';
    }

    async function printReportPdf() {
        const modal = document.getElementById('reportPreviewModal');
        const area = document.getElementById('reportPrintArea');
        if (!area || !area.innerHTML.trim()) {
            await generateReportPreview();
        } else if (modal) {
            modal.style.display = 'flex';
        }
        setTimeout(() => window.print(), 250);
    }

    async function ensureReportReady() {
        const area = document.getElementById('reportPrintArea');
        if (!area || !area.innerHTML.trim()) {
            await generateReportPreview();
            await new Promise(resolve => setTimeout(resolve, 500));
        } else {
            const modal = document.getElementById('reportPreviewModal');
            if (modal) modal.style.display = 'flex';
        }
        return document.getElementById('reportPrintArea');
    }

    function reportExportFilename(ext) {
        const area = document.getElementById('reportPrintArea');
        if (area?.dataset?.exportBase) return `${area.dataset.exportBase}.${ext}`;
        const month = document.getElementById('reportMonth')?.value || new Date().toISOString().slice(0, 7);
        const warehouse = document.getElementById('reportWarehouse')?.value || 'All';
        const type = document.getElementById('reportType')?.value || 'monthly_ops';
        const monthText = month.startsWith('year:') ? month.replace('year:', '') + '全年' : (month === 'annual' ? new Date().getFullYear() + '全年' : month);
        const clean = value => String(value || '全部').replace(/[\\/:*?"<>|\s]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
        return `${APP_VERSION}_${clean(type)}_${clean(monthText)}.${ext}`;
    }

    function downloadReportBlob(blob, filename) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            URL.revokeObjectURL(a.href);
            a.remove();
        }, 800);
    }

    function blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    async function cloneReportForExport(area) {
        const clone = area.cloneNode(true);
        const sourceCanvases = area.querySelectorAll('canvas');
        clone.querySelectorAll('canvas').forEach((canvas, idx) => {
            const srcCanvas = sourceCanvases[idx];
            if (!srcCanvas) return;
            const img = document.createElement('img');
            img.src = srcCanvas.toDataURL('image/png');
            img.alt = canvas.id || 'chart';
            img.style.width = '100%';
            img.style.height = canvas.style.height || 'auto';
            img.style.display = 'block';
            canvas.replaceWith(img);
        });
        for (const img of clone.querySelectorAll('img')) {
            const src = img.getAttribute('src') || '';
            if (src && !src.startsWith('data:')) {
                try {
                    const abs = new URL(src, location.href).href;
                    const res = await fetch(abs, { cache: 'no-store' });
                    if (res.ok) img.src = await blobToDataUrl(await res.blob());
                    else img.src = abs;
                } catch (_) {
                    img.src = new URL(src, location.href).href;
                }
            }
        }
        return clone;
    }

    async function exportReportHtml() {
        const area = await ensureReportReady();
        if (!area) return toast('请先生成报告预览', 'error');
        const clone = await cloneReportForExport(area);
        const styles = [...document.querySelectorAll('style')].map(s => s.textContent || '').join('\n');
        const links = [...document.querySelectorAll('link[rel="stylesheet"]')].map(l => `<link rel="stylesheet" href="${new URL(l.getAttribute('href'), location.href).href}">`).join('\n');
        const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(area.querySelector('.report-title')?.textContent || '零售中央仓月度报告')}</title>
${links}
<style>
${styles}
body { margin:0; background:#f1f5f9; padding:24px 0; }
.report-sheet { margin:0 auto !important; box-shadow:0 12px 36px rgba(15,23,42,0.16) !important; }
.report-preview-modal,.report-preview-shell { all: unset; }
@media print {
  body { background:#fff; padding:0; }
  .report-sheet { width:100% !important; box-shadow:none !important; padding:14mm !important; }
}
</style>
</head>
<body>
${clone.outerHTML}
</body>
</html>`;
        downloadReportBlob(new Blob(['\uFEFF' + html], { type: 'text/html;charset=utf-8' }), reportExportFilename('html'));
        toast('HTML 长报告已导出');
    }

    async function ensureHtml2Canvas() {
        if (window.html2canvas) return window.html2canvas;
        await new Promise((resolve, reject) => {
            const existing = document.querySelector('script[data-lib="html2canvas"]');
            if (existing) {
                existing.addEventListener('load', resolve, { once: true });
                existing.addEventListener('error', reject, { once: true });
                return;
            }
            const script = document.createElement('script');
            script.src = '/static/vendor/html2canvas.min.js';
            script.dataset.lib = 'html2canvas';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
        return window.html2canvas;
    }

    async function exportReportPng() {
        const area = await ensureReportReady();
        if (!area) return toast('请先生成报告预览', 'error');
        toast('正在生成长图，请稍等...');
        try {
            const render = await ensureHtml2Canvas();
            const exportScale = area.scrollHeight > 9000 ? 2.25 : 3;
            const canvas = await render(area, {
                backgroundColor: '#ffffff',
                scale: exportScale,
                useCORS: true,
                allowTaint: true,
                logging: false,
                windowWidth: area.scrollWidth,
                windowHeight: area.scrollHeight
            });
            canvas.toBlob(blob => {
                if (!blob) return toast('长图生成失败', 'error');
                downloadReportBlob(blob, reportExportFilename('png'));
                toast(`长图 PNG 已导出（${exportScale}x）`);
            }, 'image/png');
        } catch (e) {
            toast('长图生成失败：请检查网络或改用 HTML 导出', 'error');
            console.error(e);
        }
    }

    Object.assign(window, { loadReportHeaderIcon, uploadReportHeaderIcon, generateReportPreview, closeReportPreview, printReportPdf, exportReportHtml, exportReportPng });

    async function loadSummary() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/summary' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const updateTimeEl = document.getElementById('update-time');
        if (updateTimeEl) {
            updateTimeEl.textContent = data.latest_logistics_upload || '--';
        }
        const grid = document.getElementById('stats-grid');
        grid.innerHTML = `
            <div class="stat-card clickable" onclick="drillDown(null, t('allShipments'))">
                <div class="label">${t('totalShipments')}</div>
                <div class="value accent">${data.total_shipments}</div>
                <div class="sub">${t('viewAll')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('已交付', t('deliveredShipments'))">
                <div class="label">${t('delivered')}</div>
                <div class="value success">${data.delivered}</div>
                <div class="sub">${tf('ratioClick', { pct: data.total_shipments ? Math.round(data.delivered / data.total_shipments * 100) : 0 })}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('待核实', t('pendingVerifyShipments'))" style="border-color:rgba(168,85,247,0.3)">
                <div class="label">${t('pendingVerify')}</div>
                <div class="value" style="color:#a855f7">${data.pending_verify}</div>
                <div class="sub">${t('etaReached')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('运输中', t('inTransitShipments'))">
                <div class="label">${t('inTransit')}</div>
                <div class="value" style="color:#f59e0b">${data.in_transit}</div>
                <div class="sub">${t('clickToView')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('异常单', t('exceptionShipments'))">
                <div class="label">${t('exception')}</div>
                <div class="value danger">${data.exception}</div>
                <div class="sub">${t('shipOverdue')}</div>
            </div>
            `;
    }

    const STATUS_LABEL_KEYS = {
        '已交付': 'delivered',
        '待核实': 'pendingVerify',
        '运输中': 'inTransit',
        '异常单': 'exception',
    };
    function statusLabel(status) {
        return t(STATUS_LABEL_KEYS[status] || status);
    }

    const STATUS_COLORS = {
        '已交付': '#22c55e',
        '待核实': '#a855f7',
        '运输中': '#f59e0b',
        '异常单': '#ef4444',
    };

    function doughnutValueLabelPlugin(sourceData, labelFn, total) {
        return {
            id: 'doughnutValueLabels',
            afterDatasetsDraw(chart) {
                const { ctx } = chart;
                const meta = chart.getDatasetMeta(0);
                ctx.save();
                ctx.font = '700 11px Inter, sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                meta.data.forEach((arc, idx) => {
                    const raw = Number(chart.data.datasets[0].data[idx] || 0);
                    if (!raw) return;
                    const pct = total ? raw / total : 0;
                    if (pct < 0.045) return;
                    const pos = arc.tooltipPosition();
                    const text = `${labelFn(sourceData[idx])} ${raw} · ${Math.round(pct * 100)}%`;
                    ctx.lineWidth = 4;
                    ctx.strokeStyle = 'rgba(15,23,42,0.85)';
                    ctx.strokeText(text, pos.x, pos.y);
                    ctx.fillStyle = '#ffffff';
                    ctx.fillText(text, pos.x, pos.y);
                });
                ctx.restore();
            }
        };
    }

    async function loadBudget() {
        try {
            const data = await apiFetch(API + '/api/invoices/budget');
            const spentEl = document.getElementById('budget-spent');
            const remainEl = document.getElementById('budget-remaining');
            if (spentEl) {
                const spentUsd = data.logistics_usd || 0;
                const remainUsd = data.remaining_usd || 250000;
                spentEl.textContent = '$' + spentUsd.toLocaleString();
                remainEl.textContent = '$' + remainUsd.toLocaleString();
                // Change color if over budget
                if (remainUsd <= 0) {
                    spentEl.className = 'value danger';
                } else if (remainUsd < 50000) {
                    spentEl.className = 'value warning';
                }
            }
        } catch(e) {
            console.error('Failed to load budget:', e);
        }
    }

    async function loadStatusChart() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/status_distribution' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const total = data.reduce((s, d) => s + Number(d.count || 0), 0);
        const ctx = document.getElementById('chart-status').getContext('2d');
        if (charts.status) charts.status.destroy();
        charts.status = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => `${statusLabel(d.shipment_status)} ${fmtPct(d.count, total)}`),
                datasets: [{
                    data: data.map(d => d.count),
                    backgroundColor: data.map(d => STATUS_COLORS[d.shipment_status] || '#64748b'),
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        const label = data[idx].shipment_status;
                        drillDown(label, statusLabel(label));
                    }
                },
                plugins: {
                    legend: { position: 'right', labels: { color: '#94a3b8', padding: 12, font: { size: 12 } } },
                    tooltip: { callbacks: { label: (ctx) => `${statusLabel(data[ctx.dataIndex].shipment_status)}: ${ctx.raw} ${t('orderUnit')} (${fmtPct(ctx.raw, total)})` } }
                },
                cutout: '55%'
            },
            plugins: [doughnutValueLabelPlugin(data, d => statusLabel(d.shipment_status), total)]
        });
    }

    const TYPE_COLORS = {
        'warehouse_central': '#f59e0b',
        'warehouse_furniture': '#06b6d4',
        'direct': '#a78bfa',
    };
    const TYPE_LABELS = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    };
    const TYPE_LABEL_KEYS = {
        'warehouse_central': 'centralWarehouseOutbound',
        'warehouse_furniture': 'furnitureWarehouseOutbound',
        'direct': 'directShipment',
    };
    function typeLabel(type, fallback) {
        return t(TYPE_LABEL_KEYS[type] || '') || fallback || type;
    }

    async function loadTypeChart() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/type_distribution' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const total = data.reduce((s, d) => s + Number(d.count || 0), 0);
        const ctx = document.getElementById('chart-type').getContext('2d');
        if (charts.type) charts.type.destroy();
        charts.type = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => `${typeLabel(d.shipment_type, d.label)} ${fmtPct(d.count, total)}`),
                datasets: [{
                    data: data.map(d => d.count),
                    backgroundColor: data.map(d => TYPE_COLORS[d.shipment_type] || '#64748b'),
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        const type = data[idx].shipment_type;
                        const label = typeLabel(type, data[idx].label);
                        drillDownType(type, label);
                    }
                },
                plugins: {
                    legend: { position: 'right', labels: { color: '#94a3b8', padding: 12, font: { size: 12 } } },
                    tooltip: { callbacks: { label: (ctx) => `${typeLabel(data[ctx.dataIndex].shipment_type, data[ctx.dataIndex].label)}: ${ctx.raw} ${t('orderUnit')} (${fmtPct(ctx.raw, total)})` } }
                },
                cutout: '55%'
            },
            plugins: [doughnutValueLabelPlugin(data, d => typeLabel(d.shipment_type, d.label), total)]
        });
    }

    // ===== 2字母 → 3字母 ISO 码映射 =====
    const ISO2_TO_3 = {
        'DE':'DEU','FR':'FRA','PL':'POL','ES':'ESP','CZ':'CZE','RO':'ROU','LT':'LTU',
        'IT':'ITA','BG':'BGR','SI':'SVN','HU':'HUN','AT':'AUT','GR':'GRC','PT':'PRT',
        'SE':'SWE','FI':'FIN','HR':'HRV','NL':'NLD','BE':'BEL','DK':'DNK','IE':'IRL',
        'SK':'SVK','EE':'EST','LV':'LVA','NO':'NOR','CH':'CHE','GB':'GBR','UK':'GBR','RU':'RUS',
        'UA':'UKR','MD':'MDA','ME':'MNE','RS':'SRB','MK':'MKD','AL':'ALB','BA':'BIH',
        'IS':'ISL','LU':'LUX','MT':'MLT','CY':'CYP','GI':'GIB','FO':'FRO','GL':'GRL','AX':'ALA',
        'SM':'SMR','MC':'MCO','AD':'AND','LI':'LIE','VA':'VAT','JE':'JEY','GG':'GGY',
        'IM':'IMN','SJ':'SJM',
    };
    const ISO2_TO_NAME = {
        'DE':'Germany','FR':'France','PL':'Poland','ES':'Spain','CZ':'Czechia','RO':'Romania',
        'LT':'Lithuania','IT':'Italy','BG':'Bulgaria','SI':'Slovenia','HU':'Hungary',
        'AT':'Austria','GR':'Greece','PT':'Portugal','SE':'Sweden','FI':'Finland',
        'HR':'Croatia','NL':'Netherlands','BE':'Belgium','LU':'Luxembourg','SK':'Slovakia',
        'UA':'Ukraine','DK':'Denmark','NO':'Norway','IS':'Iceland','EE':'Estonia',
        'LV':'Latvia','GB':'United Kingdom','UK':'United Kingdom','CH':'Switzerland',
        'RS':'Serbia','IE':'Ireland','FO':'Faroe Islands','GL':'Greenland','AX':'Aland Islands',
    };
    const COUNTRY_OFFICES = [
        { key: 'poland', label: '波兰代表处', short: 'PL Office', color: 'rgba(59,130,246,0.72)', countries: ['PL','UA','CZ','SK','SE','FI','NO','DK','IS','FO','GL','AX','EE','LV','LT'] },
        { key: 'germany', label: '德国代表处', short: 'DE Office', color: 'rgba(34,197,94,0.68)', countries: ['DE','AT','CH'] },
        { key: 'france', label: '法国代表处', short: 'FR Office', color: 'rgba(245,158,11,0.70)', countries: ['GB','UK','FR','NL','BE','LU','IE'] },
        { key: 'south_europe', label: '南欧代表处', short: 'South EU', color: 'rgba(236,72,153,0.68)', countries: ['ES','PT','IT'] },
        { key: 'eastern_europe', label: '东欧多国代表处', short: 'East EU', color: 'rgba(139,92,246,0.68)', countries: ['HU','SI','GR','RO','HR','RS','BG'] },
    ];
    const COUNTRY_TO_OFFICE = COUNTRY_OFFICES.reduce((map, office, idx) => {
        office.countries.forEach(code => { map[String(code).toUpperCase()] = { ...office, order: idx }; });
        return map;
    }, {});

    // ===== 欧洲地区 ID =====
    const EUROPE_IDS = new Set([
        'ALA','ALB','AND','AUT','BEL','BGR','BIH','CHE','CZE','DEU','DNK','ESP',
        'EST','FIN','FRA','FRO','GBR','GRC','HRV','HUN','IMN','IRL','ISL','ITA',
        'JEY','KOS','LTU','LUX','LVA','MDA','MNE','MKD','NLD','NOR','POL','PRT','GRL',
        'ROU','SMR','SRB','SVK','SVN','SWE','VAT','CYP','MLT'
    ]);

    let europeMap = null;
    let geoJsonLayer = null;
    let countryLabelLayer = null;
    let countryRankingData = null;

    function populateMonthFilter(months) {
        if (!months || !months.length) return;
        const select = document.getElementById('map-month-filter');
        const current = select.value;
        while (select.options.length > 1) select.remove(1);
        months.forEach(m => {
            const opt = document.createElement('option');
            opt.value = m;
            opt.textContent = m;
            select.appendChild(opt);
        });
        select.value = current;
    }

    function syncCountryOfficeControls() {
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const wrap = document.getElementById('country-office-filter-wrap');
        if (wrap) {
            wrap.style.display = '';
            wrap.style.opacity = sortMode === 'office_single' ? '1' : '0.45';
            wrap.style.pointerEvents = sortMode === 'office_single' ? 'auto' : 'none';
        }
    }

    function countryOfficeOf(countryCode) {
        return COUNTRY_TO_OFFICE[String(countryCode || '').toUpperCase()] || {
            key: 'other',
            label: '其他代表处',
            short: 'Other',
            color: 'rgba(100,116,139,0.58)',
            order: 99,
            countries: []
        };
    }

    function sortedCountryBarData(rows) {
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const selectedOffice = document.getElementById('country-office-filter')?.value || 'poland';
        const withOffice = rows.map(r => ({ ...r, office: countryOfficeOf(r.country) }));
        const byCountDesc = (a, b) => {
            const countDiff = Number(b.count || 0) - Number(a.count || 0);
            if (countDiff) return countDiff;
            return String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN');
        };
        if (sortMode === 'office_single') {
            return withOffice.filter(r => r.office.key === selectedOffice).sort(byCountDesc);
        }
        if (sortMode === 'office_group') {
            return withOffice.sort((a, b) => {
                const officeDiff = Number(a.office.order || 99) - Number(b.office.order || 99);
                return officeDiff || byCountDesc(a, b);
            });
        }
        return withOffice.sort(byCountDesc);
    }
    Object.assign(window, { syncCountryOfficeControls, sortedCountryBarData });

    async function loadCountryChart() {
        syncCountryOfficeControls();
        const selectedBefore = document.getElementById('map-month-filter')?.value || '';
        let resp;
        if (selectedBefore) {
            resp = await apiFetch(API + '/api/dashboard/country_ranking?month=' + encodeURIComponent(selectedBefore));
        } else {
            resp = await apiFetch(API + '/api/dashboard/country_ranking');
            populateMonthFilter(resp.available_months || []);
        }
        const selectedAfterPopulate = document.getElementById('map-month-filter')?.value || selectedBefore;
        if (selectedAfterPopulate && !selectedBefore) {
            resp = await apiFetch(API + '/api/dashboard/country_ranking?month=' + encodeURIComponent(selectedAfterPopulate));
        }
        const filtered = (resp.data || [])
            .map(d => ({
                country: String(d.country || '').trim().toUpperCase(),
                count: Number(d.count || 0),
                weight: Number(d.weight || 0),
                price: Number(d.price || 0),
                avg_delivery_days: d.avg_delivery_days == null ? null : Number(d.avg_delivery_days)
            }))
            .filter(d => d.country && d.count > 0)
            .sort((a, b) => String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN'));

        countryRankingData = filtered;

        const totalCount = filtered.reduce((s, d) => s + d.count, 0);
        const maxCount = Math.max(...filtered.map(d => d.count), 1);

        const dataByISO3 = {};
        const nameByISO3 = {};
        filtered.forEach(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (iso3) {
                dataByISO3[iso3] = d;
                nameByISO3[iso3] = ISO2_TO_NAME[d.country] || d.country;
            }
        });

        const sortedCounts = Object.values(dataByISO3).map(d => d.count).sort((a, b) => a - b);
        const minCount = sortedCounts[0] || 1;
        const logMin = Math.log(minCount);
        const logMax = Math.log(maxCount);
        const logRange = logMax - logMin || 1;

        function getColor(count) {
            if (!count) return 'rgba(30,41,59,0.4)';
            const ratio = (Math.log(count) - logMin) / logRange;
            const hue = 190 - ratio * 190;
            const sat = 60 + ratio * 30;
            const light = 30 + ratio * 20;
            return `hsl(${hue},${sat}%,${light}%)`;
        }

        if (!europeMap) {
            europeMap = L.map('europe-map', {
                center: [50, 15],
                zoom: 4,
                minZoom: 3,
                maxZoom: 6,
                zoomControl: true,
                attributionControl: false,
                maxBounds: [[35, -15], [72, 45]],
            });
        }

        if (geoJsonLayer) europeMap.removeLayer(geoJsonLayer);
        if (countryLabelLayer) europeMap.removeLayer(countryLabelLayer);

        const geoRes = await fetch('/static/europe.geojson');
        const geoData = await geoRes.json();
        const europeFeatures = geoData.features.filter(f => EUROPE_IDS.has(f.id));

        geoJsonLayer = L.geoJSON({ type: 'FeatureCollection', features: europeFeatures }, {
            style: (feature) => {
                const d = dataByISO3[feature.id];
                return {
                    fillColor: getColor(d ? d.count : 0),
                    weight: 1,
                    opacity: 1,
                    color: 'rgba(148,163,184,0.3)',
                    fillOpacity: 0.85,
                };
            },
            onEachFeature: (feature, layer) => {
                const iso3 = feature.id;
                const d = dataByISO3[iso3];
                const count = d ? d.count : 0;
                const name = nameByISO3[iso3] || feature.properties.name || iso3;
                const pct = totalCount ? Math.round(count / totalCount * 100) : 0;

                let tooltipHtml = `<div class="tt-name">${name}</div>`;
                if (d && count > 0) {
                    tooltipHtml += `<div class="tt-count">${count} ${t('orderUnit')}</div>`;
                    tooltipHtml += `<div style="color:var(--text-secondary);font-size:11px">${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg</div>`;
                    if (d.avg_delivery_days != null) {
                        tooltipHtml += `<div style="color:var(--text-secondary);font-size:11px">${t('avgDelivery')}: ${Number(d.avg_delivery_days).toFixed(1)} ${t('workdays')}</div>`;
                    }
                    tooltipHtml += `<div class="tt-pct">${pct}%</div>`;
                } else {
                    tooltipHtml += `<div style="color:var(--text-muted)">${t('noData')}</div>`;
                }

                layer.bindTooltip(tooltipHtml, { className: 'map-tooltip', direction: 'auto', autoPan: true });

                if (count > 0) {
                    const clickCountry = d?.clickCountry || d?.country;
                    layer.on('click', () => {
                        if (clickCountry) drillDownCountry(clickCountry);
                    });
                    layer.setStyle({ cursor: 'pointer' });
                }
            }
        }).addTo(europeMap);

        countryLabelLayer = L.layerGroup().addTo(europeMap);
        const labelFeatures = europeFeatures.filter(f => dataByISO3[f.id]);
        labelFeatures.forEach(feature => {
            const d = dataByISO3[feature.id];
            const countryName = nameByISO3[feature.id] || feature.properties.name || feature.id;
            const layer = geoJsonLayer.getLayers().find(l => l.feature && l.feature.id === feature.id);
            if (!layer) return;
            const bounds = layer.getBounds();
            if (!bounds || !bounds.isValid()) return;
            L.marker(bounds.getCenter(), {
                interactive: false,
                icon: L.divIcon({
                    className: 'map-country-label',
                    html: `${escapeHtml(countryName)}${d ? ` · ${d.count}` : ''}`,
                    iconSize: null
                })
            }).addTo(countryLabelLayer);
        });

        // 柱状图
        const metric = document.getElementById('country-bar-metric')?.value || 'count';
        const metricConfig = {
            count: { label: t('shipmentCount'), format: v => `${Number(v || 0).toLocaleString()} ${t('orderUnit')}` },
            weight: { label: t('weightLabel'), format: v => `${Number(v || 0).toLocaleString()} kg` },
            price: { label: '费用', format: v => '$' + Number(v || 0).toLocaleString() },
            avg_delivery_days: { label: t('avgDelivery'), format: v => v == null ? '-' : `${Number(v || 0).toFixed(1)} ${t('workdays')}` }
        };
        const metricInfo = metricConfig[metric] || metricConfig.count;
        const barData = sortedCountryBarData(filtered);
        const barLabels = barData.map(d => ISO2_TO_NAME[d.country] || d.country);
        const barTotal = barData.reduce((s, d) => s + Number(d[metric] || 0), 0);
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const barColors = barData.map(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (sortMode !== 'all_desc') return d.office?.color || 'rgba(100,116,139,0.5)';
            return iso3 ? getColor(d.count) : 'rgba(100,116,139,0.5)';
        });

        const barCtx = document.getElementById('chart-country-bar').getContext('2d');
        if (charts.countryBar) charts.countryBar.destroy();
        charts.countryBar = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: barLabels,
                datasets: [{
                    label: metricInfo.label,
                    data: barData.map(d => Number(d[metric] || 0)),
                    backgroundColor: barColors,
                    borderRadius: 4,
                    barPercentage: 0.7,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        drillDownCountry(barData[idx].country);
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${metricInfo.label}: ${metricInfo.format(ctx.raw)}${metric === 'avg_delivery_days' ? '' : ` (${fmtPct(ctx.raw, barTotal)})`}`,
                            afterLabel: (ctx) => {
                                const d = barData[ctx.dataIndex];
                                let extra = `${d.office?.label || '其他代表处'}\n${t('shipmentCount')}: ${Number(d.count || 0).toLocaleString()} ${t('orderUnit')}\n${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg`;
                                if (d.avg_delivery_days != null) {
                                    extra += '\n' + t('avgDelivery') + ': ' + d.avg_delivery_days + ' ' + t('workdays');
                                }
                                return extra;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { color: '#94a3b8', font: { size: 11 }, maxRotation: 45 } },
                    y: { grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8', callback: v => metricInfo.format(v).replace(' ' + t('orderUnit'), '') }, beginAtZero: true, title: { display: true, text: metricInfo.label, color: '#94a3b8' } }
                }
            }
        });

        const pieWrap = document.getElementById('country-office-pie-wrap');
        if (charts.countryOfficePie) {
            charts.countryOfficePie.destroy();
            charts.countryOfficePie = null;
        }
        if (pieWrap) pieWrap.style.display = sortMode === 'office_single' && barData.length ? 'block' : 'none';
        if (sortMode === 'office_single' && barData.length) {
            const selectedOffice = barData[0].office;
            const pieTitle = document.getElementById('country-office-pie-title');
            if (pieTitle) pieTitle.textContent = `${selectedOffice?.label || '代表处'}内部订单对比`;
            const pieTotal = barData.reduce((s, d) => s + Number(d.count || 0), 0);
            const pieCtx = document.getElementById('chart-country-office-pie').getContext('2d');
            charts.countryOfficePie = new Chart(pieCtx, {
                type: 'doughnut',
                data: {
                    labels: barData.map(d => ISO2_TO_NAME[d.country] || d.country),
                    datasets: [{
                        data: barData.map(d => Number(d.count || 0)),
                        backgroundColor: TTL_COLORS,
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    onClick: (e, elements) => {
                        if (elements.length) drillDownCountry(barData[elements[0].index].country);
                    },
                    plugins: {
                        legend: { position: 'right', labels: { color: '#94a3b8', padding: 10, font: { size: 11 } } },
                        tooltip: { callbacks: { label: ctx => `${ctx.label}: ${Number(ctx.raw || 0).toLocaleString()} ${t('orderUnit')} (${fmtPct(ctx.raw, pieTotal)})` } }
                    },
                    cutout: '52%'
                },
                plugins: [doughnutValueLabelPlugin(barData, d => ISO2_TO_NAME[d.country] || d.country, pieTotal)]
            });
        }
    }

    async function loadMonthlyChart() {
        const data = await apiFetch(API + '/api/dashboard/monthly_trend');
        applyMonthlyMetricSelection();
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        if (!selected.length) {
            document.querySelector('#monthlyMetricToggles input[value="count"]').checked = true;
            selected.push('count');
        }
        const metricConfig = {
            count: { label: t('shipmentCount'), field: 'count', type: 'bar', yAxisID: 'y', color: 'rgba(59,130,246,0.65)', border: '#3b82f6', order: 4, format: v => Number(v || 0).toLocaleString() },
            weight: { label: t('weightKg'), field: 'weight', type: 'line', yAxisID: 'y1', color: 'rgba(245,158,11,0.14)', border: '#f59e0b', order: 3, format: v => Number(v || 0).toLocaleString() + ' kg' },
            volume: { label: '体积 m³', field: 'volume', type: 'line', yAxisID: 'y2', color: 'rgba(6,182,212,0.12)', border: '#06b6d4', order: 2, format: v => Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' m³' },
            price: { label: '费用', field: 'price', type: 'line', yAxisID: 'y3', color: 'rgba(34,197,94,0.12)', border: '#22c55e', order: 1, format: v => '$' + Number(v || 0).toLocaleString() }
        };
        const datasets = selected.map(key => {
            const cfg = metricConfig[key];
            return {
                label: cfg.label,
                data: data.map(d => Number(d[cfg.field] || 0)),
                type: cfg.type,
                backgroundColor: cfg.color,
                borderColor: cfg.border,
                borderWidth: cfg.type === 'line' ? 2 : 0,
                pointRadius: cfg.type === 'line' ? 4 : 0,
                pointBackgroundColor: cfg.border,
                borderRadius: cfg.type === 'bar' ? 6 : 0,
                fill: cfg.type === 'line',
                yAxisID: cfg.yAxisID,
                order: cfg.order,
                metricKey: key
            };
        });
        const ctx = document.getElementById('chart-monthly').getContext('2d');
        if (charts.monthly) charts.monthly.destroy();
        charts.monthly = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.map(d => d.month),
                datasets
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${metricConfig[ctx.dataset.metricKey]?.format(ctx.raw) || ctx.raw}` } }
                },
                scales: {
                    x: { grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8' } },
                    y: { display: selected.includes('count'), position: 'left', grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8' }, title: { display: true, text: t('shipmentCount'), color: '#94a3b8' } },
                    y1: { display: selected.includes('weight'), position: 'right', grid: { display: false }, ticks: { color: '#f59e0b', callback: v => Number(v).toLocaleString() + ' kg' }, title: { display: true, text: t('weightKg'), color: '#f59e0b' } },
                    y2: { display: selected.includes('volume'), position: 'right', grid: { display: false }, ticks: { color: '#06b6d4', callback: v => Number(v).toLocaleString() + ' m³' }, title: { display: true, text: '体积', color: '#06b6d4' } },
                    y3: { display: selected.includes('price'), position: 'right', grid: { display: false }, ticks: { color: '#22c55e', callback: v => '$' + Number(v).toLocaleString() }, title: { display: true, text: '费用', color: '#22c55e' } }
                }
            }
        });
    }

    function saveMonthlyMetricSelection() {
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        localStorage.setItem('vn12_monthly_metrics', JSON.stringify(selected.length ? selected : ['count']));
    }

    function applyMonthlyMetricSelection() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem('vn12_monthly_metrics') || 'null'); } catch {}
        if (!Array.isArray(saved) || !saved.length) return;
        document.querySelectorAll('#monthlyMetricToggles input').forEach(input => {
            input.checked = saved.includes(input.value);
        });
    }

    // ===== 物流清单 =====
    async function loadShipments() {
        const search = document.getElementById('search-input')?.value || '';
        const params = new URLSearchParams({
            page: currentPage,
            per_page: shipmentPerPage,
            ds: currentFilterDs,
            type: currentFilterType,
            country: currentFilterCountry,
            warehouse: currentFilterWarehouse,
            verify: currentFilterVerify,
            pickup_month: currentFilterPickupMonth || currentFilterMonth,
            actual_delivery_month: currentFilterActualDeliveryMonth,
            sort_by: shipmentSortBy,
            sort_dir: shipmentSortDir,
            search: search
        });
        const data = await apiFetch(API + '/api/shipments?' + params);
        renderShipmentsTable(data);
        renderPagination(data);
    }

    function setShipmentPerPage(value) {
        shipmentPerPage = Number(value || 20);
        localStorage.setItem('vn22_shipment_per_page', String(shipmentPerPage));
        currentPage = 1;
        loadShipments();
    }

    function updateShipmentFiltersUI() {
        const dsSelect = document.getElementById('th-filter-ds');
        const typeSelect = document.getElementById('th-filter-type');
        const countrySelect = document.getElementById('th-filter-country');
        const verifySelect = document.getElementById('th-filter-verify');
        const pickupSelect = document.getElementById('th-filter-pickup-month');
        const actualSelect = document.getElementById('th-filter-actual-month');
        const perPageSelect = document.getElementById('shipmentPerPage');
        if (dsSelect) { dsSelect.value = currentFilterDs; dsSelect.classList.toggle('has-value', !!currentFilterDs); }
        if (typeSelect) { typeSelect.value = currentFilterType; typeSelect.classList.toggle('has-value', !!currentFilterType); }
        if (countrySelect) { countrySelect.value = currentFilterCountry; countrySelect.classList.toggle('has-value', !!currentFilterCountry); }
        if (verifySelect) { verifySelect.value = currentFilterVerify; verifySelect.classList.toggle('has-value', !!currentFilterVerify); }
        if (pickupSelect) { pickupSelect.value = currentFilterPickupMonth || currentFilterMonth; pickupSelect.classList.toggle('has-value', !!pickupSelect.value); }
        if (actualSelect) { actualSelect.value = currentFilterActualDeliveryMonth; actualSelect.classList.toggle('has-value', !!currentFilterActualDeliveryMonth); }
        if (perPageSelect) perPageSelect.value = String(shipmentPerPage);
        document.querySelectorAll('#shipmentsTable th.sortable').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.sort === shipmentSortBy && shipmentSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.sort === shipmentSortBy && shipmentSortDir === 'desc');
        });
    }

    function renderShipmentsTable(data) {
        const tbody = document.getElementById('shipments-tbody');
        const selectAll = document.getElementById('shipment-select-all');
        if (selectAll) selectAll.checked = false;
        if (!data.shipments.length) {
            tbody.innerHTML = '<tr><td colspan="14" style="text-align:center;color:var(--text-muted);padding:32px;">暂无数据</td></tr>';
            return;
        }
        tbody.innerHTML = data.shipments.map(s => {
            const ds = s.display_status || '运输中';
            const statusClass = ds === '已交付' ? 'status-delivered' : ds === '待核实' ? 'status-pending_verify' : ds === '异常单' ? 'status-canceled' : 'status-in_transport';
            const typeClass = 'type-' + (s.shipment_type || '');
            const dd = s.delivery_date || '';
            const ddDate = dd ? dd.split(' ')[0] : '-';
            const actualDd = s.actual_delivery_date || '';
            const actualDdDate = actualDd ? actualDd.split(' ')[0] : '';
            const isLocked = s.delivery_locked == 1;
            const stt = s.stt_number || '';
            const bid = s.booking_id || '';
            const bidAttr = escapeHtml(bid);
            const trackUrl = stt ? `https://www.dbschenker.com/app/tracking-public/?refNumber=${encodeURIComponent(stt)}` : '';
            const primaryId = stt || bid || '-';
            const detailId = stt || bid || '';

            const addrParts = [
                s.consignee_name || '',
                s.consignee_name2 || '',
                s.consignee_street || '',
                s.consignee_street2 || ''
            ].filter(p => p.trim());
            const addrInfo = addrParts.join(', ') || '-';

            let workdays = '-';
            if (actualDdDate && actualDdDate !== '-' && s.pickup_date) {
                workdays = calcWorkdays(s.pickup_date.split(' ')[0], actualDdDate);
            }

            const actualDisplay = actualDdDate ? `${actualDdDate} 🔒` : '-';
            const selectable = true;
            const detailAttr = escapeHtml(detailId);
            const sttDisplay = detailId ? `<button type="button" class="link-btn" data-shipment-detail="${detailAttr}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" title="查看物流详情 / 维护状态" style="padding:0;font-family:monospace;font-size:12px;font-weight:700">${escapeHtml(primaryId)}</button>` : escapeHtml(primaryId);
            return `<tr>
                <td style="text-align:center"><input type="checkbox" class="shipment-select" value="${bidAttr}" ${selectable ? '' : 'disabled'} title="选择后可批量核实或移入回收站"></td>
                <td style="font-family:monospace;font-size:12px;color:var(--text-secondary)">${sttDisplay}</td>
                <td><span class="status-badge ${statusClass}">${escapeHtml(ds)}</span></td>
                <td><span class="type-tag ${typeClass}">${escapeHtml(s.shipment_type_label || s.shipment_type || '')}</span></td>
                <td>${shipmentCountryDisplay(s)}</td>
                <td class="col-detail">${escapeHtml(s.consignee_city || '-')}</td>
                <td class="col-detail" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;color:var(--text-secondary)" title="${escapeHtml(addrInfo)}">${escapeHtml(addrInfo)}</td>
                <td>${escapeHtml((s.pickup_date || '').split(' ')[0] || '-')}</td>
                <td class="col-detail">${escapeHtml(ddDate)}</td>
                <td class="col-detail" style="font-size:12px;font-weight:500;color:${workdays !== '-' ? 'var(--accent)' : 'var(--text-muted)'}">${workdays}</td>
                <td style="font-size:12px;color:${actualDdDate ? 'var(--success)' : 'var(--text-muted)'}">${escapeHtml(actualDisplay)}</td>
                <td class="col-detail">${s.total_weight ? Number(s.total_weight).toLocaleString() : '-'}</td>
                <td><span class="badge ${s.verify_status === '已验收' ? 'badge-delivered' : s.verify_status === '待验收' ? 'badge-pending' : ''}" style="${s.verify_status === '未关联' ? 'color:var(--text-muted)' : ''}">${escapeHtml(s.verify_status || '未关联')}</span></td>
                <td style="text-align:right;font-weight:500;color:${s.accepted_amount != null ? 'var(--success)' : 'var(--text-muted)'}" title="${escapeHtml((s.accepted_invoices || []).join(', '))}">${s.accepted_amount != null ? Number(s.accepted_amount).toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' PLN' : '-'}</td>
            </tr>`;
        }).join('');
    }

    function calcWorkdays(startStr, endStr) {
        if (!startStr || !endStr || startStr === '-' || endStr === '-') return '-';
        const start = new Date(startStr);
        const end = new Date(endStr);
        if (isNaN(start) || isNaN(end)) return '-';
        let count = 0;
        const cur = new Date(start);
        while (cur < end) {
            const day = cur.getDay();
            if (day !== 0 && day !== 6) count++;
            cur.setDate(cur.getDate() + 1);
        }
        return count;
    }

    function renderPagination(data) {
        const div = document.getElementById('pagination');
        if (data.total_pages <= 1) { div.innerHTML = ''; return; }
        let html = `<button class="page-btn" ${data.page <= 1 ? 'disabled' : ''} onclick="goPage(${data.page - 1})">上一页</button>`;
        for (let i = 1; i <= data.total_pages; i++) {
            if (data.total_pages > 7 && Math.abs(i - data.page) > 2 && i !== 1 && i !== data.total_pages) {
                if (i === data.page - 3 || i === data.page + 3) html += '<span style="color:var(--text-muted);padding:6px">...</span>';
                continue;
            }
            html += `<button class="page-btn ${i === data.page ? 'active' : ''}" onclick="goPage(${i})">${i}</button>`;
        }
        html += `<button class="page-btn" ${data.page >= data.total_pages ? 'disabled' : ''} onclick="goPage(${data.page + 1})">下一页</button>`;
        div.innerHTML = html;
    }

    function goPage(p) { currentPage = p; loadShipments(); }
    function toggleShipmentDetailCols() { document.getElementById('shipmentsTable').classList.toggle('compact'); }

    function setShipmentSort(key) {
        if (!key) return;
        if (shipmentSortBy === key) shipmentSortDir = shipmentSortDir === 'asc' ? 'desc' : 'asc';
        else {
            shipmentSortBy = key;
            shipmentSortDir = ['stt_number', 'display_status', 'shipment_type', 'country', 'consignee_city', 'verify_status'].includes(key) ? 'asc' : 'desc';
        }
        currentPage = 1;
        updateShipmentFiltersUI();
        loadShipments();
    }

    function filterByDsVal(val) {
        currentFilterDs = val;
        document.getElementById('th-filter-ds').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function filterByTypeVal(val) {
        currentFilterType = val;
        document.getElementById('th-filter-type').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function filterByCountryVal(val) {
        currentFilterCountry = val;
        currentFilterMonth = '';
        document.getElementById('th-filter-country').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function filterByVerifyVal(val) {
        currentFilterVerify = val;
        document.getElementById('th-filter-verify').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function filterByPickupMonth(val) {
        currentFilterPickupMonth = val;
        currentFilterMonth = val;
        document.getElementById('th-filter-pickup-month').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function filterByActualDeliveryMonth(val) {
        currentFilterActualDeliveryMonth = val;
        document.getElementById('th-filter-actual-month').classList.toggle('has-value', !!val);
        currentPage = 1;
        loadShipments();
    }
    function clearFilters() {
        currentFilterDs = '';
        currentFilterType = '';
        currentFilterCountry = '';
        currentFilterWarehouse = '';
        currentFilterVerify = '';
        currentFilterMonth = '';
        currentFilterPickupMonth = '';
        currentFilterActualDeliveryMonth = '';
        shipmentSortBy = '';
        shipmentSortDir = 'desc';
        currentPage = 1;
        document.getElementById('search-input').value = '';
        document.getElementById('shipments-title').textContent = '物流清单';
        ['th-filter-ds', 'th-filter-type', 'th-filter-country', 'th-filter-verify', 'th-filter-pickup-month', 'th-filter-actual-month'].forEach(id => {
            const el = document.getElementById(id);
            el.value = '';
            el.classList.remove('has-value');
        });
        loadShipments();
    }

    function filterShipments() { currentPage = 1; loadShipments(); }

    // ===== 快捷追踪 =====
    function trackShipment() {
        const val = document.getElementById('track-input').value.trim();
        if (!val) return;
        window.open(`https://www.dbschenker.com/app/my-shipments/overview`, '_blank');
    }
    document.getElementById('track-input')?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') trackShipment();
    });

    async function openSelectedShipmentEditor() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) {
            showToast('请先勾选运单，或直接点击 STT / Booking 查看详情和追踪', 'error');
            return;
        }
        if (ids.length > 1) {
            openShipmentBatchEditor(ids);
            return;
        }
        openShipmentEditorById(ids[0]);
    }

    function openShipmentBatchEditor(bookingIds = []) {
        const ids = [...new Set((bookingIds || []).map(x => String(x || '').trim()).filter(Boolean))];
        if (!ids.length) {
            showToast('请先勾选需要批量编辑的运单', 'error');
            return;
        }
        document.getElementById('shipmentBatchEditTitle').textContent = `批量编辑运单（${ids.length} 条）`;
        document.getElementById('shipmentBatchEditBody').innerHTML = `
            <div class="modal-detail-summary">
                <div>
                    <div class="modal-detail-title">已选择 ${ids.length} 条运单</div>
                    <div class="modal-detail-subtitle">批量维护只处理共性字段；单条详情和追踪请点击 STT / Booking。</div>
                </div>
                <span class="badge badge-pending">批量</span>
            </div>
            <div class="modal-detail-field" style="margin-bottom:12px">
                <div class="modal-detail-label">已选运单</div>
                <div class="modal-detail-value mono" style="max-height:76px;overflow:auto">${ids.map(escapeHtml).join(' / ')}</div>
            </div>
            <div class="batch-action-grid">
                <div class="batch-action-card">
                    <h4>批量修改需求国家</h4>
                    <p>用于少数需求国和收货国不同的订单，保留原始收货国家。</p>
                    <button class="btn btn-primary btn-sm" onclick="batchChangeDemandCountry()">修改需求国家</button>
                </div>
                <div class="batch-action-card">
                    <h4>批量标记已交付</h4>
                    <p>为所选运单设置同一个实际交付日期，并锁定状态。</p>
                    <button class="btn btn-success btn-sm" onclick="batchMarkDeliveredWithDate()">标记已交付</button>
                </div>
                <div class="batch-action-card">
                    <h4>批量标记异常</h4>
                    <p>将未交付的所选运单标记为异常单。</p>
                    <button class="btn btn-secondary btn-sm" onclick="batchMarkAbnormal()">标记异常</button>
                </div>
                <div class="batch-action-card">
                    <h4>移入回收站</h4>
                    <p>用于错误、无效或不应统计的异常运单，需要填写原因。</p>
                    <button class="btn btn-danger btn-sm" onclick="closeModal('shipmentBatchEditModal');openShipmentRecycleDialog()">移入回收站</button>
                </div>
            </div>`;
        document.getElementById('shipmentBatchEditActions').innerHTML = `
            <div class="modal-action-group">
                <button class="btn btn-secondary btn-sm" onclick="closeModal('shipmentBatchEditModal')">关闭</button>
            </div>`;
        openModal('shipmentBatchEditModal');
    }

    async function openShipmentEditorById(shipmentId) {
        const normalizedId = String(shipmentId || '').trim();
        if (!normalizedId) {
            showToast('缺少运单编号，无法打开详情', 'error');
            return;
        }
        const data = await apiFetch(API + '/api/shipments?search=' + encodeURIComponent(normalizedId) + '&per_page=20');
        const shipment = (data.shipments || []).find(s => s.booking_id === normalizedId || s.stt_number === normalizedId) || (data.shipments || [])[0];
        if (!shipment) {
            showToast('未找到对应运单', 'error');
            return;
        }
        currentEditShipment = shipment;
        const ds = shipment.display_status || '运输中';
        const stt = shipment.stt_number || '-';
        const demand = demandCountryOfShipment(shipment) || '-';
        const consignee = consigneeCountryOfShipment(shipment) || '-';
        const bookingId = shipment.booking_id || '';
        const bookingAttr = escapeHtml(shipment.booking_id || '');
        const demandAttr = escapeHtml(demand === '-' ? '' : demand);
        const trackingUrl = stt && stt !== '-' ? `https://www.dbschenker.com/app/tracking-public/?refNumber=${encodeURIComponent(stt)}` : '';
        const trackingAttr = escapeHtml(trackingUrl);
        const shipmentTypeText = shipment.shipment_type_label || shipment.shipment_type || '-';
        const pickupDateText = (shipment.pickup_date || '').split(' ')[0] || '-';
        const deliveryDateText = (shipment.actual_delivery_date || '').split(' ')[0] || '-';
        const weightText = Number(shipment.total_weight || 0) ? `${Number(shipment.total_weight || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} kg` : '-';
        const volumeText = Number(shipment.total_volume || 0) ? `${Number(shipment.total_volume || 0).toLocaleString(undefined, { maximumFractionDigits: 3 })} m³` : '-';
        const amountText = shipment.accepted_amount != null ? Number(shipment.accepted_amount).toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' PLN' : '-';
        const trackButton = trackingUrl ? `<button class="btn btn-secondary btn-sm" data-shipment-action="track" data-tracking-url="${trackingAttr}">追踪网页</button>` : '';
        const demandButton = `<button class="btn btn-primary btn-sm" data-shipment-action="demand-country" data-booking-id="${bookingAttr}" data-current-demand="${demandAttr}">修改需求国家</button>`;
        let statusButtons = '';
        if (ds === '异常单') {
            statusButtons = `
                <button class="btn btn-secondary btn-sm" data-shipment-action="unmark-abnormal" data-booking-id="${bookingAttr}">取消异常</button>
                <button class="btn btn-danger btn-sm" data-shipment-action="recycle" data-booking-id="${bookingAttr}">移入回收站</button>`;
        } else if (ds !== '已交付') {
            statusButtons = `<button class="btn btn-danger btn-sm" data-shipment-action="mark-abnormal" data-booking-id="${bookingAttr}">标记异常</button>`;
        }
        let deliveryButtons = '';
        if (ds === '已交付') {
            deliveryButtons = `<button class="btn btn-warning btn-sm" data-shipment-action="unmark-delivered" data-booking-id="${bookingAttr}">撤销交付</button>`;
        } else if (ds !== '异常单') {
            deliveryButtons = `
                <button class="btn btn-primary btn-sm" data-shipment-action="delivery-date" data-booking-id="${bookingAttr}">到货时间</button>
                <button class="btn btn-success btn-sm" data-shipment-action="mark-delivered" data-booking-id="${bookingAttr}">已交付</button>`;
        }
        document.getElementById('shipmentEditTitle').textContent = '运单详情';
        document.getElementById('shipmentEditBody').innerHTML = `
            <div class="modal-detail-summary">
                <div>
                    <div class="modal-detail-title">${escapeHtml(bookingId || stt || '-')}</div>
                    <div class="modal-detail-subtitle">单条运单详情与状态维护</div>
                </div>
                <div class="modal-summary-actions">
                    ${trackButton}
                    <span class="status-badge ${ds === '已交付' ? 'status-delivered' : ds === '待核实' ? 'status-pending_verify' : ds === '异常单' ? 'status-canceled' : 'status-in_transport'}">${escapeHtml(ds)}</span>
                    ${statusButtons}
                </div>
            </div>
            <div class="modal-detail-grid shipment-detail-grid">
                <div class="modal-detail-field"><div class="modal-detail-label">物流类型</div><div class="modal-detail-value">${escapeHtml(shipmentTypeText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">需求国家 / 收货国家</div><div class="modal-detail-value">${escapeHtml(demand)} / ${escapeHtml(consignee)}</div><div class="modal-field-actions">${demandButton}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">发货日期</div><div class="modal-detail-value">${escapeHtml(pickupDateText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">实际交付</div><div class="modal-detail-value">${escapeHtml(deliveryDateText)}</div>${deliveryButtons ? `<div class="modal-field-actions">${deliveryButtons}</div>` : ''}</div>
                <div class="modal-detail-field"><div class="modal-detail-label">体积 / 重量</div><div class="modal-detail-value">${escapeHtml(volumeText)} / ${escapeHtml(weightText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">验收金额</div><div class="modal-detail-value">${escapeHtml(amountText)}</div></div>
            </div>
        `;
        document.getElementById('shipmentEditActions').innerHTML = `<div class="modal-action-group"><button class="btn btn-secondary btn-sm" onclick="closeModal('shipmentEditModal')">关闭</button></div>`;
        openModal('shipmentEditModal');
    }

    // ===== 标记已交付 / 撤销 =====
    let pendingBookingId = null;

	    async function openDeliveryDateDialog(bookingId) {
	        pendingBookingId = bookingId;
	        openModal('delivery-date-dialog');
	        document.getElementById('delivery-date-input').value = new Date().toISOString().split('T')[0];
	        document.getElementById('delivery-date-input').focus();
	    }

	    function closeDeliveryDateDialog() {
	        closeModal('delivery-date-dialog');
	        pendingBookingId = null;
	    }

    async function confirmDeliveryDate() {
        const dateVal = document.getElementById('delivery-date-input').value;
        if (!dateVal || !pendingBookingId) return;
        const bid = pendingBookingId;
        closeDeliveryDateDialog();
        try {
            const data = await apiFetch(API + '/api/shipments/mark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bid, delivery_date: dateVal })
            });
            if (data.success) {
                showToast('已标记为已交付', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }

    async function markDelivered(bookingId) {
        if (!confirm('确认标记该运单为已交付（日期为今天）？')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/mark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已标记为已交付', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }
    async function unmarkDelivered(bookingId) {
        if (!confirm('确认撤销已交付标记？撤销后该单将变为待核实状态。')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/unmark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已撤销交付标记', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '撤销失败', 'error');
            }
        } catch (e) {
            showToast('撤销失败: ' + e.message, 'error');
        }
    }
    async function markAbnormal(bookingId) {
        if (!confirm('确认将该运单标记为异常单？')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/mark_abnormal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已标记为异常单', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }
	    async function unmarkAbnormal(bookingId) {
	        if (!confirm('确认取消异常标记？')) return;
	        try {
	            const data = await apiFetch(API + '/api/shipments/unmark_abnormal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已取消异常标记', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '取消失败', 'error');
            }
	        } catch (e) {
	            showToast('取消失败: ' + e.message, 'error');
	        }
	    }

	    function getSelectedShipmentIds() {
	        return [...new Set([...document.querySelectorAll('.shipment-select:checked:not(:disabled)')].map(el => el.value).filter(Boolean))];
	    }

    function toggleShipmentSelectAll(checked) {
        document.querySelectorAll('.shipment-select:not(:disabled)').forEach(el => { el.checked = checked; });
    }

	    async function openShipmentRecycleDialog(bookingId) {
	        const selectedIds = getSelectedShipmentIds();
	        const bookingIds = selectedIds.length ? selectedIds : (bookingId ? [bookingId] : []);
	        if (!bookingIds.length) {
	            showToast('请先选择异常单', 'error');
	            return;
	        }
        const reason = prompt(`请输入移入回收站原因（${bookingIds.length} 条）：`);
        if (reason === null) return;
        if (!reason.trim()) {
            showToast('必须填写原因', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/recycle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: bookingIds, reason, password })
                });
                if (data.success) {
                    showToast(`已移入回收站：${data.recycled} 条`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '移入失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('移入失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function openRecycleBin() {
        openModal('shipmentRecycleModal');
        await loadRecycleBin();
    }

    async function loadRecycleBin() {
        const tbody = document.getElementById('recycleBinBody');
        if (!tbody) return;
        const search = document.getElementById('recycleSearchInput')?.value || '';
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:20px">加载中...</td></tr>';
        try {
            const data = await apiFetch(API + '/api/shipments/recycle_bin?search=' + encodeURIComponent(search));
            const rows = data.shipments || [];
            if (!rows.length) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:20px">回收站为空</td></tr>';
                return;
            }
            tbody.innerHTML = rows.map(s => `
                <tr>
                    <td style="font-family:monospace">${escapeHtml(s.booking_id || '-')}</td>
                    <td style="font-family:monospace">${escapeHtml(s.stt_number || '-')}</td>
                    <td>${escapeHtml(s.consignee_country_code || '-')}</td>
                    <td><span class="status-badge status-canceled">${escapeHtml(s.display_status || '异常单')}</span></td>
                    <td>${escapeHtml(s.recycled_at || '-')}</td>
                    <td style="max-width:280px;white-space:normal">${escapeHtml(s.recycle_reason || '-')}</td>
                    <td><button class="btn btn-secondary btn-sm" onclick="restoreShipmentFromRecycle(${jsArg(s.booking_id || '')})">恢复</button></td>
                </tr>
            `).join('');
        } catch (e) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--danger);padding:20px">加载失败：${escapeHtml(e.message)}</td></tr>`;
        }
    }

    async function restoreShipmentFromRecycle(bookingId) {
        if (!bookingId) return;
        const password = askMaintenancePassword('请输入恢复密码：');
        if (password === null) return;
        try {
            const data = await apiFetch(API + '/api/shipments/recycle/restore', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_ids: [bookingId], password })
            });
            if (data.success) {
                showToast('已恢复运单', 'success');
                loadRecycleBin();
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '恢复失败', 'error');
            }
        } catch (e) {
            showToast('恢复失败: ' + e.message, 'error');
        }
    }

    async function changeDemandCountry(bookingId, currentDemand = '') {
        if (!bookingId) return;
        const demand = prompt('请输入需求国家代码，例如 DE / PL / FR：', currentDemand || '');
        if (demand === null) return;
        const normalized = demand.trim().toUpperCase();
        if (!/^[A-Z]{2,3}$/.test(normalized)) {
            showToast('请输入正确的国家代码，例如 DE / PL / FR', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/demand_country', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: [bookingId], demand_country: normalized, password })
                });
                if (data.success) {
                    showToast(`需求国家已改为 ${data.demand_country}`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '修改失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('修改失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function batchChangeDemandCountry() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要修改的运单', 'error');
        const demand = prompt(`请输入需求国家代码（${ids.length} 条），例如 DE / PL / FR：`, '');
        if (demand === null) return;
        const normalized = demand.trim().toUpperCase();
        if (!/^[A-Z]{2,3}$/.test(normalized)) {
            showToast('请输入正确的国家代码，例如 DE / PL / FR', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/demand_country', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: ids, demand_country: normalized, password })
                });
                if (data.success) {
                    closeModal('shipmentBatchEditModal');
                    showToast(`已更新需求国家：${data.updated || 0} 条`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '批量修改失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('批量修改失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function batchMarkDeliveredWithDate() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要标记的运单', 'error');
        const today = new Date().toISOString().split('T')[0];
        const deliveryDate = prompt(`请输入实际交付日期（${ids.length} 条）：`, today);
        if (deliveryDate === null) return;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(deliveryDate.trim())) {
            showToast('日期格式应为 YYYY-MM-DD', 'error');
            return;
        }
        if (!confirm(`确认将 ${ids.length} 条运单标记为已交付？`)) return;
        const result = await runShipmentBatchRequests(ids, '/api/shipments/mark_delivered', id => ({ booking_id: id, delivery_date: deliveryDate.trim() }));
        closeModal('shipmentBatchEditModal');
        showToast(`批量已交付完成：成功 ${result.ok} 条，失败 ${result.fail} 条`, result.fail ? 'error' : 'success');
        loadShipments();
        loadDashboard();
    }

    async function batchMarkAbnormal() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要标记的运单', 'error');
        if (!confirm(`确认将 ${ids.length} 条运单标记为异常单？`)) return;
        const result = await runShipmentBatchRequests(ids, '/api/shipments/mark_abnormal', id => ({ booking_id: id }));
        closeModal('shipmentBatchEditModal');
        showToast(`批量异常标记完成：成功 ${result.ok} 条，失败 ${result.fail} 条`, result.fail ? 'error' : 'success');
        loadShipments();
        loadDashboard();
    }

    async function runShipmentBatchRequests(ids, url, payloadFactory) {
        let ok = 0;
        let fail = 0;
        for (const id of ids) {
            try {
                const data = await apiFetch(API + url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payloadFactory(id))
                });
                if (data && data.success) ok += 1;
                else fail += 1;
            } catch (e) {
                fail += 1;
            }
        }
        return { ok, fail };
    }

	    document.addEventListener('click', (event) => {
	        const btn = event.target.closest('[data-shipment-action]');
	        if (!btn) return;
	        event.preventDefault();
	        event.stopPropagation();
	        const action = btn.dataset.shipmentAction;
            if (action === 'track') {
                const url = btn.dataset.trackingUrl || '';
                if (url) window.open(url, '_blank');
                return;
            }
	        const bookingId = btn.dataset.bookingId || '';
	        if (!bookingId) {
	            showToast('缺少 Booking ID，无法操作', 'error');
	            return;
	        }
	        closeModal('shipmentEditModal');
	        if (action === 'delivery-date') {
	            openDeliveryDateDialog(bookingId);
	        } else if (action === 'mark-delivered') {
	            markDelivered(bookingId);
	        } else if (action === 'mark-abnormal') {
	            markAbnormal(bookingId);
	        } else if (action === 'unmark-delivered') {
	            unmarkDelivered(bookingId);
	        } else if (action === 'unmark-abnormal') {
	            unmarkAbnormal(bookingId);
	        } else if (action === 'recycle') {
	            openShipmentRecycleDialog(bookingId);
	        } else if (action === 'demand-country') {
	            changeDemandCountry(bookingId, btn.dataset.currentDemand || '');
	        }
	    });

	    Object.assign(window, {
	        openDeliveryDateDialog,
	        closeDeliveryDateDialog,
	        confirmDeliveryDate,
	        markDelivered,
	        unmarkDelivered,
	        markAbnormal,
	        unmarkAbnormal,
	        openShipmentRecycleDialog,
            openShipmentBatchEditor,
            batchChangeDemandCountry,
            batchMarkDeliveredWithDate,
            batchMarkAbnormal,
	        toggleShipmentSelectAll,
	        openRecycleBin,
	        loadRecycleBin,
	        restoreShipmentFromRecycle
	    });

	    // ===== 批量自动核实 =====
    let verifyPolling = null;
    async function startVerify() {
        const btn = document.getElementById('verify-btn');
        const progressWrap = document.getElementById('verify-progress-wrap');
        const progressFill = document.getElementById('verify-progress-fill');
        const verifyText = document.getElementById('verify-text');
        btn.disabled = true;
        btn.textContent = '启动中...';
        progressWrap.style.display = 'block';
        try {
            const data = await apiFetch(API + '/api/shipments/verify', { method: 'POST' });
            if (data.error) {
                // 核实任务卡住（409），自动重置
                if (data.progress !== undefined && data.total !== undefined) {
                    verifyText.textContent = `任务卡住 (${data.progress}/${data.total})，正在重置...`;
                    await apiFetch(API + '/api/shipments/verify/reset', { method: 'POST' });
                    await new Promise(r => setTimeout(r, 500));
                    btn.disabled = false;
                    btn.textContent = '批量核实';
                    verifyText.textContent = '已重置，请重新点击核实';
                    progressWrap.style.display = 'none';
                    return;
                }
                btn.textContent = '批量核实';
                btn.disabled = false;
                verifyText.textContent = data.error;
                return;
            }
            if (data.total === 0) {
                btn.disabled = false;
                btn.textContent = '批量核实';
                verifyText.textContent = '没有需要核实的运单';
                progressWrap.style.display = 'none';
                return;
            }
            btn.textContent = '核实中...';
            verifyPolling = setInterval(async () => {
                const status = await apiFetch(API + '/api/shipments/verify/status');
                const pct = status.total ? Math.round(status.progress / status.total * 100) : 0;
                progressFill.style.width = pct + '%';
                verifyText.textContent = `${status.progress} / ${status.total}`;
                if (!status.running) {
                    clearInterval(verifyPolling);
                    btn.disabled = false;
                    btn.textContent = '批量核实';
                    const delivered = status.delivered_count || 0;
                    const inTransport = status.in_transport_count || 0;
                    const cancelled = status.cancelled_count || 0;
                    const unresolved = status.unresolved_count || 0;
                    const failed = status.failed_count || 0;
                    if (status.error) {
                        verifyText.textContent = '核实出错: ' + status.error;
                    } else {
                        let msg = `核实完成，新增 ${delivered} 单已交付`;
                        if (inTransport > 0) msg += `，${inTransport} 单仍在运输`;
                        if (cancelled > 0) msg += `，${cancelled} 单已取消`;
                        if (unresolved > 0) msg += `，${unresolved} 单未识别`;
                        if (failed > 0) msg += `，${failed} 单抓取失败`;
                        if (unresolved > 0 || failed > 0) msg += '（状态未改动）';
                        verifyText.textContent = msg;
                    }
                    progressFill.style.width = '100%';
                    loadShipments();
                    loadDashboard();
                }
            }, 3000);
        } catch (e) {
            btn.disabled = false;
            btn.textContent = '批量核实';
            verifyText.textContent = '启动失败: ' + e.message;
        }
    }

    // ===== 数据导入 =====
    function updateSelectedFileLabel(input, targetId, emptyText) {
        const el = document.getElementById(targetId);
        if (!el) return;
        const files = Array.from(input?.files || []);
        if (!files.length) {
            el.textContent = emptyText || '选择文件';
            return;
        }
        el.textContent = files.length === 1
            ? files[0].name
            : files.map(f => f.name).slice(0, 2).join('；') + (files.length > 2 ? ` 等 ${files.length} 个文件` : '');
    }

    function submitLogisticsAutoImport() {
        const input = document.getElementById('file-logistics_auto');
        if (!input?.files?.length) return toast('请先选择物流 Excel 文件', 'error');
        uploadLogisticsAuto(input);
    }

    function handleLogisticsAutoFileSelected(input) {
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
        if (input?.files?.length) submitLogisticsAutoImport();
    }

    function submitInvoiceImport(type) {
        const input = document.getElementById('logistics-invoice-file');
        if (!input?.files?.length) return toast('请先选择发票 PDF 文件', 'error');
        uploadInvoice(input, type);
    }

    function inferInvoiceTypeFromFile(file) {
        const name = String(file?.name || '').toLowerCase();
        const warehouseKeywords = ['warehouse', 'warehousing', 'storage', 'handling', 'operation', 'operacja', 'magazyn', '仓储', '仓库', '操作'];
        return warehouseKeywords.some(k => name.includes(k)) ? 'warehouse' : 'logistics';
    }

    function invoiceTypeLabel(type) {
        return type === 'warehouse' ? '仓储操作费用发票' : '物流累计发票';
    }

    function selectedInvoiceType() {
        const input = document.getElementById('logistics-invoice-file');
        return inferInvoiceTypeFromFile(input?.files?.[0]);
    }

    function selectInvoicePdfFile() {
        document.getElementById('logistics-invoice-file')?.click();
    }

    function handleInvoicePdfSelected() {
        syncInvoicePdfSelectionLabel();
        submitSelectedInvoiceImport();
    }

    function submitSelectedInvoiceImport() {
        const input = document.getElementById('logistics-invoice-file');
        if (!input?.files?.length) return toast('请先选择发票 PDF 文件', 'error');
        uploadInvoice(input, 'auto');
    }

    function syncInvoicePdfSelectionLabel() {
        const input = document.getElementById('logistics-invoice-file');
        updateSelectedFileLabel(input, 'invoicePdfFileName', '发票 PDF');
        const hint = document.getElementById('invoiceAutoTypeHint');
        if (!hint) return;
        if (!input?.files?.length) {
            hint.textContent = '自动识别发票类型';
            return;
        }
        const type = inferInvoiceTypeFromFile(input.files[0]);
        hint.textContent = `自动识别：${invoiceTypeLabel(type)}`;
    }

    async function uploadWithType(input, type) {
        if (!input.files.length) return;
        const file = input.files[0];
        if (!file.name.toLowerCase().endsWith('.xlsx') && !file.name.toLowerCase().endsWith('.xls')) {
            toast('请上传 Excel 文件（.xlsx 或 .xls）', 'error');
            input.value = '';
            return;
        }
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);
        const resultDiv = document.getElementById('result-' + type);
        if (!resultDiv) { toast('上传区域未找到: ' + type, 'error'); return; }
        resultDiv.className = 'import-result loading';
        resultDiv.textContent = '⏳ 导入中...';
        resultDiv.style.display = 'block';

        try {
            const data = await uploadFormWithProgress(API + '/api/shipments/import', formData, 'progress-' + type);
            if (data.error) {
                resultDiv.className = 'import-result error';
                resultDiv.textContent = '❌ ' + data.error;
            } else {
                resultDiv.className = 'import-result success';
                resultDiv.textContent = '✅ 成功导入 ' + (data.imported || 0) + ' 条';
                await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters()]);
                loadUploadRecords();
            }
        } catch (e) {
            resultDiv.className = 'import-result error';
            resultDiv.textContent = '❌ ' + (e.message || '上传失败');
            console.error('Upload error:', e);
        }
        input.value = '';
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
    }

    async function uploadLogisticsAuto(input) {
        const files = Array.from(input.files || []);
        const resultDiv = document.getElementById('result-logistics_auto');
        if (!resultDiv) return toast('物流一键导入区域未找到', 'error');
        if (!files.length) return;
        const bad = files.filter(file => !file.name.match(/\.(xlsx|xls)$/i));
        if (bad.length) {
            toast('请只上传 Excel 文件（.xlsx 或 .xls）', 'error');
            input.value = '';
            updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
            return;
        }
        const formData = new FormData();
        files.forEach(file => formData.append('files', file));
        resultDiv.className = 'import-result loading';
        resultDiv.textContent = `⏳ 正在自动识别并导入 ${files.length} 个物流文件...`;
        resultDiv.style.display = 'block';
        try {
            const data = await uploadFormWithProgress(API + '/api/shipments/import-auto', formData, 'progress-logistics_auto');
            if (data.error) {
                resultDiv.className = 'import-result error';
                resultDiv.textContent = '❌ ' + data.error;
            } else {
                const s = data.summary || {};
                const fileLines = (data.files || []).map(f => {
                    if (f.error) return `<div>${escapeHtml(f.filename || '-')}：${escapeHtml(f.error)}</div>`;
                    const c = f.type_counts || {};
                    return `<div>${escapeHtml(f.filename || '-')}：导入 ${f.imported || 0} 条，新增 ${f.inserted || 0}，更新 ${f.updated || 0}，中央仓 ${c.warehouse_central || 0}，家具仓 ${c.warehouse_furniture || 0}，调拨 ${c.direct || 0}</div>`;
                }).join('');
                resultDiv.className = 'import-result success';
                resultDiv.innerHTML = `
                    <div><b>✅ 物流一键导入完成</b></div>
                    <div>文件 ${data.file_count || files.length} 个；导入 ${s.imported || 0} 条；新增 ${s.inserted || 0}；更新 ${s.updated || 0}；跳过无 STT ${s.skipped_missing_stt || 0}；跳过旧日期 ${s.skipped_date || 0}</div>
                    <div>中央仓 ${s.type_counts?.warehouse_central || 0}；家具仓 ${s.type_counts?.warehouse_furniture || 0}；调拨 ${s.type_counts?.direct || 0}</div>
                    ${fileLines ? `<div style="margin-top:6px">${fileLines}</div>` : ''}
                `;
                await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters(), loadUploadRecords()]);
            }
        } catch (e) {
            resultDiv.className = 'import-result error';
            resultDiv.textContent = '❌ ' + (e.message || '上传失败');
            console.error('Logistics auto upload error:', e);
        }
        input.value = '';
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
    }

    // ===== 拖拽上传 =====
    ['warehouse', 'pl_domestic', 'intl_direct', 'logistics_auto'].forEach(type => {
        const zone = document.getElementById('import-' + type);
        if (!zone) return;
        zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.style.borderColor = 'var(--accent)'; });
        zone.addEventListener('dragleave', () => { zone.style.borderColor = 'var(--border)'; });
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            zone.style.borderColor = 'var(--border)';
            const input = document.getElementById('file-' + type);
            input.files = e.dataTransfer.files;
            if (type === 'logistics_auto') {
                updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
                uploadLogisticsAuto(input);
            }
            else uploadWithType(input, type);
        });
    });

    // ===== 企鹅动画 =====
    function spawnPenguin() {
        document.querySelectorAll('.penguin-wrap').forEach(el => el.remove());

        const wrap = document.createElement('div');
        wrap.className = 'penguin-wrap';
        wrap.innerHTML = `
            <div class="penguin-body" style="position:relative;display:inline-block;">
                <div class="penguin-sign">Welcome to Join the Conference</div>
                <img src="/static/penguin.gif" alt="QQ Penguin" style="width:200px;height:166px;object-fit:contain;margin-top:8px;" />
            </div>
        `;
        document.body.appendChild(wrap);

        setTimeout(() => {
            wrap.classList.add('hide');
            setTimeout(() => wrap.remove(), 700);
        }, 5000);
    }

    // ===================================================================
    //  WMS ( 库存概览 + 库存清单 + 操作 + 上传 + 发货 )
    // ===================================================================

    const TTL_COLORS = ['#3b82f6','#06b6d4','#22c55e','#eab308','#ef4444','#8b5cf6','#ec4899','#f97316','#14b8a6','#6366f1','#a855f7','#f43f5e'];
    const DEFAULT_CATEGORY_OPTIONS = ['ACRYLIC PROP','DUMMY','FURNITURE','GIFT','PROP','SECURITY SYSTEM','TOOLS/ACCESSORIES','TRAINING MATERIALS','UNIFORM','WOODEN OVERLAY'];
    const DEFAULT_CATEGORY2_OPTIONS = ['AUDIO','IOT','OTHER','PHONE','TABLET','WEARABLE'];
    const DEFAULT_INSTRUCTION_OPTIONS = ['DE','ITALY','PL','RHQ','UK','ES','FR','NL','BE','AT','CH','SE','NO','DK','FI'];
    const MANAGED_OPTIONS_KEY = 'vn12_managed_options';
    const INVENTORY_BREAKDOWN_KEY = 'vn12_inventory_breakdowns';
    let currentInvDashTab = 'breakdown';
    let pendingStockListFilters = null;
    let stockQualityFilter = '';
    const overdueState = {
        dos: { sortBy: 'ttl_amount', sortDir: 'desc', page: 1, perPage: 25, showDetails: false, filter: { keyword: '', category: '', category2: '', instruction: '' } },
        idle: { sortBy: 'ttl_amount', sortDir: 'desc', page: 1, perPage: 25, showDetails: false, filter: { keyword: '', category: '', category2: '', instruction: '' } }
    };

    function openStockListFromInventory(filters = {}) {
        const wh = document.getElementById('dashWarehouse')?.value || '';
        currentWarehouse = wh;
        pendingStockListFilters = {
            q: filters.q || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || '',
            quality: filters.quality || ''
        };
        stockPage = 1;
        switchPage('stocklist');
    }

    function applyPendingStockListFilters() {
        if (!pendingStockListFilters) return;
        const f = pendingStockListFilters;
        const setVal = (id, value) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.value = value || '';
            el.classList.toggle('has-value', Boolean(value));
        };
        setVal('stockSearch', f.q);
        setVal('filterCategory', f.category);
        setVal('filterCat2', f.category2);
        setVal('filterInstruction', f.instruction);
        stockQualityFilter = f.quality || '';
        pendingStockListFilters = null;
    }

    function switchInvDashTab(el) {
        document.querySelectorAll('#invDashTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active');
        currentInvDashTab = el.dataset.dtab; loadCurrentInvDashTab();
    }

    function loadCurrentInvDashTab() {
        const wh = document.getElementById('dashWarehouse').value;
        document.getElementById('inventoryBreakdownToggles').style.display = currentInvDashTab === 'breakdown' ? 'flex' : 'none';
        if (currentInvDashTab === 'breakdown') loadInventoryBreakdowns(wh);
        else if (currentInvDashTab === 'catTtl') loadCatTtl(wh);
        else if (currentInvDashTab === 'cat2Ttl') loadCat2Ttl(wh);
        else if (currentInvDashTab === 'instrTtl') loadInstrTtl(wh);
        else if (currentInvDashTab === 'dos180') loadDos180(wh);
        else if (currentInvDashTab === 'idle180') loadIdle180(wh);
    }

    async function loadInvDashboard() {
        const wh = document.getElementById('dashWarehouse').value;
        const [d, health] = await Promise.all([
            apiGet('/api/inventory/stats?warehouse=' + encodeURIComponent(wh)),
            apiGet('/api/inventory/stats/health?warehouse=' + encodeURIComponent(wh)).catch(() => ({}))
        ]);
        const scopeLabel = wh ? wh.replace(' warehouse', ' 仓库') : '全部仓库';
        const scopeChip = document.getElementById('inventoryScopeChip');
        const refreshChip = document.getElementById('inventoryRefreshChip');
        if (scopeChip) scopeChip.textContent = scopeLabel;
        if (refreshChip) refreshChip.textContent = d.last_updated_at ? `更新至 ${formatStockUpdatedAt(d.last_updated_at)}` : '随库存数据刷新';
        document.getElementById('invStatsGrid').innerHTML = `
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">SKU 总数</div><div class="value">${Number(d.total_skus || 0).toLocaleString()}</div><div class="sub">${scopeLabel} · 点击进入库存清单</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">库存总件数</div><div class="value success">${Number(d.total_pcs || 0).toLocaleString()}</div><div class="sub">PCS · 用于周度库存规模汇报</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">库存总货值</div><div class="value accent">$${Number(d.total_value || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</div><div class="sub">USD · 用于库存货值和超期报告</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card"><div class="label">库存更新时间</div><div class="value">${formatStockUpdatedAt(d.last_updated_at) || '-'}</div><div class="sub">${scopeLabel} · 最近库存记录更新时间</div></div>`;
        const riskEl = document.getElementById('inventoryRiskSnapshot');
        if (riskEl) riskEl.innerHTML = buildInventoryRiskSnapshot(health || {});
        loadCurrentInvDashTab();
    }

    function drawInvBarChart(canvasId, labels, vals, metric) {
        const key = canvasId;
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(document.getElementById(canvasId), {
            type: 'bar',
            data: { labels, datasets: [{ data: vals, backgroundColor: TTL_COLORS, borderRadius: 4 }] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: c => metric === 'value' ? fmt$(c.raw) : Number(c.raw || 0).toLocaleString() + ' PCS' } }
                },
                scales: {
                    x: { ticks: { color: '#64748b', callback: v => metric === 'value' ? '$' + (v / 1000).toFixed(0) + 'k' : Number(v).toLocaleString() }, grid: { color: '#1e293b' } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    async function renderInventoryBreakdown({ apiUrl, field, title, valueCanvas, pcsCanvas }) {
        const wh = document.getElementById('dashWarehouse').value;
        const resp = await apiGet(apiUrl + '?warehouse=' + encodeURIComponent(wh));
        const data = resp.data || [];
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const rows = data.map(r => {
            const label = r[field] || 'N/A';
            return `<tr>
                <td style="font-weight:500">${escapeHtml(label)}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.total_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">${fmtPct(r.total_pcs || 0, totalPcs)}</td>
                <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                <td style="text-align:right">${fmtPct(r.ttl_amount || 0, totalValue)}</td>
            </tr>`;
        }).join('');
        document.getElementById('invDashContent').innerHTML = `
            <div style="display:flex;align-items:center;gap:18px;margin-bottom:16px">
                <span style="font-size:12px;color:var(--text-secondary)">总货值</span><span style="font-size:20px;font-weight:700;color:var(--accent)">${fmt$(totalValue)}</span>
                <span style="font-size:12px;color:var(--text-secondary)">总件数</span><span style="font-size:20px;font-weight:700;color:var(--success)">${totalPcs.toLocaleString()}</span>
            </div>
            <div class="charts-grid">
                <div class="chart-card"><h3>${title}与货值关系图</h3><div class="chart-container"><canvas id="${valueCanvas}"></canvas></div></div>
                <div class="chart-card"><h3>${title}与总件数关系图</h3><div class="chart-container"><canvas id="${pcsCanvas}"></canvas></div></div>
                <div class="chart-card full-width"><h3>${title} 明细</h3><div style="max-height:500px;overflow-y:auto"><table><thead><tr><th>${title}</th><th style="text-align:right">SKU数</th><th style="text-align:right">总件数</th><th style="text-align:right">件数占比</th><th style="text-align:right">总货值 (USD)</th><th style="text-align:right">货值占比</th></tr></thead><tbody>${rows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:32px">暂无数据</td></tr>`}</tbody></table></div></div>
            </div>`;
        drawInvBarChart(valueCanvas, data.map(r => r[field] || 'N/A'), data.map(r => Number(r.ttl_amount || 0)), 'value');
        drawInvBarChart(pcsCanvas, data.map(r => r[field] || 'N/A'), data.map(r => Number(r.total_pcs || 0)), 'pcs');
    }

    const INVENTORY_DIMENSIONS = {
        category: { label: '物料品类', short: '品类' },
        category_2: { label: '适用产品', short: '产品' },
        instruction: { label: '归属国家', short: '国家' }
    };

    function inventoryBreakdownSection(def, data) {
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const rows = data.map(r => {
            const label = r[def.field] || 'N/A';
            return `<tr>
                <td style="font-weight:500">${escapeHtml(label)}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.total_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">${fmtPct(r.total_pcs || 0, totalPcs)}</td>
                <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                <td style="text-align:right">${fmtPct(r.ttl_amount || 0, totalValue)}</td>
            </tr>`;
        }).join('');
        return `<div style="margin-bottom:20px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px">
                <h3>${def.title} 货值</h3>
                <div style="display:flex;gap:16px;font-size:12px;color:var(--text-secondary)">
                    <span>总件数 <b style="color:var(--success)">${totalPcs.toLocaleString()}</b></span>
                    <span>总货值 <b style="color:var(--accent)">${fmt$(totalValue)}</b></span>
                </div>
            </div>
            <div class="charts-grid">
                <div class="chart-card"><h3>${def.title}与货值关系图</h3><div class="chart-container"><canvas id="${def.valueCanvas}"></canvas></div></div>
                <div class="chart-card"><h3>${def.title}与总件数关系图</h3><div class="chart-container"><canvas id="${def.pcsCanvas}"></canvas></div></div>
                <div class="chart-card full-width"><h3>${def.title} 明细</h3><div style="max-height:360px;overflow-y:auto"><table><thead><tr><th>${def.title}</th><th style="text-align:right">SKU数</th><th style="text-align:right">总件数</th><th style="text-align:right">件数占比</th><th style="text-align:right">总货值 (USD)</th><th style="text-align:right">货值占比</th></tr></thead><tbody>${rows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:32px">暂无数据</td></tr>`}</tbody></table></div></div>
            </div>
        </div>`;
    }

    function saveInventoryBreakdownSelection() {
        const primary = document.getElementById('inventoryPrimaryDim')?.value || 'category';
        const secondary = document.getElementById('inventorySecondaryDim')?.value || 'category_2';
        localStorage.setItem(INVENTORY_BREAKDOWN_KEY, JSON.stringify({ primary, secondary }));
    }

    function applyInventoryBreakdownSelection() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem(INVENTORY_BREAKDOWN_KEY) || 'null'); } catch {}
        const primaryEl = document.getElementById('inventoryPrimaryDim');
        const secondaryEl = document.getElementById('inventorySecondaryDim');
        if (!primaryEl || !secondaryEl) return;
        if (saved && !Array.isArray(saved)) {
            if (INVENTORY_DIMENSIONS[saved.primary]) primaryEl.value = saved.primary;
            if (INVENTORY_DIMENSIONS[saved.secondary]) secondaryEl.value = saved.secondary;
        }
        if (primaryEl.value === secondaryEl.value) {
            secondaryEl.value = primaryEl.value === 'category' ? 'category_2' : 'category';
        }
    }

    function groupInventoryRows(rows, field) {
        const map = new Map();
        rows.forEach(r => {
            const label = r[field] || 'UNSPECIFIED';
            const cur = map.get(label) || { label, sku_count: 0, total_pcs: 0, ttl_amount: 0, avg_unit_value: 0 };
            cur.sku_count += Number(r.sku_count || 0);
            cur.total_pcs += Number(r.total_pcs || 0);
            cur.ttl_amount += Number(r.ttl_amount || 0);
            map.set(label, cur);
        });
        return [...map.values()].map(r => ({ ...r, avg_unit_value: r.total_pcs ? r.ttl_amount / r.total_pcs : 0 }))
            .sort((a, b) => b.ttl_amount - a.ttl_amount);
    }

    function buildInventoryHeatmap(rows, primary, secondary, totalValue) {
        const primaryLabels = groupInventoryRows(rows, primary).slice(0, 8).map(r => r.label);
        const secondaryLabels = groupInventoryRows(rows, secondary).slice(0, 7).map(r => r.label);
        const cellMap = new Map();
        rows.forEach(r => {
            const key = `${r[primary] || 'UNSPECIFIED'}|||${r[secondary] || 'UNSPECIFIED'}`;
            const cur = cellMap.get(key) || { ttl_amount: 0, total_pcs: 0, sku_count: 0 };
            cur.ttl_amount += Number(r.ttl_amount || 0);
            cur.total_pcs += Number(r.total_pcs || 0);
            cur.sku_count += Number(r.sku_count || 0);
            cellMap.set(key, cur);
        });
        const maxValue = Math.max(...[...cellMap.values()].map(v => v.ttl_amount), 1);
        const empty = `<td style="background:rgba(148,163,184,0.04)"><div class="heatmap-cell-main" style="color:var(--text-muted)">-</div></td>`;
        const body = primaryLabels.map(p => {
            const cells = secondaryLabels.map(s => {
                const c = cellMap.get(`${p}|||${s}`);
                if (!c) return empty;
                const intensity = Math.max(0.08, c.ttl_amount / maxValue);
                const pct = fmtPct(c.ttl_amount, totalValue);
                return `<td style="background:rgba(59,130,246,${Math.min(0.82, 0.10 + intensity * 0.72)})" title="${escapeHtml(p)} / ${escapeHtml(s)} · ${fmt$(c.ttl_amount)} · ${Number(c.total_pcs).toLocaleString()} PCS">
                    <div class="heatmap-cell-main">${fmt$(c.ttl_amount)}</div>
                    <div class="heatmap-cell-sub">${Number(c.total_pcs).toLocaleString()} PCS · ${pct}</div>
                </td>`;
            }).join('');
            return `<tr><th style="min-width:130px">${escapeHtml(p)}</th>${cells}</tr>`;
        }).join('');
        return `<div class="heatmap-wrap"><table class="heatmap-table"><thead><tr><th>${INVENTORY_DIMENSIONS[primary].short} × ${INVENTORY_DIMENSIONS[secondary].short}</th>${secondaryLabels.map(s => `<th>${escapeHtml(s)}</th>`).join('')}</tr></thead><tbody>${body || `<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:32px">暂无组合数据</td></tr>`}</tbody></table></div>`;
    }

    function getInventoryGroupPosition(row, totalValue, totalPcs) {
        const valueShare = totalValue ? Number(row.ttl_amount || 0) / totalValue : 0;
        const pcsShare = totalPcs ? Number(row.total_pcs || 0) / totalPcs : 0;
        const gap = valueShare - pcsShare;
        if (valueShare >= 0.15 && pcsShare >= 0.15) return { key: 'core', label: '重点库存', color: '#3b82f6', bg: 'rgba(59,130,246,0.16)', advice: '货值和件数都高，优先做盘点、图片和价格维护。' };
        if (gap >= 0.04) return { key: 'value', label: '高货值低件数', color: '#f59e0b', bg: 'rgba(245,158,11,0.16)', advice: '金额占比高于件数占比，适合重点关注单价、丢失风险和库龄。' };
        if (gap <= -0.04) return { key: 'bulk', label: '数量大低货值', color: '#22c55e', bg: 'rgba(34,197,94,0.15)', advice: '件数占比高于金额占比，重点看占用空间、呆滞和清理机会。' };
        return { key: 'balanced', label: '结构均衡', color: '#94a3b8', bg: 'rgba(148,163,184,0.14)', advice: '货值和件数比例接近，按正常库存节奏维护。' };
    }

    function buildInventoryDecisionCards(grouped, totalValue, totalPcs, pDef) {
        const buckets = { core: [], value: [], bulk: [], balanced: [] };
        grouped.forEach(r => {
            const pos = getInventoryGroupPosition(r, totalValue, totalPcs);
            buckets[pos.key].push({ ...r, pos, valueShare: totalValue ? r.ttl_amount / totalValue : 0, pcsShare: totalPcs ? r.total_pcs / totalPcs : 0 });
        });
        const pick = [
            buckets.core.sort((a, b) => (b.ttl_amount + b.total_pcs) - (a.ttl_amount + a.total_pcs))[0],
            buckets.value.sort((a, b) => (b.valueShare - b.pcsShare) - (a.valueShare - a.pcsShare))[0],
            buckets.bulk.sort((a, b) => (b.pcsShare - b.valueShare) - (a.pcsShare - a.valueShare))[0],
            buckets.balanced.sort((a, b) => b.ttl_amount - a.ttl_amount)[0]
        ].filter(Boolean);
        if (!pick.length) return '';
        return `<div class="inventory-decision-grid">${pick.map(r => `
            <div class="inventory-decision">
                <div class="tag" style="color:${r.pos.color};background:${r.pos.bg}">${r.pos.label}</div>
                <div class="name">${escapeHtml(r.label || '-')}</div>
                <div class="meta">
                    ${pDef.label} · 货值 ${fmtPct(r.ttl_amount, totalValue)} / 件数 ${fmtPct(r.total_pcs, totalPcs)}<br>
                    ${fmt$(r.ttl_amount)} · ${Number(r.total_pcs || 0).toLocaleString()} PCS · ${Number(r.sku_count || 0).toLocaleString()} SKU<br>
                    ${r.pos.advice}
                </div>
                <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({${pDef.label === '物料品类' ? 'category' : pDef.label === '适用产品' ? 'category2' : 'instruction'}:${jsArg(r.label || '')}})">查看明细</button>
            </div>`).join('')}</div>`;
    }

    function inventoryRiskLevel(amount, total) {
        const pct = total ? amount / total : 0;
        if (pct >= 0.25) return { color: 'var(--danger)', text: '高风险' };
        if (pct >= 0.10) return { color: 'var(--warning)', text: '需关注' };
        return { color: 'var(--success)', text: '可控' };
    }

    function buildInventoryPriorityPanel(title, rows, kind) {
        const list = (rows || []).slice(0, 3);
        if (!list.length) {
            return `<div class="inventory-priority-panel"><h3>${title}</h3><div class="inventory-priority-muted">暂无需要优先处理的 SKU</div></div>`;
        }
        const dayLabel = kind === 'idle' ? '未使用' : '库龄';
        return `<div class="inventory-priority-panel">
            <h3>${title}</h3>
            ${list.map(r => {
                const product = r.product_number || r.bom_code || '';
                const days = Number(kind === 'idle' ? (r.idle_days || 0) : (r.dos || 0));
                return `<div class="inventory-priority-item">
                    <div class="inventory-priority-code">
                        <button type="button" class="link-btn" data-product-detail="${escapeHtml(product || '')}" onclick="openProductDetail(this.dataset.productDetail)" title="${escapeHtml(r.product_description || product)}">${escapeHtml(product || '-')}</button>
                    </div>
                    <div>${fmt$(r.ttl_amount)}</div>
                    <div>${Number(r.inventory || 0).toLocaleString()} PCS</div>
                    <div class="inventory-priority-muted">${dayLabel} ${days.toLocaleString()} 天</div>
                </div>`;
            }).join('')}
        </div>`;
    }

    function buildInventoryPriorityBoard(health) {
        return `<div class="inventory-priority-board">
            ${buildInventoryPriorityPanel('优先行动 · DOS 超期 Top3', health.top_dos, 'dos')}
            ${buildInventoryPriorityPanel('优先行动 · 长期未使用 Top3', health.top_idle, 'idle')}
        </div>`;
    }

    function buildInventoryActionRows(rows, type) {
        const list = (rows || []).slice(0, 6);
        if (!list.length) return '<div style="color:var(--text-muted);padding:18px 0">暂无需要提醒的物料</div>';
        const dayLabel = type === 'idle' ? '未使用天数' : 'DOS 天数';
        const header = `<div class="inventory-action-item inventory-action-header" aria-hidden="true">
            <div></div>
            <div class="item-main">物料</div>
            <div class="item-metric">货值</div>
            <div class="item-metric">单价</div>
            <div class="item-metric">库存</div>
            <div class="item-metric">${dayLabel}</div>
            <div class="item-advice">处理建议</div>
        </div>`;
        return `<div class="inventory-action-list">${header}${list.map(r => {
            const days = type === 'idle' ? (r.idle_days || 0) : (r.dos || 0);
            const advice = type === 'idle'
                ? (days >= 365 ? '超过 365 天未出库，建议和业务确认是否清理或转移。' : '长期未使用，建议确认后续需求。')
                : ((r.overdue_days || 0) >= 90 ? '超期严重，优先盘点并确认是否仍需保留。' : '已超过品类阈值，建议纳入定期跟进。');
            const imagePath = r.image_path || '';
            const remark = r.product_description || '';
            const imageArg = jsArg(imagePath);
            const remarkArg = jsArg(remark);
            const thumb = imagePath
                ? `<img class="inventory-action-thumb stock-thumb thumb-clickable" src="${escapeHtml(imageUrl(imagePath))}" data-image-path="${escapeHtml(imagePath)}" data-remark="${escapeHtml(remark)}" onclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" ondblclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="点击或双击查看大图">`
                : '<div class="inventory-action-noimg">无图</div>';
            return `<div class="inventory-action-item">
                ${thumb}
                <div class="item-main" title="${escapeHtml(r.product_description || r.product_number || '')}">
                    <button type="button" class="link-btn inventory-action-title" data-product-detail="${escapeHtml(r.product_number || r.bom_code || '')}" onclick="openProductDetail(this.dataset.productDetail)" style="padding:0;font-weight:800;text-align:left">${escapeHtml(r.product_number || r.bom_code || '-')}</button>
                    <div class="inventory-action-desc">${escapeHtml(r.product_description || '无描述')}</div>
                    <div class="inventory-action-meta">仓库：${escapeHtml(r.warehouse || '-')} · BOM：${escapeHtml(r.bom_code || '-')}</div>
                </div>
                <div class="item-metric">${fmt$(r.ttl_amount)}</div>
                <div class="item-metric">${r.unit_price != null ? '$' + Number(r.unit_price || 0).toFixed(2) : '-'}</div>
                <div class="item-metric">${Number(r.inventory || 0).toLocaleString()} PCS</div>
                <div class="item-metric">${days} 天</div>
                <div class="item-advice">${advice}</div>
            </div>`;
        }).join('')}</div>`;
    }

    function buildInventoryRiskSnapshot(health) {
        const total = health.total || {};
        const dos = health.dos || {};
        const idle = health.idle || {};
        const neverOutbound = health.never_outbound || {};
        const dq = health.data_quality || {};
        const missingPrice = dq.missing_price || {};
        const missingImage = dq.missing_image || {};
        const missingInbound = dq.missing_inbound || {};
        const dosLevel = inventoryRiskLevel(dos.ttl_amount || 0, total.ttl_amount || 0);
        const idleLevel = inventoryRiskLevel(idle.ttl_amount || 0, total.ttl_amount || 0);
        const riskCard = (label, value, sub, cls, action = '') => `
            <div class="inventory-risk-card ${action ? 'inventory-risk-click clickable' : ''}" ${action}>
                <div class="risk-label">${label}</div>
                <div class="risk-value ${cls || ''}">${value}</div>
                <div class="risk-sub">${sub}</div>
            </div>`;
        return `<div class="inventory-risk-grid inventory-risk-snapshot">
            ${riskCard('DOS 超期', fmt$(dos.ttl_amount || 0), `${Number(dos.total_pcs || 0).toLocaleString()} PCS · ${Number(dos.sku_count || 0).toLocaleString()} SKU · ${dosLevel.text}`, 'danger', `onclick="document.querySelector('#invDashTabs .tab[data-dtab=dos180]')?.click()"`)}
            ${riskCard('长期未使用', fmt$(idle.ttl_amount || 0), `${Number(idle.total_pcs || 0).toLocaleString()} PCS · ${Number(idle.sku_count || 0).toLocaleString()} SKU · 含从未出库 ${Number(neverOutbound.sku_count || 0).toLocaleString()} SKU`, 'warning', `onclick="document.querySelector('#invDashTabs .tab[data-dtab=idle180]')?.click()"`)}
            ${riskCard('缺价格', Number(missingPrice.sku_count || 0).toLocaleString(), `${fmt$(missingPrice.ttl_amount || 0)} · ${Number(missingPrice.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'danger', `onclick="openStockListFromInventory({quality:'missing_price'})"`)}
            ${riskCard('缺图片', Number(missingImage.sku_count || 0).toLocaleString(), `${fmt$(missingImage.ttl_amount || 0)} · ${Number(missingImage.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'warning', `onclick="openStockListFromInventory({quality:'missing_image'})"`)}
            ${riskCard('缺入库时间', Number(missingInbound.sku_count || 0).toLocaleString(), `${fmt$(missingInbound.ttl_amount || 0)} · ${Number(missingInbound.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'warning', `onclick="openStockListFromInventory({quality:'missing_inbound'})"`)}
        </div>
        ${buildInventoryPriorityBoard(health)}`;
    }

    function buildInventoryHealthPanel(health) {
        const total = health.total || {};
        const dos = health.dos || {};
        const idle = health.idle || {};
        const neverOutbound = health.never_outbound || {};
        const dq = health.data_quality || {};
        const dosLevel = inventoryRiskLevel(dos.ttl_amount || 0, total.ttl_amount || 0);
        const idleLevel = inventoryRiskLevel(idle.ttl_amount || 0, total.ttl_amount || 0);
        const missingPrice = dq.missing_price || {};
        const missingImage = dq.missing_image || {};
        const missingInbound = dq.missing_inbound || {};
        return `
            <div class="inventory-health-panel">
                <h3>库存健康总览</h3>
                <div class="inventory-risk-grid">
                    <div class="inventory-risk-card">
                        <div class="risk-label">当前库存规模</div>
                        <div class="risk-value">${fmt$(total.ttl_amount || 0)}</div>
                        <div class="risk-sub">${Number(total.total_pcs || 0).toLocaleString()} PCS · ${Number(total.sku_count || 0).toLocaleString()} SKU</div>
                    </div>
                    <div class="inventory-risk-card">
                        <div class="risk-label">DOS 超期货值</div>
                        <div class="risk-value" style="color:${dosLevel.color}">${fmt$(dos.ttl_amount || 0)}</div>
                        <div class="risk-sub">${dosLevel.text} · ${Number(dos.total_pcs || 0).toLocaleString()} PCS · ${Number(dos.sku_count || 0).toLocaleString()} SKU · 平均超期 ${dos.avg_overdue_days || 0} 天</div>
                    </div>
                    <div class="inventory-risk-card">
                        <div class="risk-label">长期未使用货值</div>
                        <div class="risk-value" style="color:${idleLevel.color}">${fmt$(idle.ttl_amount || 0)}</div>
                        <div class="risk-sub">${idleLevel.text} · ${Number(idle.total_pcs || 0).toLocaleString()} PCS · ${Number(idle.sku_count || 0).toLocaleString()} SKU · 平均超期 ${idle.avg_overdue_days || 0} 天</div>
                    </div>
                    <div class="inventory-risk-card">
                        <div class="risk-label">从未出库库存</div>
                        <div class="risk-value" style="color:var(--warning)">${fmt$(neverOutbound.ttl_amount || 0)}</div>
                        <div class="risk-sub">${Number(neverOutbound.total_pcs || 0).toLocaleString()} PCS · ${Number(neverOutbound.sku_count || 0).toLocaleString()} SKU · 建议确认新品、备品或无需求物料。</div>
                    </div>
                    <div class="inventory-risk-card">
                        <div class="risk-label">主数据缺失</div>
                        <div class="risk-value" style="color:var(--danger)">${Number(missingPrice.sku_count || 0) + Number(missingImage.sku_count || 0) + Number(missingInbound.sku_count || 0)}</div>
                        <div class="risk-sub">缺价格 ${Number(missingPrice.sku_count || 0)} SKU · 缺图片 ${Number(missingImage.sku_count || 0)} SKU · 缺入库时间 ${Number(missingInbound.sku_count || 0)} SKU</div>
                        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
                            <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_price'})">缺价格</button>
                            <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_image'})">缺图片</button>
                            <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_inbound'})">缺入库时间</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="charts-grid">
                <div class="chart-card full-width">
                    <h3>优先处理 · DOS 超期物料</h3>
                    ${buildInventoryActionRows(health.top_dos, 'dos')}
                </div>
                <div class="chart-card full-width">
                    <h3>优先处理 · 长期未使用物料</h3>
                    ${buildInventoryActionRows(health.top_idle, 'idle')}
                </div>
            </div>`;
    }

    function drawInventoryShareCompare(rows, primary, totalValue, totalPcs) {
        const grouped = groupInventoryRows(rows, primary).slice(0, 14);
        const labels = grouped.map(r => r.label);
        const valuePct = grouped.map(r => totalValue ? Number(((r.ttl_amount || 0) / totalValue * 100).toFixed(2)) : 0);
        const pcsPct = grouped.map(r => totalPcs ? Number(((r.total_pcs || 0) / totalPcs * 100).toFixed(2)) : 0);
        const key = 'chartInvValuePcsShare';
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(document.getElementById(key), {
            type: 'bar',
            data: {
                labels,
                datasets: [
                    { label: '货值占比', data: valuePct, backgroundColor: 'rgba(59,130,246,0.78)', borderColor: '#3b82f6', borderWidth: 1 },
                    { label: '件数占比', data: pcsPct, backgroundColor: 'rgba(34,197,94,0.62)', borderColor: '#22c55e', borderWidth: 1 }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: {
                        callbacks: {
                            afterBody: ctx => {
                                const row = grouped[ctx[0].dataIndex] || {};
                                const pos = getInventoryGroupPosition(row, totalValue, totalPcs);
                                return `${pos.label}: ${pos.advice}`;
                            },
                            label: c => `${c.dataset.label}: ${Number(c.raw || 0).toFixed(1)}%`
                        }
                    }
                },
                scales: {
                    x: { title: { display: true, text: '占总库存比例 %', color: '#94a3b8' }, ticks: { color: '#64748b', callback: v => v + '%' }, grid: { color: 'rgba(148,163,184,0.14)' } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    async function loadInventoryBreakdowns(wh) {
        applyInventoryBreakdownSelection();
        const primary = document.getElementById('inventoryPrimaryDim')?.value || 'category';
        const secondary = document.getElementById('inventorySecondaryDim')?.value || 'category_2';
        const pDef = INVENTORY_DIMENSIONS[primary];
        const sDef = INVENTORY_DIMENSIONS[secondary];
        document.getElementById('invDashContent').innerHTML = '<div style="color:var(--text-muted);padding:24px">加载中...</div>';
        const resp = await apiGet('/api/inventory/stats/value-pcs-matrix?warehouse=' + encodeURIComponent(wh));
        const data = resp.data || [];
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const primaryRows = groupInventoryRows(data, primary);
        const topValue = primaryRows[0] || {};
        const topPcs = [...primaryRows].sort((a, b) => b.total_pcs - a.total_pcs)[0] || {};
        const topConcentration = primaryRows.slice(0, 3).reduce((s, r) => s + r.ttl_amount, 0);
        const highValueLowPcs = primaryRows.filter(r => r.total_pcs > 0).sort((a, b) => b.avg_unit_value - a.avg_unit_value)[0] || {};
        document.getElementById('invDashContent').innerHTML = `
            <div class="inventory-insight-grid">
                <div class="inventory-insight"><div class="label">最高货值 ${pDef.label}</div><div class="value">${escapeHtml(topValue.label || '-')}</div><div class="sub">${fmt$(topValue.ttl_amount)} · ${fmtPct(topValue.ttl_amount || 0, totalValue)}</div></div>
                <div class="inventory-insight"><div class="label">最高件数 ${pDef.label}</div><div class="value">${escapeHtml(topPcs.label || '-')}</div><div class="sub">${Number(topPcs.total_pcs || 0).toLocaleString()} PCS · ${fmtPct(topPcs.total_pcs || 0, totalPcs)}</div></div>
                <div class="inventory-insight"><div class="label">Top 3 货值集中度</div><div class="value">${fmtPct(topConcentration, totalValue)}</div><div class="sub">前三个${pDef.short}合计 ${fmt$(topConcentration)}</div></div>
                <div class="inventory-insight"><div class="label">高单件货值</div><div class="value">${escapeHtml(highValueLowPcs.label || '-')}</div><div class="sub">平均 ${fmt$(highValueLowPcs.avg_unit_value)} / PCS</div></div>
            </div>
            ${buildInventoryDecisionCards(primaryRows, totalValue, totalPcs, pDef)}
            <div class="charts-grid">
                <div class="chart-card full-width">
                    <h3>${pDef.label} × ${sDef.label} 货值关系热力图</h3>
                    ${buildInventoryHeatmap(data, primary, secondary, totalValue)}
                </div>
                <div class="chart-card full-width">
                    <h3>${pDef.label} 货值占比 / 件数占比对比</h3>
                    <div class="inventory-ratio-note">
                        <span>蓝色高：钱主要压在这里</span>
                        <span>绿色高：数量主要堆在这里</span>
                        <span>两条都高：优先盘点和维护</span>
                    </div>
                    <div class="chart-container tall"><canvas id="chartInvValuePcsShare"></canvas></div>
                </div>
            </div>`;
        bindStockImagePreviewEvents();
        drawInventoryShareCompare(data, primary, totalValue, totalPcs);
    }

    async function loadCatTtl() {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/category-ttl', field: 'category', title: 'Category', valueCanvas: 'chartCatTtlValue', pcsCanvas: 'chartCatTtlPcs' });
    }

    function uniqueLines(text) {
        return [...new Set(String(text || '').split(/\n|,/).map(s => s.trim().toUpperCase()).filter(Boolean))];
    }
    function getManagedOptions() {
        const fallback = { category: DEFAULT_CATEGORY_OPTIONS, category2: DEFAULT_CATEGORY2_OPTIONS, instruction: DEFAULT_INSTRUCTION_OPTIONS };
        try {
            const saved = JSON.parse(localStorage.getItem(MANAGED_OPTIONS_KEY) || '{}');
            return {
                category: Array.isArray(saved.category) && saved.category.length ? saved.category : fallback.category,
                category2: Array.isArray(saved.category2) && saved.category2.length ? saved.category2 : fallback.category2,
                instruction: Array.isArray(saved.instruction) && saved.instruction.length ? saved.instruction : fallback.instruction
            };
        } catch {
            return fallback;
        }
    }
    function normalizeInventoryOption(value) {
        return String(value || '').trim().toUpperCase();
    }
    function uniqueSortedInventoryOptions(rows, field) {
        return [...new Set((rows || []).map(r => normalizeInventoryOption(r[field])).filter(Boolean))].sort();
    }
    function renderSettingsClassificationSummary(opts) {
        const el = document.getElementById('settingsClassificationSummary');
        if (!el) return;
        const preview = values => {
            const list = values || [];
            if (!list.length) return '暂无';
            const visible = list.slice(0, 8).join(' / ');
            return list.length > 8 ? `${visible} / +${list.length - 8}` : visible;
        };
        el.innerHTML = `
            <div class="settings-scan-card"><b>物料品类 Category · ${(opts.category || []).length}</b><span>${escapeHtml(preview(opts.category))}</span></div>
            <div class="settings-scan-card"><b>适用产品 Category 2 · ${(opts.category2 || []).length}</b><span>${escapeHtml(preview(opts.category2))}</span></div>
            <div class="settings-scan-card"><b>归属国家 Instruction · ${(opts.instruction || []).length}</b><span>${escapeHtml(preview(opts.instruction))}</span></div>
        `;
    }
    async function scanInventoryClassificationOptions(warehouse = '') {
        const params = new URLSearchParams({ warehouse: warehouse || '', per_page: '9999' });
        const data = await apiGet('/api/inventory?' + params.toString()).catch(() => ({ data: [] }));
        const rows = Array.isArray(data.data) ? data.data : [];
        const activeRows = rows.filter(r => Number(r.inventory || 0) > 0);
        const sourceRows = activeRows.length ? activeRows : rows;
        return {
            category: uniqueSortedInventoryOptions(sourceRows, 'category'),
            category2: uniqueSortedInventoryOptions(sourceRows, 'category_2'),
            instruction: uniqueSortedInventoryOptions(sourceRows, 'instruction')
        };
    }
    function initSettings() {
        const cat = document.getElementById('settingCategoryOptions');
        if (!cat) return;
        cat.value = '扫描中...';
        document.getElementById('settingCategory2Options').value = '扫描中...';
        document.getElementById('settingInstructionOptions').value = '扫描中...';
        scanInventoryClassificationOptions('').then(opts => {
            cat.value = opts.category.join('\n') || '暂无库存分类';
            document.getElementById('settingCategory2Options').value = opts.category2.join('\n') || '暂无适用产品';
            document.getElementById('settingInstructionOptions').value = opts.instruction.join('\n') || '暂无归属国家';
            renderSettingsClassificationSummary(opts);
        }).catch(e => {
            cat.value = '扫描失败：' + e.message;
            document.getElementById('settingCategory2Options').value = '扫描失败';
            document.getElementById('settingInstructionOptions').value = '扫描失败';
            renderSettingsClassificationSummary({ category: ['扫描失败'], category2: [], instruction: [] });
        });
        document.getElementById('settingLang').value = currentLang;
        document.getElementById('settingWarehouse').value = currentWarehouse;
        applyTheme();
        loadThresholdSettings();
    }
    async function loadVersionChangelog() {
        const el = document.getElementById('versionTimeline');
        if (!el) return;
        try {
            const res = await fetch('/static/version_changelog.json', { cache: 'no-store' });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const rows = await res.json();
            el.innerHTML = rows.map((row, idx) => {
                const isLatest = idx === 0;
                return `
                <div class="version-entry ${isLatest ? 'current' : ''}">
                    <div class="version-entry-head">
                        <div>
                            <div class="version-entry-title">${escapeHtml(row.version || '-')} · ${escapeHtml(row.time || '-')}</div>
                            <div class="version-entry-meta">${escapeHtml(row.type || '')}</div>
                        </div>
                        <span class="version-badge ${isLatest ? 'current' : ''}">${isLatest ? '最新版本' : escapeHtml(row.confidence || 'unknown')}</span>
                    </div>
                    <ul>${(row.items || []).map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>
                </div>
            `}).join('');
        } catch (e) {
            el.innerHTML = `<div style="color:var(--danger);font-size:13px">版本纪要加载失败：${escapeHtml(e.message)}</div>`;
        }
    }
    let pendingSoftwareUpdate = null;
    function formatVersionDisplay(version, time) {
        const ver = String(version || '').trim();
        const releaseTime = String(time || '').trim();
        if (!ver) return '-';
        if (ver === APP_VERSION && !releaseTime) return APP_VERSION_FULL;
        return releaseTime ? `${ver} · ${releaseTime}` : ver;
    }
    function renderUpdateNotes(notes) {
        const rows = Array.isArray(notes) ? notes : [];
        return rows.length ? `<ul style="margin:8px 0 0 18px;padding:0">${rows.map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>` : '';
    }
    async function checkSoftwareUpdate() {
        const status = document.getElementById('updateStatus');
        const currentEl = document.getElementById('updateCurrentVersion');
        const latestEl = document.getElementById('updateLatestVersion');
        const latestCard = document.getElementById('updateLatestCard');
        const btn = document.getElementById('installUpdateBtn');
        if (currentEl) currentEl.textContent = APP_VERSION_FULL;
        if (latestCard) latestCard.classList.remove('needs-update');
        if (btn) btn.style.display = 'none';
        pendingSoftwareUpdate = null;
        if (status) status.innerHTML = '正在检查更新...';
        const data = await apiGet('/api/update/check').catch(e => ({ success: false, error: e.message }));
        if (!data.success) {
            if (latestEl) latestEl.textContent = '检查失败';
            if (status) status.innerHTML = `<span style="color:var(--danger)">检查更新失败：${escapeHtml(data.error || '未知错误')}</span><br><span style="color:var(--text-muted)">请确认电脑可以访问 Qiteng的GitHub 更新源。</span>`;
            return;
        }
        if (latestEl) latestEl.textContent = data.current_ahead_of_patch_channel
            ? `补丁通道 ${formatVersionDisplay(data.latest_version, data.release_time)}`
            : formatVersionDisplay(data.latest_version, data.release_time);
        pendingSoftwareUpdate = data;
        if (!data.update_available) {
            if (latestCard) latestCard.classList.remove('needs-update');
            if (data.current_ahead_of_patch_channel) {
                if (status) status.innerHTML = `<b>当前版本无需更新。</b><br>当前版本：${escapeHtml(formatVersionDisplay(data.current_version || APP_VERSION))}<br>补丁通道：${escapeHtml(formatVersionDisplay(data.latest_version || '', data.release_time))}<br><span style="color:var(--text-muted)">当前系统版本高于补丁通道版本，无需降级安装旧补丁。</span>`;
            } else if (status) {
                status.innerHTML = `<b>当前已是最新版本。</b><br>当前版本：${escapeHtml(formatVersionDisplay(data.current_version || APP_VERSION))} · 最新版本：${escapeHtml(formatVersionDisplay(data.latest_version || APP_VERSION, data.release_time))}`;
            }
            return;
        }
        if (latestCard) latestCard.classList.add('needs-update');
        if (btn) btn.style.display = '';
        if (status) status.innerHTML = `
            <b style="color:var(--accent)">发现新版本 ${escapeHtml(data.latest_version || '')}</b>
            <div>发布时间：${escapeHtml(data.release_time || '-')}</div>
            <div>安全说明：只下载更新清单和补丁包，不上传任何业务数据。</div>
            <div>SHA256：<span style="font-family:monospace">${escapeHtml(data.sha256 || '')}</span></div>
            ${renderUpdateNotes(data.notes)}
        `;
    }
    async function installSoftwareUpdate() {
        const status = document.getElementById('updateStatus');
        const data = pendingSoftwareUpdate;
        if (!data || !data.update_available) return toast('请先检查版本更新', 'error');
        if (!confirm(`确认下载并安装 ${data.latest_version}？\n\n系统只会从 Qiteng的GitHub 下载更新包，不上传任何业务数据。升级器启动后会关闭当前服务并覆盖程序代码。`)) return;
        const btn = document.getElementById('installUpdateBtn');
        if (btn) btn.disabled = true;
        if (status) status.innerHTML = `正在下载并校验 ${escapeHtml(data.latest_version)} 更新包，请稍候...`;
        const result = await apiPost('/api/update/install', {}).catch(e => ({ success: false, error: e.message }));
        if (btn) btn.disabled = false;
        if (!result.success) {
            if (status) status.innerHTML = `<span style="color:var(--danger)">更新失败：${escapeHtml(result.error || '未知错误')}</span>`;
            return toast(result.error || '更新失败', 'error');
        }
        if (status) status.innerHTML = `<b style="color:var(--success)">${escapeHtml(result.message || '更新器已启动')}</b><br>SHA256：<span style="font-family:monospace">${escapeHtml(result.sha256 || '')}</span>`;
        toast('更新包已校验，升级器已启动');
    }
    function saveManagedOptions() {
        const opts = {
            category: uniqueLines(document.getElementById('settingCategoryOptions').value),
            category2: uniqueLines(document.getElementById('settingCategory2Options').value),
            instruction: uniqueLines(document.getElementById('settingInstructionOptions').value)
        };
        localStorage.setItem(MANAGED_OPTIONS_KEY, JSON.stringify(opts));
        loadStockFilters();
        toast('分类选项已保存');
    }
    function resetManagedOptions() {
        localStorage.removeItem(MANAGED_OPTIONS_KEY);
        initSettings();
        loadStockFilters();
        toast('已恢复默认分类');
    }

    let thresholdSortBy = 'category';
    let thresholdSortDir = 'asc';
    function setThresholdSort(key) {
        if (thresholdSortBy === key) thresholdSortDir = thresholdSortDir === 'asc' ? 'desc' : 'asc';
        else {
            thresholdSortBy = key;
            thresholdSortDir = ['sku_count', 'inventory_pcs', 'ttl_amount', 'avg_unit_price'].includes(key) ? 'desc' : 'asc';
        }
        loadThresholdSettings();
    }
    function updateThresholdSortIndicators() {
        document.querySelectorAll('[data-threshold-sort]').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.thresholdSort === thresholdSortBy && thresholdSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.thresholdSort === thresholdSortBy && thresholdSortDir === 'desc');
        });
    }

    async function loadThresholdSettings() {
        const body = document.getElementById('thresholdSettingsBody');
        if (!body) return;
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        const data = await apiGet('/api/inventory/settings/thresholds').catch(e => ({ error: e.message }));
        if (data.error) {
            body.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--danger);padding:24px">${escapeHtml(data.error)}</td></tr>`;
            return;
        }
        let rows = data.data || [];
        const sortKey = thresholdSortBy || 'category';
        const dir = thresholdSortDir === 'desc' ? -1 : 1;
        rows = rows.slice().sort((a, b) => {
            const numeric = ['sku_count', 'inventory_pcs', 'ttl_amount', 'avg_unit_price', 'dos_threshold', 'idle_threshold'];
            const av = numeric.includes(sortKey) ? Number(a[sortKey] || 0) : String(a[sortKey] || '').toUpperCase();
            const bv = numeric.includes(sortKey) ? Number(b[sortKey] || 0) : String(b[sortKey] || '').toUpperCase();
            if (av === bv) return 0;
            return av > bv ? dir : -dir;
        });
        updateThresholdSortIndicators();
        body.innerHTML = rows.length ? rows.map(r => `
            <tr data-threshold-category="${escapeHtml(r.category || '')}">
                <td style="font-weight:500">${escapeHtml(r.category || '')}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.inventory_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">$${Number(r.ttl_amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td style="text-align:right">$${Number(r.avg_unit_price || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td style="text-align:center"><input class="wms-input threshold-dos" type="number" min="1" step="1" value="${r.dos_threshold || 180}" style="width:92px;text-align:center"></td>
                <td style="text-align:center"><input class="wms-input threshold-idle" type="number" min="1" step="1" value="${r.idle_threshold || 180}" style="width:92px;text-align:center"></td>
            </tr>
        `).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">暂无 Product Number 主数据，请先导入供应商库存 + 维护表</td></tr>';
    }

    async function saveThresholdSettings() {
        const body = document.getElementById('thresholdSettingsBody');
        if (!body) return;
        const rows = Array.from(body.querySelectorAll('tr[data-threshold-category]')).map(tr => ({
            category: tr.dataset.thresholdCategory,
            dos_threshold: Number(tr.querySelector('.threshold-dos')?.value || 180),
            idle_threshold: Number(tr.querySelector('.threshold-idle')?.value || 180)
        }));
        const data = await apiPost('/api/inventory/settings/thresholds', { rows });
        if (data.success) {
            toast(`已更新 ${data.updated || 0} 个 Product Number`);
            await loadThresholdSettings();
            if (currentInvDashTab === 'dos180' || currentInvDashTab === 'idle180') loadInvDashboard();
        } else {
            toast(data.error || '保存失败', 'error');
        }
    }

    async function loadCat2Ttl(wh) {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/category2-ttl', field: 'category_2', title: 'Category 2', valueCanvas: 'chartCat2TtlValue', pcsCanvas: 'chartCat2TtlPcs' });
    }

    async function loadInstrTtl(wh) {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/instruction-ttl', field: 'instruction', title: 'Instruction', valueCanvas: 'chartInstrTtlValue', pcsCanvas: 'chartInstrTtlPcs' });
    }

    function overdueSortValue(row, field, kind) {
        if (field === 'warehouse') return String(row.warehouse || '').toUpperCase();
        if (field === 'bom_code') return String(row.bom_code || '').toUpperCase();
        if (field === 'product_number') return String(row.product_number || '').toUpperCase();
        if (field === 'product_description') return String(row.product_description || '').toUpperCase();
        if (field === 'category') return String(row.category || '').toUpperCase();
        if (field === 'category_2') return String(row.category_2 || '').toUpperCase();
        if (field === 'instruction') return String(row.instruction || '').toUpperCase();
        if (field === 'inventory') return Number(row.inventory || 0);
        if (field === 'unit_price') return Number(row.unit_price || 0);
        if (field === 'ttl_amount') return Number(row.ttl_amount || 0);
        if (field === 'days') return Number(row[kind === 'idle' ? 'idle_days' : 'dos'] || 0);
        if (field === 'threshold') return Number(row[kind === 'idle' ? 'idle_threshold' : 'dos_threshold'] || 0);
        if (field === 'overdue_days') return Number(row.overdue_days || 0);
        return '';
    }

    function setOverdueSort(kind, field) {
        const state = overdueState[kind];
        if (state.sortBy === field) state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
        else {
            state.sortBy = field;
            state.sortDir = ['warehouse','bom_code','product_number','product_description','category','category_2','instruction'].includes(field) ? 'asc' : 'desc';
        }
        renderOverdueView(kind);
    }

    function updateOverdueFilter(kind, field, value) {
        overdueState[kind].filter[field] = value || '';
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function resetOverdueFilter(kind) {
        overdueState[kind].filter = { keyword: '', category: '', category2: '', instruction: '' };
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function updateOverduePerPage(kind, value) {
        overdueState[kind].perPage = Number(value || 25);
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function toggleOverdueDetails(kind, checked) {
        overdueState[kind].showDetails = Boolean(checked);
        renderOverdueView(kind);
    }

    function changeOverduePage(kind, page) {
        const rows = getFilteredOverdueRows(kind);
        const maxPage = Math.max(1, Math.ceil(rows.length / overdueState[kind].perPage));
        overdueState[kind].page = Math.min(Math.max(1, Number(page || 1)), maxPage);
        renderOverdueView(kind);
    }

    function getFilteredOverdueRows(kind) {
        const rows = overdueState[kind].rows || [];
        const filter = overdueState[kind].filter;
        const keyword = (filter.keyword || '').trim().toUpperCase();
        const filtered = rows.filter(r => {
            if (filter.category && (r.category || '') !== filter.category) return false;
            if (filter.category2 && (r.category_2 || '') !== filter.category2) return false;
            if (filter.instruction && (r.instruction || '') !== filter.instruction) return false;
            if (keyword) {
                const hay = [r.warehouse, r.bom_code, r.product_number, r.product_description, r.category, r.category_2, r.instruction].join(' ').toUpperCase();
                if (!hay.includes(keyword)) return false;
            }
            return true;
        });
        const state = overdueState[kind];
        return filtered.sort((a, b) => {
            const av = overdueSortValue(a, state.sortBy, kind);
            const bv = overdueSortValue(b, state.sortBy, kind);
            const result = typeof av === 'number' && typeof bv === 'number'
                ? av - bv
                : String(av).localeCompare(String(bv), 'zh-Hans-CN', { numeric: true, sensitivity: 'base' });
            return state.sortDir === 'asc' ? result : -result;
        });
    }

    function overdueHeader(kind, field, label, style = '') {
        const state = overdueState[kind];
        const arrow = state.sortBy === field ? (state.sortDir === 'asc' ? ' ↑' : ' ↓') : '';
        return `<th class="upload-record-sort ${state.sortBy === field ? 'active' : ''}" style="${style}" data-overdue-sort="${field}" data-overdue-kind="${kind}">${label}${arrow}</th>`;
    }

    function overdueOptions(rows, field) {
        return [...new Set(rows.map(r => r[field]).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), 'zh-Hans-CN'));
    }

    function renderOverdueFilters(kind, rows) {
        const state = overdueState[kind];
        const cats = overdueOptions(rows, 'category');
        const cat2s = overdueOptions(rows, 'category_2');
        const instructions = overdueOptions(rows, 'instruction');
        return `<div class="overdue-report-toolbar">
            <input class="wms-input" placeholder="搜索编码 / 描述 / 仓库" value="${escapeHtml(state.filter.keyword || '')}" data-overdue-filter="keyword" data-overdue-kind="${kind}">
            <select class="wms-select" data-overdue-filter="category" data-overdue-kind="${kind}">
                <option value="">全部物料品类</option>${cats.map(v => `<option value="${escapeHtml(v)}" ${state.filter.category === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <select class="wms-select" data-overdue-filter="category2" data-overdue-kind="${kind}">
                <option value="">全部适用产品</option>${cat2s.map(v => `<option value="${escapeHtml(v)}" ${state.filter.category2 === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <select class="wms-select" data-overdue-filter="instruction" data-overdue-kind="${kind}">
                <option value="">全部归属国家</option>${instructions.map(v => `<option value="${escapeHtml(v)}" ${state.filter.instruction === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <label class="overdue-report-toggle"><input type="checkbox" ${state.showDetails ? 'checked' : ''} data-overdue-details="${kind}"> 详细列</label>
            <select class="wms-select" data-overdue-per-page="${kind}" style="min-width:98px">
                ${[10,25,50,100].map(v => `<option value="${v}" ${state.perPage === v ? 'selected' : ''}>${v} 条/页</option>`).join('')}
            </select>
            <button class="btn btn-secondary btn-sm" data-overdue-reset="${kind}">清除筛选</button>
            <button class="btn btn-primary btn-sm" data-overdue-export="${kind}">导出 Excel</button>
        </div>`;
    }

    function drawOverdueCategoryChart(kind, rows) {
        const key = kind === 'idle' ? 'chartIdle180' : 'chartDos180';
        const canvas = document.getElementById(key);
        if (!canvas) return;
        if (charts[key]) charts[key].destroy();
        const catMap = {};
        rows.forEach(r => {
            const k = r.category || 'UNSPECIFIED';
            const cur = catMap[k] || { value: 0, pcs: 0 };
            cur.value += Number(r.ttl_amount || 0);
            cur.pcs += Number(r.inventory || 0);
            catMap[k] = cur;
        });
        const labels = Object.keys(catMap).sort((a, b) => catMap[b].value - catMap[a].value).slice(0, 10);
        charts[key] = new Chart(canvas, {
            type: 'bar',
            data: {
                labels,
                datasets: [
                    { label: kind === 'idle' ? '长期未使用货值' : 'DOS 超期货值', data: labels.map(k => catMap[k].value), xAxisID: 'xValue', backgroundColor: kind === 'idle' ? 'rgba(245,158,11,0.68)' : 'rgba(239,68,68,0.68)', borderColor: kind === 'idle' ? '#f59e0b' : '#ef4444', borderWidth: 1, borderRadius: 4 },
                    { label: '超期数量 PCS', data: labels.map(k => catMap[k].pcs), xAxisID: 'xPcs', backgroundColor: 'rgba(34,197,94,0.50)', borderColor: '#22c55e', borderWidth: 1, borderRadius: 4 }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: { callbacks: { label: c => c.dataset.xAxisID === 'xPcs' ? `${c.dataset.label}: ${Number(c.raw || 0).toLocaleString()} PCS` : `${c.dataset.label}: ${fmt$(c.raw)}` } }
                },
                scales: {
                    xValue: { position: 'bottom', ticks: { color: '#64748b', callback: v => '$' + (v / 1000).toFixed(0) + 'k' }, grid: { color: 'rgba(148,163,184,0.14)' } },
                    xPcs: { position: 'top', ticks: { color: '#22c55e', callback: v => Number(v).toLocaleString() }, grid: { drawOnChartArea: false } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    function renderOverdueTable(kind, rows) {
        const state = overdueState[kind];
        const totalRows = rows.length;
        const maxPage = Math.max(1, Math.ceil(totalRows / state.perPage));
        if (state.page > maxPage) state.page = maxPage;
        const start = (state.page - 1) * state.perPage;
        const pageRows = rows.slice(start, start + state.perPage);
        const dayField = kind === 'idle' ? 'idle_days' : 'dos';
        const thresholdField = kind === 'idle' ? 'idle_threshold' : 'dos_threshold';
        const empty = kind === 'idle' ? '暂无超过阈值的长期未使用物料' : '暂无超过阈值的库龄超期物料';
        const detailHeaders = state.showDetails ? `
                ${overdueHeader(kind, 'category_2', '适用产品')}
                ${overdueHeader(kind, 'instruction', '归属国家')}
                <th>${kind === 'idle' ? '最近出库' : '最近入库'}</th>
                ${overdueHeader(kind, 'threshold', kind === 'idle' ? '提醒线' : '超期线', 'text-align:center')}
        ` : '';
        const detailColspan = state.showDetails ? 15 : 11;
        return `<div style="overflow-x:auto"><table>
            <thead><tr>
                <th>Photo</th>
                ${overdueHeader(kind, 'warehouse', '仓库')}
                ${overdueHeader(kind, 'bom_code', 'BOM 编号')}
                ${overdueHeader(kind, 'product_number', '产品编号')}
                ${overdueHeader(kind, 'product_description', '产品描述')}
                ${overdueHeader(kind, 'category', '物料品类')}
                ${overdueHeader(kind, 'inventory', '库存', 'text-align:right')}
                ${overdueHeader(kind, 'unit_price', '单价', 'text-align:right')}
                ${overdueHeader(kind, 'ttl_amount', '总货值', 'text-align:right')}
                ${overdueHeader(kind, 'days', kind === 'idle' ? '未使用天数' : '库龄', 'text-align:center;color:var(--warning)')}
                ${overdueHeader(kind, 'overdue_days', '超期天数', 'text-align:center;color:var(--danger)')}
                ${detailHeaders}
            </tr></thead>
            <tbody>${pageRows.length === 0 ? `<tr><td colspan="${detailColspan}" style="text-align:center;color:var(--text-muted);padding:40px">${empty}</td></tr>` : pageRows.map(r => {
                const imagePath = r.image_path || '';
                const imageArg = jsArg(imagePath);
                const remarkArg = jsArg(r.product_description || '');
                const thumb = imagePath ? `<img class="thumb stock-thumb thumb-clickable" src="${escapeHtml(imageUrl(imagePath))}" data-image-path="${escapeHtml(imagePath)}" onclick="showImage(${imageArg}, ${remarkArg})" ondblclick="showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="点击查看大图">` : '<span style="color:var(--text-muted);font-size:12px">-</span>';
                const detailCells = state.showDetails ? `
                    <td>${escapeHtml(r.category_2 || '')}</td>
                    <td>${escapeHtml(r.instruction || '')}</td>
                    <td>${escapeHtml(kind === 'idle' ? (r.last_outbound_date || '') : (r.last_inbound_date || ''))}</td>
                    <td style="text-align:center">${Number(r[thresholdField] || 180).toLocaleString()} 天</td>
                ` : '';
                return `<tr>
                    <td>${thumb}</td>
                    <td>${escapeHtml(r.warehouse || '')}</td>
                    <td style="font-weight:500">${escapeHtml(r.bom_code || '')}</td>
                    <td>${escapeHtml(r.product_number || '')}</td>
                    <td style="min-width:260px;max-width:360px;white-space:normal;line-height:1.35">${escapeHtml(r.product_description || '')}</td>
                    <td><span class="badge badge-confirmed">${escapeHtml(r.category || '')}</span></td>
                    <td style="text-align:right">${Number(r.inventory || 0).toLocaleString()}</td>
                    <td style="text-align:right">${r.unit_price != null ? '$' + Number(r.unit_price).toFixed(2) : ''}</td>
                    <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                    <td style="text-align:center"><span class="badge badge-pending">${Number(r[dayField] || 0).toLocaleString()} 天</span></td>
                    <td style="text-align:center;color:var(--danger);font-weight:600">${Number(r.overdue_days || 0).toLocaleString()}</td>
                    ${detailCells}
                </tr>`;
            }).join('')}</tbody>
        </table></div>
        <div class="overdue-pagination">
            <span>显示 ${totalRows ? start + 1 : 0}-${Math.min(start + state.perPage, totalRows)} / ${totalRows} 条</span>
            <div class="overdue-pagination-actions">
                <button class="btn btn-secondary btn-sm" ${state.page <= 1 ? 'disabled' : ''} data-overdue-page="${state.page - 1}" data-overdue-kind="${kind}">上一页</button>
                <span>第 ${state.page} / ${maxPage} 页</span>
                <button class="btn btn-secondary btn-sm" ${state.page >= maxPage ? 'disabled' : ''} data-overdue-page="${state.page + 1}" data-overdue-kind="${kind}">下一页</button>
            </div>
        </div>`;
    }

    function renderOverdueView(kind) {
        const data = overdueState[kind].rows || [];
        const filtered = getFilteredOverdueRows(kind);
        const totalVal = filtered.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = filtered.reduce((s, r) => s + Number(r.inventory || 0), 0);
        const avgOverdue = filtered.length ? filtered.reduce((s, r) => s + Number(r.overdue_days || 0), 0) / filtered.length : 0;
        const severe = filtered.filter(r => Number((kind === 'idle' ? r.idle_days : r.overdue_days) || 0) >= (kind === 'idle' ? 365 : 90));
        const title = kind === 'idle' ? '长期未使用' : 'DOS 超期';
        const chartTitle = kind === 'idle' ? '长期未使用：货值与数量按物料品类' : 'DOS 超期：货值与数量按物料品类';
        document.getElementById('invDashContent').innerHTML = `
            <div class="inventory-risk-grid" style="margin-bottom:16px">
                <div class="inventory-risk-card"><div class="risk-label">${title} SKU</div><div class="risk-value" style="color:var(--warning)">${filtered.length}</div><div class="risk-sub">当前筛选结果 / 原始 ${data.length} SKU</div></div>
                <div class="inventory-risk-card"><div class="risk-label">${title}货值</div><div class="risk-value" style="color:var(--danger)">${fmt$(totalVal)}</div><div class="risk-sub">${Number(totalPcs).toLocaleString()} PCS 需要跟进</div></div>
                <div class="inventory-risk-card"><div class="risk-label">${kind === 'idle' ? '365+ 未出库' : '严重超期'}</div><div class="risk-value" style="color:var(--danger)">${severe.length}</div><div class="risk-sub">${kind === 'idle' ? '建议业务确认是否保留、转移或清理' : '超期 90 天以上，建议优先盘点'}</div></div>
                <div class="inventory-risk-card"><div class="risk-label">平均超期天数</div><div class="risk-value">${avgOverdue.toFixed(0)} 天</div><div class="risk-sub"><button class="btn btn-secondary btn-sm" onclick="downloadOverdueReport('${kind}')">导出${kind === 'idle' ? '静置' : '超期库存'}报告</button></div></div>
            </div>
            <div class="chart-card" style="margin-bottom:16px"><h3>${chartTitle}</h3><div class="chart-container"><canvas id="${kind === 'idle' ? 'chartIdle180' : 'chartDos180'}"></canvas></div></div>
            <div class="table-section">
                <div class="overdue-report-titlebar"><h3>${title}明细清单</h3><span style="font-size:12px;color:var(--text-muted)">筛选、排序、分页只影响页面展示；导出包含完整明细。</span></div>
                ${renderOverdueFilters(kind, data)}
                ${renderOverdueTable(kind, filtered)}
            </div>`;
        bindStockImagePreviewEvents();
        drawOverdueCategoryChart(kind, filtered);
    }

    async function loadDos180(wh) {
        const d = await apiGet('/api/inventory/stats/dos180?warehouse=' + encodeURIComponent(wh));
        overdueState.dos.rows = d.data || [];
        renderOverdueView('dos');
    }

    async function loadIdle180(wh) {
        const d = await apiGet('/api/inventory/stats/idle180?warehouse=' + encodeURIComponent(wh));
        overdueState.idle.rows = d.data || [];
        renderOverdueView('idle');
    }

    Object.assign(window, {
        setOverdueSort,
        updateOverdueFilter,
        resetOverdueFilter,
        updateOverduePerPage,
        toggleOverdueDetails,
        changeOverduePage
    });

    document.addEventListener('click', (event) => {
        const sortEl = event.target.closest('[data-overdue-sort]');
        if (sortEl) {
            setOverdueSort(sortEl.dataset.overdueKind, sortEl.dataset.overdueSort);
            return;
        }
        const resetEl = event.target.closest('[data-overdue-reset]');
        if (resetEl) {
            resetOverdueFilter(resetEl.dataset.overdueReset);
            return;
        }
        const pageEl = event.target.closest('[data-overdue-page]');
        if (pageEl) {
            changeOverduePage(pageEl.dataset.overdueKind, pageEl.dataset.overduePage);
            return;
        }
        const exportEl = event.target.closest('[data-overdue-export]');
        if (exportEl) downloadOverdueReport(exportEl.dataset.overdueExport);
    });
    document.addEventListener('input', (event) => {
        const el = event.target.closest('[data-overdue-filter]');
        if (el && el.tagName === 'INPUT') updateOverdueFilter(el.dataset.overdueKind, el.dataset.overdueFilter, el.value);
    });
    document.addEventListener('change', (event) => {
        const el = event.target.closest('[data-overdue-filter]');
        if (el && el.tagName !== 'INPUT') updateOverdueFilter(el.dataset.overdueKind, el.dataset.overdueFilter, el.value);
        const perPageEl = event.target.closest('[data-overdue-per-page]');
        if (perPageEl) updateOverduePerPage(perPageEl.dataset.overduePerPage, perPageEl.value);
        const detailsEl = event.target.closest('[data-overdue-details]');
        if (detailsEl) toggleOverdueDetails(detailsEl.dataset.overdueDetails, detailsEl.checked);
    });

    async function downloadOverdueReport(kind) {
        const wh = document.getElementById('dashWarehouse').value;
        const params = new URLSearchParams({ kind });
        if (wh) params.set('warehouse', wh);
        const res = await fetch(API + '/api/inventory/export/overdue?' + params.toString(), {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        });
        if (!res.ok) return toast('导出失败', 'error');
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = match ? match[1] : `VN64_${kind}_overdue.xlsx`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        toast('超期报告已导出');
    }
    window.downloadOverdueReport = downloadOverdueReport;

    // ===== Stock List =====
    let stockPage = 1, stockSortBy = 'updated_at', stockSortDir = 'desc', searchTimer = null, stockRequestSeq = 0;
    function debounceSearch() {
        clearTimeout(searchTimer);
        stockPage = 1;
        searchTimer = setTimeout(loadStockList, 260);
    }
    function toggleDetailCols() { document.getElementById('stockTable').classList.toggle('compact'); }
    function setStockSort(key) {
        if (stockSortBy === key) stockSortDir = stockSortDir === 'asc' ? 'desc' : 'asc';
        else { stockSortBy = key; stockSortDir = 'asc'; }
        stockPage = 1;
        loadStockList();
    }
    function updateStockSortHeader() {
        document.querySelectorAll('#stockTable th.sortable').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.sort === stockSortBy && stockSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.sort === stockSortBy && stockSortDir === 'desc');
        });
    }
    function clearStockFilters() {
        document.getElementById('stockSearch').value = '';
        ['filterCategory', 'filterCat2', 'filterInstruction'].forEach(id => {
            const el = document.getElementById(id);
            el.value = '';
            el.classList.remove('has-value');
        });
        stockQualityFilter = '';
        stockPage = 1;
        loadStockList();
    }
    function stockQualityLabel(value) {
        return ({
            missing_image: '仅看缺图片 SKU',
            missing_price: '仅看缺价格 SKU',
            missing_inbound: '仅看缺入库时间 SKU'
        })[value] || '';
    }
    function formatStockUpdatedAt(value) {
        if (!value) return '-';
        const raw = String(value).replace('T', ' ').slice(0, 19);
        const parsed = new Date(raw.replace(' ', 'T'));
        if (Number.isNaN(parsed.getTime())) return raw;
        return parsed.toLocaleString('zh-CN', { hour12: false });
    }
    function syncStockWarehouseTabs() {
        document.querySelectorAll('#page-stocklist .tab[data-warehouse]').forEach(t => {
            t.classList.toggle('active', t.dataset.warehouse === currentWarehouse);
        });
        const select = document.getElementById('stockWarehouseSelect');
        if (select) select.value = currentWarehouse || '';
    }
    function switchWarehouse(el) { document.querySelectorAll('#page-stocklist .tab').forEach(t => t.classList.remove('active')); el.classList.add('active'); currentWarehouse = el.dataset.warehouse; stockPage = 1; loadStockFilters(); loadStockList(); }
    function setStockWarehouseFilter(value) {
        currentWarehouse = value || '';
        stockPage = 1;
        loadStockFilters();
        loadStockList();
    }
    async function loadStockList() {
        syncStockWarehouseTabs();
        bindStockImagePreviewEvents();
        const q = document.getElementById('stockSearch').value, cat = document.getElementById('filterCategory').value, cat2 = document.getElementById('filterCat2').value, inst = document.getElementById('filterInstruction').value;
        const perPage = document.getElementById('stockPerPage')?.value || 20;
        const qualityLabelEl = document.getElementById('stockQualityFilterLabel');
        if (qualityLabelEl) {
            const label = stockQualityLabel(stockQualityFilter);
            qualityLabelEl.textContent = label;
            qualityLabelEl.style.display = label ? 'inline-flex' : 'none';
            qualityLabelEl.className = label ? 'badge badge-warning' : '';
        }
        const seq = ++stockRequestSeq;
        const tableBody = document.getElementById('stockTableBody');
        if (tableBody) tableBody.innerHTML = `<tr><td colspan="15" style="text-align:center;color:var(--text-muted);padding:28px">${tx('加载中...', 'Loading...')}</td></tr>`;
        const d = await apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&q=${encodeURIComponent(q)}&category=${encodeURIComponent(cat)}&category2=${encodeURIComponent(cat2)}&instruction=${encodeURIComponent(inst)}&quality=${encodeURIComponent(stockQualityFilter)}&sort_by=${encodeURIComponent(stockSortBy)}&sort_dir=${encodeURIComponent(stockSortDir)}&page=${stockPage}&per_page=${perPage}`);
        if (seq !== stockRequestSeq) return;
        const updatedEl = document.getElementById('stockLastUpdated');
        if (updatedEl) updatedEl.textContent = `${tx('库存更新时间', 'Inventory updated')}: ${formatStockUpdatedAt(d.last_updated_at)}`;
        updateStockSortHeader();
        if (!d.data.length) {
            const hasFilter = q || cat || cat2 || inst || stockQualityFilter;
            document.getElementById('stockTableBody').innerHTML = `<tr><td colspan="15" style="text-align:center;color:var(--text-muted);padding:36px;line-height:1.8">
                ${tx('当前', 'Current')} ${escapeHtml(currentWarehouse)} ${tx('没有可显示库存。', 'has no displayable inventory.')}${hasFilter ? tx('请清除搜索/筛选后再看。', 'Please clear search/filter and try again.') : tx('如果刚刚只上传了维护表，这是正常的；库存列表需要上传供应商库存表后才会产生数量。', 'If only the maintenance file was uploaded, this is normal; stock quantity appears after supplier inventory is uploaded.')}
            </td></tr>`;
            document.getElementById('stockPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">${tx('共 0 条', '0 records')}</span>`;
            applyFallbackEnglish(document.getElementById('page-stocklist'));
            return;
        }
        document.getElementById('stockTableBody').innerHTML = d.data.map(r => {
            const imagePath = r.image_path ? escapeHtml(r.image_path) : '';
            const imageArg = jsArg(r.image_path || '');
            const remarkArg = jsArg(r.comment || '');
            const imgSrc = imagePath ? imageUrl(r.image_path) : '';
            const bomDisplay = displayBomCode(r.bom_code || '');
            const thumb = imagePath ? `<img class="thumb stock-thumb thumb-clickable" src="${escapeHtml(imgSrc)}" data-image-path="${escapeHtml(r.image_path || '')}" data-remark="${escapeHtml(r.comment || '')}" onclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" ondblclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="${tx('点击或双击查看大图', 'Click or double-click to view large image')}">` : '<span style="color:var(--text-muted);font-size:12px">-</span>';
            return `<tr><td data-product-detail="${escapeHtml(r.product_number || '')}" style="max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer" title="${tx('点击查看 Product No 明细', 'Click to view Product No details')}"><button type="button" class="link-btn" data-product-detail="${escapeHtml(r.product_number || '')}" style="padding:0;font-weight:700">${escapeHtml(r.product_number || '')}</button></td><td class="thumb-col">${thumb}</td><td style="font-weight:500;max-width:110px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${escapeHtml(bomDisplay)}">${escapeHtml(bomDisplay)}</td><td style="min-width:260px;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(r.product_description || '')}">${escapeHtml(r.product_description || '')}</td><td style="max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-primary);font-weight:500;font-size:12px">${escapeHtml(r.category || '')}</td><td style="max-width:110px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(r.category_2 || '')}</td><td style="max-width:90px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(r.instruction || '')}</td><td style="text-align:right;max-width:90px"><span class="stock-inventory-value">${Number(r.inventory || 0).toLocaleString()}</span></td><td class="col-detail" style="text-align:right">${r.unit_price != null ? '$' + Number(r.unit_price).toFixed(2) : ''}</td><td class="col-detail" style="text-align:right;font-weight:500">${r.ttl_amount != null ? '$' + Number(r.ttl_amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : ''}</td><td class="col-detail">${escapeHtml(r.last_inbound_date || '')}</td><td class="col-detail">${escapeHtml(r.last_outbound_date || '')}</td><td class="col-detail" style="text-align:center">${r.dos || ''}</td><td class="col-detail" style="text-align:center">${r.days_without_stock || ''}</td><td class="col-detail" style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(r.comment || '')}">${escapeHtml(r.comment || '')}</td></tr>`;
        }).join('');
        const total = d.total, pageSize = d.per_page, pages = Math.max(1, Math.ceil(total / pageSize));
        document.getElementById('stockPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">${currentLang === 'en' ? `${total} records, page ${d.page}/${pages}` : `共 ${total} 条，第 ${d.page}/${pages} 页`}</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="stockPage=Math.max(1,${d.page}-1);loadStockList()" ${d.page <= 1 ? 'disabled' : ''}>${tx('上一页', 'Previous')}</button><button class="page-btn" onclick="stockPage=Math.min(${pages},${d.page}+1);loadStockList()" ${d.page >= pages ? 'disabled' : ''}>${tx('下一页', 'Next')}</button></div>`;
        applyFallbackEnglish(document.getElementById('page-stocklist'));
    }
    async function openProductDetail(productNumber) {
        if (!productNumber) return toast(tx('Product Number 为空，无法打开明细', 'Product Number is empty, unable to open details'), 'error');
        const body = document.getElementById('productDetailBody');
        openModal('productDetailModal');
        body.innerHTML = `<div style="padding:28px;color:var(--text-secondary)">${tx('加载中...', 'Loading...')}</div>`;
        const d = await apiGet('/api/inventory/product/' + encodeURIComponent(productNumber)).catch(e => ({ error: e.message }));
        if (d.error) { body.innerHTML = `<div style="padding:28px;color:var(--danger);line-height:1.8"><b>${tx('明细加载失败', 'Failed to load details')}</b><br>${escapeHtml(d.error)}<br><span style="color:var(--text-secondary)">${tx('请检查该 Product Number 是否已进入库存主数据。', 'Please check whether this Product Number exists in inventory master data.')}</span></div>`; toast(tx('Product No 明细加载失败', 'Failed to load Product No details'), 'error'); return; }
        const p = d.product || {};
        window.currentProductDetailData = d;
        const detailImagePath = p.image_path || '';
        const detailImageArg = jsArg(detailImagePath);
        const detailRemarkArg = jsArg(p.product_description || p.remark || '');
        const image = detailImagePath ? `<img class="product-detail-image" src="${escapeHtml(imageUrl(detailImagePath))}" data-detail-image="1" data-image-path="${escapeHtml(detailImagePath)}" data-remark="${escapeHtml(p.product_description || p.remark || '')}" onclick="event.preventDefault();event.stopPropagation();showImage(${detailImageArg}, ${detailRemarkArg})" title="${tx('点击查看大图', 'Click to view large image')}" style="width:160px;height:120px;object-fit:cover;border-radius:8px;border:1px solid var(--border);cursor:zoom-in">` : `<div style="width:160px;height:120px;border:1px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--text-muted)">${tx('无图', 'No image')}</div>`;
        const invRows = (d.inventory || []).map(r => `<tr><td>${escapeHtml(r.warehouse || '')}</td><td>${escapeHtml(r.instruction || '')}</td><td style="text-align:right">${r.inventory || 0}</td><td>${escapeHtml(r.last_inbound_date || '')}</td><td>${escapeHtml(r.last_outbound_date || '')}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
        const movementOrderType = (prefix) => {
            const pfx = String(prefix || '').trim().toUpperCase();
            if (pfx === 'PL') return tx('PL订单', 'PL order');
            if (pfx === 'EU') return tx('地区部订单', 'Regional order');
            return prefix || '';
        };
        const movementOrderTypeDisplay = (r) => {
            const operationId = String(r.operation_id || '').trim().toUpperCase();
            const orderType = movementOrderType(r.operation_prefix);
            if (operationId && operationId === String(orderType || '').trim().toUpperCase()) return '/';
            return orderType || '/';
        };
        const movementRows = (d.movements || []).map(r => `<tr><td>${escapeHtml(r.movement_date || '')}</td><td style="font-weight:700">${escapeHtml(r.product_number || '')}</td><td><span class="badge ${r.movement_type === 'inbound' ? 'badge-delivered' : 'badge-confirmed'}">${r.movement_type === 'inbound' ? tx('入库', 'Inbound') : tx('出库', 'Outbound')}</span></td><td style="min-width:160px">${escapeHtml(r.operation_id || '')}</td><td style="width:70px;max-width:70px;text-align:center;color:var(--text-secondary)">${escapeHtml(movementOrderTypeDisplay(r))}</td><td>${escapeHtml(r.operation_target || '')}</td><td style="text-align:right">${Number(r.quantity || 0).toLocaleString()}</td></tr>`).join('');
        const matched = (d.matched_product_numbers || []).filter(x => x && x !== (p.product_number || productNumber));
        const bomDisplay = displayBomCode(p.bom_code || '');
        body.innerHTML = `<div style="display:grid;grid-template-columns:180px 1fr;gap:18px;margin-bottom:18px">${image}<div><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start"><h3 style="margin:0 0 8px">${escapeHtml(p.product_number || productNumber)}</h3><button class="btn btn-primary btn-sm" onclick="openSkuMaintenance()">${tx('维护 SKU', 'Maintain SKU')}</button></div><div style="color:var(--text-secondary);line-height:1.8">${escapeHtml(p.product_description || '')}<br>BOM: <b>${escapeHtml(bomDisplay)}</b><br>${tx('物料品类', 'Category')}: ${escapeHtml(p.category || '')} · ${tx('适用产品', 'Category 2')}: ${escapeHtml(p.category_2 || '')}<br>${tx('单价', 'Unit price')}: $${Number(p.unit_price || 0).toFixed(2)} · ${tx('备注', 'Comment')}: ${escapeHtml(p.remark || '')}${matched.length ? `<br>${tx('关联编号', 'Related Product No')}: ${matched.map(escapeHtml).join(' / ')}` : ''}</div></div></div>
            <h4 style="margin:14px 0 8px">${tx('仓库库存', 'Warehouse inventory')}</h4><div style="overflow:auto"><table><thead><tr><th>${tx('仓库', 'Warehouse')}</th><th>${tx('归属国家', 'Instruction')}</th><th style="text-align:right">${tx('库存', 'Inventory')}</th><th>${tx('最近入库', 'Last inbound')}</th><th>${tx('最近出库', 'Last outbound')}</th><th>${tx('备注', 'Comment')}</th></tr></thead><tbody>${invRows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">${tx('暂无库存', 'No inventory')}</td></tr>`}</tbody></table></div>
            <h4 style="margin:16px 0 8px">${tx('近期出入流水（按 DATA RUCHU）', 'Recent inbound/outbound records (by DATA RUCHU)')}</h4><div style="overflow:auto;max-height:320px"><table><thead><tr><th>DATA RUCHU</th><th>Product No</th><th>${tx('类型', 'Type')}</th><th>ID_OPERACJI</th><th style="width:70px;max-width:70px;text-align:center">${tx('订单类型', 'Order type')}</th><th>${tx('对象/国家城市', 'Target / country or city')}</th><th style="text-align:right">${tx('数量', 'Qty')}</th></tr></thead><tbody>${movementRows || `<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">${tx('暂无 Specyfikacja 流水', 'No Specyfikacja records')}</td></tr>`}</tbody></table></div>`;
        applyFallbackEnglish(body);
    }
    function closeProductDetail() { closeModal('productDetailModal'); }
    window.openProductDetail = openProductDetail;
    window.showImage = showImage;
    window.closeImageModal = closeImageModal;
    function fillSkuMaintenanceSelect(id, values, selectedValue, placeholder) {
        const select = document.getElementById(id);
        if (!select) return;
        const norm = v => String(v || '').trim().toUpperCase();
        const selected = norm(selectedValue);
        const unique = [...new Set((values || []).map(norm).filter(Boolean))].sort();
        if (selected && !unique.includes(selected)) unique.unshift(selected);
        select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>` + unique.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
        select.value = selected;
    }
    function populateSkuMaintenanceOptions(product) {
        const p = product || {};
        const managed = getManagedOptions();
        const selectValues = id => Array.from(document.getElementById(id)?.options || []).map(o => o.value).filter(Boolean);
        const categories = [...managed.category, ...selectValues('filterCategory'), p.category];
        const category2s = [...managed.category2, ...selectValues('filterCat2'), p.category_2];
        fillSkuMaintenanceSelect('skuMaintCategory', categories, p.category, '请选择物料品类');
        fillSkuMaintenanceSelect('skuMaintCategory2', category2s, p.category_2, '请选择适用产品');
    }
    function openSkuMaintenance() {
        const d = window.currentProductDetailData || {};
        const p = d.product || {};
        if (!p.product_number) return toast('缺少 Product Number，无法维护', 'error');
        populateSkuMaintenanceOptions(p);
        document.getElementById('skuMaintProductNumber').value = p.product_number || '';
        document.getElementById('skuMaintProductNumberDisplay').value = p.product_number || '';
        document.getElementById('skuMaintBom').value = p.bom_code || '';
        document.getElementById('skuMaintDesc').value = p.product_description || '';
        document.getElementById('skuMaintUnitPrice').value = p.unit_price || 0;
        document.getElementById('skuMaintInbound').value = p.last_inbound_date || '';
        document.getElementById('skuMaintOutbound').value = p.last_outbound_date || '';
        document.getElementById('skuMaintDosThreshold').value = p.dos_threshold || 180;
        document.getElementById('skuMaintIdleThreshold').value = p.idle_threshold || 180;
        document.getElementById('skuMaintRemark').value = p.remark || '';
        openModal('skuMaintenanceModal');
    }
    async function saveSkuMaintenance() {
        const productNumber = document.getElementById('skuMaintProductNumber').value.trim();
        if (!productNumber) return toast('Product Number 不能为空', 'error');
        const payload = {
            bom_code: document.getElementById('skuMaintBom').value.trim(),
            product_description: document.getElementById('skuMaintDesc').value.trim(),
            category: document.getElementById('skuMaintCategory').value.trim(),
            category_2: document.getElementById('skuMaintCategory2').value.trim(),
            unit_price: parseFloat(document.getElementById('skuMaintUnitPrice').value) || 0,
            last_inbound_date: document.getElementById('skuMaintInbound').value,
            last_outbound_date: document.getElementById('skuMaintOutbound').value,
            dos_threshold: parseInt(document.getElementById('skuMaintDosThreshold').value) || 180,
            idle_threshold: parseInt(document.getElementById('skuMaintIdleThreshold').value) || 180,
            remark: document.getElementById('skuMaintRemark').value.trim()
        };
        const d = await apiPut('/api/inventory/product/' + encodeURIComponent(productNumber) + '/maintenance', payload).catch(e => ({ error: e.message }));
        if (!d.success) return toast(d.error || 'SKU 维护保存失败', 'error');
        toast('SKU 维护已保存');
        closeModal('skuMaintenanceModal');
        await openProductDetail(productNumber);
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
    }
    async function uploadSkuMaintenanceImage() {
        const input = document.getElementById('skuMaintImageFile');
        const productNumber = document.getElementById('skuMaintProductNumber')?.value || '';
        if (!input?.files?.[0]) return toast('请选择图片', 'error');
        const fd = new FormData();
        fd.append('files', input.files[0], input.files[0].name);
        const data = await fetch(API + '/api/inventory/images/upload', {
            method: 'POST',
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {},
            body: fd
        }).then(r => r.json()).catch(e => ({ error: e.message }));
        if (!data.success) return toast(data.error || '图片上传失败', 'error');
        input.value = '';
        document.getElementById('skuMaintImageName').textContent = '未选择图片';
        toast(`图片已上传 ${data.uploaded?.length || 0} 张`);
        if (productNumber) await openProductDetail(productNumber);
        await loadStockList();
    }
    function exportStockList() { apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&per_page=9999`).then(d => { let csv = 'BOM编号,产品编号,描述,物料品类,适用产品,归属国家,库存,单价,总金额,最近入库,最近出库,库龄,静置天数,备注\n'; d.data.forEach(r => { csv += `"${r.bom_code}","${r.product_number || ''}","${r.product_description || ''}","${r.category || ''}","${r.category_2 || ''}","${r.instruction || ''}",${r.inventory || 0},"${r.unit_price || 0}","${r.ttl_amount || 0}","${r.last_inbound_date || ''}","${r.last_outbound_date || ''}",${r.dos || ''},${r.days_without_stock || ''},"${r.comment || ''}"\n`; }); const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); const label = currentWarehouse ? currentWarehouse.replace(/\s/g, '_') : 'All_Warehouses'; a.download = `${label}_${new Date().toISOString().slice(0, 10)}.csv`; a.click(); toast('导出成功'); }); }
    async function exportLogisticsList(filters = {}) {
        const params = new URLSearchParams(filters || {});
        const res = await fetch(API + '/api/export/logistics' + (params.toString() ? '?' + params.toString() : ''), {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            return toast(err.error || `物流清单导出失败 HTTP ${res.status}`, 'error');
        }
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = match ? match[1] : `VN64_logistics_shipments_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        toast('物流清单已导出');
    }
    function openLogisticsExportModal() {
        fillSelectFromOptions('logisticsExportStatus', 'th-filter-ds', '全部物流状态');
        fillSelectFromOptions('logisticsExportType', 'th-filter-type', '全部类型');
        fillSelectFromOptions('logisticsExportCountry', 'th-filter-country', '全部需求国家');
        fillSelectFromOptions('logisticsExportPickupMonth', 'th-filter-pickup-month', '全部发货月份');
        const pickupMonth = document.getElementById('logisticsExportPickupMonth');
        if (pickupMonth) {
            const years = [...new Set(Array.from(pickupMonth.options)
                .map(o => String(o.value || '').slice(0, 4))
                .filter(y => /^\d{4}$/.test(y)))].sort().reverse();
            years.forEach(year => {
                const value = `year:${year}`;
                if (!Array.from(pickupMonth.options).some(o => o.value === value)) {
                    pickupMonth.insertAdjacentHTML('beforeend', `<option value="${value}">${year}全年</option>`);
                }
            });
        }
        openModal('logisticsExportModal');
    }
    function runLogisticsExportFromModal() {
        const filters = {
            ds: document.getElementById('logisticsExportStatus')?.value || '',
            type: document.getElementById('logisticsExportType')?.value || '',
            country: document.getElementById('logisticsExportCountry')?.value || '',
            pickup_month: document.getElementById('logisticsExportPickupMonth')?.value || ''
        };
        closeModal('logisticsExportModal');
        return exportLogisticsList(filters);
    }
    async function downloadBlobEndpoint(url, fallbackName, successText, preferFallbackName = false) {
        const res = await fetch(API + url, {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            return toast(err.error || `导出失败 HTTP ${res.status}`, 'error');
        }
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = preferFallbackName ? fallbackName : (match ? match[1] : fallbackName);
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        toast(successText || '导出成功');
    }
    function exportLogisticsCalibration() {
        return downloadBlobEndpoint('/api/export/logistics-calibration', `VN64_logistics_status_calibration_${new Date().toISOString().slice(0, 10)}.xlsx`, '物流状态校准 Excel 已导出');
    }
    function exportInvoiceDetailExcel() {
        return downloadBlobEndpoint('/api/export/invoice-calibration', `VN64_invoice_detail_${new Date().toISOString().slice(0, 10)}.xlsx`, '发票明细 Excel 已导出', true);
    }
    function exportInvoiceCalibration() {
        return exportInvoiceDetailExcel();
    }
    function exportAcceptanceDetailList() {
        return downloadBlobEndpoint('/api/export/invoice-calibration', `VN64_acceptance_detail_${new Date().toISOString().slice(0, 10)}.xlsx`, '验收明细 Excel 已导出', true);
    }
    function exportCoreBackup() {
        return downloadBlobEndpoint('/api/export/core-backup', `VN64_core_backup_no_images_${new Date().toISOString().slice(0, 10)}.xlsx`, '底层备份 Excel 已导出');
    }
    function fillSelectFromOptions(targetId, sourceId, allText) {
        const target = document.getElementById(targetId);
        const source = document.getElementById(sourceId);
        if (!target || !source) return;
        const current = target.value;
        target.innerHTML = `<option value="">${allText}</option>` + Array.from(source.options || [])
            .filter(o => o.value)
            .map(o => `<option value="${escapeHtml(o.value)}">${escapeHtml(o.textContent || o.value)}</option>`)
            .join('');
        target.value = Array.from(target.options).some(o => o.value === current) ? current : '';
    }
    function fillCheckMultiFromOptions(targetId, sourceId) {
        const target = document.getElementById(targetId);
        const source = document.getElementById(sourceId);
        if (!target || !source) return;
        const current = new Set(Array.from(target.querySelectorAll('input[type="checkbox"]:checked')).map(o => o.value).filter(Boolean));
        target.innerHTML = Array.from(source.options || [])
            .filter(o => o.value)
            .map(o => `<label class="checkline"><input type="checkbox" value="${escapeHtml(o.value)}" ${(!current.size || current.has(o.value)) ? 'checked' : ''}> ${escapeHtml(o.textContent || o.value)}</label>`)
            .join('');
    }
    function fillExcelFilterFromOptions(targetId, sourceId, allText = '全部') {
        const target = document.getElementById(targetId);
        const source = document.getElementById(sourceId);
        if (!target || !source) return;
        const current = new Set(Array.from(target.querySelectorAll('input[type="checkbox"]:checked')).map(o => o.value).filter(Boolean));
        const options = Array.from(source.options || []).filter(o => o.value).map(o => ({ value: o.value, label: o.textContent || o.value }));
        target.classList.add('excel-filter');
        target.dataset.allText = allText;
        target.innerHTML = `<button type="button" class="excel-filter-trigger" onclick="toggleExcelFilter(event, '${targetId}')">${escapeHtml(allText)}</button>
            <div class="excel-filter-menu" onclick="event.stopPropagation()">
                <input class="wms-input excel-filter-search" placeholder="搜索..." oninput="filterExcelOptions('${targetId}', this.value)">
                <div class="excel-filter-actions">
                    <button class="btn btn-secondary btn-sm" type="button" onclick="setExcelFilter('${targetId}', true)">全选</button>
                    <button class="btn btn-secondary btn-sm" type="button" onclick="setExcelFilter('${targetId}', false)">清空</button>
                </div>
                <div class="excel-filter-options">
                    ${options.map(o => `<label class="excel-filter-option" data-filter-text="${escapeHtml(String(o.label).toUpperCase())}"><input type="checkbox" value="${escapeHtml(o.value)}" ${(!current.size || current.has(o.value)) ? 'checked' : ''} onchange="updateExcelFilterLabel('${targetId}')"> <span>${escapeHtml(o.label)}</span></label>`).join('')}
                </div>
            </div>`;
        updateExcelFilterLabel(targetId);
    }
    function toggleExcelFilter(event, id) {
        event.stopPropagation();
        document.querySelectorAll('.excel-filter.open').forEach(el => { if (el.id !== id) el.classList.remove('open'); });
        document.getElementById(id)?.classList.toggle('open');
    }
    function setExcelFilter(id, checked) {
        const el = document.getElementById(id);
        if (!el) return;
        el.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
        updateExcelFilterLabel(id);
    }
    function filterExcelOptions(id, value) {
        const el = document.getElementById(id);
        const q = String(value || '').trim().toUpperCase();
        if (!el) return;
        el.querySelectorAll('.excel-filter-option').forEach(option => {
            option.style.display = !q || (option.dataset.filterText || '').includes(q) ? '' : 'none';
        });
    }
    function excelFilterValue(id) {
        const el = document.getElementById(id);
        if (!el) return '';
        const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
        const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
        return (!values.length || values.length === all.length) ? '' : values.join(',');
    }
    function excelFilterLabel(id, allText = '全部') {
        const el = document.getElementById(id);
        if (!el) return allText;
        const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
        const values = all.filter(o => o.checked).map(o => o.closest('label')?.querySelector('span')?.textContent || o.value).filter(Boolean);
        if (!values.length || values.length === all.length) return allText;
        return values.length > 3 ? `${values.slice(0, 3).join(' / ')} 等 ${values.length} 项` : values.join(' / ');
    }
    function updateExcelFilterLabel(id) {
        const el = document.getElementById(id);
        if (!el) return;
        const btn = el.querySelector('.excel-filter-trigger');
        if (btn) btn.textContent = excelFilterLabel(id, el.dataset.allText || '全部');
    }
    document.addEventListener('click', (event) => {
        if (!event.target.closest('.excel-filter')) {
            document.querySelectorAll('.excel-filter.open').forEach(el => el.classList.remove('open'));
        }
    });
    function setMultiCheck(id, checked) {
        const el = document.getElementById(id);
        if (!el) return;
        el.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
    }
    function multiCheckValue(id) {
        const el = document.getElementById(id);
        if (!el) return '';
        const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
        const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
        const total = all.length;
        return (!values.length || values.length === total) ? '' : values.join(',');
    }
    function multiCheckLabel(id, allText = '全部') {
        const el = document.getElementById(id);
        if (!el) return allText;
        const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
        const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
        const total = all.length;
        if (!values.length || values.length === total) return allText;
        return values.length > 3 ? `${values.slice(0, 3).join('-')}等${values.length}项` : values.join('-');
    }
    function openStockExportModal() {
        document.getElementById('stockExportWarehouse').value = currentWarehouse || '';
        fillExcelFilterFromOptions('stockExportCategory', 'filterCategory', '全部物料品类');
        fillExcelFilterFromOptions('stockExportCategory2', 'filterCat2', '全部适用产品');
        fillExcelFilterFromOptions('stockExportInstruction', 'filterInstruction', '全部归属国家');
        document.getElementById('stockExportFormat').value = 'pdf';
        openModal('stockExportModal');
    }
    function openMovementExportModal() {
        document.getElementById('movementExportWarehouse').value = currentWarehouse || '';
        document.getElementById('movementExportType').value = '';
        fillExcelFilterFromOptions('movementExportCategory', 'filterCategory', '全部物料品类');
        fillExcelFilterFromOptions('movementExportCategory2', 'filterCat2', '全部适用产品');
        fillExcelFilterFromOptions('movementExportInstruction', 'filterInstruction', '全部归属国家');
        const now = new Date();
        const first = new Date(now.getFullYear(), now.getMonth(), 1);
        const iso = d => d.toISOString().slice(0, 10);
        document.getElementById('movementExportStart').value = iso(first);
        document.getElementById('movementExportEnd').value = iso(now);
        openModal('movementExportModal');
    }
    async function downloadInventoryExcel(filters, format) {
        const params = new URLSearchParams({
            warehouse: filters.warehouse || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || ''
        });
        if (format === 'excel_images') params.set('include_images', '1');
        const res = await fetch(API + '/api/export/inventory?' + params.toString(), {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        });
        if (!res.ok) return toast('库存清单导出失败', 'error');
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = match ? match[1] : `VN64_inventory_${format}_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        return toast(format === 'excel_images' ? '库存图片版 Excel 已导出' : '库存全量 Excel 已导出');
    }
    async function runStockExportFromModal() {
        const format = document.getElementById('stockExportFormat')?.value || 'pdf';
        const filters = {
            warehouse: document.getElementById('stockExportWarehouse')?.value || '',
            category: excelFilterValue('stockExportCategory'),
            categoryLabel: excelFilterLabel('stockExportCategory', '全部物料品类'),
            category2: excelFilterValue('stockExportCategory2'),
            category2Label: excelFilterLabel('stockExportCategory2', '全部适用产品'),
            instruction: excelFilterValue('stockExportInstruction'),
            instructionLabel: excelFilterLabel('stockExportInstruction', '全部归属国家')
        };
        closeModal('stockExportModal');
        if (format === 'excel' || format === 'excel_images') {
            return downloadInventoryExcel(filters, format);
        }
        await exportAllStockListPdf(filters, format === 'pdf');
        if (format === 'html') setTimeout(exportReportHtml, 450);
        if (format === 'png') setTimeout(exportReportPng, 450);
    }
    async function runMovementExportFromModal() {
        const params = new URLSearchParams({
            warehouse: document.getElementById('movementExportWarehouse')?.value || '',
            movement_type: document.getElementById('movementExportType')?.value || '',
            category: excelFilterValue('movementExportCategory'),
            category2: excelFilterValue('movementExportCategory2'),
            instruction: excelFilterValue('movementExportInstruction'),
            start_date: document.getElementById('movementExportStart')?.value || '',
            end_date: document.getElementById('movementExportEnd')?.value || ''
        });
        closeModal('movementExportModal');
        const res = await fetch(API + '/api/inventory/export/movements?' + params.toString(), {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        }).catch(e => ({ ok: false, error: e.message }));
        if (!res || !res.ok) return toast(res?.error || '出入库流水导出失败', 'error');
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = match ? match[1] : `VN64_inventory_movements_${new Date().toISOString().slice(0, 10)}.xlsx`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        toast('出入库流水已导出');
    }
    async function exportAllStockList() { openStockExportModal(); }
    async function exportAllStockListPdf(filters = null, autoPrint = true) {
        filters = filters || {
            warehouse: currentWarehouse || '',
            category: document.getElementById('filterCategory')?.value || '',
            category2: document.getElementById('filterCat2')?.value || '',
            instruction: document.getElementById('filterInstruction')?.value || ''
        };
        const params = new URLSearchParams({
            warehouse: filters.warehouse || '',
            q: document.getElementById('stockSearch')?.value || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || '',
            per_page: 9999
        });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        const scopeBits = [
            filters.warehouse || '全部仓库',
            filters.categoryLabel || filters.category || '全部物料品类',
            filters.category2Label || filters.category2 || '全部适用产品',
            filters.instructionLabel || filters.instruction || '全部归属国家'
        ];
        renderInventoryPdfReport('库存清单', d.data || [], scopeBits.join(' · '), autoPrint);
    }
    async function exportCategory2StockReportPdf() {
        const category2 = (document.getElementById('filterCat2')?.value || '').trim();
        if (!category2) return toast('请先在表头选择“适用产品 Category 2”筛选项', 'error');
        const params = new URLSearchParams({ category2, warehouse: currentWarehouse || '', per_page: 9999 });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        renderInventoryPdfReport(`适用产品库存清单 · ${category2}`, d.data || [], currentWarehouse || '全部仓库');
    }
    function renderInventoryPdfReport(title, rows, scopeText, autoPrint = true) {
        const totalPcs = rows.reduce((s, r) => s + Number(r.inventory || 0), 0);
        const totalValue = rows.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const missingImage = rows.filter(r => !r.image_path).length;
        const missingPrice = rows.filter(r => Number(r.unit_price || 0) <= 0).length;
        const summarize = (field, label) => {
            const map = new Map();
            rows.forEach(r => {
                const key = String(r[field] || '未分类').trim() || '未分类';
                const cur = map.get(key) || { label: key, sku: 0, pcs: 0, value: 0 };
                cur.sku += 1;
                cur.pcs += Number(r.inventory || 0);
                cur.value += Number(r.ttl_amount || 0);
                map.set(key, cur);
            });
            const body = [...map.values()].sort((a, b) => b.value - a.value).slice(0, 8).map(r => `
                <tr><td title="${escapeHtml(r.label)}">${escapeHtml(r.label)}</td><td class="num">${r.sku.toLocaleString()}</td><td class="num">${r.pcs.toLocaleString()}</td><td class="num">${fmtPct(r.pcs, totalPcs)}</td><td class="num">${reportFmtMoney(r.value)}</td><td class="num">${fmtPct(r.value, totalValue)}</td></tr>
            `).join('');
            return `<div class="report-summary-card"><h3>${escapeHtml(label)}</h3><table><colgroup><col style="width:30%"><col style="width:12%"><col style="width:14%"><col style="width:14%"><col style="width:16%"><col style="width:14%"></colgroup><thead><tr><th>分类</th><th class="num">SKU</th><th class="num">PCS</th><th class="num">PCS占比</th><th class="num">货值</th><th class="num">货值占比</th></tr></thead><tbody>${body || '<tr><td colspan="6">暂无数据</td></tr>'}</tbody></table></div>`;
        };
        const cards = rows.map(r => {
            const img = r.image_path ? `<img class="report-inventory-top-thumb" src="${escapeHtml(imageUrl(r.image_path))}" alt="">` : '<div class="report-inventory-top-noimg">NO IMAGE</div>';
            return `<div class="report-inventory-top-item">${img}<div class="report-inventory-top-title" title="${escapeHtml(r.product_number || '')}">${escapeHtml(r.product_number || '')}</div><div><div class="report-inventory-top-desc" title="${escapeHtml(r.product_description || '')}">${escapeHtml(r.product_description || '')}</div></div><div class="report-inventory-top-meta">${escapeHtml(r.category || '-')}<span class="print-only"> / ${escapeHtml(r.category_2 || '-')} / ${escapeHtml(r.instruction || '-')}</span></div><div class="report-inventory-top-meta print-hide">${escapeHtml(r.category_2 || '-')}</div><div class="report-inventory-top-meta print-hide">${escapeHtml(r.instruction || '-')}</div><div class="report-inventory-top-metric"><b>${Number(r.inventory || 0).toLocaleString()}</b>PCS</div><div class="report-inventory-top-metric"><b>${reportFmtMoney(r.ttl_amount || 0)}</b>$${Number(r.unit_price || 0).toFixed(2)}/pcs</div></div>`;
        }).join('');
        const area = document.getElementById('reportPrintArea');
        document.getElementById('reportPreviewModal').style.display = 'flex';
        const cleanName = value => String(value || '全部').replace(/[\\/:*?"<>|\s]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '').slice(0, 80);
        const cat2Hint = (scopeText.match(/AUDIO|IOT|OTHER|PHONE|TABLET|WEARABLE|等\d+项|全部适用产品/g) || ['全部适用产品']).slice(-1)[0];
        area.dataset.exportBase = `${APP_VERSION}_库存清单_${cleanName(cat2Hint)}_${new Date().toISOString().slice(0, 10)}`;
        document.title = `${area.dataset.exportBase}`;
        area.innerHTML = `<div class="report-header"><div><h1 class="report-title">${escapeHtml(title)}</h1><div class="report-subtitle">统计范围：${escapeHtml(scopeText)} · 生成时间：${new Date().toLocaleString('zh-CN', { hour12:false })} · 版本：${APP_VERSION}</div></div></div>
            <div class="report-section"><div class="report-kpi-grid"><div class="report-kpi"><div class="label">SKU 条目</div><div class="value">${rows.length.toLocaleString()}</div><div class="sub">当前筛选</div></div><div class="report-kpi"><div class="label">库存总件数</div><div class="value">${totalPcs.toLocaleString()}</div><div class="sub">PCS</div></div><div class="report-kpi"><div class="label">库存总货值</div><div class="value">${reportFmtMoney(totalValue)}</div><div class="sub">USD</div></div><div class="report-kpi"><div class="label">缺图片 SKU</div><div class="value">${missingImage.toLocaleString()}</div><div class="sub">需维护</div></div><div class="report-kpi"><div class="label">缺价格 SKU</div><div class="value">${missingPrice.toLocaleString()}</div><div class="sub">需维护</div></div></div></div>
            <div class="report-section"><h2>Summary 统计</h2><div class="report-summary-grid">${summarize('category', '品类')}${summarize('category_2', '产业')}${summarize('instruction', '归属国家')}</div></div>
            <div class="report-section"><h2>库存明细</h2><div class="report-inventory-top-list">${cards || '<div class="report-note">暂无数据</div>'}</div></div>
            <div class="report-footer"><span>Generated by ${APP_VERSION}</span><span>Inventory PDF report</span></div>`;
        if (autoPrint) setTimeout(() => window.print(), 350);
    }
    async function exportReportCategory2Inventory() {
        const category2 = (document.getElementById('reportCategory2')?.value || '').trim();
        if (!category2) return toast('请选择适用产品 Category 2', 'error');
        const warehouse = document.getElementById('reportWarehouse')?.value || '';
        const params = new URLSearchParams({ category2, per_page: 9999, warehouse });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        const rows = d.data || [];
        const whText = warehouse || '全部仓库';
        renderInventoryPdfReport(`适用产品库存清单 · ${category2}`, rows, whText);
    }
    async function downloadFullExport(scope) {
        const params = new URLSearchParams({ scope });
        if (scope === 'current') params.set('warehouse', currentWarehouse);
        const res = await fetch(API + `/api/export/full?${params.toString()}`, {
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {}
        });
        if (!res.ok) return toast('导出失败', 'error');
        const blob = await res.blob();
        const cd = res.headers.get('Content-Disposition') || '';
        const match = cd.match(/filename="?([^"]+)"?/);
        const filename = match ? match[1] : `VN64_export_${scope}_${new Date().toISOString().slice(0, 10)}.zip`;
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(a.href);
        toast('完整导出包已生成');
    }
    async function loadStockFilters() {
        const invData = await apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&per_page=9999`).catch(() => ({ data: [] }));
        const selected = {
            category: document.getElementById('filterCategory').value,
            category2: document.getElementById('filterCat2').value,
            instruction: document.getElementById('filterInstruction').value
        };
        const rows = Array.isArray(invData.data) ? invData.data : [];
        const activeRows = rows.filter(s => Number(s.inventory || 0) > 0);
        const sourceRows = activeRows.length ? activeRows : rows;
        const cats = uniqueSortedInventoryOptions(sourceRows, 'category');
        const cat2s = uniqueSortedInventoryOptions(sourceRows, 'category_2');
        const insts = uniqueSortedInventoryOptions(sourceRows, 'instruction');
        document.getElementById('filterCategory').innerHTML = '<option value="">全部</option>' + cats.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        document.getElementById('filterCat2').innerHTML = '<option value="">全部</option>' + cat2s.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        document.getElementById('filterInstruction').innerHTML = '<option value="">全部</option>' + insts.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        if (document.getElementById('reportCategory2')) {
            const currentReportCat2 = document.getElementById('reportCategory2').value;
            document.getElementById('reportCategory2').innerHTML = '<option value="">选择适用产品</option>' + cat2s.map(c => `<option>${escapeHtml(c)}</option>`).join('');
            document.getElementById('reportCategory2').value = cat2s.includes(currentReportCat2) ? currentReportCat2 : '';
        }
        document.getElementById('filterCategory').value = cats.includes(selected.category) ? selected.category : '';
        document.getElementById('filterCat2').value = cat2s.includes(selected.category2) ? selected.category2 : '';
        document.getElementById('filterInstruction').value = insts.includes(selected.instruction) ? selected.instruction : '';
    }

    // ===== Operations =====
    function switchOpsTab(el) {
        document.querySelectorAll('#opsTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active');
        const tab = el.dataset.otab;
        if (tab === 'adjust') renderOpsAdjust();
        else if (tab === 'scrap') renderOpsScrap();
        else if (tab === 'history') renderOpsHistory();
    }

    async function renderOpsAdjust() {
        document.getElementById('opsTabContent').innerHTML = `<div style="display:grid;grid-template-columns:340px 1fr;gap:24px"><div><div class="table-section"><div class="form-group"><label>仓库</label><select class="wms-select" id="adjWarehouse" style="width:100%"><option value="Lodz warehouse">Lodz 仓库</option><option value="Bydgoszcz warehouse">Bydgoszcz 仓库</option></select></div><div class="form-group"><label>类型</label><select class="wms-select" id="adjType" style="width:100%"><option value="inbound">入库</option><option value="outbound">出库</option><option value="adjustment">调整</option></select></div><div class="form-group"><label>Product Number</label><input class="wms-input" id="adjProductNumber" style="width:100%" placeholder="输入仓库产品编号/CWH号..."></div><div class="form-group"><label>数量</label><input class="wms-input" id="adjQty" type="number" min="0" style="width:100%" placeholder="0"></div><div class="form-group"><label>备注</label><textarea class="wms-textarea" id="adjComment" rows="2" style="width:100%" placeholder="原因说明..."></textarea></div><button class="btn btn-primary" style="width:100%" onclick="submitAdjustment()">提 交</button></div></div><div><div class="table-section"><h3 style="font-size:15px;font-weight:600;margin-bottom:12px">变动记录</h3><div style="overflow-x:auto"><table><thead><tr><th>时间</th><th>仓库</th><th>Product Number</th><th>BOM 编号</th><th>描述</th><th>类型</th><th style="text-align:right">数量变动</th><th>备注</th></tr></thead><tbody id="adjTxnBody"></tbody></table></div></div></div></div>`;
        loadAdjustTransactions();
    }

    async function loadAdjustTransactions() {
        const d = await apiGet('/api/inventory/transactions?per_page=50');
        const typeColors = { inbound: 'badge-delivered', outbound: 'badge-danger', adjustment: 'badge-pending', order_ship: 'badge-confirmed', scrap: 'badge-danger', calibration: 'badge-confirmed' };
        const typeLabels = { inbound: '入库', outbound: '出库', adjustment: '调整', order_ship: '发货指令', scrap: '报废', calibration: '校准' };
        document.getElementById('adjTxnBody').innerHTML = d.data.map(r => `<tr><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td>${escapeHtml(r.warehouse || '')}</td><td style="font-weight:500">${escapeHtml(r.product_number || '')}</td><td>${escapeHtml(r.bom_code || '')}</td><td>${escapeHtml(r.product_description || '')}</td><td><span class="badge ${typeColors[r.change_type] || ''}">${escapeHtml(typeLabels[r.change_type] || r.change_type)}</span></td><td style="text-align:right;color:${r.quantity_change >= 0 ? 'var(--success)' : 'var(--danger)'}">${r.quantity_change > 0 ? '+' : ''}${r.quantity_change}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
    }

    async function submitAdjustment() {
        const data = { warehouse: document.getElementById('adjWarehouse').value, product_number: document.getElementById('adjProductNumber').value.trim(), change_type: document.getElementById('adjType').value, quantity: parseInt(document.getElementById('adjQty').value) || 0, comment: document.getElementById('adjComment').value.trim() };
        if (!data.product_number || !data.quantity) return toast('请填写 Product Number 和数量', 'error');
        const d = await apiPost('/api/inventory/adjust', data);
        if (d.success) { toast('库存已更新'); document.getElementById('adjProductNumber').value = ''; document.getElementById('adjQty').value = ''; document.getElementById('adjComment').value = ''; loadAdjustTransactions(); loadStockList(); }
        else toast(d.error || '操作失败', 'error');
    }

    async function renderOpsScrap() {
        document.getElementById('opsTabContent').innerHTML = `<div style="display:grid;grid-template-columns:340px 1fr;gap:24px"><div><div class="table-section"><h4 style="font-size:13px;color:var(--danger);margin-bottom:12px">报废出库</h4><div class="form-group"><label>仓库</label><select class="wms-select" id="scrapWarehouse" style="width:100%"><option value="Lodz warehouse">Lodz 仓库</option><option value="Bydgoszcz warehouse">Bydgoszcz 仓库</option></select></div><div class="form-group"><label>Product Number</label><input class="wms-input" id="scrapProductNumber" style="width:100%" placeholder="输入仓库产品编号/CWH号..."></div><div class="form-group"><label>报废数量</label><input class="wms-input" id="scrapQty" type="number" min="1" style="width:100%" placeholder="0"></div><div class="form-group"><label>报废原因</label><select class="wms-select" id="scrapReason" style="width:100%"><option value="">请选择...</option><option value="损坏">损坏</option><option value="过期">过期</option><option value="质量问题">质量问题</option><option value="滞销报废">滞销报废</option><option value="其他">其他</option></select></div><div class="form-group"><label>备注</label><textarea class="wms-textarea" id="scrapComment" rows="2" style="width:100%"></textarea></div><button class="btn btn-danger" style="width:100%" onclick="submitScrap()">确认报废</button></div></div></div>`;
        loadScrapStats();
    }

    async function submitScrap() {
        const data = { warehouse: document.getElementById('scrapWarehouse').value, product_number: document.getElementById('scrapProductNumber').value.trim(), change_type: 'scrap', quantity: parseInt(document.getElementById('scrapQty').value) || 0, comment: `[${document.getElementById('scrapReason').value}] ${document.getElementById('scrapComment').value.trim()}` };
        if (!data.product_number || data.quantity <= 0) return toast('请填写完整信息', 'error');
        const d = await apiPost('/api/inventory/adjust', data);
        if (d.success) toast('已报废 ' + data.quantity + ' 件'); else toast(d.error || '操作失败', 'error');
    }

    async function loadScrapStats() { const d = await apiGet('/api/inventory/stats/scrap'); }

    async function renderOpsHistory() {
        document.getElementById('opsTabContent').innerHTML = `<div class="table-section"><div style="overflow-x:auto"><table><thead><tr><th>时间</th><th>仓库</th><th>Product Number</th><th>BOM 编号</th><th>描述</th><th>类型</th><th style="text-align:right">数量变动</th><th>备注</th></tr></thead><tbody id="allTxnBody"></tbody></table></div></div>`;
        const d = await apiGet('/api/inventory/transactions?per_page=100');
        const typeColors = { inbound: 'badge-delivered', outbound: 'badge-danger', adjustment: 'badge-pending', order_ship: 'badge-confirmed', scrap: 'badge-danger', calibration: 'badge-confirmed' };
        const typeLabels = { inbound: '入库', outbound: '出库', adjustment: '调整', order_ship: '发货指令', scrap: '报废', calibration: '校准' };
        document.getElementById('allTxnBody').innerHTML = d.data.map(r => `<tr><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td>${escapeHtml(r.warehouse || '')}</td><td style="font-weight:500">${escapeHtml(r.product_number || '')}</td><td>${escapeHtml(r.bom_code || '')}</td><td>${escapeHtml(r.product_description || '')}</td><td><span class="badge ${typeColors[r.change_type] || ''}">${escapeHtml(typeLabels[r.change_type] || r.change_type)}</span></td><td style="text-align:right;color:${r.quantity_change >= 0 ? 'var(--success)' : 'var(--danger)'}">${r.quantity_change > 0 ? '+' : ''}${r.quantity_change}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
    }

    // ===== Upload List =====
    function askRareUploadPassword() {
        const pwd = prompt('非常用数据校准入口，请输入密码');
        if (pwd == null) return null;
        if (!pwd.trim()) {
            toast('请输入密码', 'error');
            return null;
        }
        return pwd.trim();
    }
    async function submitCoreBackupImport() {
        const fileInput = document.getElementById('coreBackupFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择完整包 ZIP / 底层备份 Excel', 'error');
        const password = askRareUploadPassword();
        if (password == null) return;
        if (!confirm('确认恢复完整包？系统会按备份内容更新/新增物流、发票、库存、SKU 和出入库流水。')) return;
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        fd.append('password', password);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在恢复完整包 / 底层备份 Excel...';
        const data = await uploadFormWithProgress(API + '/api/import/core-backup', fd, 'progress-coreBackup').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '完整包恢复失败';
            return toast(data.error || '完整包恢复失败', 'error');
        }
        const r = data.report || {};
        const line = (label, obj) => `<div>${label}：新建 ${Number(obj?.created || 0)}，更新 ${Number(obj?.updated || 0)}，跳过 ${Number((obj?.skipped || 0) + (obj?.skipped_existing || 0))}</div>`;
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>完整包恢复完成</b></div>
            ${line('物流底表', r.shipments)}
            ${line('发票验收底表', r.invoices)}
            ${line('库存底表', r.inventory)}
            ${line('SKU 主数据', r.sku)}
            ${line('出入库流水', r.movements)}
            <div>图片文件：还原 ${Number(r.images?.extracted || 0)}，映射 ${Number(r.images?.mapped || 0)}，跳过 ${Number(r.images?.skipped || 0)}</div>
        </div>`;
        fileInput.value = '';
        document.getElementById('coreBackupFileName').textContent = '选择完整包 ZIP / 底层备份 Excel';
        currentFilterMonth = '';
        currentFilterPickupMonth = '';
        currentPage = 1;
        stockPage = 1;
        await Promise.allSettled([
            loadDashboard(),
            loadSummary(),
            loadShipments(),
            loadStockFilters(),
            loadStockList(),
            loadUploadRecords()
        ]);
        toast(`恢复完成：物流 ${Number(r.shipments?.created || 0) + Number(r.shipments?.updated || 0)} 条，图片 ${Number(r.images?.extracted || 0)} 张`);
        toast('完整包恢复完成');
        await Promise.allSettled([loadDashboard(), loadStockFilters(), loadStockList(), loadInvDashboard(), loadBudgetPage()]);
        loadUploadRecords();
    }
    async function submitInventoryCalibrationImport() {
        const fileInput = document.getElementById('calibrationInventoryFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择库存校准 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在导入库存校准 Excel...';
        const data = await uploadFormWithProgress(API + '/api/inventory/import-calibration', fd, 'progress-calibrationImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '库存校准导入失败';
            return toast(data.error || '库存校准导入失败', 'error');
        }
        const r = data.report || {};
        const sheets = Object.entries(r.sheets || {}).map(([name, s]) => {
            if (s.missing) return `<div>${escapeHtml(name)}：缺少 Sheet</div>`;
            if (s.error) return `<div>${escapeHtml(name)}：${escapeHtml(s.error)}</div>`;
            return `<div>${escapeHtml(name)}：导入 ${s.imported || 0} 行，新建 ${s.created || 0}，更新 ${s.updated || 0}，库存变化 ${s.inventory_changed || 0}，跳过 ${s.skipped || 0}</div>`;
        }).join('');
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>库存校准完成</b></div>
            <div>本地源文件：${escapeHtml(r.source_file || '-')}</div>
            <div>合计导入 ${r.imported || 0} 行，新建 ${r.created || 0}，更新 ${r.updated || 0}，库存变化 ${r.inventory_changed || 0}，跳过 ${r.skipped || 0}</div>
            ${sheets}
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 6).join('；'))}${r.errors.length > 6 ? '；...' : ''}</div>` : ''}
        </div>`;
        fileInput.value = '';
        document.getElementById('calibrationInventoryFileName').textContent = '选择库存校准 Excel';
        toast('库存校准导入完成');
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleInventoryCalibrationFileSelected(input) {
        updateSelectedFileLabel(input, 'calibrationInventoryFileName', '选择库存校准 Excel');
        if (input?.files?.length) submitInventoryCalibrationImport();
    }

    async function submitSpecyfikacjaImport() {
        const fileInput = document.getElementById('specyfikacjaFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择 Specyfikacja Excel', 'error');
        const fd = new FormData();
        Array.from(fileInput.files).forEach(f => fd.append('files', f, f.name));
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = `正在导入 ${fileInput.files.length} 个 Specyfikacja 出入库流水文件...`;
        const data = await uploadFormWithProgress(API + '/api/inventory/import-specyfikacja', fd, 'progress-specyfikacjaImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || 'Specyfikacja 导入失败';
            return toast(data.error || 'Specyfikacja 导入失败', 'error');
        }
        const r = data.report || {};
        const files = (r.files || []).map(f => {
            if (f.error) return `<div>${escapeHtml(f.source_file || '-')}：${escapeHtml(f.error)}</div>`;
            return `<div>${escapeHtml(f.source_file || '-')}：入库 ${f.inbound_rows || 0} 行，出库 ${f.outbound_rows || 0} 行，跳过 ${f.skipped || 0} 行</div>`;
        }).join('');
        const sheets = Object.entries(r.sheets || {}).slice(0, 12).map(([name, s]) => {
            if (s.ignored) return `<div>${escapeHtml(name)}：已忽略${s.reason ? '（' + escapeHtml(s.reason) + '）' : ''}</div>`;
            if (s.error) return `<div>${escapeHtml(name)}：${escapeHtml(s.error)}</div>`;
            return `<div>${escapeHtml(name)}：${escapeHtml(s.type || '')} ${s.rows || 0} 行，跳过 ${s.skipped || 0}</div>`;
        }).join('');
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>出入库流水导入完成</b></div>
            <div>本地源文件：${escapeHtml((r.source_files || []).join('；') || r.source_file || '-')}</div>
            <div>文件数 ${r.file_count || (r.source_files || []).length || 1}</div>
            <div>入库流水 ${r.inbound_rows || 0} 行；出库流水 ${r.outbound_rows || 0} 行；更新主数据 ${r.updated_products || 0} 条；更新库存记录 ${r.updated_inventory_rows || 0} 条；跳过 ${r.skipped || 0} 行</div>
            ${files}
            ${sheets}
            ${Object.keys(r.sheets || {}).length > 12 ? '<div>Sheet 明细较多，仅显示前 12 条。</div>' : ''}
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 6).join('；'))}${r.errors.length > 6 ? '；...' : ''}</div>` : ''}
        </div>`;
        fileInput.value = '';
        document.getElementById('specyfikacjaFileName').textContent = '选择 Specyfikacja Excel（可多选）';
        toast('出入库流水已导入');
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleSpecyfikacjaFileSelected(input) {
        updateSelectedFileLabel(input, 'specyfikacjaFileName', '选择 Specyfikacja Excel（可多选）');
        if (input?.files?.length) submitSpecyfikacjaImport();
    }

    async function submitLogisticsCalibrationImport() {
        const fileInput = document.getElementById('logisticsCalibrationFile');
        if (!fileInput.files[0]) return toast('请选择物流状态校准 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        const data = await uploadFormWithProgress(API + '/api/shipments/import-calibration', fd, 'progress-logisticsCalibration').catch(e => ({ error: e.message }));
        if (!data.success) return toast(data.error || '物流状态校准导入失败', 'error');
        fileInput.value = '';
        document.getElementById('logisticsCalibrationFileName').textContent = '选择物流状态校准 Excel';
        toast(`物流状态校准完成：更新 ${data.updated || 0} 条，跳过 ${data.skipped || 0} 条`);
        await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters()]);
        loadUploadRecords();
    }

    async function submitInvoiceCalibrationImport() {
        const fileInput = document.getElementById('invoiceCalibrationFile');
        const resultEl = document.getElementById('invoice-calibration-result');
        if (!fileInput.files[0]) return toast('请选择验收明细 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        if (resultEl) {
            resultEl.className = 'import-result import-file-name loading';
            resultEl.textContent = '正在导入验收明细...';
        }
        const data = await uploadFormWithProgress(API + '/api/invoices/import-calibration', fd, 'progress-invoiceCalibration').catch(e => ({ error: e.message }));
        if (!data.success) {
            if (resultEl) {
                resultEl.className = 'import-result import-file-name error';
                resultEl.textContent = data.error || '验收明细导入失败';
            }
            return toast(data.error || '验收明细导入失败', 'error');
        }
        fileInput.value = '';
        document.getElementById('invoiceCalibrationFileName').textContent = '';
        if (resultEl) {
            resultEl.className = 'import-result import-file-name success';
            resultEl.textContent = `验收明细导入完成：发票 ${data.updated_headers || 0} 张，明细 ${data.updated_items || 0} 行`;
        }
        toast(`验收明细导入完成：发票 ${data.updated_headers || 0} 张，明细 ${data.updated_items || 0} 行`);
        await Promise.allSettled([loadInvoicePage(), loadBudgetPage(), loadShipments()]);
        loadUploadRecords();
    }

    function handleInvoiceCalibrationFileSelected(input) {
        updateSelectedFileLabel(input, 'invoiceCalibrationFileName', '');
        if (input?.files?.length) submitInvoiceCalibrationImport();
    }

    async function submitSupplierInventoryImport() {
        const supplier = document.getElementById('supplierInventoryFile');
        const maintenance = document.getElementById('maintenanceInventoryFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!supplier.files[0] && !maintenance.files[0]) return toast('请选择供应商库存表或维护表', 'error');
        const fd = new FormData();
        if (supplier.files[0]) fd.append('supplier_file', supplier.files[0]);
        if (maintenance.files[0]) fd.append('maintenance_file', maintenance.files[0]);
        fd.append('warehouse', document.getElementById('supplierImportWarehouse').value);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在导入/刷新...';
        const data = await uploadFormWithProgress(API + '/api/inventory/import-supplier', fd, 'progress-supplierImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '导入失败';
            return toast(data.error || '导入失败', 'error');
        }
        const r = data.report;
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>${escapeHtml(r.warehouse)}</b> 导入/刷新完成</div>
            <div>供应商表头行：${r.supplier_header_row ? '第 ' + r.supplier_header_row + ' 行' : '未上传'}；维护表头行：${r.maintenance_header_row ? '第 ' + r.maintenance_header_row + ' 行' : '未上传'}</div>
            <div>供应商库存 ${r.supplier_rows || 0} 行，刷新库存 ${r.imported || 0} 行，跳过无效行 ${r.skipped_supplier_rows || 0} 行，移除旧库存 ${r.removed_inventory || 0} 行</div>
            <div>维护表 ${r.maintenance_rows || 0} 行；新建主数据 ${r.created_products || 0}；更新主数据 ${r.updated_products || 0}</div>
            <div>沿用已有维护数据：${r.used_existing_maintenance || 0} 行；自动推断 Bom Code：${r.inferred_bom?.length ? escapeHtml(r.inferred_bom.join(', ')) : '无'}</div>
            <div>库存校准：${r.updated_inventory || 0}</div>
            <div>缺维护/BOM：${r.missing_bom?.length ? escapeHtml(r.missing_bom.join(', ')) : '无'}</div>
            <div>缺图片：${r.missing_images.length ? escapeHtml(r.missing_images.join(', ')) : '无'}</div>
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 5).join('；'))}${r.errors.length > 5 ? '；...' : ''}</div>` : ''}
        </div>`;
        supplier.value = '';
        maintenance.value = '';
        document.getElementById('supplierInventoryFileName').textContent = '选择供应商库存表';
        document.getElementById('maintenanceInventoryFileName').textContent = '选择库存维护表';
        toast('导入/刷新成功');
        currentWarehouse = r.warehouse;
        syncStockWarehouseTabs();
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleSupplierInventoryFileSelected(input) {
        updateSelectedFileLabel(input, 'supplierInventoryFileName', '选择供应商库存表');
        if (input?.files?.length) submitSupplierInventoryImport();
    }

    function handleMaintenanceInventoryFileSelected(input) {
        updateSelectedFileLabel(input, 'maintenanceInventoryFileName', '选择库存维护表');
        if (input?.files?.length) submitSupplierInventoryImport();
    }

    // ===== Upload Images =====
    function handleImageFiles(files) {
        pendingImageFiles = Array.from(files).filter(f => /\.(png|jpg|jpeg|gif|webp)$/i.test(f.name));
        document.getElementById('imagePreviewList').innerHTML = pendingImageFiles.length ? `<div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px">已选择 ${pendingImageFiles.length} 个文件：</div>` + pendingImageFiles.slice(0, 20).map(f => `<div style="padding:2px 0;color:var(--text-muted);font-size:11px">${f.webkitRelativePath || f.name}</div>`).join('') : '';
        document.getElementById('imageUploadFileName').textContent = pendingImageFiles.length ? `已选择 ${pendingImageFiles.length} 张图片` : '请选择图片文件';
        const uploadBtn = document.getElementById('uploadImagesBtn');
        if (uploadBtn) uploadBtn.style.display = 'none';
    }
    function handleAndSubmitImageFiles(files) {
        handleImageFiles(files);
        if (pendingImageFiles.length) submitImageUpload();
    }
    async function submitImageUpload() {
        if (!pendingImageFiles.length) return toast('请先选择图片文件', 'error');
        const fd = new FormData(); pendingImageFiles.forEach(f => fd.append('files', f, f.name));
        const d = await uploadFormWithProgress(API + '/api/inventory/images/upload', fd, 'progress-images').catch(e => ({ error: e.message }));
        if (d.success) { let msg = `已上传 ${d.uploaded.length} 张图片`; if (d.repaired) msg += `，修复映射 ${d.repaired} 条`; if (d.not_found.length) msg += `。未匹配: ${d.not_found.join(', ')}`; toast(msg); pendingImageFiles = []; document.getElementById('imageFileInput').value = ''; document.getElementById('imagePreviewList').innerHTML = ''; document.getElementById('imageUploadFileName').textContent = '请选择图片文件'; const uploadBtn = document.getElementById('uploadImagesBtn'); if (uploadBtn) uploadBtn.style.display = 'none'; loadStockList(); loadUploadRecords(); }
        else toast(d.error || '上传失败', 'error');
    }

    async function clearInventoryImages() {
        if (!confirm('确认清理全部库存图片？库存、物流和发票数据不会删除。')) return;
        const password = askMaintenancePassword('请输入清理密码');
        if (password == null) return;
        const d = await apiFetch(API + '/api/inventory/images', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        }).catch(e => ({ error: e.message }));
        if (!d.success) return toast(d.error || '清理失败', 'error');
        pendingImageFiles = [];
        document.getElementById('imageFileInput').value = '';
        document.getElementById('imagePreviewList').innerHTML = '';
        document.getElementById('imageUploadFileName').textContent = '请选择图片文件';
        const uploadBtn = document.getElementById('uploadImagesBtn');
        if (uploadBtn) uploadBtn.style.display = 'none';
        toast(`已清理 ${d.deleted || 0} 张图片`);
        loadStockList();
        loadInvDashboard();
    }

    async function runSlimMaintenance() {
        const options = {
            clear_inventory: document.getElementById('slimClearInventory')?.checked === true,
            clear_images: document.getElementById('slimClearImages')?.checked === true,
            clear_non_business_uploads: document.getElementById('slimClearUploads')?.checked === true,
            clear_logistics_uploads: document.getElementById('slimClearLogisticsUploads')?.checked === true,
            clear_invoice_uploads: document.getElementById('slimClearInvoiceUploads')?.checked === true,
            clear_cache: document.getElementById('slimClearCache')?.checked === true,
            clear_update_downloads: document.getElementById('slimClearUpdateDownloads')?.checked === true,
            clear_backups: document.getElementById('slimClearBackups')?.checked === true,
        };
        if (!Object.values(options).some(Boolean)) return toast('请至少选择一个清理项', 'error');
        const backupWarning = options.clear_backups ? '\n\n注意：你勾选了清理历史备份/旧补丁，会影响本机回档，但能明显降低体积。' : '';
        if (!confirm('确认执行一键瘦身？\n\n系统会保留物流数据、发票/验收数据、手动状态、异常单和回收站记录。' + backupWarning)) return;
        const password = prompt('请输入维护密码');
        if (password == null) return;
        const box = document.getElementById('slimMaintenanceResult');
        if (box) {
            box.style.display = 'block';
            box.innerHTML = '正在瘦身，请稍候...';
        }
        const d = await apiFetch(API + '/api/maintenance/slim', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password, ...options })
        }).catch(e => ({ error: e.message }));
        if (!d.success) {
            if (box) box.innerHTML = `<div style="color:var(--danger)">${escapeHtml(d.error || '瘦身失败')}</div>`;
            return toast(d.error || '瘦身失败', 'error');
        }
        const inv = d.deleted?.inventory_records || {};
        const invCount = Object.values(inv).reduce((sum, n) => sum + (Number(n) || 0), 0);
        const freedMb = Number(d.freed_bytes || 0) / 1024 / 1024;
        const lines = [
            `释放空间：${freedMb.toFixed(1)} MB`,
            `库存相关记录：${invCount} 条`,
            `库存图片：${Number(d.deleted?.image_files || 0)} 个`,
            `物流上传源文件：${Number(d.deleted?.logistics_upload_files || 0)} 个`,
            `发票上传源文件：${Number(d.deleted?.invoice_upload_files || 0)} 个`,
            `其他上传源文件：${Number(d.deleted?.other_upload_files || 0)} 个`,
            `保留上传源文件：${Number(d.deleted?.kept_upload_files || 0)} 个`,
            `缓存文件：${Number(d.deleted?.cache_files || 0)} 个`,
            `已下载更新包/临时文件：${Number(d.deleted?.downloaded_update_files || 0)} 个`,
            `历史备份文件：${Number(d.deleted?.backup_files || 0)} 个`,
            `旧 VN 启动/说明文件：${Number(d.deleted?.old_patch_files || 0)} 个`,
            `旧补丁/备份文件夹：${Number(d.deleted?.old_patch_dirs || 0)} 个`,
            `失败项：${(d.failed || []).length} 个`,
        ];
        if (box) {
            box.innerHTML = `<b>瘦身完成</b><br>${lines.map(escapeHtml).join('<br>')}`;
        }
        toast('一键瘦身完成');
        loadUploadRecords();
        loadStockFilters();
        loadStockList();
        loadInvDashboard();
    }

    // ===== Edit Inventory =====
    function openEditInv(id, bom, qty, inbound, outbound, instruction, comment) { document.getElementById('invEditId').value = id; document.getElementById('invEditBom').value = bom; document.getElementById('invEditQty').value = qty || 0; document.getElementById('invEditInbound').value = inbound || ''; document.getElementById('invEditOutbound').value = outbound || ''; document.getElementById('invEditInstruction').value = instruction || ''; document.getElementById('invEditComment').value = comment || ''; openModal('invEditModal'); }
    async function saveInvEdit() { const id = document.getElementById('invEditId').value; const d = await apiPut('/api/inventory/' + id, { inventory: parseInt(document.getElementById('invEditQty').value) || 0, last_inbound_date: document.getElementById('invEditInbound').value, last_outbound_date: document.getElementById('invEditOutbound').value, instruction: document.getElementById('invEditInstruction').value, comment: document.getElementById('invEditComment').value }); if (d.success) { toast('库存已更新'); closeModal('invEditModal'); loadStockList(); } else toast(d.error || '操作失败', 'error'); }

    // ===== Orders =====
    let orderPage = 1;
    function filterOrders(el, status) { document.querySelectorAll('#orderTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active'); currentOrderStatus = status; orderPage = 1; loadOrders(); }

    async function loadOrders() {
        const d = await apiGet(`/api/orders?status=${encodeURIComponent(currentOrderStatus)}&page=${orderPage}`);
        const sb = { pending: 'badge-pending', confirmed: 'badge-confirmed', shipped: 'badge-shipped', delivered: 'badge-delivered' };
        const sl = { pending: '待确认', confirmed: '已确认', shipped: '已发货', delivered: '已签收' };
        document.getElementById('orderTableBody').innerHTML = d.data.map(r => `<tr><td style="font-weight:500">${escapeHtml(r.order_number)}</td><td>${escapeHtml(r.warehouse)}</td><td>${escapeHtml(r.destination_country || '')}</td><td style="text-align:center">${r.item_count || 0}</td><td style="text-align:right">${r.total_requested || 0}</td><td style="text-align:right">${r.total_actual || '-'}</td><td><span class="badge ${sb[r.status] || ''}">${escapeHtml(sl[r.status] || r.status)}</span></td><td>${r.stt_number ? escapeHtml(r.stt_number) : '<span style="color:var(--text-muted)">-</span>'}</td><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td><button class="btn btn-ghost btn-sm" onclick="viewOrder(${r.id})">详情</button></td></tr>`).join('');
        const total = d.total, perPage = d.per_page, pages = Math.ceil(total / perPage);
        document.getElementById('orderPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">共 ${total} 条，第 ${d.page}/${pages} 页</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="orderPage=Math.max(1,${d.page}-1);loadOrders()" ${d.page <= 1 ? 'disabled' : ''}>上一页</button><button class="page-btn" onclick="orderPage=Math.min(${pages},${d.page}+1);loadOrders()" ${d.page >= pages ? 'disabled' : ''}>下一页</button></div>`;
    }

    function openCreateOrder() { document.getElementById('orderItemsList').innerHTML = ''; addOrderItemRow(); openModal('createOrderModal'); }
    function addOrderItemRow() { const div = document.getElementById('orderItemsList'), row = document.createElement('div'); row.style.cssText = 'display:grid;grid-template-columns:1fr 120px 40px;gap:8px;margin-bottom:8px;align-items:center'; row.innerHTML = `<input class="wms-input order-item-product" placeholder="搜索 Product Number..." autocomplete="off"><input class="wms-input order-item-qty" type="number" min="1" placeholder="数量" value="1"><button class="btn btn-ghost btn-sm" onclick="this.parentElement.remove()" style="color:var(--danger)">X</button>`; div.appendChild(row); }
    async function submitCreateOrder() { const items = []; document.querySelectorAll('#orderItemsList > div').forEach(row => { const product = row.querySelector('.order-item-product').value.trim(), qty = parseInt(row.querySelector('.order-item-qty').value) || 0; if (product && qty > 0) items.push({ product_number: product, requested_qty: qty }); }); if (!items.length) return toast('请至少添加一条物料', 'error'); const d = await apiPost('/api/orders', { warehouse: document.getElementById('orderWarehouse').value, destination_country: document.getElementById('orderCountry').value, items }); if (d.success) { toast(`指令已创建：${d.order_number}`); closeModal('createOrderModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }

    async function viewOrder(id) {
        const d = await apiGet('/api/orders/' + id); const o = d.order, items = d.items;
        const sb = { pending: 'badge-pending', confirmed: 'badge-confirmed', shipped: 'badge-shipped', delivered: 'badge-delivered' };
        const sl = { pending: '待确认', confirmed: '已确认', shipped: '已发货', delivered: '已签收' };
        let actionsHtml = '';
        if (o.status === 'pending') actionsHtml = `<button class="btn btn-primary btn-sm" onclick="closeModal('orderDetailModal');openConfirmOrder(${id})">确认指令</button>`;
        if (o.status === 'confirmed') actionsHtml = `<button class="btn btn-primary btn-sm" onclick="closeModal('orderDetailModal');openShipOrder(${id})">确认发货</button>`;
        if (o.status === 'shipped') actionsHtml = `<button class="btn btn-success btn-sm" onclick="deliverOrder(${id})">标记签收</button>`;
        document.getElementById('orderDetailBody').innerHTML = `<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:20px"><div><div style="font-size:11px;color:var(--text-muted)">指令单号</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.order_number)}</div></div><div><div style="font-size:11px;color:var(--text-muted)">状态</div><div><span class="badge ${sb[o.status]}">${escapeHtml(sl[o.status])}</span></div></div><div><div style="font-size:11px;color:var(--text-muted)">仓库</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.warehouse)}</div></div><div><div style="font-size:11px;color:var(--text-muted)">目的国家</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.destination_country || 'N/A')}</div></div><div><div style="font-size:11px;color:var(--text-muted)">STT 运单号</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.stt_number || '-')}</div></div><div><div style="font-size:11px;color:var(--text-muted)">创建时间</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.created_at || '')}</div></div></div><div style="margin-bottom:12px">${actionsHtml}</div><table style="width:100%"><thead><tr><th>Product Number</th><th>BOM 编号</th><th>描述</th><th style="text-align:right">请求数量</th><th style="text-align:right">实际数量</th></tr></thead><tbody>${items.map(i => `<tr><td style="font-weight:500">${escapeHtml(i.product_number || '')}</td><td>${escapeHtml(i.bom_code || '')}</td><td>${escapeHtml(i.product_description || '')}</td><td style="text-align:right">${i.requested_qty}</td><td style="text-align:right">${i.actual_qty != null ? i.actual_qty : '-'}</td></tr>`).join('')}</tbody></table>`;
        document.getElementById('orderDetailTitle').textContent = '指令 ' + o.order_number; openModal('orderDetailModal');
    }

    async function openConfirmOrder(id) { currentOrderConfirmId = id; const d = await apiGet('/api/orders/' + id); document.getElementById('confirmOrderBody').innerHTML = `<input type="hidden" id="confirmOrderId" value="${id}"><table style="width:100%"><thead><tr><th>Product Number</th><th>BOM 编号</th><th>描述</th><th style="text-align:right">请求数量</th><th style="text-align:right">实际数量 *</th></tr></thead><tbody>${d.items.map(i => `<tr><td style="font-weight:500">${escapeHtml(i.product_number || '')}</td><td>${escapeHtml(i.bom_code || '')}</td><td>${escapeHtml(i.product_description || '')}</td><td style="text-align:right">${i.requested_qty}</td><td><input class="wms-input confirm-actual-qty" type="number" min="0" data-product="${escapeHtml(i.product_number || '')}" value="${i.requested_qty}" style="width:80px;text-align:right"></td></tr>`).join('')}</tbody></table>`; openModal('confirmOrderModal'); }
    async function submitConfirmOrder() { const id = document.getElementById('confirmOrderId').value, items = []; document.querySelectorAll('.confirm-actual-qty').forEach(inp => items.push({ product_number: inp.dataset.product, actual_qty: parseInt(inp.value) || 0 })); const d = await apiPut('/api/orders/' + id + '/confirm', { items }); if (d.success) { toast('指令已确认，库存已扣减'); closeModal('confirmOrderModal'); loadOrders(); loadStockList(); } else toast(d.error || '操作失败', 'error'); }
    function openShipOrder(id) { document.getElementById('shipSttNumber').value = ''; document.getElementById('shipSubmitBtn').dataset.orderId = id; openModal('shipOrderModal'); }
    async function submitShipOrder() { const id = document.getElementById('shipSubmitBtn').dataset.orderId, stt = document.getElementById('shipSttNumber').value.trim(); if (!stt) return toast('请输入 STT 运单号', 'error'); const d = await apiPut('/api/orders/' + id + '/ship', { stt_number: stt }); if (d.success) { toast('已发货，STT: ' + stt); closeModal('shipOrderModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }
    async function deliverOrder(id) { if (!confirm('确认标记为已签收？')) return; const d = await apiPut('/api/orders/' + id + '/deliver', {}); if (d.success) { toast('已标记签收'); closeModal('orderDetailModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }

    // ===== Init Shipment Header Filters =====
    const SHIPMENT_TYPE_LABELS = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    };
    const SHIPMENT_STATUS_ORDER = ['已交付', '运输中', '待核实', '异常单'];
    async function initShipmentHeaderFilters() {
        try {
            const data = await apiFetch(API + '/api/shipments?per_page=999');
            const statuses = [...new Set(data.shipments.map(s => s.display_status).filter(Boolean))];
            statuses.sort((a, b) => {
                const ai = SHIPMENT_STATUS_ORDER.indexOf(a), bi = SHIPMENT_STATUS_ORDER.indexOf(b);
                return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
            });
            document.getElementById('th-filter-ds').innerHTML = '<option value="">全部</option>' + statuses.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');

            const types = [...new Set(data.shipments.map(s => s.shipment_type).filter(Boolean))];
            document.getElementById('th-filter-type').innerHTML = '<option value="">全部</option>' + types.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(SHIPMENT_TYPE_LABELS[t] || t)}</option>`).join('');

            const countries = [...new Set(data.shipments.map(s => demandCountryOfShipment(s)).filter(Boolean))].sort();
            document.getElementById('th-filter-country').innerHTML = '<option value="">全部</option>' + countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');

            const pickupMonths = [...new Set(data.shipments.map(s => (s.pickup_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
            document.getElementById('th-filter-pickup-month').innerHTML = '<option value="">全部</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            const actualMonths = [...new Set(data.shipments.map(s => (s.actual_delivery_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
            document.getElementById('th-filter-actual-month').innerHTML = '<option value="">全部</option>' + actualMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');

            // 验收状态筛选
            const verifyStatuses = ['已验收', '待验收', '未关联'];
            document.getElementById('th-filter-verify').innerHTML = '<option value="">全部</option>' + verifyStatuses.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
            updateShipmentFiltersUI();
        } catch(e) { console.error('Failed to init shipment header filters:', e); }
    }

    // ===== Invoice Functions =====
    let invoicePlnToUsd = 0.25; // 默认汇率 4 PLN = 1 USD

    async function uploadInvoice(input, type) {
        if (!input.files.length) return;
        const file = input.files[0];
        if (!file.name.toLowerCase().endsWith('.pdf')) {
            toast('请上传 PDF 文件', 'error');
            return;
        }
        const resultEl = document.getElementById('invoice-import-result')
            || document.getElementById('legacy-logistics-invoice-result');
        if (!resultEl) return toast('发票导入结果区域未找到', 'error');
        resultEl.innerHTML = '<span style="color:var(--text-muted)">正在解析...</span>';

        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        try {
            const data = await apiFetch(API + '/api/invoices/upload', { method: 'POST', body: formData });
            if (data.error) {
                resultEl.innerHTML = `<span style="color:var(--danger)">❌ ${escapeHtml(data.error)}</span>`;
                return;
            }
            resultEl.innerHTML = `<span style="color:var(--success)">✅ ${escapeHtml(invoiceTypeLabel(data.type || type))}已导入 ${data.total_items} 条明细，匹配 ${data.matched_items} 条</span>`;
            loadInvoicePage();
            loadBudget();
            loadUploadRecords();
            // 如果费用验收看板可见，也刷新
            if (document.getElementById('page-budget')?.classList.contains('active')) loadBudgetPage();
            input.value = '';
            const unifiedInvoiceName = document.getElementById('invoicePdfFileName');
            if (unifiedInvoiceName) unifiedInvoiceName.textContent = '发票 PDF';
            const autoHint = document.getElementById('invoiceAutoTypeHint');
            if (autoHint) autoHint.textContent = '自动识别发票类型';
            if (input.id === 'logistics-invoice-file') {
                setTimeout(() => exportInvoiceDetailExcel(), 350);
            }
        } catch(e) {
            resultEl.innerHTML = `<span style="color:var(--danger)">上传失败: ${escapeHtml(e.message)}</span>`;
        }
    }

    async function loadInvoicePage() {
        try {
            const data = await apiFetch(API + '/api/invoices');
            const tbody = document.getElementById('invoice-list-body');
            if (!data.length) {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无发票数据</td></tr>';
                return;
            }
            tbody.innerHTML = data.map(inv => `<tr>
                <td>${invoiceNumberLink(inv)}</td>
                <td>${escapeHtml(inv.invoice_date || '-')}</td>
                <td>${inv.invoice_type === 'logistics' ? '物流' : '仓储'}</td>
                <td style="text-align:right">${Number(inv.total_net).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</td>
                <td style="text-align:right">$${(Number(inv.total_net) * invoicePlnToUsd).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                <td style="text-align:center">${inv.item_count}</td>
                <td style="text-align:center">${inv.matched_count}</td>
                <td><span class="badge ${inv.status === 'verified' ? 'badge-delivered' : inv.status === 'rejected' ? 'badge-danger' : 'badge-pending'}">${inv.status === 'verified' ? '已验收' : inv.status === 'rejected' ? '已拒绝' : '待验收'}</span></td>
                <td style="white-space:nowrap">${inv.status === 'pending' ? `<button class="btn btn-primary btn-sm" onclick="verifyInvoice(${inv.id})">验收</button> <button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="rejectInvoice(${inv.id})">拒绝</button>` : '<span style="color:var(--text-muted)">-</span>'}</td>
            </tr>`).join('');

            // Update budget display
            loadBudget();
        } catch(e) {
            console.error('Failed to load invoices:', e);
        }
    }

    function invoiceNumberLink(inv) {
        if (!inv?.id) return escapeHtml(inv?.invoice_number || '-');
        return `<button type="button" class="link-btn" data-invoice-id="${Number(inv.id)}" onclick="viewInvoiceDetail(Number(this.dataset.invoiceId))" style="padding:0;font-weight:700">${escapeHtml(inv.invoice_number || '-')}</button>`;
    }

    function renderInvoiceDetailRows(items) {
        return (items || []).map(item => {
            const stt = String(item.stt_number || '').trim();
            const matched = String(item.matched_booking_id || '').trim();
            const sttCell = stt
                ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(stt)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0;font-family:monospace;font-size:12px;font-weight:700">${escapeHtml(stt)}</button>`
                : '-';
            const matchedCell = matched
                ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(matched)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0"><span class="badge badge-delivered">✓ ${escapeHtml(matched)}</span></button>`
                : '<span style="color:var(--text-muted)">未匹配</span>';
            return `<tr>
                <td>${sttCell}</td>
                <td style="text-align:right">${Number(item.net_amount).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</td>
                <td style="text-align:right">$${(Number(item.net_amount) * invoicePlnToUsd).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(item.ref_date || '-')}</td>
                <td>${matchedCell}</td>
            </tr>`;
        }).join('');
    }

    async function viewInvoiceDetail(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id);
            const title = document.getElementById('invoice-detail-title');
            const body = document.getElementById('invoice-detail-body');
            const modal = document.getElementById('invoice-detail-modal');
            if (modal && modal.parentElement !== document.body) document.body.appendChild(modal);

            title.textContent = `发票 ${data.invoice_number} 明细`;
            body.innerHTML = `
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
                    <div><div style="font-size:11px;color:var(--text-muted)">发票日期</div><div style="font-size:14px;font-weight:500">${escapeHtml(data.invoice_date || '-')}</div></div>
                    <div><div style="font-size:11px;color:var(--text-muted)">总净额 (PLN)</div><div style="font-size:14px;font-weight:500">${Number(data.total_net).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</div></div>
                    <div><div style="font-size:11px;color:var(--text-muted)">总净额 (USD)</div><div style="font-size:14px;font-weight:500">$${(Number(data.total_net) * invoicePlnToUsd).toLocaleString('en-US', {minimumFractionDigits: 2})}</div></div>
                </div>
                <table style="width:100%">
                    <thead><tr><th>STT Number</th><th>净额 (PLN)</th><th>净额 (USD)</th><th>Ref 日期</th><th>匹配运单</th></tr></thead>
                    <tbody>${renderInvoiceDetailRows(data.items)}</tbody>
                </table>`;
            if (modal) modal.style.display = 'flex';
        } catch(e) {
            toast('加载明细失败: ' + e.message, 'error');
        }
    }

    function closeInvoiceDetail() {
        document.getElementById('invoice-detail-modal').style.display = 'none';
    }

    async function verifyInvoice(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'verified' }) });
            if (data.success) { toast('发票已验收'); loadInvoicePage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    async function rejectInvoice(id) {
        if (!confirm('确认拒绝此发票？')) return;
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'rejected' }) });
            if (data.success) { toast('发票已拒绝'); loadInvoicePage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    // ===== 费用验收看板 =====
    async function loadBudgetPage() {
        try {
            const data = await apiFetch(API + '/api/invoices/budget');
            const plnToUsd = data.pln_to_usd || 0.25;
            // 更新页面元素
            const totalEl = document.getElementById('budget-total');
            if (totalEl) totalEl.textContent = '$' + Number(data.budget_usd).toLocaleString('en-US');
            
            const spentEl = document.getElementById('budget-logistics-spent');
            const plnEl = document.getElementById('budget-logistics-pln');
            if (spentEl) spentEl.textContent = '$' + Number(data.logistics_usd).toLocaleString('en-US', {minimumFractionDigits: 2});
            if (plnEl) plnEl.textContent = Number(data.logistics_pln).toLocaleString('pl-PL', {minimumFractionDigits: 2});
            const pendingSpentEl = document.getElementById('budget-pending-spent');
            const pendingPlnEl = document.getElementById('budget-pending-pln');
            const matchRateEl = document.getElementById('budget-match-rate');
            if (pendingSpentEl) pendingSpentEl.textContent = '$' + Number(data.pending_logistics_usd || 0).toLocaleString('en-US', {minimumFractionDigits: 2});
            if (pendingPlnEl) pendingPlnEl.textContent = Number(data.pending_logistics_pln || 0).toLocaleString('pl-PL', {minimumFractionDigits: 2});
            if (matchRateEl) matchRateEl.textContent = Number(data.invoice_match_rate || 0).toFixed(1) + '%';

            const remainValEl = document.getElementById('budget-remaining-val');
            const remainPctEl = document.getElementById('budget-remaining-pct');
            const remainCard = document.getElementById('budget-remaining-card');
            if (remainValEl) remainValEl.textContent = '$' + Number(data.remaining_usd).toLocaleString('en-US', {minimumFractionDigits: 2});
            const pct = data.budget_usd > 0 ? ((data.total_spent_usd / data.budget_usd) * 100) : 0;
            if (remainPctEl) remainPctEl.textContent = (100 - pct).toFixed(1) + '% 可用';

            // 进度条
            const bar = document.getElementById('budget-progress-bar');
            const label = document.getElementById('budget-progress-label');
            const progressText = document.getElementById('budget-progress-text');
            if (bar) {
                bar.style.width = Math.min(pct, 100) + '%';
                if (pct > 80) bar.style.background = 'linear-gradient(90deg,#f59e0b,#ef4444)';
                else if (pct > 50) bar.style.background = 'linear-gradient(90deg,#22c55e,#f59e0b)';
                else bar.style.background = 'linear-gradient(90deg,#22c55e,#16a34a)';
            }
            if (label) label.textContent = pct.toFixed(1) + '%';
            if (progressText) progressText.textContent = '$' + Number(data.total_spent_usd).toLocaleString('en-US', {minimumFractionDigits: 2}) + ' / $' + Number(data.budget_usd).toLocaleString('en-US');

            // 颜色
            if (remainCard && remainValEl) {
                if (data.remaining_usd <= 0) { remainValEl.className = 'value danger'; remainCard.style.borderColor = 'rgba(239,68,68,0.3)'; }
                else if (data.remaining_usd < 50000) { remainValEl.className = 'value warning'; remainCard.style.borderColor = 'rgba(245,158,11,0.3)'; }
                else { remainValEl.className = 'value success'; remainCard.style.borderColor = 'rgba(34,197,94,0.3)'; }
            }

            // 发票列表
            const tbody = document.getElementById('budget-invoice-list');
            if (data.invoices && data.invoices.length) {
                tbody.innerHTML = data.invoices.map(inv => `<tr>
                    <td>${invoiceNumberLink(inv)}</td>
                    <td>${escapeHtml(inv.invoice_date || '-')}</td>
                    <td>${inv.invoice_type === 'logistics' ? '物流' : '仓储'}</td>
                    <td style="text-align:right">${Number(inv.total_net).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</td>
                    <td style="text-align:right">$${(Number(inv.total_net) * plnToUsd).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                    <td style="text-align:center">${inv.item_count}</td>
                    <td style="text-align:center">${inv.matched_count}</td>
                    <td><span class="badge ${inv.status === 'verified' ? 'badge-delivered' : inv.status === 'rejected' ? 'badge-danger' : 'badge-pending'}">${inv.status === 'verified' ? '已验收' : inv.status === 'rejected' ? '已拒绝' : '待验收'}</span></td>
                    <td style="white-space:nowrap">
                        ${inv.status === 'pending' ? `<button class="btn btn-primary btn-sm" onclick="verifyBudgetInvoice(${inv.id})">验收</button> <button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="rejectBudgetInvoice(${inv.id})">拒绝</button>` : '<span style="color:var(--text-muted)">-</span>'}
                    </td>
                </tr>`).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无发票数据，请上传物流费用发票</td></tr>';
            }
            await loadAcceptanceUsageAnalysis(plnToUsd);
        } catch(e) {
            console.error('Failed to load budget page:', e);
        }
    }

    function invoiceItemAmount(item) {
        const accepted = item?.accepted_amount;
        return Number(accepted === null || accepted === undefined || accepted === '' ? item?.net_amount || 0 : accepted || 0);
    }

    function chartThemeColor(token, fallback) {
        return getComputedStyle(document.documentElement).getPropertyValue(token).trim() || fallback;
    }

    function getChartTextColor() {
        return chartThemeColor('--text-secondary', '#64748b');
    }

    function getChartGridColor() {
        return chartThemeColor('--border', '#d9e2ef');
    }

    function renderAcceptanceChart(key, canvasId, labels, datasets, stacked = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: { labels, datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { position: 'bottom', labels: { color: getChartTextColor(), boxWidth: 10 } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${Number(ctx.parsed.y || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })} PLN` } }
                },
                scales: {
                    x: { stacked, grid: { display: false }, ticks: { color: getChartTextColor() } },
                    y: { stacked, beginAtZero: true, grid: { color: getChartGridColor() }, ticks: { color: getChartTextColor(), callback: v => Number(v).toLocaleString('pl-PL') } }
                }
            }
        });
    }

    async function loadAcceptanceUsageAnalysis(plnToUsd = 0.25) {
        const body = document.getElementById('acceptanceCountryUsageBody');
        try {
            const data = await apiFetch(API + '/api/invoices/items?type=logistics');
            const items = data.items || [];
            const byMonth = {};
            const byOffice = {};
            const byCountry = {};
            items.forEach(item => {
                const amount = invoiceItemAmount(item);
                const status = item.invoice_status || item.acceptance_status || 'pending';
                const bucket = status === 'verified' ? 'verified' : 'pending';
                const month = String(item.invoice_date || item.ref_date || '').slice(0, 7) || '未归档';
                const country = String(item.consignee_country_code || '未匹配').toUpperCase();
                const office = countryOfficeOf(country);
                const officeLabel = country === '未匹配' ? '未匹配' : (office?.label || '其他代表处');
                byMonth[month] ||= { verified: 0, pending: 0 };
                byMonth[month][bucket] += amount;
                byOffice[officeLabel] ||= { verified: 0, pending: 0, total: 0 };
                byOffice[officeLabel][bucket] += amount;
                byOffice[officeLabel].total += amount;
                byCountry[country] ||= { country, office: officeLabel, verified: 0, pending: 0, total: 0, count: 0 };
                byCountry[country][bucket] += amount;
                byCountry[country].total += amount;
                byCountry[country].count += 1;
            });

            const months = Object.keys(byMonth).sort();
            renderAcceptanceChart('acceptanceMonthly', 'chart-acceptance-monthly', months, [
                { label: '已验收', data: months.map(m => byMonth[m].verified), backgroundColor: 'rgba(22,163,74,0.72)' },
                { label: '待验收', data: months.map(m => byMonth[m].pending), backgroundColor: 'rgba(217,119,6,0.72)' },
            ], true);

            const offices = Object.entries(byOffice).sort((a, b) => b[1].total - a[1].total).map(([label]) => label);
            renderAcceptanceChart('acceptanceOffice', 'chart-acceptance-office', offices, [
                { label: '费用合计', data: offices.map(o => byOffice[o].total), backgroundColor: 'rgba(37,99,235,0.72)' },
            ]);

            const countryRows = Object.values(byCountry).sort((a, b) => b.total - a.total);
            if (body) {
                body.innerHTML = countryRows.length ? countryRows.map(r => `<tr>
                    <td>${escapeHtml(r.country)}</td>
                    <td>${escapeHtml(r.office)}</td>
                    <td style="text-align:right">${Number(r.count || 0).toLocaleString()}</td>
                    <td style="text-align:right">${Number(r.verified || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })}</td>
                    <td style="text-align:right">${Number(r.pending || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })}</td>
                    <td style="text-align:right;font-weight:700">${Number(r.total || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })}</td>
                    <td style="text-align:right">$${Number((r.total || 0) * plnToUsd).toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                </tr>`).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">暂无费用明细</td></tr>';
            }
        } catch(e) {
            if (body) body.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--danger);padding:24px">费用分析加载失败：${escapeHtml(e.message)}</td></tr>`;
        }
    }

    async function viewBudgetInvoiceDetail(id) {
        return viewInvoiceDetail(id);
    }

    function closeBudgetInvoiceDetail() {
        document.getElementById('budget-invoice-detail-modal').style.display = 'none';
    }

    async function verifyBudgetInvoice(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'verified' }) });
            if (data.success) { toast('发票已验收'); loadBudgetPage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    async function rejectBudgetInvoice(id) {
        if (!confirm('确认拒绝此发票？')) return;
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'rejected' }) });
            if (data.success) { toast('发票已拒绝'); loadBudgetPage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    let movementPage = 1;
    let movementSearchTimer = null;
    let movementSortBy = 'movement_date';
    let movementSortDir = 'desc';
    let movementHeaderFilters = { category: '', category2: '', instruction: '' };
    function debouncedLoadMovements() {
        clearTimeout(movementSearchTimer);
        movementSearchTimer = setTimeout(loadMovementList, 250);
    }
    function setSelectOptionsKeepValue(selectId, values, placeholder = '全部') {
        const select = document.getElementById(selectId);
        if (!select) return;
        const current = select.value || '';
        const cleanValues = [...new Set((values || []).map(v => String(v || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'en'));
        if (current && !cleanValues.includes(current)) cleanValues.unshift(current);
        select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>` + cleanValues.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
        select.value = cleanValues.includes(current) ? current : '';
        select.classList.toggle('has-value', !!select.value);
    }
    function updateMovementHeaderOptions(rows) {
        setSelectOptionsKeepValue('movementHeaderCategoryFilter', (rows || []).map(r => r.category), '全部');
        setSelectOptionsKeepValue('movementHeaderCat2Filter', (rows || []).map(r => r.category_2), '全部');
        const instructions = [];
        (rows || []).forEach(r => String(r.instructions || '').split(',').forEach(v => instructions.push(v.trim())));
        setSelectOptionsKeepValue('movementHeaderInstructionFilter', instructions, '全部');
    }
    function syncMovementHeaderControls() {
        const typeHeader = document.getElementById('movementHeaderTypeFilter');
        const warehouseHeader = document.getElementById('movementHeaderWarehouseFilter');
        const categoryHeader = document.getElementById('movementHeaderCategoryFilter');
        const cat2Header = document.getElementById('movementHeaderCat2Filter');
        const instructionHeader = document.getElementById('movementHeaderInstructionFilter');
        if (typeHeader) typeHeader.value = document.getElementById('movementTypeFilter')?.value || '';
        if (warehouseHeader) warehouseHeader.value = document.getElementById('movementWarehouse')?.value || '';
        if (categoryHeader) categoryHeader.value = movementHeaderFilters.category || '';
        if (cat2Header) cat2Header.value = movementHeaderFilters.category2 || '';
        if (instructionHeader) instructionHeader.value = movementHeaderFilters.instruction || '';
        [typeHeader, warehouseHeader, categoryHeader, cat2Header, instructionHeader].forEach(el => el?.classList.toggle('has-value', !!el.value));
    }
    function updateMovementHeaderFilter(field, value) {
        if (field === 'type') {
            const control = document.getElementById('movementTypeFilter');
            if (control) control.value = value || '';
        } else if (field === 'warehouse') {
            const control = document.getElementById('movementWarehouse');
            if (control) control.value = value || '';
        } else {
            movementHeaderFilters[field] = value || '';
        }
        movementPage = 1;
        loadMovementList();
    }
    function clearMovementFilters() {
        document.getElementById('movementSearch').value = '';
        document.getElementById('movementWarehouse').value = '';
        document.getElementById('movementTypeFilter').value = '';
        movementHeaderFilters = { category: '', category2: '', instruction: '' };
        const startInput = document.getElementById('movementStartDate');
        const endInput = document.getElementById('movementEndDate');
        if (startInput) startInput.value = '';
        if (endInput) endInput.value = '';
        movementSortBy = 'movement_date';
        movementSortDir = 'desc';
        movementPage = 1;
        loadMovementList();
    }
    function setMovementSort(key) {
        if (movementSortBy === key) movementSortDir = movementSortDir === 'asc' ? 'desc' : 'asc';
        else {
            movementSortBy = key;
            movementSortDir = 'asc';
        }
        movementPage = 1;
        loadMovementList();
    }
    function updateMovementSortIndicators() {
        document.querySelectorAll('#movementTable th.sortable').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.sort === movementSortBy && movementSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.sort === movementSortBy && movementSortDir === 'desc');
        });
    }
    function toggleMovementDetailCols() { document.getElementById('movementTable')?.classList.toggle('compact'); }
    async function loadMovementList() {
        const tbody = document.getElementById('movementListBody');
        if (!tbody) return;
        const params = new URLSearchParams({
            page: movementPage,
            per_page: document.getElementById('movementPerPage')?.value || '20',
            q: document.getElementById('movementSearch')?.value || '',
            warehouse: document.getElementById('movementWarehouse')?.value || '',
            movement_type: document.getElementById('movementTypeFilter')?.value || '',
            start_date: document.getElementById('movementStartDate')?.value || '',
            end_date: document.getElementById('movementEndDate')?.value || '',
            category: movementHeaderFilters.category || '',
            category2: movementHeaderFilters.category2 || '',
            instruction: movementHeaderFilters.instruction || '',
            sort_by: movementSortBy,
            sort_dir: movementSortDir
        });
        updateMovementSortIndicators();
        syncMovementHeaderControls();
        tbody.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        try {
            const data = await apiFetch(API + '/api/inventory/movements?' + params.toString());
            const rows = data.items || [];
            updateMovementHeaderOptions(rows);
            syncMovementHeaderControls();
            if (!rows.length) {
                tbody.innerHTML = '<tr><td colspan="13" style="text-align:center;color:var(--text-muted);padding:24px">暂无出入库流水</td></tr>';
            } else {
                tbody.innerHTML = rows.map(r => {
                    const badge = String(r.movement_type || '').toLowerCase() === 'inbound' ? 'badge-delivered' : String(r.movement_type || '').toLowerCase() === 'outbound' ? 'badge-danger' : 'badge-pending';
                    return `<tr>
                        <td>${escapeHtml(r.movement_date || '-')}</td>
                        <td><span class="badge ${badge}">${escapeHtml(r.movement_label || r.movement_type || '-')}</span></td>
                        <td><button type="button" class="link-btn" data-product-detail="${escapeHtml(r.product_number || '')}" onclick="openProductDetail(this.dataset.productDetail)" style="padding:0;font-weight:700">${escapeHtml(r.product_number || '-')}</button></td>
                        <td>${escapeHtml(r.product_description || '-')}</td>
                        <td class="col-detail"><span class="badge badge-confirmed">${escapeHtml(r.category || '-')}</span></td>
                        <td class="col-detail">${escapeHtml(r.category_2 || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.instructions || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.warehouses || '-')}</td>
                        <td>${escapeHtml(r.operation_id || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.operation_target || '-')}</td>
                        <td style="text-align:right;font-weight:700">${Number(r.quantity || 0).toLocaleString()}</td>
                        <td class="col-detail" style="text-align:right">${Number(r.current_inventory || 0).toLocaleString()}</td>
                        <td class="col-detail" style="text-align:right">$${Number(r.value_usd || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                    </tr>`;
                }).join('');
            }
            const pages = Math.max(1, data.pages || 1);
            document.getElementById('movementPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">共 ${data.total || 0} 条，第 ${data.page || movementPage}/${pages} 页</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="movementPage=Math.max(1,${data.page || movementPage}-1);loadMovementList()" ${(data.page || movementPage) <= 1 ? 'disabled' : ''}>上一页</button><button class="page-btn" onclick="movementPage=Math.min(${pages},${data.page || movementPage}+1);loadMovementList()" ${(data.page || movementPage) >= pages ? 'disabled' : ''}>下一页</button></div>`;
        } catch(e) {
            tbody.innerHTML = `<tr><td colspan="13" style="text-align:center;color:var(--danger);padding:24px">加载失败：${escapeHtml(e.message)}</td></tr>`;
        }
    }

    let acceptancePage = 1;
    let acceptanceSearchTimer = null;
    let acceptanceSortBy = 'invoice_date';
    let acceptanceSortDir = 'desc';
    let acceptanceHeaderCountryFilter = '';
    function debouncedLoadAcceptanceList() {
        clearTimeout(acceptanceSearchTimer);
        acceptanceSearchTimer = setTimeout(loadAcceptanceList, 250);
    }
    function syncAcceptanceHeaderControls() {
        const invoiceMonthHeader = document.getElementById('acceptanceHeaderInvoiceMonthFilter');
        const pickupMonthHeader = document.getElementById('acceptanceHeaderPickupMonthFilter');
        const typeHeader = document.getElementById('acceptanceHeaderTypeFilter');
        const statusHeader = document.getElementById('acceptanceHeaderStatusFilter');
        const countryHeader = document.getElementById('acceptanceHeaderCountryFilter');
        if (invoiceMonthHeader) invoiceMonthHeader.value = document.getElementById('acceptanceMonthFilter')?.value || '';
        if (pickupMonthHeader) pickupMonthHeader.value = document.getElementById('acceptancePickupMonthFilter')?.value || '';
        if (typeHeader) typeHeader.value = document.getElementById('acceptanceTypeFilter')?.value || '';
        if (statusHeader) statusHeader.value = document.getElementById('acceptanceStatusFilter')?.value || '';
        if (countryHeader) countryHeader.value = acceptanceHeaderCountryFilter || '';
        [invoiceMonthHeader, pickupMonthHeader, typeHeader, statusHeader, countryHeader].forEach(el => el?.classList.toggle('has-value', !!el.value));
    }
    function updateAcceptanceHeaderFilter(field, value) {
        const map = {
            invoiceMonth: 'acceptanceMonthFilter',
            pickupMonth: 'acceptancePickupMonthFilter',
            type: 'acceptanceTypeFilter',
            status: 'acceptanceStatusFilter'
        };
        if (field === 'country') {
            acceptanceHeaderCountryFilter = value || '';
        } else if (map[field]) {
            const control = document.getElementById(map[field]);
            if (control) control.value = value || '';
        }
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function clearAcceptanceFilters() {
        document.getElementById('acceptanceSearch').value = '';
        document.getElementById('acceptanceTypeFilter').value = '';
        document.getElementById('acceptanceStatusFilter').value = '';
        document.getElementById('acceptanceMonthFilter').value = '';
        acceptanceHeaderCountryFilter = '';
        const pickupMonthFilter = document.getElementById('acceptancePickupMonthFilter');
        if (pickupMonthFilter) pickupMonthFilter.value = '';
        acceptanceSortBy = 'invoice_date';
        acceptanceSortDir = 'desc';
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function setAcceptanceSort(key) {
        if (acceptanceSortBy === key) acceptanceSortDir = acceptanceSortDir === 'asc' ? 'desc' : 'asc';
        else {
            acceptanceSortBy = key;
            acceptanceSortDir = 'asc';
        }
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function updateAcceptanceSortIndicators() {
        document.querySelectorAll('#acceptanceTable th.sortable').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.sort === acceptanceSortBy && acceptanceSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.sort === acceptanceSortBy && acceptanceSortDir === 'desc');
        });
    }
    function toggleAcceptanceDetailCols() { document.getElementById('acceptanceTable')?.classList.toggle('compact'); }
    function acceptanceSortValue(row, key) {
        if (key === 'country') return String(row.consignee_country_code || '').toUpperCase();
        if (key === 'invoice_status') return String(row.invoice_status || row.acceptance_status || '').toUpperCase();
        if (key === 'net_amount') return Number(row.net_amount || 0);
        if (key === 'accepted_amount') return row.accepted_amount == null ? -Infinity : Number(row.accepted_amount || 0);
        return String(row[key] ?? '').toUpperCase();
    }
    function updateAcceptanceMonthOptions(rows) {
        const select = document.getElementById('acceptanceMonthFilter');
        const pickupSelect = document.getElementById('acceptancePickupMonthFilter');
        const invoiceHeader = document.getElementById('acceptanceHeaderInvoiceMonthFilter');
        const pickupHeader = document.getElementById('acceptanceHeaderPickupMonthFilter');
        const countryHeader = document.getElementById('acceptanceHeaderCountryFilter');
        const months = [...new Set((rows || []).map(r => String(r.invoice_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
        const pickupMonths = [...new Set((rows || []).map(r => String(r.pickup_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
        const countries = [...new Set((rows || []).map(r => String(r.consignee_country_code || '').trim().toUpperCase()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'en'));
        if (select) {
            const current = select.value || '';
            select.innerHTML = '<option value="">全部发票月份</option>' + months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            select.value = months.includes(current) ? current : '';
            select.classList.toggle('has-value', !!select.value);
        }
        if (pickupSelect) {
            const currentPickup = pickupSelect.value || '';
            pickupSelect.innerHTML = '<option value="">全部发货月份</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            pickupSelect.value = pickupMonths.includes(currentPickup) ? currentPickup : '';
            pickupSelect.classList.toggle('has-value', !!pickupSelect.value);
        }
        if (invoiceHeader) {
            const current = document.getElementById('acceptanceMonthFilter')?.value || '';
            invoiceHeader.innerHTML = '<option value="">全部</option>' + months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            invoiceHeader.value = months.includes(current) ? current : '';
        }
        if (pickupHeader) {
            const current = document.getElementById('acceptancePickupMonthFilter')?.value || '';
            pickupHeader.innerHTML = '<option value="">全部</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            pickupHeader.value = pickupMonths.includes(current) ? current : '';
        }
        if (countryHeader) {
            countryHeader.innerHTML = '<option value="">全部</option>' + countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
            countryHeader.value = countries.includes(acceptanceHeaderCountryFilter) ? acceptanceHeaderCountryFilter : '';
            if (acceptanceHeaderCountryFilter && !countryHeader.value) acceptanceHeaderCountryFilter = '';
        }
        syncAcceptanceHeaderControls();
    }
    async function loadAcceptanceList() {
        const tbody = document.getElementById('acceptanceListBody');
        if (!tbody) return;
        const type = document.getElementById('acceptanceTypeFilter')?.value || '';
        const status = document.getElementById('acceptanceStatusFilter')?.value || '';
        const month = document.getElementById('acceptanceMonthFilter')?.value || '';
        const pickupMonth = document.getElementById('acceptancePickupMonthFilter')?.value || '';
        const search = String(document.getElementById('acceptanceSearch')?.value || '').trim().toUpperCase();
        const perPage = Number(document.getElementById('acceptancePerPage')?.value || 20);
        const params = new URLSearchParams();
        if (type) params.set('type', type);
        if (status) params.set('status', status);
        updateAcceptanceSortIndicators();
        syncAcceptanceHeaderControls();
        tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        try {
            const data = await apiFetch(API + '/api/invoices/items?' + params.toString());
            let rows = data.items || [];
            updateAcceptanceMonthOptions(rows);
            const activeMonth = document.getElementById('acceptanceMonthFilter')?.value || month;
            if (activeMonth) {
                rows = rows.filter(r => String(r.invoice_date || '').slice(0, 7) === activeMonth);
            }
            const activePickupMonth = document.getElementById('acceptancePickupMonthFilter')?.value || pickupMonth;
            if (activePickupMonth) {
                rows = rows.filter(r => String(r.pickup_date || '').slice(0, 7) === activePickupMonth);
            }
            if (acceptanceHeaderCountryFilter) {
                rows = rows.filter(r => String(r.consignee_country_code || '').trim().toUpperCase() === acceptanceHeaderCountryFilter);
            }
            if (search) {
                rows = rows.filter(r => [r.stt_number, r.invoice_number, r.consignee_country_code, r.matched_booking_id, r.exception_reason].some(v => String(v || '').toUpperCase().includes(search)));
            }
            const dir = acceptanceSortDir === 'asc' ? 1 : -1;
            rows = rows.slice().sort((a, b) => {
                const av = acceptanceSortValue(a, acceptanceSortBy);
                const bv = acceptanceSortValue(b, acceptanceSortBy);
                if (av === bv) return 0;
                return av > bv ? dir : -dir;
            });
            const total = rows.length;
            const pages = Math.max(1, Math.ceil(total / perPage));
            acceptancePage = Math.min(Math.max(1, acceptancePage), pages);
            rows = rows.slice((acceptancePage - 1) * perPage, acceptancePage * perPage);
            if (!rows.length) {
                tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:var(--text-muted);padding:24px">暂无验收明细</td></tr>';
            } else {
                tbody.innerHTML = rows.map(item => {
                    const statusValue = item.invoice_status || item.acceptance_status || 'pending';
                    const statusBadge = statusValue === 'verified' ? 'badge-delivered' : statusValue === 'rejected' ? 'badge-danger' : 'badge-pending';
                    const statusLabel = statusValue === 'verified' ? '已验收' : statusValue === 'rejected' ? '已拒绝' : '待验收';
                    const stt = item.stt_number || '';
                    const matched = item.matched_booking_id || '';
                    const invoiceCell = item.invoice_id
                        ? `<button type="button" class="link-btn" data-invoice-id="${Number(item.invoice_id)}" onclick="viewInvoiceDetail(Number(this.dataset.invoiceId))" style="padding:0;font-weight:700">${escapeHtml(item.invoice_number || '-')}</button>`
                        : escapeHtml(item.invoice_number || '-');
                    const sttCell = stt ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(stt)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0;font-weight:700">${escapeHtml(stt)}</button>` : '-';
                    const matchedCell = matched ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(matched)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0"><span class="badge badge-delivered">${escapeHtml(matched)}</span></button>` : '<span style="color:var(--text-muted)">未匹配</span>';
                    return `<tr>
                        <td>${invoiceCell}</td>
                        <td class="col-detail">${escapeHtml(item.invoice_date || '-')}</td>
                        <td class="col-detail">${item.invoice_type === 'warehouse' ? '仓储操作费' : '物流费用'}</td>
                        <td>${sttCell}</td>
                        <td>${matchedCell}</td>
                        <td class="col-detail">${escapeHtml(item.consignee_country_code || '-')}</td>
                        <td class="col-detail">${escapeHtml(item.pickup_date || '-')}</td>
                        <td style="text-align:right">${Number(item.net_amount || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })}</td>
                        <td style="text-align:right">${item.accepted_amount == null ? '-' : Number(item.accepted_amount || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 })}</td>
                        <td><span class="badge ${statusBadge}">${statusLabel}</span></td>
                        <td class="col-detail">${escapeHtml(item.exception_reason || item.acceptance_remark || '-')}</td>
                    </tr>`;
                }).join('');
            }
            document.getElementById('acceptancePagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">共 ${total} 条，第 ${acceptancePage}/${pages} 页</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="acceptancePage=Math.max(1,acceptancePage-1);loadAcceptanceList()" ${acceptancePage <= 1 ? 'disabled' : ''}>上一页</button><button class="page-btn" onclick="acceptancePage=Math.min(${pages},acceptancePage+1);loadAcceptanceList()" ${acceptancePage >= pages ? 'disabled' : ''}>下一页</button></div>`;
        } catch(e) {
            tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;color:var(--danger);padding:24px">加载失败：${escapeHtml(e.message)}</td></tr>`;
        }
    }

    // ===== 费用列表 =====
    function switchCostTab(el) {
        if (el.style.opacity === '0.4') return;
        document.querySelectorAll('#costTabs .tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
        const tab = el.dataset.ctab;
        document.getElementById('cost-logistics-panel').style.display = tab === 'logistics' ? 'block' : 'none';
        document.getElementById('cost-warehouse-panel').style.display = tab === 'warehouse' ? 'block' : 'none';
    }

    async function loadCostList() {
        try {
            const status = document.getElementById('costStatusFilter')?.value || '';
            const data = await apiFetch(API + '/api/invoices/items?type=logistics&status=' + encodeURIComponent(status));
            const summary = data.summary || {};
            const plnToUsd = summary.pln_to_usd || 0.25;
            const tbody = document.getElementById('cost-logistics-body');
            const summaryEl = document.getElementById('cost-logistics-summary');
            const allItems = data.items || [];

            if (!allItems.length) {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无费用数据</td></tr>';
                if (summaryEl) summaryEl.textContent = '-';
                return;
            }

            tbody.innerHTML = allItems.map(item => {
                const usd = (item.net_amount * plnToUsd).toFixed(2);
                const matchBadge = item.matched_booking_id
                    ? `<span class="badge badge-delivered">${escapeHtml(item.matched_booking_id)}</span>`
                    : '<span style="color:var(--text-muted)">未匹配</span>';
                const statusBadge = item.invoice_status === 'verified'
                    ? '<span class="badge badge-delivered">已验收</span>'
                    : item.invoice_status === 'rejected'
                        ? '<span class="badge badge-danger">已拒绝</span>'
                        : '<span class="badge badge-pending">待验收</span>';
                return `<tr>
                    <td style="font-family:monospace;font-size:12px">${escapeHtml(item.stt_number)}</td>
                    <td style="text-align:right">${Number(item.net_amount).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</td>
                    <td style="text-align:right">$${Number(usd).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                    <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(item.ref_date || '-')}</td>
                    <td>${matchBadge}</td>
                    <td>${escapeHtml(item.consignee_country_code || '-')}</td>
                    <td style="font-size:12px">${escapeHtml(item.invoice_number)}</td>
                    <td style="font-size:12px">${escapeHtml(item.invoice_date || '-')}</td>
                    <td>${statusBadge}</td>
                </tr>`;
            }).join('');

            if (summaryEl) {
                summaryEl.textContent = `共 ${summary.item_count || allItems.length} 条物流费用 · 已匹配 ${summary.matched_count || 0} 条 · 待验收 ${summary.pending_count || 0} 条 · 已验收 ${summary.verified_count || 0} 条 · 合计 ${Number(summary.total_pln || 0).toLocaleString('pl-PL', {minimumFractionDigits: 2})} PLN ≈ $${Number(summary.total_usd || 0).toLocaleString('en-US', {minimumFractionDigits: 2})} USD`;
            }
        } catch(e) {
            console.error('Failed to load cost list:', e);
            const tbody = document.getElementById('cost-logistics-body');
            if (tbody) tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--danger);padding:24px">加载失败</td></tr>';
        }
    }

    // ===== Init App =====
    function initApp() {
        // Populate shipment header filters
        applyTheme();
        expandSidebarOnEntry();
        initShipmentHeaderFilters();
        currentWarehouse = 'Lodz warehouse';
        if (document.getElementById('settingLang')) document.getElementById('settingLang').value = currentLang;
        if (document.getElementById('settingWarehouse')) document.getElementById('settingWarehouse').value = currentWarehouse;
        initSettings();
        assembleImportCenter();
        loadReportHeaderIcon();
        loadReportMonths();
        loadStockFilters();
        applyUnifiedUi();
        switchPage('logistics');
        setTimeout(() => {
            loadDashboard();
            Object.values(charts || {}).forEach(chart => chart?.resize?.());
        }, 180);
    }

    // ===== 初始加载 =====
    checkAuth().then(() => {
        if (getAuthToken()) {
            initApp();
        }
    });
    
