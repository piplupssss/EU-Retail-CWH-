@echo off
chcp 65001 >nul
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":5001" ^| findstr "LISTENING"') do taskkill /PID %%P /F
pause
