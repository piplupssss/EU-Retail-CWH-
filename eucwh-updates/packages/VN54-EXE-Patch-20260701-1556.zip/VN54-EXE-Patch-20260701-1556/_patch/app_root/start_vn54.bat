@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PORT=5001
set AUTO_OPEN_BROWSER=1
"_system\python\python.exe" "_system\run.py"
pause
