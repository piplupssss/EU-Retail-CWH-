@echo off
cd /d %~dp0\..
set AUTO_OPEN_BROWSER=1
_system\python\python.exe _system\run.py
pause
