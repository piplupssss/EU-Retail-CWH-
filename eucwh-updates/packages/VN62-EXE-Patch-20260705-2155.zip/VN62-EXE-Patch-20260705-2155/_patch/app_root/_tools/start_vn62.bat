@echo off
cd /d %~dp0\..
start "" EUCWH-VN62.exe
