#!/usr/bin/env python3
"""Assemble a GitHub-hosted update package from the clean program package.

The installed updater currently requires a ZIP with one top-level directory and
an `upgrade_to_*.exe` inside that directory. The Windows updater also expects
program files under `_patch/_system` and optional launcher files under
`_patch/app_root`, matching the legacy VN64 patch layout. This script enforces
that contract and refuses to emit `latest.json` unless a real updater EXE path
is supplied.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from build_clean_package import build_clean_package
from build_clean_package import load_release_info
from build_clean_package import safe_package_name
from validate_release_manifest import (
    MANIFEST_PATH,
    ROOT,
    first_matching_pattern,
    iter_paths,
    read_json,
    rel_posix,
)


UPDATE_ARTIFACT_ROOT = ROOT / "artifacts" / "update_packages"
DEFAULT_REPO = "piplupssss/EU-Retail-CWH-"

UPDATE_FORBIDDEN_PATTERNS = [
    ".git/",
    ".workbuddy/",
    ".pycache_check/",
    "**/__pycache__/",
    "**/*.pyc",
    "*.db",
    "*.db-shm",
    "*.db-wal",
    "app/data/uploads/",
    "app/data/backups/",
    "app/static/images/",
    "artifacts/",
    "build_spreadsheets/",
    "downloaded_update/",
    "downloaded_updates/",
    "*.zip",
    "*.vbs",
    "start*.bat",
    "launch*.bat",
    "launch*.vbs",
]


def update_dir_name(version: str) -> str:
    return safe_package_name(f"{version.upper()}-update")


def updater_name(version: str) -> str:
    return f"upgrade_to_{version.lower()}.exe"


def default_package_url(repo: str, tag: str, zip_name: str) -> str:
    repo = repo.strip().strip("/")
    tag = tag.strip() or "latest"
    return f"https://github.com/{repo}/releases/download/{tag}/{zip_name}"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_tree_contents(source: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        destination = target / item.name
        if item.is_dir():
            shutil.copytree(item, destination)
        else:
            shutil.copy2(item, destination)


def validate_updater_exe(path: Path, version: str) -> None:
    if not path.exists() or not path.is_file():
        raise RuntimeError(f"Updater EXE does not exist: {path}")
    if path.suffix.lower() != ".exe":
        raise RuntimeError("Updater path must point to a .exe file")
    if path.stat().st_size <= 0:
        raise RuntimeError("Updater EXE is empty")
    expected = updater_name(version)
    if path.name.lower() != expected.lower() and not path.name.lower().startswith("upgrade_to_"):
        raise RuntimeError(f"Updater EXE should be named {expected} or upgrade_to_*.exe")


def validate_update_stage(stage_dir: Path, version: str) -> list[dict[str, str]]:
    violations: list[dict[str, str]] = []
    expected_updater = updater_name(version).lower()
    updater_count = 0
    for item in iter_paths(stage_dir):
        rel = rel_posix(item, stage_dir)
        lower = item.name.lower()
        if item.is_file() and lower.endswith(".exe"):
            if rel.startswith("_patch/app_root/"):
                continue
            updater_count += 1
            if lower != expected_updater and not lower.startswith("upgrade_to_"):
                violations.append({"path": rel, "matched": "unexpected exe"})
            continue
        matched = first_matching_pattern(rel, UPDATE_FORBIDDEN_PATTERNS)
        if matched:
            violations.append({"path": rel, "matched": matched})
    if updater_count != 1:
        violations.append({"path": str(stage_dir), "matched": f"expected exactly one updater exe, found {updater_count}"})
    if not (stage_dir / "_patch" / "_system" / "run.py").exists():
        violations.append({"path": str(stage_dir / "_patch" / "_system"), "matched": "missing legacy _patch/_system/run.py"})
    return violations


def create_zip_from_stage(stage_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        zip_path.unlink()
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        root = stage_dir.parent
        for path in sorted(stage_dir.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(root).as_posix())


def validate_zip_contract(zip_path: Path, version: str) -> None:
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        top_dirs = {name.split("/")[0] for name in names if name and "/" in name and not name.startswith("../")}
        if len(top_dirs) != 1:
            raise RuntimeError("Update ZIP must contain exactly one top-level directory")
        top_dir = next(iter(top_dirs))
        expected = f"{top_dir}/{updater_name(version)}"
        if expected not in names and not any(name.startswith(f"{top_dir}/upgrade_to_") and name.lower().endswith(".exe") for name in names):
            raise RuntimeError("Update ZIP is missing upgrade_to_*.exe")
        with tempfile.TemporaryDirectory(prefix="eucwh_update_check_") as tmp:
            zf.extractall(tmp)
            violations = validate_update_stage(Path(tmp) / top_dir, version)
            if violations:
                sample = "; ".join(f"{row['path']} by {row['matched']}" for row in violations[:10])
                raise RuntimeError(f"Update ZIP validation failed: {sample}")


def release_notes(limit: int = 8) -> list[str]:
    path = ROOT / "app" / "static" / "version_changelog.json"
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, list) or not data:
        return []
    first = data[0]
    notes = first.get("changes") or first.get("items") or []
    return [str(note) for note in notes[:limit]]


def build_update_package(args: argparse.Namespace) -> dict[str, Any]:
    release_info = load_release_info()
    version = str(args.version or release_info.get("version") or "").upper()
    if not version:
        raise RuntimeError("Missing version")
    build_time = str(args.release_time or release_info.get("build_time") or "")
    tag = args.tag or version
    zip_name = safe_package_name(args.zip_name or f"{version}_update.zip")
    if not zip_name.lower().endswith(".zip"):
        zip_name += ".zip"
    package_url = args.package_url or default_package_url(args.github_repo, tag, zip_name)

    with tempfile.TemporaryDirectory(prefix=f"eucwh_{version.lower()}_clean_") as tmp_dir:
        clean_dir = Path(tmp_dir) / safe_package_name(f"{version}_clean_program")
        clean_result = build_clean_package(
            output_dir=clean_dir,
            clean=True,
            skip_gate=args.skip_gate,
            skip_smoke=args.skip_smoke,
            require_smoke=args.require_smoke,
        )

        result: dict[str, Any] = {
            "ok": True,
            "dry_run": bool(args.dry_run),
            "version": version,
            "release_time": build_time,
            "package_url": package_url,
            "clean_program_dir": "temporary build directory removed after validation",
            "clean_program_files": clean_result["copied_file_count"],
            "clean_program_size": clean_result["copied_size"],
        }
        if args.dry_run:
            result["message"] = "Dry run completed. Provide --updater-exe to emit update ZIP and latest.json."
            return result

        if not args.updater_exe:
            raise RuntimeError("Missing --updater-exe. A real Windows upgrade_to_*.exe is required to emit update ZIP/latest.json.")
        updater_exe = Path(args.updater_exe)
        validate_updater_exe(updater_exe, version)

        stage_parent = UPDATE_ARTIFACT_ROOT / "_staging"
        stage_dir = stage_parent / update_dir_name(version)
        if stage_dir.exists():
            shutil.rmtree(stage_dir)
        stage_dir.mkdir(parents=True, exist_ok=True)
        system_dir = stage_dir / "_patch" / "_system"
        system_dir.mkdir(parents=True, exist_ok=True)
        copy_tree_contents(clean_dir, system_dir)
        shutil.copy2(updater_exe, stage_dir / updater_name(version))

        if args.app_launcher_exe:
            launcher_exe = Path(args.app_launcher_exe)
            validate_updater_exe(launcher_exe, version) if launcher_exe.name.lower().startswith("upgrade_to_") else None
            if not launcher_exe.exists() or launcher_exe.suffix.lower() != ".exe":
                raise RuntimeError(f"Launcher EXE does not exist or is not an .exe file: {launcher_exe}")
            app_root = stage_dir / "_patch" / "app_root"
            app_root.mkdir(parents=True, exist_ok=True)
            shutil.copy2(launcher_exe, app_root / f"EUCWH-{version}.exe")

        metadata = {
            "version": version,
            "release_time": build_time,
            "package_type": "windows-update-package",
            "layout": "legacy _patch/_system compatible with installed updater",
            "business_data_included": False,
            "clean_program_source": {
                **clean_result,
                "output_dir": "temporary build directory removed after staging",
            },
            "manifest_source": str(MANIFEST_PATH.relative_to(ROOT)),
        }
        (stage_dir / "_update_package_manifest.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        violations = validate_update_stage(stage_dir, version)
        if violations:
            sample = "; ".join(f"{row['path']} by {row['matched']}" for row in violations[:10])
            raise RuntimeError(f"Update stage validation failed: {sample}")

        zip_path = UPDATE_ARTIFACT_ROOT / "packages" / zip_name
        create_zip_from_stage(stage_dir, zip_path)
        validate_zip_contract(zip_path, version)
        digest = sha256_file(zip_path)

        latest = {
            "latest_version": version,
            "release_time": build_time,
            "package_url": package_url,
            "sha256": digest,
            "notes": release_notes(),
        }
        latest_path = UPDATE_ARTIFACT_ROOT / "latest.json"
        latest_path.parent.mkdir(parents=True, exist_ok=True)
        latest_path.write_text(json.dumps(latest, ensure_ascii=False, indent=2), encoding="utf-8")

        result.update({
            "zip_path": str(zip_path),
            "zip_size": zip_path.stat().st_size,
            "sha256": digest,
            "latest_json": str(latest_path),
            "stage_dir": str(stage_dir),
        })
        return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a GitHub-compatible EU CWH update package.")
    parser.add_argument("--version", help="Version to publish, defaults to release_info.json version.")
    parser.add_argument("--release-time", help="Release time, defaults to release_info.json build_time.")
    parser.add_argument("--github-repo", default=DEFAULT_REPO, help="GitHub owner/repo used for default package_url.")
    parser.add_argument("--tag", help="GitHub release tag, defaults to version.")
    parser.add_argument("--zip-name", help="Update ZIP filename, defaults to <version>_update.zip.")
    parser.add_argument("--package-url", help="Explicit package URL to write into latest.json.")
    parser.add_argument("--updater-exe", help="Path to Windows upgrade_to_*.exe. Required unless --dry-run is used.")
    parser.add_argument("--app-launcher-exe", help="Optional generic EUCWH launcher EXE to place under _patch/app_root as EUCWH-<version>.exe.")
    parser.add_argument("--dry-run", action="store_true", help="Run gates and build clean source package, but do not emit ZIP/latest.json.")
    parser.add_argument("--skip-gate", action="store_true", help="Do not run tools/engineering_gate.py through the clean-package builder.")
    parser.add_argument("--skip-smoke", action="store_true", help="Pass --skip-smoke to the engineering gate.")
    parser.add_argument("--require-smoke", action="store_true", help="Fail if smoke credentials are missing.")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    try:
        result = build_update_package(args)
    except Exception as exc:  # noqa: BLE001
        if args.json:
            print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        else:
            print(f"FAIL {exc}")
        return 1

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS update package dry run" if result.get("dry_run") else "PASS update package built")
        for key in ("version", "release_time", "package_url", "clean_program_dir", "zip_path", "sha256", "latest_json"):
            if result.get(key):
                print(f"- {key}: {result[key]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
