#!/usr/bin/env python3
"""Generate a local engineering baseline for the VN65+ cleanup.

The script is read-only. It scans source size, code hotspots, route ownership,
and packaging hygiene so future cleanup work can be compared against the same
baseline.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = ROOT.parent

DEFAULT_EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "node_modules",
}

SOURCE_EXCLUDE_DIRS = DEFAULT_EXCLUDE_DIRS | {
    ".pycache_check",
    "artifacts",
    "build_spreadsheets",
    "downloaded_update",
    "downloaded_updates",
}

PACKAGE_RISK_SUFFIXES = {
    ".zip",
    ".exe",
    ".bat",
    ".vbs",
    ".xlsx",
    ".xls",
    ".csv",
    ".pdf",
    ".html",
    ".db",
    ".db-shm",
    ".db-wal",
}

CODE_SUFFIXES = {".py", ".js", ".css", ".html", ".json", ".md"}
GENERATED_BASELINE_NAMES = {
    "VN65_ENGINEERING_BASELINE.md",
    "VN65_ENGINEERING_BASELINE.json",
    "VN65_WORKSPACE_HYGIENE.md",
    "VN65_WORKSPACE_HYGIENE.json",
}


def format_bytes(num: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    value = float(num)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{num} B"


def iter_files(base: Path, exclude_dirs: Iterable[str] = DEFAULT_EXCLUDE_DIRS) -> Iterable[Path]:
    exclude = set(exclude_dirs)
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [d for d in dirnames if d not in exclude]
        current = Path(dirpath)
        for filename in filenames:
            yield current / filename


def raw_path_size(path: Path) -> int:
    if path.is_file():
        return path.stat().st_size
    total = 0
    for dirpath, _, filenames in os.walk(path):
        current = Path(dirpath)
        for filename in filenames:
            try:
                total += (current / filename).stat().st_size
            except OSError:
                pass
    return total


def path_size(path: Path, exclude_dirs: Iterable[str] = DEFAULT_EXCLUDE_DIRS) -> int:
    if path.is_file():
        return path.stat().st_size
    total = 0
    for item in iter_files(path, exclude_dirs=exclude_dirs):
        try:
            total += item.stat().st_size
        except OSError:
            pass
    return total


def count_lines(path: Path) -> int:
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            return sum(1 for _ in handle)
    except OSError:
        return 0


def collect_directories(base: Path, max_depth: int = 3, exclude_dirs: Iterable[str] = DEFAULT_EXCLUDE_DIRS) -> list[dict]:
    rows = []
    exclude = set(exclude_dirs)
    for dirpath, dirnames, _ in os.walk(base):
        current = Path(dirpath)
        dirnames[:] = [d for d in dirnames if d not in exclude]
        rel = current.relative_to(base)
        depth = 0 if str(rel) == "." else len(rel.parts)
        if depth > max_depth:
            dirnames[:] = []
            continue
        if current.name in exclude:
            dirnames[:] = []
            continue
        size = path_size(current, exclude_dirs=exclude)
        rows.append({"path": str(rel), "bytes": size, "size": format_bytes(size)})
    rows.sort(key=lambda row: row["bytes"], reverse=True)
    return rows


def collect_code_hotspots(base: Path, limit: int = 30) -> list[dict]:
    rows = []
    for path in iter_files(base, exclude_dirs=SOURCE_EXCLUDE_DIRS):
        if path.name in GENERATED_BASELINE_NAMES:
            continue
        if path.suffix.lower() not in CODE_SUFFIXES:
            continue
        lines = count_lines(path)
        if lines <= 0:
            continue
        rows.append({
            "path": str(path.relative_to(base)),
            "lines": lines,
            "bytes": path.stat().st_size,
            "size": format_bytes(path.stat().st_size),
        })
    rows.sort(key=lambda row: row["lines"], reverse=True)
    return rows[:limit]


def collect_route_map(base: Path) -> list[dict]:
    rows = []
    app_dir = base / "app"
    for path in sorted(app_dir.glob("*.py")):
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError:
            continue
        for idx, line in enumerate(lines, start=1):
            stripped = line.strip()
            if stripped.startswith("@") and ".route(" in stripped:
                rows.append({
                    "file": str(path.relative_to(base)),
                    "line": idx,
                    "route": stripped,
                })
    return rows


def collect_package_risks(base: Path, limit: int = 80) -> list[dict]:
    rows = []
    for path in iter_files(base):
        name = path.name.lower()
        suffixes = {path.suffix.lower()}
        if name.endswith(".db-shm"):
            suffixes.add(".db-shm")
        if name.endswith(".db-wal"):
            suffixes.add(".db-wal")
        if suffixes & PACKAGE_RISK_SUFFIXES:
            rows.append({
                "path": str(path.relative_to(base)),
                "bytes": path.stat().st_size,
                "size": format_bytes(path.stat().st_size),
            })
    rows.sort(key=lambda row: row["bytes"], reverse=True)
    return rows[:limit]


def build_report() -> dict:
    root_dirs = collect_directories(PROJECT_ROOT, max_depth=3, exclude_dirs=SOURCE_EXCLUDE_DIRS)
    vn8_dirs = collect_directories(ROOT, max_depth=3, exclude_dirs=SOURCE_EXCLUDE_DIRS)
    return {
        "project_root": str(PROJECT_ROOT),
        "vn8_root": str(ROOT),
        "raw_project_size": format_bytes(raw_path_size(PROJECT_ROOT)),
        "raw_vn8_size": format_bytes(raw_path_size(ROOT)),
        "scanned_project_size": format_bytes(path_size(PROJECT_ROOT, exclude_dirs=SOURCE_EXCLUDE_DIRS)),
        "scanned_vn8_size": format_bytes(path_size(ROOT, exclude_dirs=SOURCE_EXCLUDE_DIRS)),
        "scan_note": "Scanned source size excludes .git, node_modules, common caches, and generated release artifacts. Workspace bloat is tracked separately by tools/workspace_hygiene.py.",
        "largest_project_dirs": root_dirs[:25],
        "largest_vn8_dirs": vn8_dirs[:25],
        "code_hotspots": collect_code_hotspots(ROOT),
        "route_map": collect_route_map(ROOT),
        "package_risks": collect_package_risks(PROJECT_ROOT),
    }


def write_markdown(report: dict, output: Path) -> None:
    lines = [
        "# VN65+ Engineering Baseline",
        "",
        "This file is generated by `vn8/tools/engineering_audit.py`.",
        "It is a read-only baseline for cleanup work.",
        "",
        "## Size Summary",
        "",
        f"- Project root: `{report['project_root']}`",
        f"- Raw project size: {report['raw_project_size']}",
        f"- Raw VN8 size: {report['raw_vn8_size']}",
        f"- Scanned project size: {report['scanned_project_size']}",
        f"- Scanned VN8 size: {report['scanned_vn8_size']}",
        f"- Note: {report['scan_note']}",
        "",
        "## Largest Project Directories",
        "",
    ]
    for row in report["largest_project_dirs"]:
        lines.append(f"- `{row['path']}`: {row['size']}")
    lines.extend(["", "## Code Hotspots", ""])
    for row in report["code_hotspots"]:
        lines.append(f"- `{row['path']}`: {row['lines']} lines, {row['size']}")
    lines.extend(["", "## Route Map", ""])
    for row in report["route_map"]:
        lines.append(f"- `{row['file']}:{row['line']}` {row['route']}")
    lines.extend(["", "## Package Risk Files", ""])
    for row in report["package_risks"]:
        lines.append(f"- `{row['path']}`: {row['size']}")
    lines.append("")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate VN65+ engineering baseline.")
    parser.add_argument("--json", dest="json_path", type=Path, help="Optional JSON output path.")
    parser.add_argument("--markdown", dest="markdown_path", type=Path, help="Optional Markdown output path.")
    args = parser.parse_args()

    report = build_report()
    if args.json_path:
        args.json_path.parent.mkdir(parents=True, exist_ok=True)
        args.json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if args.markdown_path:
        write_markdown(report, args.markdown_path)
    if not args.json_path and not args.markdown_path:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
