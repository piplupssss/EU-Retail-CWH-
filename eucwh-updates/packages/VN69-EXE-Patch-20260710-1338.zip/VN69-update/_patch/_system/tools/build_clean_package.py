#!/usr/bin/env python3
"""Build a clean program-only package directory.

The output is intentionally code/runtime-structure only. It excludes local
business databases, uploaded supplier files, product images, old launchers,
update caches, and generated archives according to `release_manifest.json`.

This is not a full Windows EXE builder. It creates a clean source package that
can be combined with the embedded Python runtime by a later packaging step.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from validate_release_manifest import (
    MANIFEST_PATH,
    ROOT,
    collect_plan,
    first_matching_pattern,
    format_bytes,
    iter_files,
    read_json,
    rel_posix,
    validate_manifest,
    validate_package_root,
)


ARTIFACT_ROOT = ROOT / "artifacts" / "clean_program"


def load_release_info() -> dict[str, Any]:
    manifest = read_json(MANIFEST_PATH)
    version_source = manifest.get("version_source") or "app/static/release_info.json"
    return read_json(ROOT / str(version_source))


def safe_package_name(value: str) -> str:
    text = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in value.strip())
    return text.strip("._-") or "EUCWH-clean-program"


def run_gate(skip_gate: bool, skip_smoke: bool, require_smoke: bool) -> None:
    if skip_gate:
        return
    command = [sys.executable, "tools/engineering_gate.py"]
    if skip_smoke:
        command.append("--skip-smoke")
    if require_smoke:
        command.append("--require-smoke")
    completed = subprocess.run(command, cwd=ROOT, text=True, check=False)
    if completed.returncode != 0:
        raise RuntimeError("Engineering gate failed; package build stopped.")


def assert_safe_output_dir(path: Path) -> None:
    resolved = path.resolve()
    if resolved == ROOT:
        raise RuntimeError("Refusing to use project root as output directory.")
    if not str(resolved).startswith(str(ROOT.resolve())):
        return
    rel = rel_posix(resolved, ROOT)
    if not first_matching_pattern(rel + "/", ["artifacts/"]):
        raise RuntimeError("Output directory inside project must be under artifacts/.")


def copy_clean_files(target: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    include = manifest.get("include") or []
    exclude = manifest.get("exclude_from_clean_program_package") or []
    copied: list[dict[str, Any]] = []
    excluded: list[dict[str, str]] = []

    for item in include:
        source = ROOT / item
        if not source.exists():
            raise RuntimeError(f"Manifest include path does not exist: {item}")
        for file_path in iter_files(source):
            rel = rel_posix(file_path, ROOT)
            matched = first_matching_pattern(rel, exclude)
            if matched:
                excluded.append({"path": rel, "matched": matched})
                continue
            destination = target / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(file_path, destination)
            copied.append({
                "path": rel,
                "bytes": file_path.stat().st_size,
                "size": format_bytes(file_path.stat().st_size),
            })

    return {
        "copied_file_count": len(copied),
        "copied_bytes": sum(row["bytes"] for row in copied),
        "copied_size": format_bytes(sum(row["bytes"] for row in copied)),
        "excluded_file_count": len(excluded),
        "excluded_examples": excluded[:40],
    }


def write_package_metadata(target: Path, release_info: dict[str, Any], copy_result: dict[str, Any]) -> None:
    metadata = {
        "created_at_epoch": int(time.time()),
        "version": release_info.get("version"),
        "build_time": release_info.get("build_time"),
        "package_type": "clean-program-source",
        "business_data_included": False,
        "restore_business_data_with": [
            "core_backup_no_images.xlsx",
            "images/",
        ],
        "copy_result": copy_result,
    }
    (target / "_clean_package_manifest.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def build_clean_package(output_dir: Path, clean: bool, skip_gate: bool, skip_smoke: bool, require_smoke: bool) -> dict[str, Any]:
    manifest = read_json(MANIFEST_PATH)
    errors = validate_manifest(manifest)
    if errors:
        raise RuntimeError("Manifest validation failed: " + "; ".join(errors))

    run_gate(skip_gate=skip_gate, skip_smoke=skip_smoke, require_smoke=require_smoke)

    assert_safe_output_dir(output_dir)
    if output_dir.exists():
        if not clean:
            raise RuntimeError(f"Output directory already exists: {output_dir}")
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    release_info = load_release_info()
    copy_result = copy_clean_files(output_dir, manifest)
    write_package_metadata(output_dir, release_info, copy_result)

    violations = validate_package_root(output_dir, manifest)
    if violations:
        sample = "; ".join(f"{row['path']} by {row['matched']}" for row in violations[:10])
        raise RuntimeError(f"Package validation failed: {sample}")

    plan = collect_plan(manifest)
    return {
        "ok": True,
        "output_dir": str(output_dir),
        "version": release_info.get("version"),
        "build_time": release_info.get("build_time"),
        "planned_file_count": plan.get("planned_file_count"),
        "copied_file_count": copy_result["copied_file_count"],
        "copied_size": copy_result["copied_size"],
        "package_violations": 0,
    }


def main() -> int:
    release_info = load_release_info()
    default_name = safe_package_name(f"{release_info.get('version', 'VN')}_clean_program")
    parser = argparse.ArgumentParser(description="Build a clean EU CWH program-only package directory.")
    parser.add_argument("--output-dir", type=Path, default=ARTIFACT_ROOT / default_name)
    parser.add_argument("--clean", action="store_true", help="Delete the output directory first if it exists.")
    parser.add_argument("--skip-gate", action="store_true", help="Do not run tools/engineering_gate.py before copying.")
    parser.add_argument("--skip-smoke", action="store_true", help="Pass --skip-smoke to the engineering gate.")
    parser.add_argument("--require-smoke", action="store_true", help="Fail if smoke credentials are missing.")
    parser.add_argument("--json", action="store_true", help="Print JSON output.")
    args = parser.parse_args()

    try:
        result = build_clean_package(
            output_dir=args.output_dir,
            clean=args.clean,
            skip_gate=args.skip_gate,
            skip_smoke=args.skip_smoke,
            require_smoke=args.require_smoke,
        )
    except Exception as exc:  # noqa: BLE001
        if args.json:
            print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2))
        else:
            print(f"FAIL {exc}")
        return 1

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS clean program package built")
        print(f"- Output: {result['output_dir']}")
        print(f"- Version: {result['version']} · {result['build_time']}")
        print(f"- Files: {result['copied_file_count']}")
        print(f"- Size: {result['copied_size']}")
        print("- Package violations: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
