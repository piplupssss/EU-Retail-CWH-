#!/usr/bin/env python3
"""Run the local engineering gate for EU Retail CWH.

This script is intended for pre-package and pre-update checks. It does not
import source files, export business data, restore backups, or write database
records. Package contract checks only write to temporary OS directories. Smoke
checks are only run when credentials are available.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

PYTHON_DIRS = ("app", "tools")
JSON_PATHS = (
    "app/static/release_info.json",
    "app/static/version_changelog.json",
    "docs/VN65_ENGINEERING_BASELINE.json",
    "docs/VN65_WORKSPACE_HYGIENE.json",
    "release_manifest.json",
)
JS_DIR = ROOT / "app" / "static" / "js"


@dataclass
class GateResult:
    name: str
    ok: bool
    detail: str = ""
    seconds: float = 0.0


def iter_files(base: Path, suffix: str) -> list[Path]:
    if not base.exists():
        return []
    rows: list[Path] = []
    for path in base.rglob(f"*{suffix}"):
        if "__pycache__" in path.parts:
            continue
        rows.append(path)
    return sorted(rows)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def timed(name: str, fn) -> GateResult:
    start = time.perf_counter()
    try:
        detail = fn()
        ok = True
    except Exception as exc:  # noqa: BLE001
        detail = str(exc)
        ok = False
    return GateResult(name=name, ok=ok, detail=detail, seconds=time.perf_counter() - start)


def check_python_syntax() -> str:
    checked = 0
    for dirname in PYTHON_DIRS:
        for path in iter_files(ROOT / dirname, ".py"):
            source = path.read_text(encoding="utf-8", errors="replace")
            compile(source, str(path), "exec")
            checked += 1
    return f"{checked} Python files"


def check_json_syntax() -> str:
    checked = 0
    missing: list[str] = []
    for item in JSON_PATHS:
        path = ROOT / item
        if not path.exists():
            missing.append(item)
            continue
        with path.open("r", encoding="utf-8-sig") as handle:
            json.load(handle)
        checked += 1
    if missing:
        raise RuntimeError("Missing JSON files: " + ", ".join(missing))
    return f"{checked} JSON files"


def check_release_metadata() -> str:
    release_path = ROOT / "app/static/release_info.json"
    changelog_path = ROOT / "app/static/version_changelog.json"
    manifest_path = ROOT / "release_manifest.json"

    release = json.loads(release_path.read_text(encoding="utf-8-sig"))
    changelog = json.loads(changelog_path.read_text(encoding="utf-8-sig"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if not isinstance(release, dict):
        raise RuntimeError("release_info.json must be a JSON object")
    if not isinstance(changelog, list) or not changelog:
        raise RuntimeError("version_changelog.json must be a non-empty list")

    version = str(release.get("version") or "").strip().upper()
    build_time = str(release.get("build_time") or "").strip()
    if not re.fullmatch(r"VN\d+", version):
        raise RuntimeError("release_info.version must look like VN65")
    if not build_time or build_time.lower() == "unknown":
        raise RuntimeError("release_info.build_time must be explicit")
    if manifest.get("version_source") != "app/static/release_info.json":
        raise RuntimeError("release_manifest.json must use app/static/release_info.json as version_source")

    top = changelog[0] if isinstance(changelog[0], dict) else {}
    if str(top.get("version") or "").strip().upper() != version:
        raise RuntimeError("Top version_changelog entry must match release_info.version")
    if str(top.get("time") or "").strip() != build_time:
        raise RuntimeError("Top version_changelog time must match release_info.build_time")

    update_url = str(release.get("update_manifest_url") or "").strip()
    parsed = urllib.parse.urlparse(update_url)
    if parsed.scheme != "https" or not parsed.hostname:
        raise RuntimeError("release_info.update_manifest_url must be HTTPS")
    allowed_hosts = [str(host).lower() for host in release.get("update_allowed_hosts") or []]
    if parsed.hostname.lower() not in allowed_hosts:
        raise RuntimeError("release_info.update_manifest_url host must be included in update_allowed_hosts")
    if not release.get("security_note") or "uploaded" not in str(release.get("security_note")).lower():
        raise RuntimeError("release_info.security_note must explicitly describe no-upload behavior")
    return f"{version} · {build_time} · {parsed.hostname.lower()}"


def run_subprocess(command: list[str], env: dict[str, str] | None = None) -> tuple[int, str]:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    return completed.returncode, completed.stdout.strip()


def check_js_syntax() -> str:
    files = iter_files(JS_DIR, ".js")
    if not files:
        return "0 JavaScript files"
    for path in files:
        code, output = run_subprocess(["node", "--check", rel(path)])
        if code != 0:
            raise RuntimeError(f"{rel(path)} failed node --check\n{output}")
    return f"{len(files)} JavaScript files"


def check_core_script_loading() -> str:
    index_path = ROOT / "app" / "static" / "index.html"
    core_dir = JS_DIR / "core"
    if not index_path.exists():
        raise RuntimeError("app/static/index.html is missing")
    if not core_dir.exists():
        return "0 core scripts"

    index_html = index_path.read_text(encoding="utf-8", errors="replace")
    expected = {
        f"/static/js/core/{path.name}"
        for path in sorted(core_dir.glob("*.js"))
        if path.is_file()
    }
    actual = set(
        re.findall(
            r"<script\s+src=[\"'](/static/js/core/[^\"']+\.js)[\"']",
            index_html,
        )
    )

    missing = sorted(expected - actual)
    stale = sorted(actual - expected)
    if missing or stale:
        details: list[str] = []
        if missing:
            details.append("missing script tags: " + ", ".join(missing))
        if stale:
            details.append("stale script tags: " + ", ".join(stale))
        raise RuntimeError("; ".join(details))
    return f"{len(expected)} core scripts loaded by index.html"


def check_release_manifest() -> str:
    code, output = run_subprocess([sys.executable, "tools/validate_release_manifest.py", "--json"])
    if code != 0:
        raise RuntimeError(output or "release manifest validation failed")
    data = json.loads(output)
    if not data.get("ok"):
        raise RuntimeError(output)
    plan = data.get("plan") or {}
    return f"{plan.get('planned_file_count')} files, {plan.get('planned_size')}, violations=0"


def check_update_package_dry_run() -> str:
    code, output = run_subprocess([
        sys.executable,
        "tools/build_update_package.py",
        "--dry-run",
        "--skip-gate",
        "--json",
    ])
    if code != 0:
        raise RuntimeError(output or "update package dry run failed")
    data = json.loads(output)
    if not data.get("ok"):
        raise RuntimeError(output)
    if not data.get("dry_run"):
        raise RuntimeError("Update package check did not run in dry-run mode")
    clean_dir = str(data.get("clean_program_dir") or "")
    if "temporary build directory" not in clean_dir:
        raise RuntimeError("Update package dry-run must use temporary clean-program staging")
    return f"{data.get('clean_program_files')} files, {data.get('clean_program_size')}, temporary staging"


def check_smoke(require_smoke: bool) -> str:
    username = os.environ.get("EUCWH_SMOKE_USER", "")
    password = os.environ.get("EUCWH_SMOKE_PASS", "")
    if not username or not password:
        if require_smoke:
            raise RuntimeError("Missing EUCWH_SMOKE_USER / EUCWH_SMOKE_PASS")
        return "skipped: missing EUCWH_SMOKE_USER / EUCWH_SMOKE_PASS"
    env = os.environ.copy()
    code, output = run_subprocess(
        [sys.executable, "tools/smoke_check.py", "--in-process", "--json"],
        env=env,
    )
    if code != 0:
        raise RuntimeError(output or "smoke check failed")
    rows: list[dict[str, Any]] = json.loads(output)
    failed = [row for row in rows if not row.get("ok")]
    if failed:
        names = ", ".join(str(row.get("name")) for row in failed)
        raise RuntimeError(f"Smoke failed: {names}")
    return f"{len(rows)} checks"


def print_text(results: list[GateResult]) -> None:
    for result in results:
        status = "PASS" if result.ok else "FAIL"
        seconds = f"{result.seconds:.2f}s"
        detail = f" - {result.detail}" if result.detail else ""
        print(f"{status} {result.name} ({seconds}){detail}")
    print(f"Overall: {'PASS' if all(r.ok for r in results) else 'FAIL'}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Run EU CWH local engineering gate.")
    parser.add_argument("--skip-smoke", action="store_true", help="Skip smoke checks even if credentials are present.")
    parser.add_argument("--require-smoke", action="store_true", help="Fail if smoke credentials are missing.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON output.")
    args = parser.parse_args()

    checks = [
        ("python syntax", check_python_syntax),
        ("json syntax", check_json_syntax),
        ("release metadata", check_release_metadata),
        ("javascript syntax", check_js_syntax),
        ("core script loading", check_core_script_loading),
        ("release manifest", check_release_manifest),
        ("update package dry-run", check_update_package_dry_run),
    ]
    if not args.skip_smoke:
        checks.append(("read-only smoke", lambda: check_smoke(args.require_smoke)))

    results = [timed(name, fn) for name, fn in checks]
    if args.json:
        print(json.dumps([result.__dict__ for result in results], ensure_ascii=False, indent=2))
    else:
        print_text(results)
    return 0 if all(result.ok for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
