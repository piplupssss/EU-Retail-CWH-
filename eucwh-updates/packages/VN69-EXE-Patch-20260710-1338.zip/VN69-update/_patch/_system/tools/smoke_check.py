#!/usr/bin/env python3
"""Read-only smoke checks for the local EU Retail CWH system.

This script does not upload, delete, import, export, or mutate business data.
Provide credentials through environment variables when authenticated checks are
needed:

    EUCWH_SMOKE_USER=... EUCWH_SMOKE_PASS=... python3 tools/smoke_check.py

Use `--in-process` to run against Flask directly without starting the local
server. This is useful after code cleanup because it avoids browser/server
noise while still checking key read-only routes.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib import error, request


DEFAULT_BASE_URL = "http://127.0.0.1:5001"
ROOT = Path(__file__).resolve().parents[1]


@dataclass
class CheckResult:
    name: str
    ok: bool
    status: int | None = None
    detail: str = ""


class Client:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")
        self.token = ""

    def request_json(self, method: str, path: str, payload: dict[str, Any] | None = None) -> tuple[int, Any]:
        body = None
        headers = {"Accept": "application/json"}
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = request.Request(self.base_url + path, data=body, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=10) as res:
                raw = res.read().decode("utf-8", errors="replace")
                if not raw:
                    return res.status, None
                return res.status, json.loads(raw)
        except error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            try:
                data = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                data = raw[:300]
            return exc.code, data

    def request_text(self, path: str) -> tuple[int, str]:
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = request.Request(self.base_url + path, headers=headers, method="GET")
        try:
            with request.urlopen(req, timeout=10) as res:
                return res.status, res.read().decode("utf-8", errors="replace")
        except error.HTTPError as exc:
            return exc.code, exc.read().decode("utf-8", errors="replace")


class InProcessClient:
    def __init__(self):
        sys.path.insert(0, str(ROOT))
        from app import create_app  # pylint: disable=import-outside-toplevel

        self.app = create_app()
        self.client = self.app.test_client()
        self.token = ""

    def request_json(self, method: str, path: str, payload: dict[str, Any] | None = None) -> tuple[int, Any]:
        headers = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        response = self.client.open(path, method=method, json=payload, headers=headers)
        data = response.get_json(silent=True)
        if data is None:
            raw = response.get_data(as_text=True)
            data = raw[:300] if raw else None
        return response.status_code, data

    def request_text(self, path: str) -> tuple[int, str]:
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        response = self.client.get(path, headers=headers)
        return response.status_code, response.get_data(as_text=True)


def add_result(results: list[CheckResult], name: str, ok: bool, status: int | None = None, detail: str = "") -> None:
    results.append(CheckResult(name=name, ok=ok, status=status, detail=detail))


def run_checks(base_url: str, username: str, password: str, in_process: bool = False) -> list[CheckResult]:
    client = InProcessClient() if in_process else Client(base_url)
    results: list[CheckResult] = []

    try:
        status, text = client.request_text("/")
        add_result(results, "home page", status == 200 and "HUAWEI" in text, status)
    except Exception as exc:  # noqa: BLE001
        add_result(results, "home page", False, detail=str(exc))
        return results

    if username and password:
        status, data = client.request_json("POST", "/api/auth/login", {"username": username, "password": password})
        token = data.get("token") if isinstance(data, dict) else ""
        client.token = token or ""
        add_result(results, "auth login", status == 200 and bool(client.token), status)
    else:
        add_result(results, "auth login", True, detail="skipped: set EUCWH_SMOKE_USER and EUCWH_SMOKE_PASS for authenticated checks")
        return results

    checks = [
        ("auth check", "/api/auth/check", lambda data: isinstance(data, dict) and data.get("authenticated") is True),
        ("logistics dashboard summary", "/api/dashboard/summary", lambda data: isinstance(data, dict)),
        ("logistics status distribution", "/api/dashboard/status_distribution", lambda data: isinstance(data, list)),
        ("logistics type distribution", "/api/dashboard/type_distribution", lambda data: isinstance(data, list)),
        ("shipments list", "/api/shipments?page=1&per_page=5", lambda data: isinstance(data, dict) and "shipments" in data),
        ("inventory list", "/api/inventory?page=1&per_page=5", lambda data: isinstance(data, dict) and "data" in data),
        ("inventory stats", "/api/inventory/stats", lambda data: isinstance(data, dict)),
        ("inventory movements", "/api/inventory/movements?page=1&per_page=5", lambda data: isinstance(data, dict)),
        ("invoice acceptance list", "/api/invoices/items", lambda data: isinstance(data, dict)),
        ("uploads list", "/api/uploads", lambda data: isinstance(data, dict)),
    ]

    for name, path, validator in checks:
        try:
            status, data = client.request_json("GET", path)
            add_result(results, name, status == 200 and validator(data), status)
        except Exception as exc:  # noqa: BLE001
            add_result(results, name, False, detail=str(exc))

    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="Run read-only local smoke checks.")
    parser.add_argument("--base-url", default=os.environ.get("EUCWH_SMOKE_BASE_URL", DEFAULT_BASE_URL))
    parser.add_argument("--in-process", action="store_true", help="Run through Flask test client without starting the server.")
    parser.add_argument("--include-update", action="store_true", help="Also check the external update manifest endpoint.")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of text.")
    args = parser.parse_args()

    username = os.environ.get("EUCWH_SMOKE_USER", "")
    password = os.environ.get("EUCWH_SMOKE_PASS", "")
    results = run_checks(args.base_url, username, password, in_process=args.in_process)

    if args.include_update and username and password:
        client = InProcessClient() if args.in_process else Client(args.base_url)
        status, data = client.request_json("POST", "/api/auth/login", {"username": username, "password": password})
        if status == 200 and isinstance(data, dict):
            client.token = data.get("token") or ""
        try:
            status, data = client.request_json("GET", "/api/update/check")
            add_result(results, "update check", status == 200 and isinstance(data, dict), status)
        except Exception as exc:  # noqa: BLE001
            add_result(results, "update check", False, detail=str(exc))

    if args.json:
        print(json.dumps([r.__dict__ for r in results], ensure_ascii=False, indent=2))
    else:
        for result in results:
            status = f" HTTP {result.status}" if result.status is not None else ""
            detail = f" - {result.detail}" if result.detail else ""
            print(f"{'PASS' if result.ok else 'FAIL'} {result.name}{status}{detail}")

    return 0 if all(r.ok for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
