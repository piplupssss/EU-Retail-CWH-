#!/usr/bin/env python3
"""Validate release manifest and clean-package hygiene.

The script is read-only. By default it validates `release_manifest.json`,
checks required source paths, and prints the program-package plan computed from
the include/exclude rules. Use `--package-root <path>` to validate an already
built Windows package directory.
"""

from __future__ import annotations

import argparse
import fnmatch
import json
import os
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
MANIFEST_PATH = ROOT / "release_manifest.json"


def format_bytes(num: int) -> str:
    units = ["B", "KB", "MB", "GB"]
    value = float(num)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024
    return f"{num} B"


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def rel_posix(path: Path, base: Path) -> str:
    return path.relative_to(base).as_posix()


def iter_files(path: Path):
    if path.is_file():
        yield path
        return
    for dirpath, dirnames, filenames in os.walk(path):
        dirnames[:] = [d for d in dirnames if d not in {".git", "__pycache__"}]
        current = Path(dirpath)
        for filename in filenames:
            yield current / filename


def iter_paths(path: Path):
    for dirpath, dirnames, filenames in os.walk(path):
        current = Path(dirpath)
        for dirname in dirnames:
            yield current / dirname
        for filename in filenames:
            yield current / filename


def matches_pattern(rel: str, pattern: str) -> bool:
    pattern = pattern.strip()
    if not pattern:
        return False
    rel = rel.strip("/")
    basename = rel.rsplit("/", 1)[-1]

    if pattern.endswith("/"):
        directory = pattern.strip("/")
        if directory.startswith("**/"):
            part = directory[3:]
            return rel == part or rel.endswith("/" + part) or ("/" + part + "/") in ("/" + rel + "/")
        return rel == directory or rel.startswith(directory + "/")

    if "/" not in pattern:
        return fnmatch.fnmatch(basename, pattern)
    return fnmatch.fnmatch(rel, pattern)


def first_matching_pattern(rel: str, patterns: list[str]) -> str:
    for pattern in patterns:
        if matches_pattern(rel, pattern):
            return pattern
    return ""


def collect_plan(manifest: dict[str, Any]) -> dict[str, Any]:
    include = manifest.get("include") or []
    exclude = manifest.get("exclude_from_clean_program_package") or []
    included: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    missing: list[str] = []

    for item in include:
        target = ROOT / item
        if not target.exists():
            missing.append(item)
            continue
        for file_path in iter_files(target):
            rel = rel_posix(file_path, ROOT)
            matched = first_matching_pattern(rel, exclude)
            row = {
                "path": rel,
                "bytes": file_path.stat().st_size,
                "size": format_bytes(file_path.stat().st_size),
            }
            if matched:
                row["excluded_by"] = matched
                excluded.append(row)
            else:
                included.append(row)

    return {
        "missing_include_paths": missing,
        "planned_file_count": len(included),
        "planned_bytes": sum(row["bytes"] for row in included),
        "planned_size": format_bytes(sum(row["bytes"] for row in included)),
        "excluded_file_count": len(excluded),
        "excluded_bytes": sum(row["bytes"] for row in excluded),
        "excluded_size": format_bytes(sum(row["bytes"] for row in excluded)),
        "excluded_examples": sorted(excluded, key=lambda row: row["bytes"], reverse=True)[:20],
    }


def validate_manifest(manifest: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for key in ("include", "exclude_from_clean_program_package", "version_source", "backup_package_contract"):
        if key not in manifest:
            errors.append(f"Missing manifest key: {key}")

    version_source = manifest.get("version_source")
    if version_source:
        version_path = ROOT / str(version_source)
        if not version_path.exists():
            errors.append(f"Version source does not exist: {version_source}")
        else:
            try:
                release_info = read_json(version_path)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Version source is not valid JSON: {exc}")
            else:
                for key in ("version", "build_time", "update_manifest_url"):
                    if not release_info.get(key):
                        errors.append(f"Version source missing value: {key}")

    backup_contract = manifest.get("backup_package_contract") or {}
    required = set(backup_contract.get("required") or [])
    for required_item in ("core_backup_no_images.xlsx", "images/"):
        if required_item not in required:
            errors.append(f"Backup package contract missing: {required_item}")

    plan = collect_plan(manifest)
    errors.extend([f"Missing include path: {path}" for path in plan["missing_include_paths"]])
    return errors


def validate_package_root(package_root: Path, manifest: dict[str, Any]) -> list[dict[str, str]]:
    patterns = manifest.get("exclude_from_clean_program_package") or []
    violations: list[dict[str, str]] = []
    if not package_root.exists():
        return [{"path": str(package_root), "matched": "package root does not exist"}]

    for item in iter_paths(package_root):
        rel = rel_posix(item, package_root)
        matched = first_matching_pattern(rel, patterns)
        if matched:
            violations.append({"path": rel, "matched": matched})
    return violations


def build_result(package_root: Path | None = None) -> dict[str, Any]:
    manifest = read_json(MANIFEST_PATH)
    errors = validate_manifest(manifest)
    plan = collect_plan(manifest)
    result: dict[str, Any] = {
        "manifest": str(MANIFEST_PATH),
        "ok": not errors,
        "errors": errors,
        "plan": plan,
    }
    if package_root is not None:
        violations = validate_package_root(package_root, manifest)
        result["package_root"] = str(package_root)
        result["package_violations"] = violations[:80]
        result["package_violation_count"] = len(violations)
        result["ok"] = result["ok"] and not violations
    return result


def print_text(result: dict[str, Any]) -> None:
    print(f"Manifest: {result['manifest']}")
    print(f"Status: {'PASS' if result['ok'] else 'FAIL'}")
    if result["errors"]:
        print("Errors:")
        for error in result["errors"]:
            print(f"- {error}")

    plan = result["plan"]
    print("Clean program package plan:")
    print(f"- Planned files: {plan['planned_file_count']} ({plan['planned_size']})")
    print(f"- Excluded by rules: {plan['excluded_file_count']} ({plan['excluded_size']})")
    if plan["missing_include_paths"]:
        print("- Missing include paths: " + ", ".join(plan["missing_include_paths"]))
    if plan["excluded_examples"]:
        print("Largest excluded examples:")
        for row in plan["excluded_examples"][:8]:
            print(f"- {row['path']} ({row['size']}) by {row['excluded_by']}")

    if "package_root" in result:
        print(f"Package root: {result['package_root']}")
        print(f"Package violations: {result['package_violation_count']}")
        for row in result.get("package_violations", [])[:20]:
            print(f"- {row['path']} by {row['matched']}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate EU CWH release manifest and package hygiene.")
    parser.add_argument("--package-root", type=Path, help="Optional built package directory to validate.")
    parser.add_argument("--json", action="store_true", help="Print JSON output.")
    args = parser.parse_args()

    result = build_result(args.package_root)
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_text(result)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
