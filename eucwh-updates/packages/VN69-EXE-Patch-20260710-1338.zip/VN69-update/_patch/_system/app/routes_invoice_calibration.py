from datetime import datetime

from flask import Blueprint, current_app, jsonify, request

from . import db as db_module
from .export_service import (
    cell,
    clean_cell,
    date_cell,
    find_header,
    float_cell,
    style_simple_sheet,
    xlsx_response,
)
from .invoice_service import normalize_acceptance_status, recalc_invoice_header_status
from .logistics_service import calc_display_status, get_db
from .maintenance_service import uploaded_file_size
from .update_service import APP_VERSION


invoice_calibration_bp = Blueprint('invoice_calibration', __name__)


@invoice_calibration_bp.route('/api/export/invoice-calibration')
def export_invoice_calibration():
    from openpyxl import Workbook
    from openpyxl.styles import PatternFill, Font, Alignment

    db = get_db()
    rows = db.execute("""
        SELECT h.invoice_number, h.invoice_date, h.invoice_type, h.currency, h.status AS invoice_status,
               i.stt_number, i.net_amount, i.ref_date, i.matched_booking_id,
               COALESCE(NULLIF(i.acceptance_status, ''), h.status, 'pending') AS acceptance_status,
               COALESCE(i.accepted_amount, i.net_amount, 0) AS accepted_amount,
               i.exception_reason, i.acceptance_remark,
               s.booking_id, s.shipment_status, s.manual_status, s.shipment_type,
               s.demand_country, s.consignee_country_code, s.consignee_name, s.consignee_city,
               s.pickup_date, s.delivery_date, s.actual_delivery_date, s.delivery_locked,
               s.total_weight, s.total_volume, s.price_without_vat
        FROM invoice_items i
        JOIN invoice_headers h ON i.invoice_id = h.id
        LEFT JOIN shipments s ON (
            s.booking_id = i.matched_booking_id
            OR (COALESCE(i.matched_booking_id, '') = '' AND (s.stt_number = i.stt_number OR s.booking_id = i.stt_number))
        )
        ORDER BY h.invoice_date DESC, h.invoice_number, i.id
    """).fetchall()
    headers = [
        'Invoice Number', 'Invoice Date', 'Invoice Type', 'STT Number',
        'Original Invoice Amount PLN', 'Currency', 'Ref Date',
        'Matched Booking ID', 'Match Status',
        'Logistics Status', 'Shipment Type', 'Demand Country', 'Consignee Country',
        'Consignee Name', 'Consignee City', 'Pickup Date', 'ETA Delivery Date',
        'Actual Delivery Date', 'Weight KG', 'Volume CBM', 'Logistics List Amount',
        'Amount Difference', 'Acceptance Status', 'Accepted Amount PLN',
        'Exception Reason', 'Acceptance Remark'
    ]
    type_labels = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    }
    status_labels = {'verified': '已验收', 'pending': '待验收', 'rejected': '已拒绝'}
    wb = Workbook()
    ws = wb.active
    ws.title = 'Invoice Acceptance'
    ws.append(headers)
    for r in rows:
        logistics_amount = float(r['price_without_vat'] or 0)
        invoice_amount = float(r['net_amount'] or 0)
        matched_booking = r['matched_booking_id'] or r['booking_id'] or ''
        ws.append([
            r['invoice_number'] or '',
            r['invoice_date'] or '',
            r['invoice_type'] or '',
            r['stt_number'] or '',
            invoice_amount,
            r['currency'] or 'PLN',
            r['ref_date'] or '',
            matched_booking,
            '已匹配' if matched_booking else '未匹配',
            calc_display_status(r) if r['booking_id'] else '',
            type_labels.get(r['shipment_type'], r['shipment_type'] or ''),
            r['demand_country'] or '',
            r['consignee_country_code'] or '',
            r['consignee_name'] or '',
            r['consignee_city'] or '',
            r['pickup_date'] or '',
            r['delivery_date'] or '',
            r['actual_delivery_date'] or '',
            r['total_weight'] or '',
            r['total_volume'] or '',
            logistics_amount if logistics_amount else '',
            round(invoice_amount - logistics_amount, 2) if logistics_amount else '',
            status_labels.get(r['acceptance_status'], r['acceptance_status'] or '待验收'),
            r['accepted_amount'] if r['accepted_amount'] is not None else invoice_amount,
            r['exception_reason'] or '',
            r['acceptance_remark'] or '',
        ])
    style_simple_sheet(ws)
    manual_fill = PatternFill('solid', fgColor='FEF3C7')
    readonly_fill = PatternFill('solid', fgColor='E0F2FE')
    for col_idx, title in enumerate(headers, start=1):
        header_cell = ws.cell(1, col_idx)
        if title in ('Acceptance Status', 'Accepted Amount PLN', 'Exception Reason', 'Acceptance Remark', 'Matched Booking ID'):
            header_cell.fill = manual_fill
        else:
            header_cell.fill = readonly_fill
    ws.freeze_panes = 'A2'
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for value_cell in row:
            value_cell.alignment = Alignment(vertical='center', wrap_text=False)
    note = wb.create_sheet('Read Me')
    note.append(['用途', '说明'])
    note.append(['工作方式', '本文件既是发票验收材料，也是可回传系统的发票验收校准 Excel。'])
    note.append(['黄色字段', '可人工维护：Matched Booking ID / Acceptance Status / Accepted Amount PLN / Exception Reason / Acceptance Remark。'])
    note.append(['状态值', 'Acceptance Status 支持：已验收 / 待验收 / 已拒绝，也兼容 verified / pending / rejected。'])
    note.append(['保护规则', '回传时不覆盖原始发票金额和物流原始数据，只更新人工验收字段和匹配关系。'])
    style_simple_sheet(note)
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return xlsx_response(wb, f'{APP_VERSION}_invoice_acceptance_calibration_{ts}.xlsx')


@invoice_calibration_bp.route('/api/invoices/import-calibration', methods=['POST'])
def import_invoice_calibration():
    import openpyxl

    file = request.files.get('file')
    if not file or not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'error': '请上传发票验收校准 Excel'}), 400
    if uploaded_file_size(file) > 20 * 1024 * 1024:
        return jsonify({'error': 'Excel 文件不能超过 20MB'}), 400
    db_module.backup_sqlite_db(current_app.config['DATABASE'], 'invoice_acceptance_calibration_import')
    wb = openpyxl.load_workbook(file, data_only=True)
    ws = wb.active
    required = ['Invoice Number', 'STT Number']
    aliases = {
        'Acceptance Status': ['Status', '验收状态', '验收结论', '是否确认验收'],
        'Accepted Amount PLN': ['Accepted Amount', '验收金额', '验收金额 PLN', 'Net Amount'],
        'Matched Booking ID': ['Booking ID', '匹配运单', '匹配 Booking ID'],
        'Ref Date': ['Ref日期'],
        'Exception Reason': ['异常原因', '问题类型', 'Reason'],
        'Acceptance Remark': ['人工备注', '备注', 'Comment'],
    }
    header_row, col_map = find_header(ws, required, aliases=aliases, scan_rows=8)
    if not header_row:
        return jsonify({'error': '未找到发票校准表头，请确认包含 Invoice Number / STT Number'}), 400
    db = get_db()
    updated_headers = set()
    updated_items = skipped = 0
    for row_idx in range(header_row + 1, ws.max_row + 1):
        invoice_number = clean_cell(cell(ws, row_idx, col_map, 'Invoice Number'))
        stt = clean_cell(cell(ws, row_idx, col_map, 'STT Number'))
        if not invoice_number or not stt:
            continue
        header = db.execute("SELECT id FROM invoice_headers WHERE invoice_number = ?", (invoice_number,)).fetchone()
        if not header:
            skipped += 1
            continue
        invoice_id = header['id']
        status = normalize_acceptance_status(clean_cell(cell(ws, row_idx, col_map, 'Acceptance Status')))
        accepted_amount = float_cell(cell(ws, row_idx, col_map, 'Accepted Amount PLN'), None)
        ref_date = date_cell(cell(ws, row_idx, col_map, 'Ref Date'))
        matched_booking = clean_cell(cell(ws, row_idx, col_map, 'Matched Booking ID'))
        exception_reason = clean_cell(cell(ws, row_idx, col_map, 'Exception Reason'))
        acceptance_remark = clean_cell(cell(ws, row_idx, col_map, 'Acceptance Remark'))
        fields = []
        params = []
        if status:
            fields.append('acceptance_status = ?')
            params.append(status)
        if accepted_amount is not None:
            fields.append('accepted_amount = ?')
            params.append(accepted_amount)
        if matched_booking:
            fields.append('matched_booking_id = ?')
            params.append(matched_booking)
        if exception_reason:
            fields.append('exception_reason = ?')
            params.append(exception_reason)
        if acceptance_remark:
            fields.append('acceptance_remark = ?')
            params.append(acceptance_remark)
        if fields:
            where = "invoice_id = ? AND stt_number = ?"
            params.extend([invoice_id, stt])
            if ref_date:
                where += " AND COALESCE(ref_date, '') = COALESCE(?, '')"
                params.append(ref_date)
            cur = db.execute(f"UPDATE invoice_items SET {', '.join(fields)} WHERE {where}", params)
            updated_items += cur.rowcount
            updated_headers.add(invoice_id)
    for invoice_id in updated_headers:
        recalc_invoice_header_status(db, invoice_id)
    db.commit()
    return jsonify({'success': True, 'updated_headers': len(updated_headers), 'updated_items': updated_items, 'skipped': skipped})
