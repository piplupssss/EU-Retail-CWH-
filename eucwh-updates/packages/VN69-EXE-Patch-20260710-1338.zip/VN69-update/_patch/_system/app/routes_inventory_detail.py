from flask import Blueprint, current_app, jsonify, request

from . import db as db_module
from .inventory_service import (
    clean_code,
    code_match_expr,
    code_match_value,
    get_db,
    is_local_bom_code,
    resolve_product_identity,
)


inventory_detail_bp = Blueprint('inventory_detail', __name__)


@inventory_detail_bp.route('/api/inventory/product/<path:product_number>')
def get_inventory_product_detail(product_number):
    d = get_db()
    requested_product_number = clean_code(product_number)
    match_key = code_match_value(requested_product_number)
    candidates = set([requested_product_number]) if requested_product_number else set()
    direct_identity_rows = d.execute(f"""
        SELECT bom_code FROM product_master WHERE {code_match_expr('product_number')} = ?
        UNION
        SELECT bom_code FROM warehouse_inventory WHERE {code_match_expr('product_number')} = ?
        UNION
        SELECT bom_code FROM sku_master WHERE {code_match_expr('product_number')} = ?
    """, (match_key, match_key, match_key)).fetchall()
    local_product_identity = bool(direct_identity_rows) and not any(
        row['bom_code'] and not is_local_bom_code(row['bom_code']) for row in direct_identity_rows
    )

    # Product Number may differ by case, spacing, underscore, hyphen, or Excel ".0".
    # Build a candidate set first, then use it for master data, stock, and movement lookup.
    if local_product_identity:
        lookup_rows = d.execute(f"""
            SELECT product_number, bom_code FROM product_master
            WHERE {code_match_expr('product_number')} = ?
            UNION
            SELECT product_number, bom_code FROM warehouse_inventory
            WHERE {code_match_expr('product_number')} = ?
            UNION
            SELECT product_number, bom_code FROM sku_master
            WHERE {code_match_expr('product_number')} = ?
        """, (match_key, match_key, match_key)).fetchall()
    else:
        lookup_rows = d.execute(f"""
            SELECT product_number, bom_code FROM product_master
            WHERE {code_match_expr('product_number')} = ?
               OR {code_match_expr('bom_code')} = ?
            UNION
            SELECT product_number, bom_code FROM warehouse_inventory
            WHERE {code_match_expr('product_number')} = ?
               OR {code_match_expr('bom_code')} = ?
            UNION
            SELECT product_number, bom_code FROM sku_master
            WHERE {code_match_expr('product_number')} = ?
               OR {code_match_expr('bom_code')} = ?
        """, (match_key, match_key, match_key, match_key, match_key, match_key)).fetchall()
    bom_candidates = set()
    for row in lookup_rows:
        if row['product_number']:
            candidates.add(clean_code(row['product_number']))
        if not local_product_identity and row['bom_code'] and not is_local_bom_code(row['bom_code']):
            bom_candidates.add(clean_code(row['bom_code']))
    if bom_candidates:
        placeholders = ','.join('?' for _ in bom_candidates)
        for row in d.execute(f"""
            SELECT product_number FROM product_master WHERE bom_code IN ({placeholders})
            UNION
            SELECT product_number FROM warehouse_inventory WHERE bom_code IN ({placeholders})
            UNION
            SELECT product_number FROM sku_master WHERE bom_code IN ({placeholders})
        """, list(bom_candidates) * 3).fetchall():
            if row['product_number']:
                candidates.add(clean_code(row['product_number']))

    candidate_list = sorted(c for c in candidates if c)
    candidate_keys = sorted(set(code_match_value(c) for c in candidate_list if c))
    exact_placeholders = ','.join('?' for _ in candidate_list) or "''"
    key_placeholders = ','.join('?' for _ in candidate_keys) or "''"

    product = d.execute("""
        SELECT pm.*, COALESCE(pimg.image_path, sm.image_path) AS image_path
        FROM product_master pm
        LEFT JOIN sku_master sm ON pm.bom_code = sm.bom_code
                                 AND NOT (REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE') OR COALESCE(NULLIF(pm.bom_code, ''), '') = '')
        LEFT JOIN sku_master pimg ON (REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE') OR COALESCE(NULLIF(pm.bom_code, ''), '') = '')
                                 AND pm.product_number = pimg.bom_code
        WHERE pm.product_number IN ({})
           OR {} IN ({})
        ORDER BY CASE WHEN pm.product_number = ? THEN 0 ELSE 1 END, pm.updated_at DESC
        LIMIT 1
    """.format(exact_placeholders, code_match_expr('pm.product_number'), key_placeholders),
        candidate_list + candidate_keys + [requested_product_number]).fetchone()
    inventory = d.execute("""
        SELECT id, warehouse, bom_code, product_number, instruction, inventory,
               last_inbound_date, last_outbound_date, comment, updated_at
        FROM warehouse_inventory
        WHERE product_number IN ({})
           OR {} IN ({})
        ORDER BY warehouse
    """.format(exact_placeholders, code_match_expr('product_number'), key_placeholders),
        candidate_list + candidate_keys).fetchall()
    movements = d.execute("""
        SELECT movement_type, sheet_name, product_number, movement_date, operation_id, operation_prefix,
               operation_target, order_date, quantity, uom, source_file
        FROM inventory_movements
        WHERE product_number IN ({})
           OR {} IN ({})
        ORDER BY movement_date DESC, id DESC
        LIMIT 30
    """.format(exact_placeholders, code_match_expr('product_number'), key_placeholders),
        candidate_list + candidate_keys).fetchall()
    if not product and not inventory:
        return jsonify({'error': 'Product Number 不存在'}), 404
    return jsonify({
        'product': dict(product) if product else {},
        'inventory': [dict(r) for r in inventory],
        'movements': [dict(r) for r in movements],
        'matched_product_numbers': candidate_list,
    })


@inventory_detail_bp.route('/api/inventory/adjust', methods=['POST'])
def adjust_inventory():
    d = get_db()
    data = request.get_json()
    warehouse = data.get('warehouse', '')
    product_number, bom_code = resolve_product_identity(d, data.get('product_number', ''), data.get('bom_code', ''))
    change_type = data.get('change_type', '')
    quantity = data.get('quantity', 0)
    comment = data.get('comment', '')

    if not all([warehouse, product_number, change_type, quantity]):
        return jsonify({'error': 'Missing required fields'}), 400

    db_module.backup_sqlite_db(current_app.config['WMS_DATABASE'], f"inventory_adjust_{product_number}")
    d.execute("""INSERT INTO warehouse_inventory (warehouse, bom_code, product_number, inventory)
                 VALUES (?, ?, ?, 0)
                 ON CONFLICT(warehouse, product_number) DO NOTHING""", (warehouse, bom_code, product_number))

    row = d.execute("SELECT inventory FROM warehouse_inventory WHERE warehouse = ? AND product_number = ?",
                    (warehouse, product_number)).fetchone()
    current = row['inventory'] if row else 0

    if change_type == 'outbound':
        new_qty = max(0, current - quantity)
        actual_change = -(current - new_qty)
    elif change_type == 'scrap':
        new_qty = max(0, current - quantity)
        actual_change = -(current - new_qty)
    elif change_type == 'inbound':
        new_qty = current + quantity
        actual_change = quantity
    else:
        new_qty = quantity
        actual_change = quantity - current

    d.execute("UPDATE warehouse_inventory SET inventory = ?, updated_at = CURRENT_TIMESTAMP WHERE warehouse = ? AND product_number = ?",
              (new_qty, warehouse, product_number))

    if change_type == 'inbound':
        d.execute("UPDATE warehouse_inventory SET last_inbound_date = DATE('now') WHERE warehouse = ? AND product_number = ?",
                  (warehouse, product_number))
    elif change_type in ('outbound', 'scrap'):
        d.execute("UPDATE warehouse_inventory SET last_outbound_date = DATE('now') WHERE warehouse = ? AND product_number = ?",
                  (warehouse, product_number))

    d.execute("""INSERT INTO inventory_transactions (warehouse, bom_code, product_number, change_type, quantity_change, comment)
                 VALUES (?, ?, ?, ?, ?, ?)""",
              (warehouse, bom_code, product_number, change_type, actual_change, comment))

    d.commit()
    return jsonify({'success': True, 'new_quantity': new_qty})


@inventory_detail_bp.route('/api/inventory/transactions', methods=['GET'])
def get_transactions():
    d = get_db()
    warehouse = request.args.get('warehouse', '')
    bom_code = request.args.get('bom_code', '')
    product_number = request.args.get('product_number', '')
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 50))

    where_clauses = []
    params = []
    if warehouse:
        where_clauses.append("warehouse = ?")
        params.append(warehouse)
    if bom_code:
        where_clauses.append("t.bom_code = ?")
        params.append(bom_code)
    if product_number:
        where_clauses.append("t.product_number = ?")
        params.append(product_number)

    where = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    offset = (page - 1) * per_page

    total = d.execute(f"SELECT COUNT(*) FROM inventory_transactions {where}", params).fetchone()[0]
    rows = d.execute(f"""
        SELECT t.*, sm.product_description
        FROM inventory_transactions t
        LEFT JOIN sku_master sm ON t.bom_code = sm.bom_code
        {where}
        ORDER BY t.created_at DESC
        LIMIT ? OFFSET ?
    """, params + [per_page, offset]).fetchall()

    return jsonify({'data': [dict(r) for r in rows], 'total': total, 'page': page, 'per_page': per_page})
