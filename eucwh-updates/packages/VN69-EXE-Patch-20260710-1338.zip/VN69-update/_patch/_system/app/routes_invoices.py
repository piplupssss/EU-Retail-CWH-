import os

from flask import Blueprint, current_app, jsonify, request

from .invoice_service import InvoiceImportError, detect_invoice_type, import_invoice_pdf
from .logistics_service import get_db
from .maintenance_service import remove_file_safely, safe_upload_filename, uploaded_file_size


invoices_bp = Blueprint('invoices', __name__)


@invoices_bp.route('/api/invoices/upload', methods=['POST'])
def upload_invoice():
    """上传物流费用发票 PDF，解析并存入数据库"""
    if 'file' not in request.files:
        return jsonify({'error': '没有上传文件'}), 400

    file = request.files['file']
    if not file.filename.lower().endswith('.pdf'):
        return jsonify({'error': '仅支持 PDF 文件'}), 400
    if uploaded_file_size(file) > 20 * 1024 * 1024:
        return jsonify({'error': 'PDF 文件不能超过 20MB'}), 400

    invoice_type = detect_invoice_type(file.filename, request.form.get('type', 'auto'))

    upload_dir = os.path.join(os.path.dirname(current_app.config['DATABASE']), 'uploads')
    os.makedirs(upload_dir, exist_ok=True)
    saved_filename = safe_upload_filename(file.filename)
    filepath = os.path.join(upload_dir, saved_filename)
    file.save(filepath)

    try:
        result = import_invoice_pdf(filepath, saved_filename, invoice_type, current_app.config['DATABASE'])
        remove_file_safely(filepath)
        return jsonify({'success': True, **result})
    except InvoiceImportError as e:
        remove_file_safely(filepath)
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        remove_file_safely(filepath)
        return jsonify({'error': str(e)}), 500


@invoices_bp.route('/api/invoices')
def list_invoices():
    """列出所有发票"""
    db = get_db()
    rows = db.execute('''SELECT h.id, h.invoice_number, h.invoice_date, h.invoice_type, h.currency,
                          h.total_net, h.status, h.source_file, h.created_at,
                          COUNT(i.id) as item_count,
                          SUM(CASE WHEN i.matched_booking_id IS NOT NULL THEN 1 ELSE 0 END) as matched_count
                          FROM invoice_headers h LEFT JOIN invoice_items i ON h.id = i.invoice_id
                          GROUP BY h.id ORDER BY h.created_at DESC''').fetchall()
    db.close()
    return jsonify([{
        'id': r['id'],
        'invoice_number': r['invoice_number'],
        'invoice_date': r['invoice_date'],
        'invoice_type': r['invoice_type'],
        'currency': r['currency'],
        'total_net': r['total_net'],
        'status': r['status'],
        'source_file': r['source_file'],
        'created_at': r['created_at'],
        'item_count': r['item_count'],
        'matched_count': r['matched_count']
    } for r in rows])


@invoices_bp.route('/api/invoices/<int:invoice_id>')
def get_invoice(invoice_id):
    """获取单个发票详情"""
    db = get_db()
    header = db.execute('SELECT * FROM invoice_headers WHERE id = ?', (invoice_id,)).fetchone()
    if not header:
        db.close()
        return jsonify({'error': '发票不存在'}), 404
    items = db.execute('''SELECT i.*, s.booking_id as shipment_booking_id, s.shipment_type
                         FROM invoice_items i LEFT JOIN shipments s ON i.matched_booking_id = s.booking_id
                         WHERE i.invoice_id = ? ORDER BY i.id''', (invoice_id,)).fetchall()
    db.close()
    return jsonify({
        'id': header['id'],
        'invoice_number': header['invoice_number'],
        'invoice_date': header['invoice_date'],
        'invoice_type': header['invoice_type'],
        'currency': header['currency'],
        'total_net': header['total_net'],
        'status': header['status'],
        'source_file': header['source_file'],
        'created_at': header['created_at'],
        'items': [{
            'id': item['id'],
            'stt_number': item['stt_number'],
            'net_amount': item['net_amount'],
            'ref_date': item['ref_date'],
            'matched_booking_id': item['matched_booking_id'],
            'shipment_type': item['shipment_type']
        } for item in items]
    })


@invoices_bp.route('/api/invoices/items')
def list_invoice_items():
    """费用明细聚合接口，供费用列表一次性加载，避免逐张发票请求。"""
    db = get_db()
    invoice_type = request.args.get('type', 'logistics')
    status = request.args.get('status', '')
    params = []
    where = []
    if invoice_type:
        where.append('h.invoice_type = ?')
        params.append(invoice_type)
    if status:
        where.append("COALESCE(NULLIF(i.acceptance_status, ''), h.status) = ?")
        params.append(status)
    where_sql = 'WHERE ' + ' AND '.join(where) if where else ''
    rows = db.execute(f"""
        SELECT i.id, i.stt_number, i.net_amount, i.ref_date, i.matched_booking_id,
               i.accepted_amount, i.acceptance_status, i.exception_reason, i.acceptance_remark,
               h.id AS invoice_id, h.invoice_number, h.invoice_date, h.invoice_type,
               h.currency, COALESCE(NULLIF(i.acceptance_status, ''), h.status) AS invoice_status,
               s.booking_id AS shipment_booking_id, s.shipment_type, s.consignee_country_code,
               s.pickup_date
        FROM invoice_items i
        JOIN invoice_headers h ON i.invoice_id = h.id
        LEFT JOIN shipments s ON i.matched_booking_id = s.booking_id
        {where_sql}
        ORDER BY h.invoice_date DESC, h.invoice_number, i.id
    """, params).fetchall()
    pln_to_usd = 0.25
    items = [dict(r) for r in rows]
    total_pln = round(sum(float(r.get('accepted_amount') if r.get('accepted_amount') is not None else r.get('net_amount') or 0) for r in items), 2)
    return jsonify({
        'items': items,
        'summary': {
            'item_count': len(items),
            'matched_count': sum(1 for r in items if r.get('matched_booking_id')),
            'pending_count': sum(1 for r in items if r.get('invoice_status') == 'pending'),
            'verified_count': sum(1 for r in items if r.get('invoice_status') == 'verified'),
            'rejected_count': sum(1 for r in items if r.get('invoice_status') == 'rejected'),
            'total_pln': total_pln,
            'total_usd': round(total_pln * pln_to_usd, 2),
            'pln_to_usd': pln_to_usd
        }
    })


@invoices_bp.route('/api/invoices/budget')
def get_budget():
    """获取费用验收预算概览"""
    db = get_db()
    budget_usd = 250000

    logistics_total = db.execute('''SELECT COALESCE(SUM(COALESCE(i.accepted_amount, i.net_amount)), 0) FROM invoice_items i
                                    JOIN invoice_headers h ON i.invoice_id = h.id
                                    WHERE h.invoice_type = 'logistics' AND COALESCE(NULLIF(i.acceptance_status, ''), h.status) = 'verified' ''').fetchone()[0]
    pending_logistics_total = db.execute('''SELECT COALESCE(SUM(COALESCE(i.accepted_amount, i.net_amount)), 0) FROM invoice_items i
                                            JOIN invoice_headers h ON i.invoice_id = h.id
                                            WHERE h.invoice_type = 'logistics' AND COALESCE(NULLIF(i.acceptance_status, ''), h.status) = 'pending' ''').fetchone()[0]
    match_row = db.execute('''SELECT COUNT(i.id) AS item_count,
                                     SUM(CASE WHEN i.matched_booking_id IS NOT NULL THEN 1 ELSE 0 END) AS matched_count
                              FROM invoice_items i
                              JOIN invoice_headers h ON i.invoice_id = h.id
                              WHERE h.invoice_type = 'logistics' ''').fetchone()

    pln_to_usd = 0.25
    logistics_usd = round(logistics_total * pln_to_usd, 2)

    warehouse_total = 0
    warehouse_usd = 0

    total_spent_usd = logistics_usd + warehouse_usd
    remaining_usd = budget_usd - total_spent_usd

    inv_rows = db.execute('''SELECT h.id, h.invoice_number, h.invoice_date, h.invoice_type, h.currency,
                          h.total_net, h.status, h.source_file, h.created_at,
                          COUNT(i.id) as item_count,
                          SUM(CASE WHEN i.matched_booking_id IS NOT NULL THEN 1 ELSE 0 END) as matched_count
                          FROM invoice_headers h LEFT JOIN invoice_items i ON h.id = i.invoice_id
                          GROUP BY h.id ORDER BY h.created_at DESC''').fetchall()
    invoices = [{
        'id': r['id'],
        'invoice_number': r['invoice_number'],
        'invoice_date': r['invoice_date'],
        'invoice_type': r['invoice_type'],
        'currency': r['currency'],
        'total_net': r['total_net'],
        'status': r['status'],
        'source_file': r['source_file'],
        'created_at': r['created_at'],
        'item_count': r['item_count'],
        'matched_count': r['matched_count']
    } for r in inv_rows]

    db.close()

    return jsonify({
        'budget_usd': budget_usd,
        'logistics_pln': logistics_total,
        'logistics_usd': logistics_usd,
        'pending_logistics_pln': pending_logistics_total,
        'pending_logistics_usd': round(pending_logistics_total * pln_to_usd, 2),
        'invoice_item_count': match_row['item_count'] or 0,
        'invoice_matched_count': match_row['matched_count'] or 0,
        'invoice_match_rate': round(((match_row['matched_count'] or 0) / (match_row['item_count'] or 1)) * 100, 1) if match_row['item_count'] else 0,
        'warehouse_pln': warehouse_total,
        'warehouse_usd': warehouse_usd,
        'total_spent_usd': total_spent_usd,
        'remaining_usd': remaining_usd,
        'pln_to_usd': pln_to_usd,
        'invoices': invoices
    })


@invoices_bp.route('/api/invoices/<int:invoice_id>/verify', methods=['POST'])
def verify_invoice(invoice_id):
    """验收/拒绝发票"""
    data = request.get_json(silent=True) or {}
    status = data.get('status', 'verified')
    if status not in ('verified', 'rejected'):
        return jsonify({'error': '状态必须是 verified 或 rejected'}), 400
    db = get_db()
    db.execute('UPDATE invoice_headers SET status = ? WHERE id = ?', (status, invoice_id))
    db.execute("UPDATE invoice_items SET acceptance_status = ? WHERE invoice_id = ?", (status, invoice_id))
    db.commit()
    db.close()
    return jsonify({'success': True, 'status': status})


@invoices_bp.route('/api/invoices/<int:invoice_id>/match', methods=['POST'])
def match_invoice_items(invoice_id):
    """重新匹配发票明细与运单"""
    db = get_db()
    items = db.execute('SELECT id, stt_number FROM invoice_items WHERE invoice_id = ?', (invoice_id,)).fetchall()
    matched = 0
    for item in items:
        row = db.execute('SELECT booking_id FROM shipments WHERE stt_number = ? OR booking_id = ?',
                         (item['stt_number'], item['stt_number'])).fetchone()
        if row:
            db.execute('UPDATE invoice_items SET matched_booking_id = ? WHERE id = ?', (row['booking_id'], item['id']))
            matched += 1
        else:
            db.execute('UPDATE invoice_items SET matched_booking_id = NULL WHERE id = ?', (item['id'],))
    db.commit()
    db.close()
    return jsonify({'success': True, 'matched': matched, 'total': len(items)})
