def run_wms_post_schema_tasks(conn, cur):
    backfill_inventory_product_numbers(cur)
    sync_product_master_from_inventory(cur)
    normalize_product_categories(cur)
    normalize_inventory_instruction(cur)
    fill_missing_outbound_dates(cur)
    sync_unit_prices(cur)
    migrate_warehouse_inventory_product_key(cur)
    refresh_wms_indexes(conn)


def backfill_inventory_product_numbers(cur):
    cur.execute("""
        UPDATE warehouse_inventory
        SET product_number = COALESCE(NULLIF(product_number, ''), (
            SELECT product_number FROM sku_master sm
            WHERE sm.bom_code = warehouse_inventory.bom_code
              AND NOT (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(warehouse_inventory.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(warehouse_inventory.bom_code, ''), '') = ''
              )
        ), bom_code)
        WHERE product_number IS NULL OR product_number = ''
    """)
    cur.execute("""
        UPDATE delivery_order_items
        SET product_number = COALESCE(NULLIF(product_number, ''), (
            SELECT product_number FROM sku_master sm
            WHERE sm.bom_code = delivery_order_items.bom_code
              AND NOT (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(delivery_order_items.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(delivery_order_items.bom_code, ''), '') = ''
              )
        ), bom_code)
        WHERE product_number IS NULL OR product_number = ''
    """)
    cur.execute("""
        UPDATE inventory_transactions
        SET product_number = COALESCE(NULLIF(product_number, ''), (
            SELECT product_number FROM sku_master sm
            WHERE sm.bom_code = inventory_transactions.bom_code
              AND NOT (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(inventory_transactions.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(inventory_transactions.bom_code, ''), '') = ''
              )
        ), bom_code)
        WHERE product_number IS NULL OR product_number = ''
    """)


def sync_product_master_from_inventory(cur):
    cur.execute("""
        INSERT INTO product_master (product_number, bom_code, product_description, category, category_2, unit_price, updated_at)
        SELECT DISTINCT
               COALESCE(NULLIF(wi.product_number, ''), NULLIF(sm.product_number, ''), wi.bom_code) AS product_number,
               wi.bom_code,
               sm.product_description,
               UPPER(TRIM(COALESCE(sm.category, ''))) AS category,
               UPPER(TRIM(COALESCE(sm.category_2, ''))) AS category_2,
               COALESCE(sm.unit_price, 0),
               CURRENT_TIMESTAMP
        FROM warehouse_inventory wi
        LEFT JOIN sku_master sm ON wi.bom_code = sm.bom_code
            AND NOT (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(wi.bom_code, ''), '') = ''
            )
        WHERE COALESCE(NULLIF(wi.product_number, ''), NULLIF(sm.product_number, ''), wi.bom_code) IS NOT NULL
        ON CONFLICT(product_number) DO UPDATE SET
            bom_code=excluded.bom_code,
            product_description=COALESCE(excluded.product_description, product_description),
            category=COALESCE(NULLIF(excluded.category, ''), category),
            category_2=COALESCE(NULLIF(excluded.category_2, ''), category_2),
            unit_price=CASE
                WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                ELSE unit_price
            END,
            updated_at=CURRENT_TIMESTAMP
    """)


def normalize_product_categories(cur):
    category_compact = "REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(category, ''))), ' ', ''), '_', ''), '-', '')"
    category2_compact = "REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(category_2, ''))), ' ', ''), '_', ''), '-', '')"
    for table in ("product_master", "sku_master"):
        cur.execute(f"""
            UPDATE {table}
            SET category_2 = CASE
                WHEN {category2_compact} IN ('ADUIO', 'AUDIO') THEN 'AUDIO'
                WHEN {category2_compact} = 'IOT' THEN 'IOT'
                WHEN {category2_compact} = 'OTHER' THEN 'OTHER'
                WHEN {category2_compact} = 'PHONE' THEN 'PHONE'
                WHEN {category2_compact} = 'TABLET' THEN 'TABLET'
                WHEN {category2_compact} = 'WEARABLE' THEN 'WEARABLE'
                ELSE UPPER(TRIM(COALESCE(category_2, '')))
            END,
            category = CASE
                WHEN {category_compact} = 'ACRYLICPROP' THEN 'ACRYLIC PROP'
                WHEN {category_compact} = 'DUMMY' THEN 'DUMMY'
                WHEN {category_compact} = 'FURNITURE' THEN 'FURNITURE'
                WHEN {category_compact} = 'GIFT' THEN 'GIFT'
                WHEN {category_compact} = 'PROP' THEN 'PROP'
                WHEN {category_compact} = 'SECURITYSYSTEM' THEN 'SECURITY SYSTEM'
                WHEN {category_compact} IN ('TOOLS/ACCESSORIES', 'TOOLSACCESSORIES', 'TOOLACCESSORIES') THEN 'TOOLS/ACCESSORIES'
                WHEN {category_compact} = 'TRAININGMATERIALS' THEN 'TRAINING MATERIALS'
                WHEN {category_compact} = 'UNIFORM' THEN 'UNIFORM'
                WHEN {category_compact} = 'WOODENOVERLAY' THEN 'WOODEN OVERLAY'
                ELSE UPPER(TRIM(COALESCE(category, '')))
            END
        """)


def normalize_inventory_instruction(cur):
    cur.execute("UPDATE warehouse_inventory SET instruction = UPPER(TRIM(COALESCE(instruction, '')))")


def fill_missing_outbound_dates(cur):
    cur.execute("""
        UPDATE product_master
        SET last_outbound_date = last_inbound_date,
            updated_at = CURRENT_TIMESTAMP
        WHERE (last_outbound_date IS NULL OR TRIM(last_outbound_date) = '')
          AND last_inbound_date IS NOT NULL
          AND TRIM(last_inbound_date) != ''
    """)
    cur.execute("""
        UPDATE warehouse_inventory
        SET last_outbound_date = last_inbound_date,
            updated_at = CURRENT_TIMESTAMP
        WHERE (last_outbound_date IS NULL OR TRIM(last_outbound_date) = '')
          AND last_inbound_date IS NOT NULL
          AND TRIM(last_inbound_date) != ''
    """)


def sync_unit_prices(cur):
    cur.execute("""
        UPDATE product_master
        SET unit_price = (
            SELECT sm.unit_price
            FROM sku_master sm
            WHERE sm.product_number = product_master.product_number
              AND COALESCE(sm.unit_price, 0) > 0
            ORDER BY sm.updated_at DESC
            LIMIT 1
        ),
            updated_at = CURRENT_TIMESTAMP
        WHERE COALESCE(product_master.unit_price, 0) <= 0
          AND EXISTS (
            SELECT 1
            FROM sku_master sm
            WHERE sm.product_number = product_master.product_number
              AND COALESCE(sm.unit_price, 0) > 0
          )
    """)
    cur.execute("""
        UPDATE sku_master
        SET unit_price = (
            SELECT pm.unit_price
            FROM product_master pm
            WHERE pm.product_number = sku_master.product_number
              AND COALESCE(pm.unit_price, 0) > 0
            ORDER BY pm.updated_at DESC
            LIMIT 1
        ),
            updated_at = CURRENT_TIMESTAMP
        WHERE COALESCE(sku_master.unit_price, 0) <= 0
          AND EXISTS (
            SELECT 1
            FROM product_master pm
            WHERE pm.product_number = sku_master.product_number
              AND COALESCE(pm.unit_price, 0) > 0
          )
    """)


def migrate_warehouse_inventory_product_key(cur):
    table_sql = cur.execute("""
        SELECT sql FROM sqlite_master
        WHERE type = 'table' AND name = 'warehouse_inventory'
    """).fetchone()
    if not table_sql or "UNIQUE(warehouse, bom_code)" not in (table_sql[0] or ""):
        return

    cur.execute("""
        CREATE TABLE IF NOT EXISTS warehouse_inventory_vn11 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            warehouse TEXT NOT NULL,
            bom_code TEXT NOT NULL,
            product_number TEXT NOT NULL,
            instruction TEXT,
            inventory INTEGER DEFAULT 0,
            last_inbound_date DATE,
            last_outbound_date DATE,
            comment TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(warehouse, product_number)
        )
    """)
    rows = cur.execute("""
        SELECT wi.id, wi.warehouse, wi.bom_code,
               COALESCE(NULLIF(wi.product_number, ''), NULLIF(sm.product_number, ''), wi.bom_code) AS product_number,
               wi.instruction, wi.inventory, wi.last_inbound_date, wi.last_outbound_date, wi.comment, wi.updated_at
        FROM warehouse_inventory wi
        LEFT JOIN sku_master sm ON wi.bom_code = sm.bom_code
        ORDER BY COALESCE(wi.updated_at, ''), wi.id
    """).fetchall()
    for row in rows:
        cur.execute("""
            INSERT INTO warehouse_inventory_vn11
                (warehouse, bom_code, product_number, instruction, inventory, last_inbound_date, last_outbound_date, comment, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(warehouse, product_number) DO UPDATE SET
                bom_code=excluded.bom_code,
                instruction=excluded.instruction,
                inventory=excluded.inventory,
                last_inbound_date=excluded.last_inbound_date,
                last_outbound_date=excluded.last_outbound_date,
                comment=excluded.comment,
                updated_at=excluded.updated_at
        """, row[1:])
    cur.execute("DROP TABLE warehouse_inventory")
    cur.execute("ALTER TABLE warehouse_inventory_vn11 RENAME TO warehouse_inventory")


def refresh_wms_indexes(conn):
    conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_inv_warehouse ON warehouse_inventory(warehouse);
        CREATE INDEX IF NOT EXISTS idx_inv_bom ON warehouse_inventory(bom_code);
        CREATE INDEX IF NOT EXISTS idx_inv_product_number ON warehouse_inventory(product_number);
        CREATE INDEX IF NOT EXISTS idx_txn_product_number ON inventory_transactions(product_number);
        CREATE INDEX IF NOT EXISTS idx_product_bom ON product_master(bom_code);
        CREATE INDEX IF NOT EXISTS idx_product_category ON product_master(category);
        CREATE INDEX IF NOT EXISTS idx_product_category2 ON product_master(category_2);
    """)
