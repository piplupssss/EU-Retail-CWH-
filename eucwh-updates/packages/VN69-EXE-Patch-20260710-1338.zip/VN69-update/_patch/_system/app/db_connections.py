import sqlite3

from flask import current_app, g


def get_db():
    """物流看板数据库 (shipments)"""
    if 'db' not in g:
        g.db = sqlite3.connect(current_app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db


def get_wms_db():
    """WMS 库存数据库"""
    if 'wms_db' not in g:
        g.wms_db = sqlite3.connect(current_app.config['WMS_DATABASE'])
        g.wms_db.row_factory = sqlite3.Row
        g.wms_db.execute("PRAGMA journal_mode=WAL")
        g.wms_db.execute("PRAGMA foreign_keys=ON")
    return g.wms_db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()
    wms_db = g.pop('wms_db', None)
    if wms_db is not None:
        wms_db.close()


def query_db(query, args=(), one=False):
    db = get_db()
    cur = db.execute(query, args)
    rows = cur.fetchall()
    cur.close()
    return (rows[0] if rows else None) if one else rows
