import sqlite3
import threading
from datetime import datetime as dt

from flask import Blueprint, current_app, jsonify

from .logistics_service import get_db


shipment_verify_bp = Blueprint('shipment_verify', __name__)


# 单机离线部署使用进程内进度即可；不跨进程共享。
_verify_state = {
    'running': False,
    'progress': 0,
    'total': 0,
    'results': [],
    'started_at': None,
}


@shipment_verify_bp.route('/api/shipments/verify', methods=['POST'])
def start_verify():
    """启动批量核实：抓取所有'待核实'且有 STT 号的运单"""
    global _verify_state
    if _verify_state['running']:
        return jsonify({'error': '核实任务正在运行中', 'progress': _verify_state['progress'], 'total': _verify_state['total']}), 409

    db = get_db()
    rows = db.execute("""
        SELECT stt_number, booking_id, delivery_date, actual_delivery_date
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
          AND stt_number IS NOT NULL AND stt_number != ''
          AND delivery_locked = 0
          AND (manual_status IS NULL OR manual_status != 'abnormal')
    """).fetchall()

    today_str = dt.now().strftime('%Y-%m-%d')
    to_verify = []
    seen_stts = set()
    for r in rows:
        actual_dd = r['actual_delivery_date'] or ''
        if actual_dd and actual_dd.strip():
            continue
        dd = r['delivery_date'] or ''
        stt = (r['stt_number'] or '').strip()
        if not stt or stt in seen_stts:
            continue
        if dd and dd.strip() and dd[:10] <= today_str:
            to_verify.append(stt)
            seen_stts.add(stt)
        elif not dd or not dd.strip():
            to_verify.append(stt)
            seen_stts.add(stt)

    if not to_verify:
        return jsonify({'message': '没有需要核实的运单', 'total': 0})

    _verify_state = {
        'running': True,
        'progress': 0,
        'total': len(to_verify),
        'results': [],
        'started_at': dt.now().isoformat(),
    }

    def _run(db_path):
        global _verify_state
        from .scraper import verify_stt_list

        def progress_cb(current, total):
            _verify_state['progress'] = current

        try:
            results = verify_stt_list(to_verify, progress_callback=progress_cb)
        except Exception as e:
            _verify_state['running'] = False
            _verify_state['error'] = f'核实抓取失败: {str(e)}'
            return

        try:
            conn = sqlite3.connect(db_path, timeout=30)
            cursor = conn.cursor()
            delivered_count = 0
            in_transport_count = 0
            cancelled_count = 0
            unresolved_count = 0
            failed_count = 0
            for r in results:
                _verify_state['results'].append(r)
                stt = (r.get('stt_number') or '').strip()
                stt_key = stt.upper()
                status = r.get('status', '')
                if status == 'delivered':
                    dd = r.get('delivery_date')
                    if dd:
                        cursor.execute(
                            """
                            UPDATE shipments
                            SET actual_delivery_date = ?,
                                delivery_locked = 1,
                                manual_status = NULL,
                                last_checked = CURRENT_TIMESTAMP
                            WHERE UPPER(TRIM(stt_number)) = ?
                              AND delivery_locked = 0
                              AND recycled_at IS NULL
                            """,
                            (dd, stt_key)
                        )
                        delivered_count += cursor.rowcount
                elif status in ('in_transport', 'booked'):
                    cursor.execute(
                        """
                        UPDATE shipments
                        SET manual_status = ?, last_checked = CURRENT_TIMESTAMP
                        WHERE UPPER(TRIM(stt_number)) = ?
                          AND delivery_locked = 0
                          AND recycled_at IS NULL
                          AND (manual_status IS NULL OR manual_status NOT IN ('abnormal'))
                        """,
                        ('auto_booked' if status == 'booked' else 'auto_in_transport', stt_key)
                    )
                    in_transport_count += cursor.rowcount
                elif status == 'booked_cancelled':
                    cursor.execute(
                        """
                        UPDATE shipments
                        SET shipment_status = 'Canceled', last_checked = CURRENT_TIMESTAMP
                        WHERE UPPER(TRIM(stt_number)) = ?
                          AND COALESCE(shipment_status, '') != 'Canceled'
                          AND recycled_at IS NULL
                        """,
                        (stt_key,)
                    )
                    cancelled_count += cursor.rowcount
                elif status in ('unknown', 'not_found', 'error'):
                    if status == 'error':
                        failed_count += 1
                    else:
                        unresolved_count += 1
            conn.commit()
            conn.close()
            _verify_state['running'] = False
            _verify_state['delivered_count'] = delivered_count
            _verify_state['in_transport_count'] = in_transport_count
            _verify_state['cancelled_count'] = cancelled_count
            _verify_state['unresolved_count'] = unresolved_count
            _verify_state['failed_count'] = failed_count
        except Exception as e:
            _verify_state['running'] = False
            _verify_state['error'] = f'数据库写入失败: {str(e)}'

    db_path = current_app.config['DATABASE']
    thread = threading.Thread(target=_run, args=(db_path,), daemon=True)
    thread.start()

    return jsonify({
        'message': f'开始核实 {len(to_verify)} 个运单',
        'total': len(to_verify),
    })


@shipment_verify_bp.route('/api/shipments/verify/status')
def verify_status():
    """查询核实进度"""
    return jsonify(_verify_state)


@shipment_verify_bp.route('/api/shipments/verify/reset', methods=['POST'])
def verify_reset():
    """重置核实状态（卡住时使用）"""
    global _verify_state
    _verify_state = {
        'running': False,
        'progress': 0,
        'total': 0,
        'results': [],
        'started_at': None,
    }
    return jsonify({'success': True, 'message': '核实状态已重置'})
