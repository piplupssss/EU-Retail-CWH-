import sqlite3
from datetime import datetime
from pathlib import Path


def backup_sqlite_db(db_path, label):
    """Create a point-in-time SQLite backup before a data-changing operation."""
    source_path = Path(db_path)
    if not source_path.exists():
        return None

    backup_dir = source_path.parent / 'backups'
    backup_dir.mkdir(parents=True, exist_ok=True)

    safe_label = ''.join(ch if ch.isalnum() or ch in ('-', '_') else '_' for ch in label)[:40]
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_path = backup_dir / f"{source_path.stem}_{safe_label}_{timestamp}.db"

    src = sqlite3.connect(str(source_path))
    try:
        dst = sqlite3.connect(str(backup_path))
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()

    return str(backup_path)
