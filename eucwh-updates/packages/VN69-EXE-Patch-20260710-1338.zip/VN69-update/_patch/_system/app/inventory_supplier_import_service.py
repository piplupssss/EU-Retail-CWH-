import openpyxl

from . import db as db_module
from .inventory_import_errors import InventoryImportError
from .inventory_service import (
    INVENTORY_MAINTENANCE_ALIASES,
    INVENTORY_MAINTENANCE_REQUIRED_HEADERS,
    SUPPLIER_INVENTORY_ALIASES,
    SUPPLIER_INVENTORY_REQUIRED_HEADERS,
    clean_code,
    clean_text,
    date_text,
    find_existing_image_filename,
    find_header_row,
    get_cell,
    get_db,
    image_key_for_sku,
    is_local_bom_code,
    is_summary_product_number,
    normalize_dimension,
    remove_uploaded_source_file,
    save_uploaded_source_file,
    to_float,
    to_int,
    to_int_strict,
    uploaded_file_size,
)


def _validate_supplier_inventory_files(supplier_file, maintenance_file):
    has_supplier = bool(supplier_file and supplier_file.filename)
    has_maintenance = bool(maintenance_file and maintenance_file.filename)
    if not has_supplier and not has_maintenance:
        raise InventoryImportError('请至少上传供应商库存表或库存维护表')
    if has_supplier and not supplier_file.filename.endswith(('.xlsx', '.xls')):
        raise InventoryImportError('供应商库存表必须是 Excel 文件')
    if has_maintenance and not maintenance_file.filename.endswith(('.xlsx', '.xls')):
        raise InventoryImportError('库存维护表必须是 Excel 文件')
    if (
        has_supplier and uploaded_file_size(supplier_file) > 20 * 1024 * 1024
    ) or (
        has_maintenance and uploaded_file_size(maintenance_file) > 20 * 1024 * 1024
    ):
        raise InventoryImportError('Excel 文件不能超过 20MB')
    return has_supplier, has_maintenance


def _initial_supplier_inventory_report(warehouse):
    return {
        'warehouse': warehouse,
        'supplier_header_row': None,
        'maintenance_header_row': None,
        'supplier_rows': 0,
        'maintenance_rows': 0,
        'imported': 0,
        'created_products': 0,
        'updated_products': 0,
        'updated_inventory': 0,
        'removed_inventory': 0,
        'skipped_supplier_rows': 0,
        'used_existing_maintenance': 0,
        'inferred_bom': [],
        'missing_bom': [],
        'missing_images': [],
        'errors': []
    }


def _find_image(bom_code, product_number=''):
    return find_existing_image_filename(image_key_for_sku(bom_code, product_number))


def _infer_bom_code(product_number):
    if '_' in product_number:
        return clean_code(product_number.split('_', 1)[1].strip())
    return clean_code(product_number)


def _import_maintenance_file(d, maintenance_file, report):
    maintenance_wb = openpyxl.load_workbook(maintenance_file, data_only=True)
    maintenance_ws = maintenance_wb.active
    maintenance_header_row, maintenance_cols = find_header_row(
        maintenance_ws,
        INVENTORY_MAINTENANCE_REQUIRED_HEADERS,
        aliases=INVENTORY_MAINTENANCE_ALIASES,
    )
    report['maintenance_header_row'] = maintenance_header_row
    if not maintenance_header_row:
        raise InventoryImportError('维护表未找到表头行，请确认包含 Product Number / Bom Code / Unit Price 等字段')

    for row_idx in range(maintenance_header_row + 1, maintenance_ws.max_row + 1):
        product_number = clean_code(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Product Number'))
        if not product_number:
            continue
        report['maintenance_rows'] += 1
        bom_code = clean_code(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Bom Code'))
        if not bom_code or is_local_bom_code(bom_code):
            bom_code = '/'
        unit_price = to_float(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Unit Price'))
        last_inbound = date_text(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Last Inbound Date'))
        last_outbound = date_text(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Last Outbound Date'))
        remark = clean_text(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Remark'))
        dos_threshold = to_int(get_cell(maintenance_ws, row_idx, maintenance_cols, 'DOS Threshold'), 180)
        idle_threshold = to_int(get_cell(maintenance_ws, row_idx, maintenance_cols, 'Idle Threshold'), 180)
        product_exists = d.execute("SELECT 1 FROM product_master WHERE product_number = ?", (product_number,)).fetchone()
        image_filename = _find_image(bom_code, product_number)

        d.execute("""INSERT INTO product_master
                        (product_number, bom_code, unit_price, last_inbound_date, last_outbound_date, remark, dos_threshold, idle_threshold, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(product_number) DO UPDATE SET
                        bom_code=excluded.bom_code,
                        unit_price=CASE
                            WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                            ELSE product_master.unit_price
                        END,
                        last_inbound_date=excluded.last_inbound_date,
                        last_outbound_date=excluded.last_outbound_date,
                        remark=excluded.remark,
                        dos_threshold=excluded.dos_threshold,
                        idle_threshold=excluded.idle_threshold,
                        updated_at=CURRENT_TIMESTAMP""",
                  (product_number, bom_code, unit_price, last_inbound or None, last_outbound or None, remark, dos_threshold, idle_threshold))
        if is_local_bom_code(bom_code):
            image_key = image_key_for_sku(bom_code, product_number)
            if image_filename:
                d.execute("""INSERT INTO sku_master (bom_code, product_number, image_path, updated_at)
                             VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                             ON CONFLICT(bom_code) DO UPDATE SET
                                product_number=excluded.product_number,
                                image_path=COALESCE(excluded.image_path, image_path),
                                updated_at=CURRENT_TIMESTAMP""",
                          (image_key, product_number, image_filename))
        else:
            d.execute("""INSERT INTO sku_master (bom_code, product_number, unit_price, image_path, updated_at)
                         VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(bom_code) DO UPDATE SET
                            product_number=excluded.product_number,
                            unit_price=CASE
                                WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                                ELSE sku_master.unit_price
                            END,
                            image_path=COALESCE(excluded.image_path, image_path),
                            updated_at=CURRENT_TIMESTAMP""",
                      (bom_code, product_number, unit_price, image_filename))
        d.execute("""UPDATE warehouse_inventory
                     SET bom_code = ?,
                         last_inbound_date = ?,
                         last_outbound_date = ?,
                         comment = ?,
                         updated_at = CURRENT_TIMESTAMP
                     WHERE product_number = ?""",
                  (bom_code, last_inbound or None, last_outbound or None, remark, product_number))
        if product_exists:
            report['updated_products'] += 1
        else:
            report['created_products'] += 1
        if not image_filename:
            report['missing_images'].append(bom_code)


def _existing_supplier_values(d, warehouse, product_number, report):
    existing = d.execute("SELECT * FROM product_master WHERE product_number = ?", (product_number,)).fetchone()
    inv_existing = d.execute("SELECT * FROM warehouse_inventory WHERE warehouse = ? AND product_number = ?",
                             (warehouse, product_number)).fetchone()
    if existing:
        report['used_existing_maintenance'] += 1
        return existing, inv_existing, {
            'bom_code': clean_code(existing['bom_code']) or _infer_bom_code(product_number),
            'unit_price': existing['unit_price'] or 0,
            'last_inbound': existing['last_inbound_date'] or '',
            'last_outbound': existing['last_outbound_date'] or '',
            'remark': existing['remark'] or '',
            'dos_threshold': existing['dos_threshold'] or 180,
            'idle_threshold': existing['idle_threshold'] or 180,
        }
    if inv_existing:
        return existing, inv_existing, {
            'bom_code': clean_code(inv_existing['bom_code']) or _infer_bom_code(product_number),
            'unit_price': 0,
            'last_inbound': inv_existing['last_inbound_date'] or '',
            'last_outbound': inv_existing['last_outbound_date'] or '',
            'remark': inv_existing['comment'] or '',
            'dos_threshold': 180,
            'idle_threshold': 180,
        }
    report['inferred_bom'].append(product_number)
    report['missing_bom'].append(product_number)
    return existing, inv_existing, {
        'bom_code': _infer_bom_code(product_number),
        'unit_price': 0,
        'last_inbound': '',
        'last_outbound': '',
        'remark': '',
        'dos_threshold': 180,
        'idle_threshold': 180,
    }


def _upsert_supplier_sku(d, product_exists, bom_code, product_number, product_description, category, category_2, unit_price, image_filename):
    image_key = image_key_for_sku(bom_code, product_number)
    if product_exists:
        if image_filename:
            d.execute("""INSERT INTO sku_master (bom_code, product_number, image_path, updated_at)
                         VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(bom_code) DO UPDATE SET
                            product_number=COALESCE(NULLIF(excluded.product_number, ''), product_number),
                            image_path=COALESCE(excluded.image_path, image_path),
                            updated_at=CURRENT_TIMESTAMP""",
                      (image_key, product_number, image_filename))
    elif is_local_bom_code(bom_code):
        if image_filename:
            d.execute("""INSERT INTO sku_master (bom_code, product_number, image_path, updated_at)
                         VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(bom_code) DO UPDATE SET
                            product_number=excluded.product_number,
                            image_path=COALESCE(excluded.image_path, image_path),
                            updated_at=CURRENT_TIMESTAMP""",
                      (image_key, product_number, image_filename))
    else:
        d.execute("""INSERT INTO sku_master (bom_code, product_number, product_description, category, category_2, unit_price, image_path, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(bom_code) DO UPDATE SET
                        product_number=excluded.product_number,
                        product_description=excluded.product_description,
                        category=excluded.category,
                        category_2=excluded.category_2,
                        unit_price=CASE
                            WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                            ELSE sku_master.unit_price
                        END,
                        image_path=COALESCE(excluded.image_path, image_path),
                        updated_at=CURRENT_TIMESTAMP""",
                  (bom_code, product_number, product_description, category, category_2, unit_price, image_filename))


def _import_supplier_file(d, supplier_file, report, warehouse):
    supplier_wb = openpyxl.load_workbook(supplier_file, data_only=True)
    supplier_ws = supplier_wb.active
    supplier_header_row, supplier_cols = find_header_row(
        supplier_ws,
        SUPPLIER_INVENTORY_REQUIRED_HEADERS,
        aliases=SUPPLIER_INVENTORY_ALIASES,
    )
    report['supplier_header_row'] = supplier_header_row
    if not supplier_header_row:
        raise InventoryImportError('供应商库存表未找到表头行，请确认包含 Product Number / Instruction / Product Description / Sum of Quantity')

    uploaded_products = set()
    for row_idx in range(supplier_header_row + 1, supplier_ws.max_row + 1):
        product_number = clean_code(get_cell(supplier_ws, row_idx, supplier_cols, 'Product Number'))
        if not product_number:
            continue
        report['supplier_rows'] += 1
        product_description = clean_text(get_cell(supplier_ws, row_idx, supplier_cols, 'Product Description'))
        category = normalize_dimension(get_cell(supplier_ws, row_idx, supplier_cols, 'Category'), 'category')
        category_2 = normalize_dimension(get_cell(supplier_ws, row_idx, supplier_cols, 'Category 2'), 'category2')
        instruction = normalize_dimension(get_cell(supplier_ws, row_idx, supplier_cols, 'Instruction'), 'instruction')
        raw_inventory = get_cell(supplier_ws, row_idx, supplier_cols, 'Sum of Quantity')
        inventory = to_int_strict(raw_inventory)
        invalid_reasons = []
        if is_summary_product_number(product_number):
            invalid_reasons.append('汇总行')
        if not category:
            invalid_reasons.append('缺 Category')
        if not category_2:
            invalid_reasons.append('缺 Category 2')
        if not instruction:
            invalid_reasons.append('缺 Instruction')
        if inventory is None:
            invalid_reasons.append('数量无效')
        if invalid_reasons:
            report['skipped_supplier_rows'] += 1
            if len(report['errors']) < 20:
                report['errors'].append(f"供应商库存第 {row_idx} 行已跳过：{product_number}（{', '.join(invalid_reasons)}）")
            continue
        uploaded_products.add(product_number)

        existing, inv_existing, values = _existing_supplier_values(d, warehouse, product_number, report)
        product_exists = bool(existing)
        bom_code = values['bom_code']
        unit_price = values['unit_price']
        last_inbound = values['last_inbound']
        last_outbound = values['last_outbound']
        remark = values['remark']
        dos_threshold = values['dos_threshold']
        idle_threshold = values['idle_threshold']

        image_filename = _find_image(bom_code, product_number)
        image_key = image_key_for_sku(bom_code, product_number)
        if not image_filename:
            report['missing_images'].append(image_key or product_number)

        if not product_exists:
            d.execute("""INSERT INTO product_master
                            (product_number, bom_code, product_description, category, category_2, unit_price,
                             last_inbound_date, last_outbound_date, remark, dos_threshold, idle_threshold, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                         ON CONFLICT(product_number) DO NOTHING""",
                      (product_number, bom_code, product_description, category, category_2, unit_price,
                       last_inbound or None, last_outbound or None, remark, dos_threshold, idle_threshold))
            report['created_products'] += 1

        _upsert_supplier_sku(d, product_exists, bom_code, product_number, product_description, category, category_2, unit_price, image_filename)

        old_qty = inv_existing['inventory'] if inv_existing else None
        if inv_existing:
            d.execute("""UPDATE warehouse_inventory
                         SET inventory = ?, updated_at = CURRENT_TIMESTAMP
                         WHERE warehouse = ? AND product_number = ?""",
                      (inventory, warehouse, product_number))
        else:
            d.execute("""INSERT INTO warehouse_inventory
                            (warehouse, bom_code, product_number, instruction, inventory, last_inbound_date, last_outbound_date, comment, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)""",
                      (warehouse, bom_code, product_number, instruction, inventory, last_inbound or None, last_outbound or None, remark))
        if old_qty != inventory:
            report['updated_inventory'] += 1
            if old_qty is not None:
                d.execute("""INSERT INTO inventory_transactions (warehouse, bom_code, product_number, change_type, quantity_change, comment)
                             VALUES (?, ?, ?, 'calibration', ?, ?)""",
                          (warehouse, clean_code(inv_existing['bom_code']) if inv_existing else bom_code, product_number, inventory - old_qty, f"供应商库存导入校准: {old_qty} → {inventory}"))
        report['imported'] += 1

    old_rows = d.execute("SELECT product_number, bom_code, inventory FROM warehouse_inventory WHERE warehouse = ?", (warehouse,)).fetchall()
    for row in old_rows:
        if row['product_number'] not in uploaded_products:
            d.execute("DELETE FROM warehouse_inventory WHERE warehouse = ? AND product_number = ?", (warehouse, row['product_number']))
            d.execute("""INSERT INTO inventory_transactions (warehouse, bom_code, product_number, change_type, quantity_change, comment)
                         VALUES (?, ?, ?, 'calibration', ?, ?)""",
                      (warehouse, row['bom_code'], row['product_number'], -int(row['inventory'] or 0), "供应商库存刷新移除：新表未包含该 Product Number"))
            report['removed_inventory'] += 1


def import_supplier_inventory_files(supplier_file, maintenance_file, wms_database_path):
    d = get_db()
    warehouse = 'Lodz warehouse'
    has_supplier, has_maintenance = _validate_supplier_inventory_files(supplier_file, maintenance_file)

    db_module.backup_sqlite_db(wms_database_path, 'supplier_inventory_import')
    report = _initial_supplier_inventory_report(warehouse)

    if has_maintenance:
        _import_maintenance_file(d, maintenance_file, report)

    if has_supplier:
        _import_supplier_file(d, supplier_file, report, warehouse)

    report['inferred_bom'] = sorted(set(report['inferred_bom']))
    report['missing_bom'] = sorted(set(report['missing_bom']))
    report['missing_images'] = sorted(set(report['missing_images']))
    d.commit()
    return report
