from datetime import datetime

from flask import Blueprint, current_app, jsonify, request

from . import db as db_module
from .inventory_service import get_db, resolve_product_identity


delivery_bp = Blueprint('delivery', __name__)

# ==================== 发货指令管理 ====================

def _generate_order_number():
    today = datetime.now().strftime('%Y%m%d')
    d = get_db()
    prefix = f"DO-{today}-"
    last = d.execute("SELECT order_number FROM delivery_orders WHERE order_number LIKE ? ORDER BY id DESC LIMIT 1",
                     (f"{prefix}%",)).fetchone()
    if last:
        seq = int(last['order_number'].split('-')[-1]) + 1
    else:
        seq = 1
    return f"{prefix}{seq:03d}"


@delivery_bp.route('/api/orders', methods=['GET'])
def get_orders():
    d = get_db()
    status = request.args.get('status', '')
    warehouse = request.args.get('warehouse', '')
    keyword = request.args.get('q', '').strip()
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 50))

    where_clauses = []
    params = []
    if status:
        where_clauses.append("status = ?")
        params.append(status)
    if warehouse:
        where_clauses.append("warehouse = ?")
        params.append(warehouse)
    if keyword:
        where_clauses.append("(order_number LIKE ? OR stt_number LIKE ? OR destination_country LIKE ?)")
        params.extend([f'%{keyword}%'] * 3)

    where = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    offset = (page - 1) * per_page

    total = d.execute(f"SELECT COUNT(*) FROM delivery_orders {where}", params).fetchone()[0]
    rows = d.execute(f"""
        SELECT o.*,
               (SELECT COUNT(*) FROM delivery_order_items WHERE order_id = o.id) AS item_count,
               (SELECT COALESCE(SUM(requested_qty), 0) FROM delivery_order_items WHERE order_id = o.id) AS total_requested,
               (SELECT COALESCE(SUM(actual_qty), 0) FROM delivery_order_items WHERE order_id = o.id) AS total_actual
        FROM delivery_orders o
        {where}
        ORDER BY o.created_at DESC
        LIMIT ? OFFSET ?
    """, params + [per_page, offset]).fetchall()

    return jsonify({'data': [dict(r) for r in rows], 'total': total, 'page': page, 'per_page': per_page})


@delivery_bp.route('/api/orders', methods=['POST'])
def create_order():
    d = get_db()
    data = request.get_json()
    warehouse = data.get('warehouse', '')
    dest_country = data.get('destination_country', '')
    items = data.get('items', [])

    if not warehouse or not items:
        return jsonify({'error': 'Warehouse and items are required'}), 400

    order_number = _generate_order_number()
    cur = d.execute("""INSERT INTO delivery_orders (order_number, warehouse, destination_country)
                       VALUES (?, ?, ?)""", (order_number, warehouse, dest_country))
    order_id = cur.lastrowid

    for item in items:
        product_number, bom_code = resolve_product_identity(d, item.get('product_number', ''), item.get('bom_code', ''))
        requested_qty = item.get('requested_qty', 0)
        if not product_number or requested_qty <= 0:
            continue
        d.execute("""INSERT INTO delivery_order_items (order_id, bom_code, product_number, requested_qty)
                     VALUES (?, ?, ?, ?)""", (order_id, bom_code, product_number, requested_qty))

    d.commit()
    return jsonify({'success': True, 'order_id': order_id, 'order_number': order_number})


@delivery_bp.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order_detail(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404

    items = d.execute("""
        SELECT oi.*, sm.product_description, COALESCE(NULLIF(oi.product_number, ''), sm.product_number) AS product_number,
               sm.category, sm.unit_price
        FROM delivery_order_items oi
        LEFT JOIN sku_master sm ON oi.bom_code = sm.bom_code
        WHERE oi.order_id = ?
    """, (order_id,)).fetchall()

    return jsonify({'order': dict(order), 'items': [dict(r) for r in items]})


@delivery_bp.route('/api/orders/<int:order_id>', methods=['PUT'])
def update_order(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    if order['status'] != 'pending':
        return jsonify({'error': 'Only pending orders can be updated'}), 400

    data = request.get_json()
    if 'destination_country' in data:
        d.execute("UPDATE delivery_orders SET destination_country = ? WHERE id = ?",
                  (data['destination_country'], order_id))

    if 'items' in data:
        d.execute("DELETE FROM delivery_order_items WHERE order_id = ?", (order_id,))
        for item in data['items']:
            product_number, bom_code = resolve_product_identity(d, item.get('product_number', ''), item.get('bom_code', ''))
            d.execute("""INSERT INTO delivery_order_items (order_id, bom_code, product_number, requested_qty)
                         VALUES (?, ?, ?, ?)""", (order_id, bom_code, product_number, item['requested_qty']))

    d.commit()
    return jsonify({'success': True})


@delivery_bp.route('/api/orders/<int:order_id>', methods=['DELETE'])
def delete_order(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    if order['status'] != 'pending':
        return jsonify({'error': 'Only pending orders can be deleted'}), 400

    d.execute("DELETE FROM delivery_order_items WHERE order_id = ?", (order_id,))
    d.execute("DELETE FROM delivery_orders WHERE id = ?", (order_id,))
    d.commit()
    return jsonify({'success': True})


@delivery_bp.route('/api/orders/<int:order_id>/confirm', methods=['PUT'])
def confirm_order(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    if order['status'] != 'pending':
        return jsonify({'error': 'Only pending orders can be confirmed'}), 400

    db_module.backup_sqlite_db(current_app.config['WMS_DATABASE'], f"order_confirm_{order['order_number']}")
    data = request.get_json()
    actual_items = data.get('items', [])

    for item in actual_items:
        product_number, bom_code = resolve_product_identity(d, item.get('product_number', ''), item.get('bom_code', ''))
        actual_qty = item.get('actual_qty', 0)
        if not product_number:
            continue
        d.execute("UPDATE delivery_order_items SET actual_qty = ? WHERE order_id = ? AND product_number = ?",
                  (actual_qty, order_id, product_number))

    items = d.execute("SELECT * FROM delivery_order_items WHERE order_id = ?", (order_id,)).fetchall()
    warehouse = order['warehouse']
    for item in items:
        actual_qty = item['actual_qty']
        if actual_qty is None or actual_qty <= 0:
            continue
        product_number = item['product_number'] or item['bom_code']
        bom_code = item['bom_code']
        d.execute("""INSERT INTO warehouse_inventory (warehouse, bom_code, product_number, inventory)
                     VALUES (?, ?, ?, 0) ON CONFLICT(warehouse, product_number) DO NOTHING""",
                  (warehouse, bom_code, product_number))
        d.execute("UPDATE warehouse_inventory SET inventory = MAX(0, inventory - ?), last_outbound_date = DATE('now'), updated_at = CURRENT_TIMESTAMP WHERE warehouse = ? AND product_number = ?",
                  (actual_qty, warehouse, product_number))
        d.execute("""INSERT INTO inventory_transactions (warehouse, bom_code, product_number, change_type, quantity_change, order_id, comment)
                     VALUES (?, ?, ?, 'order_ship', ?, ?, ?)""",
                  (warehouse, bom_code, product_number, -actual_qty, order_id, f"Order {order['order_number']}"))

    d.execute("UPDATE delivery_orders SET status = 'confirmed', confirmed_at = CURRENT_TIMESTAMP WHERE id = ?", (order_id,))
    d.commit()
    return jsonify({'success': True, 'status': 'confirmed'})


@delivery_bp.route('/api/orders/<int:order_id>/ship', methods=['PUT'])
def ship_order(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    if order['status'] != 'confirmed':
        return jsonify({'error': 'Only confirmed orders can be shipped'}), 400

    data = request.get_json()
    stt_number = data.get('stt_number', '').strip()
    if not stt_number:
        return jsonify({'error': 'STT number is required'}), 400

    d.execute("UPDATE delivery_orders SET status = 'shipped', stt_number = ?, shipped_at = CURRENT_TIMESTAMP WHERE id = ?",
              (stt_number, order_id))
    d.commit()
    return jsonify({'success': True, 'status': 'shipped', 'stt_number': stt_number})


@delivery_bp.route('/api/orders/<int:order_id>/deliver', methods=['PUT'])
def deliver_order(order_id):
    d = get_db()
    order = d.execute("SELECT * FROM delivery_orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    if order['status'] != 'shipped':
        return jsonify({'error': 'Only shipped orders can be marked as delivered'}), 400

    d.execute("UPDATE delivery_orders SET status = 'delivered', delivered_at = CURRENT_TIMESTAMP WHERE id = ?", (order_id,))
    d.commit()
    return jsonify({'success': True, 'status': 'delivered'})
