import io
import os
import re
from datetime import datetime

from flask import send_file

from .release_config import APP_VERSION


def clean_download_filename(filename, fallback='download', max_len=96):
    text = str(filename or fallback or 'download').strip()
    text = re.sub(r'[\\/:*?"<>|\x00-\x1F]+', '_', text)
    text = re.sub(r'\s+', '_', text)
    text = re.sub(r'_+', '_', text).strip('._ ')
    if not text:
        text = fallback or 'download'
    base, ext = os.path.splitext(text)
    if not ext or len(ext) > 8:
        base, ext = text, ''
    base = base.strip('._ ') or (fallback or 'download')
    max_base = max(16, max_len - len(ext))
    if len(base) > max_base:
        base = base[:max_base].rstrip('._- ')
    return f'{base}{ext}'


def short_export_filename(kind, ext='xlsx', include_time=False):
    clean_kind = re.sub(r'[^A-Za-z0-9_-]+', '_', str(kind or 'export')).strip('_')[:34] or 'export'
    stamp = datetime.now().strftime('%Y%m%d_%H%M') if include_time else datetime.now().strftime('%Y%m%d')
    clean_ext = str(ext or 'xlsx').lstrip('.')
    clean_ext = re.sub(r'[^A-Za-z0-9]+', '', clean_ext) or 'xlsx'
    return clean_download_filename(f'{APP_VERSION}_{clean_kind}_{stamp}.{clean_ext}')


def split_request_values(value):
    return [v.strip().upper() for v in re.split(r'[,;，；]+', str(value or '')) if v.strip()]


def xlsx_response(workbook, filename):
    buf = io.BytesIO()
    workbook.save(buf)
    buf.seek(0)
    return send_file(
        buf,
        as_attachment=True,
        download_name=clean_download_filename(filename),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


def workbook_bytes(workbook):
    buf = io.BytesIO()
    workbook.save(buf)
    return buf.getvalue()


def excel_width_from_pixels(pixels):
    """Approximate Excel column width from screen pixels."""
    try:
        px = float(pixels)
    except (TypeError, ValueError):
        px = 70
    return max(4, round((px - 5) / 7, 1))


def add_summary_sheet(workbook, rows, title='Summary'):
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    ws = workbook.create_sheet(title)
    ws.append(['Metric', 'Value'])
    ws.sheet_view.showGridLines = False
    header_fill = PatternFill('solid', fgColor='EAF1FF')
    thin = Side(style='thin', color='D9E2EF')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell_obj in ws[1]:
        cell_obj.fill = header_fill
        cell_obj.font = Font(name='Arial', bold=True, color='172033')
        cell_obj.alignment = Alignment(horizontal='center', vertical='center')
        cell_obj.border = border
    for label, value in rows or []:
        ws.append([label, value])
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell_obj in row:
            cell_obj.font = Font(name='Arial', size=10, color='172033')
            cell_obj.alignment = Alignment(vertical='center', wrap_text=True)
            cell_obj.border = border
    ws.column_dimensions['A'].width = 28
    ws.column_dimensions['B'].width = 36
    return ws


def norm_header(value):
    return re.sub(r'[\s_/\-（）()]+', '', str(value or '').strip().upper())


def find_header(ws, required, aliases=None, scan_rows=12):
    aliases = aliases or {}
    wanted = {}
    for key in list(dict.fromkeys(list(required) + list(aliases.keys()))):
        wanted[norm_header(key)] = key
        for alias in aliases.get(key, []):
            wanted[norm_header(alias)] = key
    for row_idx in range(1, min(ws.max_row, scan_rows) + 1):
        found = {}
        for col_idx in range(1, ws.max_column + 1):
            label = wanted.get(norm_header(ws.cell(row_idx, col_idx).value))
            if label and label not in found:
                found[label] = col_idx
        if all(key in found for key in required):
            return row_idx, found
    return None, {}


def cell(ws, row_idx, col_map, key):
    col = col_map.get(key)
    return ws.cell(row_idx, col).value if col else None


def clean_cell(value):
    return str(value or '').strip()


def date_cell(value):
    if value is None or str(value).strip() == '':
        return ''
    if hasattr(value, 'strftime'):
        return value.strftime('%Y-%m-%d')
    text = str(value).strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d', '%d.%m.%Y', '%d/%m/%Y', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    return text[:10] if re.match(r'^\d{4}-\d{2}-\d{2}', text) else text


def float_cell(value, default=None):
    if value is None or str(value).strip() == '':
        return default
    try:
        return float(str(value).replace(',', '').replace(' ', ''))
    except ValueError:
        return default


def style_simple_sheet(ws, title=None):
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    ws.freeze_panes = 'A2'
    ws.sheet_view.showGridLines = False
    header_fill = PatternFill('solid', fgColor='EAF1FF')
    header_font = Font(name='Arial', color='172033', bold=True)
    thin = Side(style='thin', color='CBD5E1')
    description_cols = set()
    for cell_obj in ws[1]:
        if str(cell_obj.value or '').strip().lower() == 'product description':
            description_cols.add(cell_obj.column)
        cell_obj.fill = header_fill
        cell_obj.font = header_font
        cell_obj.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell_obj.border = Border(bottom=thin)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        ws.row_dimensions[row[0].row].height = 42
        for cell_obj in row:
            cell_obj.font = Font(name='Arial', size=10, color='172033')
            cell_obj.alignment = Alignment(vertical='center', wrap_text=cell_obj.column in description_cols)
            cell_obj.border = Border(bottom=thin)
    ws.auto_filter.ref = ws.dimensions
    for idx in range(1, ws.max_column + 1):
        values = [str(ws.cell(row, idx).value or '') for row in range(1, min(ws.max_row, 200) + 1)]
        header = str(ws.cell(1, idx).value or '').strip().lower()
        if header == 'product description':
            ws.column_dimensions[get_column_letter(idx)].width = excel_width_from_pixels(70)
        else:
            ws.column_dimensions[get_column_letter(idx)].width = min(max(max([len(v) for v in values] or [10]) + 2, 10), 34)


def style_report_sheet(ws, title, subtitle, headers, rows, summary_rows=None):
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    summary_rows = summary_rows or []
    col_count = max(len(headers), 1)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=col_count)
    ws.cell(1, 1, title)
    ws.cell(1, 1).font = Font(name='Arial', size=16, bold=True, color='1f2937')
    ws.cell(1, 1).alignment = Alignment(horizontal='center')
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=col_count)
    ws.cell(2, 1, subtitle)
    ws.cell(2, 1).font = Font(name='Arial', size=10, color='64748b')
    ws.cell(2, 1).alignment = Alignment(horizontal='center')

    row_idx = 4
    if summary_rows:
        ws.cell(row_idx, 1, '统计总览')
        ws.cell(row_idx, 1).font = Font(name='Arial', bold=True, color='334155')
        row_idx += 1
        for label, value in summary_rows:
            ws.cell(row_idx, 1, label)
            ws.cell(row_idx, 2, value)
            ws.cell(row_idx, 1).font = Font(name='Arial', color='64748b')
            ws.cell(row_idx, 2).font = Font(name='Arial', bold=True, color='0f172a')
            row_idx += 1
        row_idx += 1

    header_row = row_idx
    for col, header in enumerate(headers, 1):
        cell_obj = ws.cell(header_row, col, header)
        cell_obj.font = Font(name='Arial', bold=True, color='172033')
        cell_obj.fill = PatternFill('solid', fgColor='EAF1FF')
        cell_obj.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    thin = Side(style='thin', color='cbd5e1')
    description_cols = {idx for idx, header in enumerate(headers, 1) if str(header).strip().lower() == 'product description'}
    for r_offset, row in enumerate(rows, 1):
        ws.row_dimensions[header_row + r_offset].height = 42
        for col, value in enumerate(row, 1):
            cell_obj = ws.cell(header_row + r_offset, col, value)
            cell_obj.border = Border(bottom=thin)
            cell_obj.font = Font(name='Arial', size=10, color='172033')
            cell_obj.alignment = Alignment(vertical='center', wrap_text=col in description_cols)
    ws.freeze_panes = f'A{header_row + 1}'
    ws.auto_filter.ref = f"A{header_row}:{get_column_letter(col_count)}{header_row + len(rows)}"
    for idx, header in enumerate(headers, 1):
        values = [str(header)] + [str(r[idx - 1] if idx - 1 < len(r) and r[idx - 1] is not None else '') for r in rows[:300]]
        if str(header).strip().lower() == 'product description':
            ws.column_dimensions[get_column_letter(idx)].width = excel_width_from_pixels(70)
        else:
            width = min(max(max(len(v) for v in values) + 2, 10), 36)
            ws.column_dimensions[get_column_letter(idx)].width = width
    return header_row


def overdue_inventory_filename(kind, warehouse):
    filename_kind = 'idle' if kind == 'idle' else 'dos'
    return short_export_filename(f'{filename_kind}_overdue')


def build_overdue_inventory_workbook(rows, kind, warehouse, image_folder):
    import openpyxl
    from openpyxl.drawing.image import Image as ExcelImage
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo

    title = '长期未使用库存报告' if kind == 'idle' else 'DOS 超期库存报告'
    metric_label = '未使用天数' if kind == 'idle' else '库龄天数'
    threshold_label = '静置提醒线' if kind == 'idle' else 'DOS 超期线'
    metric_key = 'idle_days' if kind == 'idle' else 'dos'
    threshold_key = 'idle_threshold' if kind == 'idle' else 'dos_threshold'

    wb = openpyxl.Workbook()
    summary_ws = wb.active
    summary_ws.title = '统计总览'
    detail_ws = wb.create_sheet('明细清单')

    dark = '1F2937'
    accent = '2563EB' if kind == 'dos' else 'D97706'
    danger = 'DC2626'
    muted = '64748B'
    header_fill = PatternFill('solid', fgColor=dark)
    sub_fill = PatternFill('solid', fgColor='EAF1FF' if kind == 'dos' else 'FFF7ED')
    thin = Side(style='thin', color='CBD5E1')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    total_value = round(sum(float(row.get('ttl_amount') or 0) for row in rows), 2)
    total_pcs = sum(int(row.get('inventory') or 0) for row in rows)
    avg_overdue = round(sum(int(row.get('overdue_days') or 0) for row in rows) / len(rows), 1) if rows else 0
    severe_count = sum(1 for row in rows if int(row.get('overdue_days') or 0) >= 90)

    summary_ws.merge_cells('A1:H1')
    summary_ws['A1'] = title
    summary_ws['A1'].font = Font(bold=True, size=18, color='FFFFFF')
    summary_ws['A1'].fill = PatternFill('solid', fgColor=dark)
    summary_ws['A1'].alignment = Alignment(horizontal='center')
    summary_ws.merge_cells('A2:H2')
    summary_ws['A2'] = f"仓库：{warehouse or '全部仓库'}    导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}"
    summary_ws['A2'].font = Font(color=muted)
    summary_ws['A2'].alignment = Alignment(horizontal='center')

    kpis = [
        ('超期 SKU', len(rows)),
        ('超期数量 PCS', total_pcs),
        ('超期货值 USD', total_value),
        ('平均超期天数', avg_overdue),
        ('90+ 超期 SKU', severe_count),
    ]
    for idx, (label, value) in enumerate(kpis, start=1):
        col = 1 + (idx - 1) * 2
        summary_ws.cell(4, col, label)
        summary_ws.cell(5, col, value)
        summary_ws.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col + 1)
        summary_ws.merge_cells(start_row=5, start_column=col, end_row=5, end_column=col + 1)
        summary_ws.cell(4, col).fill = sub_fill
        summary_ws.cell(4, col).font = Font(bold=True, color=dark)
        summary_ws.cell(5, col).font = Font(bold=True, size=15, color=accent if idx != 5 else danger)
        summary_ws.cell(4, col).alignment = Alignment(horizontal='center')
        summary_ws.cell(5, col).alignment = Alignment(horizontal='center')
        summary_ws.cell(5, col).number_format = '$#,##0.00' if 'USD' in label else '#,##0.0' if '平均' in label else '#,##0'

    category_map = {}
    for row in rows:
        cat = row.get('category') or 'UNSPECIFIED'
        cur = category_map.setdefault(cat, {'sku': 0, 'pcs': 0, 'value': 0})
        cur['sku'] += 1
        cur['pcs'] += int(row.get('inventory') or 0)
        cur['value'] += float(row.get('ttl_amount') or 0)
    summary_headers = ['物料品类', 'SKU 数', '数量 PCS', '货值 USD', '数量占比', '货值占比']
    summary_ws.append([])
    summary_ws.append(summary_headers)
    start_row = summary_ws.max_row
    for cell_obj in summary_ws[start_row]:
        cell_obj.fill = header_fill
        cell_obj.font = Font(bold=True, color='FFFFFF')
        cell_obj.alignment = Alignment(horizontal='center')
        cell_obj.border = border
    for cat, values in sorted(category_map.items(), key=lambda kv: kv[1]['value'], reverse=True):
        row_idx = summary_ws.max_row + 1
        summary_ws.append([
            cat,
            values['sku'],
            values['pcs'],
            round(values['value'], 2),
            values['pcs'] / total_pcs if total_pcs else 0,
            values['value'] / total_value if total_value else 0,
        ])
        for cell_obj in summary_ws[row_idx]:
            cell_obj.border = border
        summary_ws.cell(row_idx, 4).number_format = '$#,##0.00'
        summary_ws.cell(row_idx, 5).number_format = '0.0%'
        summary_ws.cell(row_idx, 6).number_format = '0.0%'

    headers = [
        '图片', '仓库', 'BOM 编号', 'Product Number', '产品描述', '物料品类', '适用产品', '归属国家',
        '库存 PCS', '单价 USD', '总货值 USD', '最近入库', '最近出库', metric_label, threshold_label, '超期天数'
    ]
    detail_ws.append(headers)
    for cell_obj in detail_ws[1]:
        cell_obj.fill = header_fill
        cell_obj.font = Font(bold=True, color='FFFFFF')
        cell_obj.alignment = Alignment(horizontal='center', vertical='center')
        cell_obj.border = border
    for row in rows:
        row_idx = detail_ws.max_row + 1
        detail_ws.append([
            '', row.get('warehouse', ''), row.get('bom_code', ''), row.get('product_number', ''),
            row.get('product_description', ''), row.get('category', ''), row.get('category_2', ''), row.get('instruction', ''),
            row.get('inventory', 0), row.get('unit_price', 0), row.get('ttl_amount', 0),
            row.get('last_inbound_date', ''), row.get('last_outbound_date', ''),
            row.get(metric_key, 0), row.get(threshold_key, 180), row.get('overdue_days', 0)
        ])
        detail_ws.row_dimensions[row_idx].height = 58
        for cell_obj in detail_ws[row_idx]:
            cell_obj.border = border
            cell_obj.alignment = Alignment(vertical='center', wrap_text=cell_obj.column in (5,))
        detail_ws.cell(row_idx, 9).number_format = '#,##0'
        detail_ws.cell(row_idx, 10).number_format = '$#,##0.00'
        detail_ws.cell(row_idx, 11).number_format = '$#,##0.00'
        detail_ws.cell(row_idx, 16).font = Font(bold=True, color=danger)
        image_path = row.get('image_path') or ''
        if image_path:
            full_path = os.path.abspath(os.path.join(image_folder, os.path.basename(image_path)))
            if os.path.exists(full_path):
                try:
                    img = ExcelImage(full_path)
                    img.width = 54
                    img.height = 54
                    detail_ws.add_image(img, f'A{row_idx}')
                except Exception:
                    detail_ws.cell(row_idx, 1, '图片读取失败')

    if rows:
        table_ref = f"A1:P{detail_ws.max_row}"
        tab = Table(displayName=f"{'Idle' if kind == 'idle' else 'Dos'}OverdueTable", ref=table_ref)
        tab.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        detail_ws.add_table(tab)
    detail_ws.freeze_panes = 'A2'
    detail_ws.auto_filter.ref = f"A1:P{max(detail_ws.max_row, 1)}"

    summary_widths = [24, 12, 14, 16, 12, 12, 12, 12, 12, 12]
    for idx, width in enumerate(summary_widths, start=1):
        summary_ws.column_dimensions[get_column_letter(idx)].width = width
    detail_widths = [10, 20, 16, 22, 46, 18, 16, 14, 12, 12, 14, 14, 14, 12, 12, 12]
    for idx, width in enumerate(detail_widths, start=1):
        detail_ws.column_dimensions[get_column_letter(idx)].width = width
    summary_ws.freeze_panes = 'A8'
    summary_ws.sheet_view.showGridLines = False
    detail_ws.sheet_view.showGridLines = False
    return wb
