import sqlite3
from datetime import datetime

from flask import Blueprint, current_app, jsonify, request

from .export_service import short_export_filename, split_request_values, style_report_sheet, xlsx_response
from .inventory_export_service import build_inventory_list_workbook


inventory_exports_bp = Blueprint('inventory_exports', __name__)


@inventory_exports_bp.route('/api/export/inventory')
def export_inventory_list():
    """Export inventory calibration workbook: Lodz + Bydgoszcz sheets."""
    include_images = request.args.get('include_images') in ('1', 'true', 'yes')
    warehouse_filter = (request.args.get('warehouse') or '').strip()
    category_values = split_request_values(request.args.get('category') or '')
    category2_values = split_request_values(request.args.get('category2') or '')
    instruction_values = split_request_values(request.args.get('instruction') or '')
    wb = build_inventory_list_workbook(
        current_app.config['WMS_DATABASE'],
        current_app.config['DATABASE'],
        include_images=include_images,
        warehouse_filter=warehouse_filter,
        category_values=category_values,
        category2_values=category2_values,
        instruction_values=instruction_values,
    )
    suffix = 'with_images' if include_images else 'calibration'
    return xlsx_response(wb, short_export_filename('inventory_img' if suffix == 'with_images' else 'inventory'))


@inventory_exports_bp.route('/api/export/inventory/category2')
def export_inventory_category2_report():
    """Export a styled inventory report filtered by Category 2."""
    from openpyxl import Workbook

    category2 = (request.args.get('category2') or '').strip().upper()
    category2_values = split_request_values(category2)
    warehouse = (request.args.get('warehouse') or '').strip()
    if not category2_values:
        return jsonify({'error': '请选择 Category 2 / 适用产品后再导出报告'}), 400
    if warehouse and warehouse not in ('Lodz warehouse', 'Bydgoszcz warehouse'):
        return jsonify({'error': '仓库参数无效'}), 400

    placeholders = ','.join(['?'] * len(category2_values))
    where = [f"UPPER(TRIM(COALESCE(pm.category_2, sm.category_2, ''))) IN ({placeholders})"]
    params = category2_values[:]
    if warehouse:
        where.append("wi.warehouse = ?")
        params.append(warehouse)

    wms_conn = sqlite3.connect(current_app.config['WMS_DATABASE'])
    wms_conn.row_factory = sqlite3.Row
    try:
        rows = wms_conn.execute(f"""
            SELECT wi.warehouse,
                   COALESCE(NULLIF(wi.bom_code, ''), pm.bom_code, sm.bom_code) AS bom_code,
                   wi.product_number,
                   COALESCE(pm.product_description, sm.product_description) AS product_description,
                   COALESCE(pm.category, sm.category) AS category,
                   COALESCE(pm.category_2, sm.category_2) AS category_2,
                   wi.instruction,
                   wi.inventory,
                   COALESCE(pm.unit_price, sm.unit_price, 0) AS unit_price,
                   COALESCE(wi.last_inbound_date, pm.last_inbound_date, DATE(pm.created_at)) AS last_inbound_date,
                   COALESCE(wi.last_outbound_date, pm.last_outbound_date) AS last_outbound_date,
                   wi.comment,
                   COALESCE(pimg.image_path, sm.image_path) AS image_path
            FROM warehouse_inventory wi
            LEFT JOIN product_master pm ON wi.product_number = pm.product_number
            LEFT JOIN sku_master sm ON COALESCE(NULLIF(wi.bom_code, ''), pm.bom_code) = sm.bom_code
                AND NOT (
                    REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                    OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
                )
            LEFT JOIN sku_master pimg ON (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
            ) AND wi.product_number = pimg.bom_code
            WHERE {' AND '.join(where)}
            ORDER BY wi.warehouse, wi.product_number
        """, params).fetchall()

        headers = [
            'Warehouse', 'Bom Code', 'Product Number', 'Product Description',
            'Category', 'Category 2', 'Instruction', 'Inventory (Pcs)',
            'Unit Price (USD)', 'TTL Amount (USD)', 'Last Inbound date',
            'Last Outbound date', 'Dos (Days)', 'Days without Stock',
            'Comment', 'Photo'
        ]
        data_rows = []
        total_pcs = 0
        total_value = 0
        warehouse_summary = {}
        for r in rows:
            inventory = float(r['inventory'] or 0)
            unit_price = float(r['unit_price'] or 0)
            ttl_amount = inventory * unit_price
            total_pcs += inventory
            total_value += ttl_amount
            wh = r['warehouse'] or ''
            warehouse_summary.setdefault(wh, {'pcs': 0, 'value': 0, 'sku': 0})
            warehouse_summary[wh]['pcs'] += inventory
            warehouse_summary[wh]['value'] += ttl_amount
            warehouse_summary[wh]['sku'] += 1
            last_inbound = r['last_inbound_date'] or ''
            last_outbound = r['last_outbound_date'] or ''
            dos = ''
            idle = ''
            if last_inbound:
                days = wms_conn.execute("SELECT CAST(JULIANDAY('now') - JULIANDAY(?) AS INTEGER)", (last_inbound,)).fetchone()[0]
                dos = days if days is not None else ''
            if last_outbound:
                days = wms_conn.execute("SELECT CAST(JULIANDAY('now') - JULIANDAY(?) AS INTEGER)", (last_outbound,)).fetchone()[0]
                idle = days if days is not None else ''
            data_rows.append([
                wh,
                r['bom_code'] or '',
                r['product_number'] or '',
                r['product_description'] or '',
                r['category'] or '',
                r['category_2'] or '',
                r['instruction'] or '',
                int(inventory),
                unit_price,
                ttl_amount,
                last_inbound,
                last_outbound,
                dos,
                idle,
                r['comment'] or '',
                r['image_path'] or '',
            ])

        wb = Workbook()
        ws = wb.active
        ws.title = 'Category2 Inventory'
        scope_text = warehouse or 'All Warehouses'
        summary = [
            ('适用产品 Category 2', ', '.join(category2_values)),
            ('统计范围', scope_text),
            ('SKU 条目数', len(rows)),
            ('库存总件数 PCS', int(total_pcs)),
            ('库存总货值 USD', round(total_value, 2)),
        ]
        for wh, s in sorted(warehouse_summary.items()):
            summary.append((f"{wh} SKU / PCS / USD", f"{s['sku']} / {int(s['pcs'])} / {round(s['value'], 2)}"))
        style_report_sheet(
            ws,
            f"零售中央仓 - {', '.join(category2_values)} 库存清单报告",
            f'导出时间：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} · Category 2 筛选报告',
            headers,
            data_rows,
            summary
        )
        return xlsx_response(wb, short_export_filename('inventory_category2'))
    finally:
        wms_conn.close()
