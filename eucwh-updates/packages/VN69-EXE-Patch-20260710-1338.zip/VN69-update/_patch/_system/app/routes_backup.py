from flask import Blueprint, jsonify, request

from .backup_service import slim_local_package_result

backup_bp = Blueprint('backup', __name__)


@backup_bp.route('/api/maintenance/slim', methods=['POST'])
def slim_local_package():
    data = request.get_json(silent=True) or {}
    result, status = slim_local_package_result(data)
    return jsonify(result), status
