from flask import Blueprint, jsonify, request

from .inventory_service import clean_upper, get_db


inventory_settings_bp = Blueprint('inventory_settings', __name__)


@inventory_settings_bp.route('/api/inventory/settings/thresholds', methods=['GET'])
def get_inventory_threshold_settings():
    d = get_db()
    rows = d.execute("""
        SELECT UPPER(TRIM(COALESCE(pm.category, 'UNCATEGORIZED'))) AS category,
               COUNT(DISTINCT pm.product_number) AS sku_count,
               COALESCE(SUM(COALESCE(wi.inventory, 0)), 0) AS inventory_pcs,
               ROUND(COALESCE(SUM(COALESCE(wi.inventory, 0) * COALESCE(pm.unit_price, 0)), 0), 2) AS ttl_amount,
               ROUND(
                   CASE
                       WHEN COALESCE(SUM(COALESCE(wi.inventory, 0)), 0) > 0
                       THEN COALESCE(SUM(COALESCE(wi.inventory, 0) * COALESCE(pm.unit_price, 0)), 0) / SUM(COALESCE(wi.inventory, 0))
                       ELSE COALESCE(AVG(NULLIF(pm.unit_price, 0)), 0)
                   END,
                   2
               ) AS avg_unit_price,
               MIN(COALESCE(pm.dos_threshold, 180)) AS dos_threshold,
               MIN(COALESCE(pm.idle_threshold, 180)) AS idle_threshold
        FROM product_master pm
        LEFT JOIN warehouse_inventory wi ON wi.product_number = pm.product_number
        GROUP BY UPPER(TRIM(COALESCE(pm.category, 'UNCATEGORIZED')))
        ORDER BY category
    """).fetchall()
    return jsonify({'data': [dict(r) for r in rows]})


@inventory_settings_bp.route('/api/inventory/settings/thresholds', methods=['POST'])
def save_inventory_threshold_settings():
    payload = request.get_json(silent=True) or {}
    rows = payload.get('rows') or []
    if not isinstance(rows, list):
        return jsonify({'error': 'rows 必须是数组'}), 400

    d = get_db()
    updated = 0
    for row in rows:
        category = clean_upper(row.get('category'))
        if not category:
            continue
        try:
            dos_threshold = max(1, int(row.get('dos_threshold') or 180))
            idle_threshold = max(1, int(row.get('idle_threshold') or 180))
        except (TypeError, ValueError):
            return jsonify({'error': f'{category} 的超期线必须是数字'}), 400
        cur = d.execute("""
            UPDATE product_master
            SET dos_threshold = ?, idle_threshold = ?, updated_at = CURRENT_TIMESTAMP
            WHERE UPPER(TRIM(COALESCE(category, 'UNCATEGORIZED'))) = ?
        """, (dos_threshold, idle_threshold, category))
        updated += cur.rowcount

    d.commit()
    return jsonify({'success': True, 'updated': updated})
