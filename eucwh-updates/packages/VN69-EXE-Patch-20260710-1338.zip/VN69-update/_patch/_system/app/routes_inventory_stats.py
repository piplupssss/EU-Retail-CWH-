from flask import Blueprint, current_app, jsonify, request

from .export_service import build_overdue_inventory_workbook, overdue_inventory_filename, xlsx_response
from .inventory_stats_service import (
    get_dimension_ttl_stats,
    get_inventory_health_stats,
    get_inventory_stats,
    get_overdue_inventory_rows,
    get_scrap_stats,
    get_value_pcs_matrix_stats,
)


inventory_stats_bp = Blueprint('inventory_stats', __name__)


@inventory_stats_bp.route('/api/inventory/stats/scrap', methods=['GET'])
def scrap_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify(get_scrap_stats(warehouse))


@inventory_stats_bp.route('/api/inventory/stats', methods=['GET'])
def inventory_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify(get_inventory_stats(warehouse))


# ==================== 数据分析看板 ====================

@inventory_stats_bp.route('/api/inventory/stats/category-ttl', methods=['GET'])
def category_ttl_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_dimension_ttl_stats('category', warehouse)})


@inventory_stats_bp.route('/api/inventory/stats/instruction-ttl', methods=['GET'])
def instruction_ttl_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_dimension_ttl_stats('instruction', warehouse)})


@inventory_stats_bp.route('/api/inventory/stats/category2-ttl', methods=['GET'])
def category2_ttl_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_dimension_ttl_stats('category_2', warehouse)})


@inventory_stats_bp.route('/api/inventory/stats/value-pcs-matrix', methods=['GET'])
def value_pcs_matrix_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_value_pcs_matrix_stats(warehouse)})


@inventory_stats_bp.route('/api/inventory/stats/health', methods=['GET'])
def inventory_health_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify(get_inventory_health_stats(warehouse))


@inventory_stats_bp.route('/api/inventory/stats/dos180', methods=['GET'])
def dos180_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_overdue_inventory_rows('dos', warehouse)})


@inventory_stats_bp.route('/api/inventory/stats/idle180', methods=['GET'])
def idle180_stats():
    warehouse = request.args.get('warehouse', '')
    return jsonify({'data': get_overdue_inventory_rows('idle', warehouse)})


@inventory_stats_bp.route('/api/inventory/export/overdue', methods=['GET'])
def export_overdue_inventory():
    warehouse = request.args.get('warehouse', '')
    kind = request.args.get('kind', 'dos')
    if kind not in ('dos', 'idle'):
        kind = 'dos'
    rows = get_overdue_inventory_rows(kind, warehouse)
    workbook = build_overdue_inventory_workbook(
        rows=rows,
        kind=kind,
        warehouse=warehouse,
        image_folder=current_app.config['UPLOAD_FOLDER'],
    )
    return xlsx_response(workbook, overdue_inventory_filename(kind, warehouse))
