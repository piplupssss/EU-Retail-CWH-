import os
import re
import uuid

from flask import current_app, g
from werkzeug.utils import secure_filename


def safe_upload_filename(filename):
    """Return a unique, filesystem-safe upload filename."""
    base = secure_filename(filename or 'upload')
    if not base:
        base = 'upload'
    return f"{uuid.uuid4().hex}_{base}"


def uploaded_file_size(file):
    pos = file.stream.tell()
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(pos)
    return size


def remove_file_safely(filepath):
    try:
        if filepath and os.path.exists(filepath):
            os.remove(filepath)
    except OSError:
        pass


def remove_tree_contents(folder):
    removed = 0
    failed = []
    if not folder or not os.path.exists(folder):
        return removed, failed
    for root, dirs, files in os.walk(folder, topdown=False):
        for filename in files:
            path = os.path.join(root, filename)
            try:
                os.remove(path)
                removed += 1
            except OSError:
                failed.append(path)
        for dirname in dirs:
            path = os.path.join(root, dirname)
            try:
                os.rmdir(path)
            except OSError:
                pass
    return removed, failed


def upload_dir_path():
    path = os.path.join(os.path.dirname(current_app.config['DATABASE']), 'uploads')
    os.makedirs(path, exist_ok=True)
    return path


def app_base_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def dir_size_bytes(path):
    total = 0
    if not path or not os.path.exists(path):
        return 0
    if os.path.isfile(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    for root, _, files in os.walk(path):
        for filename in files:
            try:
                total += os.path.getsize(os.path.join(root, filename))
            except OSError:
                pass
    return total


def source_file_to_disk_name(source_file):
    """Map a stored source_file value back to the physical upload filename."""
    source_file = source_file or ''
    for prefix in ('warehouse_', 'pl_domestic_', 'intl_direct_', 'upload_', 'logistics_', 'warehouse_cost_'):
        if source_file.startswith(prefix):
            return source_file[len(prefix):]
    return source_file


def is_admin_request():
    return bool(getattr(g, 'is_admin', False))


def maintenance_password_ok(password, allow_admin=True):
    if allow_admin and is_admin_request():
        return True
    return (password or '') == 'Q84405995'


def safe_filename_part(value, fallback='all'):
    text = str(value or '').strip()
    if not text:
        text = fallback
    text = text.replace('全部', 'all').replace(' ', '_')
    text = re.sub(r'[\\/:*?"<>|\r\n]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_.')
    return text[:60] or fallback
