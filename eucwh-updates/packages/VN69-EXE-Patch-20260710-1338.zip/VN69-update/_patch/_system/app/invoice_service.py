import re

from . import db as db_module
from .invoice_parser import parse_invoice_pdf
from .logistics_service import get_db


class InvoiceImportError(ValueError):
    pass


def detect_invoice_type(filename='', requested_type='auto'):
    invoice_type = requested_type or 'auto'
    if invoice_type == 'auto':
        name = str(filename or '').lower()
        warehouse_keywords = [
            'warehouse', 'warehousing', 'storage', 'handling', 'operation',
            'operacja', 'magazyn', '仓储', '仓库', '操作'
        ]
        invoice_type = 'warehouse' if any(k in name for k in warehouse_keywords) else 'logistics'
    return invoice_type if invoice_type in ('logistics', 'warehouse') else 'logistics'


def import_invoice_pdf(filepath, source_filename, invoice_type, database_path):
    result = parse_invoice_pdf(filepath)
    if not result['invoice_number']:
        raise InvoiceImportError('无法识别发票号，请确认 PDF 格式')

    invoice_number = result['invoice_number']
    db_module.backup_sqlite_db(database_path, f"invoice_upload_{invoice_number}")
    db = get_db()
    try:
        parsed_items = [
            item for item in result['items']
            if item['stt_number'] and re.match(r'^[A-Z]{2,5}\d{6,}$', item['stt_number'])
        ]

        existing = db.execute(
            'SELECT id, status, total_net FROM invoice_headers WHERE invoice_number = ?',
            (invoice_number,)
        ).fetchone()
        preserved_acceptance = {}
        preserved_status = 'pending'
        if existing:
            old_items = db.execute('''SELECT stt_number, net_amount, ref_date, matched_booking_id,
                                             accepted_amount, acceptance_status, exception_reason, acceptance_remark
                                      FROM invoice_items
                                      WHERE invoice_id = ? ORDER BY stt_number, net_amount, ref_date''',
                                   (existing[0],)).fetchall()
            old_signature = [(r['stt_number'], round(r['net_amount'] or 0, 2), r['ref_date'] or '') for r in old_items]
            for r in old_items:
                preserved_acceptance[(r['stt_number'], r['ref_date'] or '')] = {
                    'matched_booking_id': r['matched_booking_id'],
                    'accepted_amount': r['accepted_amount'],
                    'acceptance_status': r['acceptance_status'],
                    'exception_reason': r['exception_reason'],
                    'acceptance_remark': r['acceptance_remark'],
                }
            new_signature = sorted((item['stt_number'], round(item['net_amount'] or 0, 2), item.get('ref_date') or '') for item in parsed_items)
            invoice_unchanged = (
                abs((existing['total_net'] or 0) - (result['total_net'] or 0)) < 0.01
                and old_signature == new_signature
            )
            db.execute('DELETE FROM invoice_items WHERE invoice_id = ?', (existing[0],))
            invoice_id = existing[0]
            preserved_status = existing['status'] if invoice_unchanged else 'pending'
            db.execute('''UPDATE invoice_headers SET invoice_date=?, invoice_type=?, currency=?, total_net=?,
                         total_vat=0, total_gross=0, status=?, source_file=? WHERE id=?''',
                       (result['invoice_date'], invoice_type, result['currency'],
                        result['total_net'], preserved_status, source_filename, invoice_id))
        else:
            db.execute('''INSERT INTO invoice_headers (invoice_number, invoice_date, invoice_type, currency, total_net, status, source_file)
                         VALUES (?, ?, ?, ?, ?, 'pending', ?)''',
                       (invoice_number, result['invoice_date'], invoice_type, result['currency'],
                        result['total_net'], source_filename))
            invoice_id = db.execute('SELECT last_insert_rowid()').fetchone()[0]

        matched_count = 0
        for item in parsed_items:
            matched_booking = None
            preserved = preserved_acceptance.get((item['stt_number'], item.get('ref_date') or ''), {})
            row = db.execute('SELECT booking_id FROM shipments WHERE stt_number = ? OR booking_id = ?',
                             (item['stt_number'], item['stt_number'])).fetchone()
            if row:
                matched_booking = row[0]
                matched_count += 1
            if preserved.get('matched_booking_id'):
                matched_booking = preserved.get('matched_booking_id')

            db.execute('''INSERT INTO invoice_items (
                              invoice_id, stt_number, net_amount, ref_date, matched_booking_id,
                              accepted_amount, acceptance_status, exception_reason, acceptance_remark
                          )
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                       (
                           invoice_id, item['stt_number'], item['net_amount'], item['ref_date'], matched_booking,
                           preserved.get('accepted_amount'), preserved.get('acceptance_status') or preserved_status,
                           preserved.get('exception_reason'), preserved.get('acceptance_remark')
                       ))

        recalc_invoice_header_status(db, invoice_id)
        db.commit()
    finally:
        db.close()

    return {
        'invoice_number': invoice_number,
        'invoice_date': result['invoice_date'],
        'total_net': result['total_net'],
        'currency': result['currency'],
        'total_items': len(result['items']),
        'matched_items': matched_count,
        'type': invoice_type
    }


def normalize_acceptance_status(value):
    text = str(value or '').strip().lower()
    mapping = {
        'verified': 'verified', 'accepted': 'verified', 'accept': 'verified',
        'yes': 'verified', 'y': 'verified', 'true': 'verified', '1': 'verified',
        '已验收': 'verified', '验收': 'verified', '通过': 'verified', '确认': 'verified', '确认验收': 'verified',
        'pending': 'pending', '待验收': 'pending', '待确认': 'pending', '待核实': 'pending', '': '',
        'rejected': 'rejected', 'reject': 'rejected', 'no': 'rejected', 'n': 'rejected', 'false': 'rejected', '0': 'rejected',
        '已拒绝': 'rejected', '拒绝': 'rejected', '异常': 'rejected', '不通过': 'rejected',
    }
    return mapping.get(text, text if text in ('verified', 'pending', 'rejected') else '')


def recalc_invoice_header_status(db, invoice_id):
    rows = db.execute("""
        SELECT COALESCE(NULLIF(acceptance_status, ''), 'pending') AS status
        FROM invoice_items
        WHERE invoice_id = ?
    """, (invoice_id,)).fetchall()
    if not rows:
        return
    statuses = [r['status'] for r in rows]
    if all(s == 'verified' for s in statuses):
        status = 'verified'
    elif all(s == 'rejected' for s in statuses):
        status = 'rejected'
    else:
        status = 'pending'
    db.execute("UPDATE invoice_headers SET status = ? WHERE id = ?", (status, invoice_id))
