from flask import Blueprint, jsonify, request

from .export_service import xlsx_response
from .inventory_movement_service import (
    build_inventory_movements_workbook,
    query_inventory_movements,
)


inventory_movements_bp = Blueprint('inventory_movements', __name__)


@inventory_movements_bp.route('/api/inventory/movements', methods=['GET'])
def list_inventory_movements():
    return jsonify(query_inventory_movements(request.args))


@inventory_movements_bp.route('/api/inventory/export/movements', methods=['GET'])
def export_inventory_movements():
    wb, filename = build_inventory_movements_workbook(request.args)
    return xlsx_response(wb, filename)
