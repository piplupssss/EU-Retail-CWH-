import openpyxl

from . import db as db_module
from .inventory_import_errors import InventoryImportError
from .inventory_service import (
    SPECYFIKACJA_ALIASES,
    SPECYFIKACJA_REQUIRED_HEADERS,
    clean_code,
    clean_text,
    find_header_row,
    get_cell,
    get_db,
    is_summary_row_value,
    parse_date_text,
    parse_operation_id,
    remove_uploaded_source_file,
    save_uploaded_source_file,
    to_float,
    uploaded_file_size,
)


def _validate_specyfikacja_files(files):
    if not files:
        raise InventoryImportError('请上传 Specyfikacja Excel')
    bad = [file.filename for file in files if not file.filename.endswith(('.xlsx', '.xls'))]
    if bad:
        raise InventoryImportError('只支持 .xlsx / .xls 文件：' + ', '.join(bad[:5]))
    if any(uploaded_file_size(file) > 30 * 1024 * 1024 for file in files):
        raise InventoryImportError('单个 Excel 文件不能超过 30MB')


def _latest_set(target, sku, date_value):
    if not sku or not date_value:
        return
    old = target.get(sku)
    if not old or date_value > old:
        target[sku] = date_value


def _new_report():
    return {
        'source_file': '',
        'source_files': [],
        'file_count': 0,
        'sheets': {},
        'files': [],
        'inbound_rows': 0,
        'outbound_rows': 0,
        'updated_products': 0,
        'updated_inventory_rows': 0,
        'skipped': 0,
        'errors': [],
    }


def _record_sheet_report(report, file_report, sheet_key, sheet_name, sheet_report):
    report['sheets'][sheet_key] = sheet_report
    file_report['sheets'][sheet_name] = sheet_report


def _import_movement_sheet(d, ws, sheet_name, saved_filename, is_inbound, report, file_report, inbound_latest, outbound_latest):
    sheet_key = f"{saved_filename} / {sheet_name}"
    header_row, col_map = find_header_row(ws, SPECYFIKACJA_REQUIRED_HEADERS, aliases=SPECYFIKACJA_ALIASES)
    sheet_report = {'header_row': header_row, 'type': 'inbound' if is_inbound else 'outbound', 'rows': 0, 'skipped': 0}
    if not header_row:
        sheet_report['error'] = '未找到 DATA RUCHU / SKU / ID_OPERACJI / ILOŚĆ / UoM 表头'
        msg = f"{saved_filename} / {sheet_name} 未找到必要表头"
        report['errors'].append(msg)
        file_report['errors'].append(msg)
        _record_sheet_report(report, file_report, sheet_key, sheet_name, sheet_report)
        return

    for row_idx in range(header_row + 1, ws.max_row + 1):
        sku = clean_code(get_cell(ws, row_idx, col_map, 'SKU'))
        move_date = parse_date_text(get_cell(ws, row_idx, col_map, 'DATA RUCHU'))
        operation_id = clean_text(get_cell(ws, row_idx, col_map, 'ID_OPERACJI'))
        qty = to_float(get_cell(ws, row_idx, col_map, 'ILOŚĆ'), 0)
        uom = clean_text(get_cell(ws, row_idx, col_map, 'UoM'))
        if not sku or is_summary_row_value(sku) or not move_date:
            sheet_report['skipped'] += 1
            file_report['skipped'] += 1
            report['skipped'] += 1
            continue

        sheet_report['rows'] += 1
        op_prefix, op_target, order_date = parse_operation_id(operation_id)
        d.execute("""INSERT INTO inventory_movements
                        (movement_type, sheet_name, product_number, movement_date, operation_id,
                         operation_prefix, operation_target, order_date, quantity, uom, source_file)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  ('inbound' if is_inbound else 'outbound', sheet_name, sku, move_date, operation_id,
                   op_prefix, op_target, order_date or None, qty, uom, saved_filename))
        if is_inbound:
            _latest_set(inbound_latest, sku, move_date)
            file_report['inbound_rows'] += 1
            report['inbound_rows'] += 1
        else:
            _latest_set(outbound_latest, sku, move_date)
            file_report['outbound_rows'] += 1
            report['outbound_rows'] += 1
    _record_sheet_report(report, file_report, sheet_key, sheet_name, sheet_report)


def _import_movement_file(d, file, report, saved_paths, inbound_latest, outbound_latest):
    saved_filename, saved_path = save_uploaded_source_file(file, 'specyfikacja')
    saved_paths.append(saved_path)
    report['source_files'].append(saved_filename)
    wb = openpyxl.load_workbook(saved_path, data_only=True)
    file_report = {'source_file': saved_filename, 'sheets': {}, 'inbound_rows': 0, 'outbound_rows': 0, 'skipped': 0, 'errors': []}
    for sheet_name in wb.sheetnames:
        normalized_sheet = sheet_name.strip().lower()
        sheet_key = f"{saved_filename} / {sheet_name}"
        if normalized_sheet == 'arkusz1':
            _record_sheet_report(report, file_report, sheet_key, sheet_name, {'ignored': True})
            continue
        is_inbound = normalized_sheet == 'inbound'
        is_outbound = normalized_sheet in ('outbound polska', 'outbound europa')
        if not is_inbound and not is_outbound:
            _record_sheet_report(report, file_report, sheet_key, sheet_name, {
                'ignored': True,
                'reason': '非出入库流水 Sheet',
            })
            continue
        _import_movement_sheet(
            d,
            wb[sheet_name],
            sheet_name,
            saved_filename,
            is_inbound,
            report,
            file_report,
            inbound_latest,
            outbound_latest,
        )
    report['files'].append(file_report)


def _refresh_latest_dates(d, report, inbound_latest, outbound_latest):
    all_skus = sorted(set(inbound_latest) | set(outbound_latest))
    for sku in all_skus:
        existing = d.execute(
            "SELECT created_at, last_inbound_date, last_outbound_date FROM product_master WHERE product_number = ?",
            (sku,),
        ).fetchone()
        fallback_inbound = ''
        if existing and not inbound_latest.get(sku) and not existing['last_inbound_date']:
            fallback_inbound = parse_date_text(existing['created_at'])
        inbound = inbound_latest.get(sku) or fallback_inbound
        outbound = outbound_latest.get(sku) or inbound
        product_cur = d.execute("""UPDATE product_master
                                   SET last_inbound_date = COALESCE(NULLIF(?, ''), last_inbound_date),
                                       last_outbound_date = COALESCE(NULLIF(?, ''), last_outbound_date),
                                       updated_at = CURRENT_TIMESTAMP
                                   WHERE product_number = ?""", (inbound, outbound, sku))
        report['updated_products'] += product_cur.rowcount if product_cur.rowcount and product_cur.rowcount > 0 else 0
        cur = d.execute("""UPDATE warehouse_inventory
                           SET last_inbound_date = COALESCE(NULLIF(?, ''), last_inbound_date),
                               last_outbound_date = COALESCE(NULLIF(?, ''), last_outbound_date),
                               updated_at = CURRENT_TIMESTAMP
                           WHERE product_number = ?""", (inbound, outbound, sku))
        report['updated_inventory_rows'] += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0

    d.execute("""
        UPDATE product_master
        SET last_outbound_date = last_inbound_date,
            updated_at = CURRENT_TIMESTAMP
        WHERE (last_outbound_date IS NULL OR TRIM(last_outbound_date) = '')
          AND last_inbound_date IS NOT NULL
          AND TRIM(last_inbound_date) != ''
    """)
    d.execute("""
        UPDATE warehouse_inventory
        SET last_outbound_date = last_inbound_date,
            updated_at = CURRENT_TIMESTAMP
        WHERE (last_outbound_date IS NULL OR TRIM(last_outbound_date) = '')
          AND last_inbound_date IS NOT NULL
          AND TRIM(last_inbound_date) != ''
    """)


def import_specyfikacja_files(files, wms_database_path):
    _validate_specyfikacja_files(files)

    db_module.backup_sqlite_db(wms_database_path, 'specyfikacja_import')
    d = get_db()
    inbound_latest = {}
    outbound_latest = {}
    report = _new_report()
    saved_paths = []

    for file in files:
        try:
            _import_movement_file(d, file, report, saved_paths, inbound_latest, outbound_latest)
        except Exception as exc:
            report['errors'].append(f"{file.filename}: {str(exc)}")
            report['files'].append({'source_file': file.filename, 'error': str(exc)})
            if len(files) == 1:
                d.rollback()
                raise InventoryImportError(f'Specyfikacja 导入失败：{str(exc)}', 500)
            continue

    _refresh_latest_dates(d, report, inbound_latest, outbound_latest)
    d.commit()
    report['file_count'] = len(report['source_files'])
    report['source_file'] = '；'.join(report['source_files'])
    for saved_path in saved_paths:
        remove_uploaded_source_file(saved_path)
    return report
