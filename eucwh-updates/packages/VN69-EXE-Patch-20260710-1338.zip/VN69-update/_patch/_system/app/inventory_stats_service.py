"""Read-only inventory statistics service."""

from __future__ import annotations

from .inventory_service import LOCAL_WI_BOM_SQL, get_db


def get_scrap_stats(warehouse: str = '') -> dict:
    d = get_db()
    where_clauses = ["t.change_type = 'scrap'"]
    params = []
    if warehouse:
        where_clauses.append("t.warehouse = ?")
        params.append(warehouse)
    where = "WHERE " + " AND ".join(where_clauses)

    total_records = d.execute(f"SELECT COUNT(*) FROM inventory_transactions t {where}", params).fetchone()[0]
    total_qty = d.execute(f"SELECT COALESCE(SUM(ABS(t.quantity_change)), 0) FROM inventory_transactions t {where}", params).fetchone()[0]
    total_value = d.execute(f"""
        SELECT COALESCE(SUM(ABS(t.quantity_change) * sm.unit_price), 0)
        FROM inventory_transactions t
        LEFT JOIN sku_master sm ON t.bom_code = sm.bom_code
        {where}
    """, params).fetchone()[0]

    by_cat = d.execute(f"""
        SELECT sm.category, COUNT(*) AS cnt, SUM(ABS(t.quantity_change)) AS total_qty,
               COALESCE(SUM(ABS(t.quantity_change) * sm.unit_price), 0) AS total_value
        FROM inventory_transactions t
        LEFT JOIN sku_master sm ON t.bom_code = sm.bom_code
        {where}
        GROUP BY sm.category ORDER BY total_value DESC
    """, params).fetchall()

    by_month = d.execute(f"""
        SELECT strftime('%Y-%m', t.created_at) AS month, COUNT(*) AS cnt,
               SUM(ABS(t.quantity_change)) AS total_qty,
               COALESCE(SUM(ABS(t.quantity_change) * sm.unit_price), 0) AS total_value
        FROM inventory_transactions t
        LEFT JOIN sku_master sm ON t.bom_code = sm.bom_code
        {where}
        GROUP BY month ORDER BY month DESC LIMIT 12
    """, params).fetchall()

    return {
        'total_records': total_records,
        'total_qty': total_qty,
        'total_value': round(total_value, 2) if total_value else 0,
        'by_category': [dict(r) for r in by_cat],
        'by_month': [dict(r) for r in by_month],
    }


def get_inventory_stats(warehouse: str = '') -> dict:
    d = get_db()
    if warehouse:
        base_where = "WHERE warehouse = ?"
        params = [warehouse]
    else:
        base_where = ""
        params = []

    total_skus = d.execute(f"SELECT COUNT(*) FROM warehouse_inventory {base_where}", params).fetchone()[0]
    total_pcs = d.execute(f"SELECT COALESCE(SUM(inventory), 0) FROM warehouse_inventory {base_where}", params).fetchone()[0]
    total_value = d.execute(f"""
        SELECT COALESCE(SUM(wi.inventory * pm.unit_price), 0)
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        {base_where.replace('warehouse_inventory', 'wi')}
    """, params).fetchone()[0]
    missing_image_skus = d.execute(f"""
        SELECT COUNT(DISTINCT wi.product_number)
        FROM warehouse_inventory wi
        LEFT JOIN sku_master simg ON wi.bom_code = simg.bom_code AND NOT {LOCAL_WI_BOM_SQL}
        LEFT JOIN sku_master pimg ON {LOCAL_WI_BOM_SQL}
                                 AND wi.product_number = pimg.bom_code
        {base_where.replace('warehouse_inventory', 'wi')}
        {'AND' if warehouse else 'WHERE'} COALESCE(pimg.image_path, simg.image_path, '') = ''
    """, params).fetchone()[0]

    stock_where = ["wi.inventory <= 5", "wi.inventory > 0"]
    stock_params = []
    if warehouse:
        stock_where.append("wi.warehouse = ?")
        stock_params.append(warehouse)
    low_stock = d.execute(f"""
        SELECT wi.warehouse, wi.bom_code, wi.product_number, wi.inventory, pm.product_description
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        WHERE {' AND '.join(stock_where)}
        ORDER BY wi.inventory ASC
        LIMIT 20
    """, stock_params).fetchall()

    idle_where = ["wi.last_outbound_date IS NOT NULL", "JULIANDAY('now') - JULIANDAY(wi.last_outbound_date) > 90", "wi.inventory > 0"]
    idle_params = []
    if warehouse:
        idle_where.append("wi.warehouse = ?")
        idle_params.append(warehouse)
    long_idle = d.execute(f"""
        SELECT wi.warehouse, wi.bom_code, wi.product_number, wi.inventory, wi.last_outbound_date, pm.product_description,
               CAST(JULIANDAY('now') - JULIANDAY(wi.last_outbound_date) AS INTEGER) AS idle_days
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        WHERE {' AND '.join(idle_where)}
        ORDER BY idle_days DESC
        LIMIT 20
    """, idle_params).fetchall()

    cat_dist = d.execute(f"""
        SELECT UPPER(TRIM(COALESCE(pm.category, ''))) AS category, COUNT(*) AS cnt, SUM(wi.inventory) AS total_pcs
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        {'WHERE wi.warehouse = ?' if warehouse else ''}
        GROUP BY UPPER(TRIM(COALESCE(pm.category, '')))
        ORDER BY total_pcs DESC
    """, params).fetchall()

    country_dist = d.execute(f"""
        SELECT UPPER(TRIM(COALESCE(wi.instruction, ''))) AS country, COUNT(*) AS cnt, SUM(wi.inventory) AS total_pcs
        FROM warehouse_inventory wi
        {'WHERE wi.warehouse = ?' if warehouse else ''}
        GROUP BY UPPER(TRIM(COALESCE(wi.instruction, '')))
        ORDER BY total_pcs DESC
    """, params).fetchall()

    return {
        'total_skus': total_skus,
        'total_pcs': total_pcs,
        'total_value': round(total_value, 2) if total_value else 0,
        'missing_image_skus': missing_image_skus or 0,
        'low_stock': [dict(r) for r in low_stock],
        'long_idle': [dict(r) for r in long_idle],
        'category_dist': [dict(r) for r in cat_dist],
        'country_dist': [dict(r) for r in country_dist],
    }


def get_dimension_ttl_stats(dimension: str, warehouse: str = '') -> list[dict]:
    d = get_db()
    where = "WHERE wi.warehouse = ?" if warehouse else ""
    params = [warehouse] if warehouse else []
    dimension_sql = {
        'category': "UPPER(TRIM(COALESCE(pm.category, '')))",
        'category_2': "UPPER(TRIM(COALESCE(pm.category_2, '')))",
        'instruction': "UPPER(TRIM(COALESCE(wi.instruction, '')))",
    }[dimension]
    rows = d.execute(f"""
        SELECT {dimension_sql} AS {dimension},
               COUNT(DISTINCT wi.product_number) AS sku_count,
               SUM(wi.inventory) AS total_pcs,
               COALESCE(SUM(wi.inventory * pm.unit_price), 0) AS ttl_amount
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        {where}
        GROUP BY {dimension_sql}
        ORDER BY ttl_amount DESC
    """, params).fetchall()
    return [dict(r) for r in rows]


def get_value_pcs_matrix_stats(warehouse: str = '') -> list[dict]:
    d = get_db()
    where = "WHERE wi.warehouse = ?" if warehouse else ""
    params = [warehouse] if warehouse else []
    rows = d.execute(f"""
        SELECT UPPER(TRIM(COALESCE(pm.category, 'UNCATEGORIZED'))) AS category,
               UPPER(TRIM(COALESCE(pm.category_2, 'UNSPECIFIED'))) AS category_2,
               UPPER(TRIM(COALESCE(wi.instruction, 'UNSPECIFIED'))) AS instruction,
               COUNT(DISTINCT wi.product_number) AS sku_count,
               COALESCE(SUM(wi.inventory), 0) AS total_pcs,
               COALESCE(SUM(wi.inventory * pm.unit_price), 0) AS ttl_amount,
               CASE
                   WHEN COALESCE(SUM(wi.inventory), 0) > 0
                   THEN COALESCE(SUM(wi.inventory * pm.unit_price), 0) / SUM(wi.inventory)
                   ELSE 0
               END AS avg_unit_value
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        {where}
        GROUP BY UPPER(TRIM(COALESCE(pm.category, 'UNCATEGORIZED'))),
                 UPPER(TRIM(COALESCE(pm.category_2, 'UNSPECIFIED'))),
                 UPPER(TRIM(COALESCE(wi.instruction, 'UNSPECIFIED')))
        ORDER BY ttl_amount DESC, total_pcs DESC
    """, params).fetchall()
    return [dict(r) for r in rows]


def inventory_aggregate(where_clauses: list[str], params: list) -> dict:
    d = get_db()
    where = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    row = d.execute(f"""
        SELECT COUNT(DISTINCT wi.product_number) AS sku_count,
               COALESCE(SUM(wi.inventory), 0) AS total_pcs,
               COALESCE(SUM(wi.inventory * pm.unit_price), 0) AS ttl_amount
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        {where}
    """, params).fetchone()
    return {
        'sku_count': row['sku_count'] or 0,
        'total_pcs': row['total_pcs'] or 0,
        'ttl_amount': round(row['ttl_amount'] or 0, 2),
    }


def get_overdue_inventory_rows(kind: str, warehouse: str = '') -> list[dict]:
    d = get_db()
    is_idle = kind == 'idle'
    date_col = 'wi.last_outbound_date' if is_idle else 'wi.last_inbound_date'
    days_alias = 'idle_days' if is_idle else 'dos'
    threshold_expr = 'COALESCE(pm.idle_threshold, 180)' if is_idle else 'COALESCE(pm.dos_threshold, 180)'
    where_clauses = [
        "wi.inventory > 0",
        f"{date_col} IS NOT NULL",
        f"JULIANDAY('now') - JULIANDAY({date_col}) >= {threshold_expr}",
    ]
    params = []
    if warehouse:
        where_clauses.append("wi.warehouse = ?")
        params.append(warehouse)
    where = "WHERE " + " AND ".join(where_clauses)
    rows = d.execute(f"""
        SELECT wi.warehouse, wi.bom_code, wi.product_number, wi.inventory,
               wi.last_inbound_date, wi.last_outbound_date,
               pm.product_description,
               COALESCE(pimg.image_path, simg.image_path) AS image_path,
               UPPER(TRIM(COALESCE(pm.category, ''))) AS category,
               UPPER(TRIM(COALESCE(pm.category_2, ''))) AS category_2,
               UPPER(TRIM(COALESCE(wi.instruction, ''))) AS instruction,
               COALESCE(pm.unit_price, 0) AS unit_price,
               COALESCE(pm.unit_price, 0) * wi.inventory AS ttl_amount,
               COALESCE(pm.dos_threshold, 180) AS dos_threshold,
               COALESCE(pm.idle_threshold, 180) AS idle_threshold,
               CAST(JULIANDAY('now') - JULIANDAY({date_col}) AS INTEGER) AS {days_alias},
               CAST(JULIANDAY('now') - JULIANDAY({date_col}) - {threshold_expr} AS INTEGER) AS overdue_days
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        LEFT JOIN sku_master simg ON wi.bom_code = simg.bom_code AND NOT {LOCAL_WI_BOM_SQL}
        LEFT JOIN sku_master pimg ON {LOCAL_WI_BOM_SQL}
                                 AND wi.product_number = pimg.bom_code
        {where}
        ORDER BY overdue_days DESC, ttl_amount DESC
    """, params).fetchall()
    return [dict(r) for r in rows]


def _summarize_overdue_by_category(rows: list[dict]) -> list[dict]:
    grouped = {}
    for row in rows:
        key = row.get('category') or 'UNSPECIFIED'
        current = grouped.setdefault(
            key,
            {'category': key, 'sku_count': 0, 'total_pcs': 0, 'ttl_amount': 0, 'max_overdue_days': 0},
        )
        current['sku_count'] += 1
        current['total_pcs'] += row.get('inventory') or 0
        current['ttl_amount'] += row.get('ttl_amount') or 0
        current['max_overdue_days'] = max(current['max_overdue_days'], row.get('overdue_days') or 0)
    return sorted(
        [{**value, 'ttl_amount': round(value['ttl_amount'], 2)} for value in grouped.values()],
        key=lambda item: item['ttl_amount'],
        reverse=True,
    )[:8]


def get_inventory_health_stats(warehouse: str = '') -> dict:
    d = get_db()
    base = ["wi.inventory > 0"]
    params = []
    if warehouse:
        base.append("wi.warehouse = ?")
        params.append(warehouse)

    total = inventory_aggregate(base, params)
    dos_rows = get_overdue_inventory_rows('dos', warehouse)
    idle_rows = get_overdue_inventory_rows('idle', warehouse)
    dos_total = {
        'sku_count': len(dos_rows),
        'total_pcs': sum(row.get('inventory') or 0 for row in dos_rows),
        'ttl_amount': round(sum(row.get('ttl_amount') or 0 for row in dos_rows), 2),
        'avg_overdue_days': round(sum(row.get('overdue_days') or 0 for row in dos_rows) / len(dos_rows), 1) if dos_rows else 0,
    }
    idle_total = {
        'sku_count': len(idle_rows),
        'total_pcs': sum(row.get('inventory') or 0 for row in idle_rows),
        'ttl_amount': round(sum(row.get('ttl_amount') or 0 for row in idle_rows), 2),
        'avg_overdue_days': round(sum(row.get('overdue_days') or 0 for row in idle_rows) / len(idle_rows), 1) if idle_rows else 0,
    }

    never_outbound = inventory_aggregate(base + ["wi.last_outbound_date IS NULL"], params)
    missing_price = inventory_aggregate(base + ["COALESCE(pm.unit_price, 0) <= 0"], params)
    missing_inbound = inventory_aggregate(base + ["wi.last_inbound_date IS NULL"], params)
    missing_image_where = "WHERE " + " AND ".join(base + ["COALESCE(pimg.image_path, simg.image_path, '') = ''"])
    missing_image = dict(d.execute(f"""
        SELECT COUNT(DISTINCT wi.product_number) AS sku_count,
               COALESCE(SUM(wi.inventory), 0) AS total_pcs,
               COALESCE(SUM(wi.inventory * pm.unit_price), 0) AS ttl_amount
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        LEFT JOIN sku_master simg ON wi.bom_code = simg.bom_code AND NOT {LOCAL_WI_BOM_SQL}
        LEFT JOIN sku_master pimg ON {LOCAL_WI_BOM_SQL}
                                 AND wi.product_number = pimg.bom_code
        {missing_image_where}
    """, params).fetchone())
    missing_image['ttl_amount'] = round(missing_image.get('ttl_amount') or 0, 2)

    return {
        'total': total,
        'dos': dos_total,
        'idle': idle_total,
        'never_outbound': never_outbound,
        'data_quality': {
            'missing_price': missing_price,
            'missing_image': missing_image,
            'missing_inbound': missing_inbound,
        },
        'top_dos': sorted(dos_rows, key=lambda row: (row.get('ttl_amount') or 0, row.get('overdue_days') or 0), reverse=True)[:8],
        'top_idle': sorted(idle_rows, key=lambda row: (row.get('ttl_amount') or 0, row.get('overdue_days') or 0), reverse=True)[:8],
        'dos_by_category': _summarize_overdue_by_category(dos_rows),
        'idle_by_category': _summarize_overdue_by_category(idle_rows),
    }
