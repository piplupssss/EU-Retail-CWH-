from flask import Blueprint, current_app

from . import db as db_module

main_bp = Blueprint('main', __name__)


@main_bp.teardown_request
def close_db(e=None):
    db_module.close_db(e)


@main_bp.route('/')
def index():
    return current_app.send_static_file('index.html')
