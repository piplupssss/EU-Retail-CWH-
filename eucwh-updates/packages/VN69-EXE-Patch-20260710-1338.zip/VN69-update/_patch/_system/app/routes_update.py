import os
import subprocess

from flask import Blueprint, jsonify

from .update_service import (
    APP_VERSION,
    APP_BUILD_TIME,
    download_update_zip,
    fetch_update_manifest,
    safe_extract_update_zip,
    version_number,
)
from .release_config import UPDATE_CHANNEL_LABEL, UPDATE_SECURITY_NOTE, UPDATE_SOURCE_LABEL

update_bp = Blueprint('update', __name__)


@update_bp.route('/api/update/check')
def api_update_check():
    try:
        manifest = fetch_update_manifest()
        latest = manifest['latest_version'].upper()
        current = APP_VERSION.upper()
        latest_num = version_number(latest)
        current_num = version_number(current)
        current_ahead = current_num > latest_num
        update_available = latest_num > current_num
        return jsonify({
            'success': True,
            'current_version': current,
            'current_time': APP_BUILD_TIME,
            'latest_version': latest,
            'release_time': manifest.get('release_time') or manifest.get('time') or '',
            'update_available': update_available,
            'current_ahead_of_patch_channel': current_ahead,
            'channel_label': UPDATE_CHANNEL_LABEL,
            'update_source_label': UPDATE_SOURCE_LABEL,
            'status_message': '当前版本高于补丁通道版本，无需降级。' if current_ahead else ('发现新版本。' if update_available else '当前已是最新版本。'),
            'sha256': manifest.get('sha256'),
            'package_url': manifest.get('package_url'),
            'notes': manifest.get('notes') or [],
            'download_only': True,
            'security': UPDATE_SECURITY_NOTE
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e), 'current_version': APP_VERSION}), 500


@update_bp.route('/api/update/install', methods=['POST'])
def api_update_install():
    try:
        manifest = fetch_update_manifest()
        latest = manifest['latest_version'].upper()
        if version_number(latest) <= version_number(APP_VERSION):
            return jsonify({'success': False, 'error': '当前已是最新版本', 'current_version': APP_VERSION, 'latest_version': latest}), 400
        zip_path, size, digest = download_update_zip(manifest['package_url'], manifest['sha256'], latest)
        extracted = safe_extract_update_zip(zip_path)
        candidates = [n for n in os.listdir(extracted) if n.lower().startswith('upgrade_to_') and n.lower().endswith('.exe')]
        if not candidates:
            raise RuntimeError('更新包缺少升级器 exe')
        updater = os.path.join(extracted, sorted(candidates)[0])
        if os.name != 'nt':
            return jsonify({
                'success': True,
                'downloaded': True,
                'installed': False,
                'message': '更新包已下载并校验；当前不是 Windows 环境，未启动 EXE 升级器。',
                'zip_path': zip_path,
                'extracted': extracted,
                'sha256': digest,
                'size': size
            })
        creationflags = getattr(subprocess, 'DETACHED_PROCESS', 0) | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
        subprocess.Popen([updater], cwd=extracted, close_fds=True, creationflags=creationflags)
        return jsonify({
            'success': True,
            'downloaded': True,
            'installed': True,
            'latest_version': latest,
            'sha256': digest,
            'size': size,
            'message': '更新器已启动。系统会关闭当前服务并完成升级。'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e), 'current_version': APP_VERSION}), 500
