import sqlite3

from flask import Blueprint, jsonify, request

from .inventory_service import (
    LOCAL_WI_BOM_SQL,
    clean_code,
    get_db,
    is_local_bom_code,
    normalize_dimension,
    resolve_product_identity,
    split_filter_values,
    to_float,
    to_int,
)


inventory_core_bp = Blueprint('inventory_core', __name__)


@inventory_core_bp.route('/api/skus', methods=['GET'])
def get_skus():
    d = get_db()
    keyword = request.args.get('q', '').strip()
    category = request.args.get('category', '')
    category2 = request.args.get('category2', '')
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 50))

    where_clauses = []
    params = []
    if keyword:
        where_clauses.append("(pm.bom_code LIKE ? OR pm.product_number LIKE ? OR pm.product_description LIKE ?)")
        params.extend([f'%{keyword}%'] * 3)
    if category:
        where_clauses.append("UPPER(TRIM(COALESCE(pm.category, ''))) = UPPER(TRIM(?))")
        params.append(category)
    category2_values = split_filter_values(category2)
    if category2_values:
        placeholders = ','.join(['?'] * len(category2_values))
        where_clauses.append(f"UPPER(TRIM(COALESCE(pm.category_2, ''))) IN ({placeholders})")
        params.extend(category2_values)

    where = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    offset = (page - 1) * per_page

    total = d.execute(f"SELECT COUNT(*) FROM product_master pm {where}", params).fetchone()[0]
    rows = d.execute(f"""
        SELECT pm.*, simg.image_path
        FROM product_master pm
        LEFT JOIN sku_master simg ON pm.bom_code = simg.bom_code
        {where}
        ORDER BY pm.updated_at DESC LIMIT ? OFFSET ?
    """,
                     params + [per_page, offset]).fetchall()
    return jsonify({'data': [dict(r) for r in rows], 'total': total, 'page': page, 'per_page': per_page})


@inventory_core_bp.route('/api/skus', methods=['POST'])
def create_sku():
    d = get_db()
    data = request.get_json()
    try:
        d.execute("""INSERT INTO sku_master (bom_code, product_number, product_description, category, category_2, unit_price)
                     VALUES (?, ?, ?, ?, ?, ?)""",
                  (data['bom_code'], data.get('product_number', ''), data.get('product_description', ''),
                   normalize_dimension(data.get('category', ''), 'category'),
                   normalize_dimension(data.get('category_2', ''), 'category2'), data.get('unit_price', 0)))
        d.commit()
        return jsonify({'success': True, 'bom_code': data['bom_code']})
    except sqlite3.IntegrityError:
        return jsonify({'error': f"BOM Code '{data['bom_code']}' already exists"}), 409


def update_sku_master_by_bom(d, bom_code, data):
    fields = []
    params = []
    for key in ['product_number', 'product_description', 'category', 'category_2', 'unit_price', 'image_path']:
        if key in data:
            fields.append(f"{key} = ?")
            if key == 'category':
                params.append(normalize_dimension(data[key], 'category'))
            elif key == 'category_2':
                params.append(normalize_dimension(data[key], 'category2'))
            else:
                params.append(data[key])
    if fields:
        fields.append("updated_at = CURRENT_TIMESTAMP")
        params.append(bom_code)
        d.execute(f"UPDATE sku_master SET {', '.join(fields)} WHERE bom_code = ?", params)
    return bool(fields)


@inventory_core_bp.route('/api/skus/<bom_code>', methods=['PUT'])
def update_sku(bom_code):
    d = get_db()
    data = request.get_json()
    if not update_sku_master_by_bom(d, bom_code, data):
        return jsonify({'error': 'No fields to update'}), 400
    d.commit()
    return jsonify({'success': True})


@inventory_core_bp.route('/api/inventory/product/<path:product_number>/maintenance', methods=['PUT'])
def update_product_maintenance(product_number):
    d = get_db()
    data = request.get_json() or {}
    product_number = clean_code(product_number)
    if not product_number:
        return jsonify({'error': 'Product Number 不能为空'}), 400
    product = d.execute("SELECT * FROM product_master WHERE product_number = ?", (product_number,)).fetchone()
    if not product:
        return jsonify({'error': 'Product Number 不存在'}), 404

    fields = []
    params = []
    for key in ['bom_code', 'product_description', 'category', 'category_2', 'unit_price',
                'last_inbound_date', 'last_outbound_date', 'remark', 'dos_threshold', 'idle_threshold']:
        if key in data:
            fields.append(f"{key} = ?")
            if key == 'category':
                params.append(normalize_dimension(data[key], 'category'))
            elif key == 'category_2':
                params.append(normalize_dimension(data[key], 'category2'))
            elif key in ('dos_threshold', 'idle_threshold'):
                params.append(to_int(data[key], 180))
            else:
                params.append(data[key])
    if not fields:
        return jsonify({'error': 'No fields to update'}), 400
    fields.append("updated_at = CURRENT_TIMESTAMP")
    params.append(product_number)
    d.execute(f"UPDATE product_master SET {', '.join(fields)} WHERE product_number = ?", params)

    bom_code = clean_code(data.get('bom_code') or product['bom_code'] or '')
    if bom_code and not is_local_bom_code(bom_code):
        d.execute("""INSERT INTO sku_master (bom_code, product_number, product_description, category, category_2, unit_price, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(bom_code) DO UPDATE SET
                        product_number=excluded.product_number,
                        product_description=excluded.product_description,
                        category=excluded.category,
                        category_2=excluded.category_2,
                        unit_price=excluded.unit_price,
                        updated_at=CURRENT_TIMESTAMP""",
                  (bom_code, product_number, data.get('product_description', product['product_description'] or ''),
                   normalize_dimension(data.get('category', product['category'] or ''), 'category'),
                   normalize_dimension(data.get('category_2', product['category_2'] or ''), 'category2'),
                   to_float(data.get('unit_price', product['unit_price'] or 0))))
        d.execute("""UPDATE warehouse_inventory
                     SET bom_code = ?,
                         last_inbound_date = COALESCE(NULLIF(?, ''), last_inbound_date),
                         last_outbound_date = COALESCE(NULLIF(?, ''), last_outbound_date),
                         comment = COALESCE(NULLIF(?, ''), comment),
                         updated_at = CURRENT_TIMESTAMP
                     WHERE product_number = ?""",
                  (bom_code, data.get('last_inbound_date', ''), data.get('last_outbound_date', ''),
                   data.get('remark', ''), product_number))
    d.commit()
    return jsonify({'success': True})


@inventory_core_bp.route('/api/skus/<bom_code>', methods=['DELETE'])
def delete_sku(bom_code):
    d = get_db()
    inv = d.execute("SELECT COUNT(*) FROM warehouse_inventory WHERE bom_code = ?", (bom_code,)).fetchone()[0]
    if inv > 0:
        return jsonify({'error': 'Cannot delete: inventory records exist for this SKU'}), 409
    items = d.execute("SELECT COUNT(*) FROM delivery_order_items WHERE bom_code = ?", (bom_code,)).fetchone()[0]
    if items > 0:
        return jsonify({'error': 'Cannot delete: delivery order items reference this SKU'}), 409
    d.execute("DELETE FROM sku_master WHERE bom_code = ?", (bom_code,))
    d.commit()
    return jsonify({'success': True})


@inventory_core_bp.route('/api/inventory', methods=['GET'])
def get_inventory():
    d = get_db()
    warehouse = request.args.get('warehouse')
    if warehouse is None:
        warehouse = 'Lodz warehouse'
    warehouse = warehouse.strip()
    keyword = request.args.get('q', '').strip()
    category = request.args.get('category', '')
    category2 = request.args.get('category2', '')
    instruction = request.args.get('instruction', '')
    quality = request.args.get('quality', '').strip().lower()
    sort_by = request.args.get('sort_by', 'updated_at')
    sort_dir = 'ASC' if request.args.get('sort_dir', 'desc').lower() == 'asc' else 'DESC'
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 100))

    where_clauses = []
    params = []
    if warehouse:
        where_clauses.append("wi.warehouse = ?")
        params.append(warehouse)
    if keyword:
        where_clauses.append("(wi.bom_code LIKE ? OR wi.product_number LIKE ? OR pm.product_description LIKE ?)")
        params.extend([f'%{keyword}%'] * 3)
    category_values = split_filter_values(category)
    if category_values:
        placeholders = ','.join(['?'] * len(category_values))
        where_clauses.append(f"UPPER(TRIM(COALESCE(pm.category, ''))) IN ({placeholders})")
        params.extend(category_values)
    category2_values = split_filter_values(category2)
    if category2_values:
        placeholders = ','.join(['?'] * len(category2_values))
        where_clauses.append(f"UPPER(TRIM(COALESCE(pm.category_2, ''))) IN ({placeholders})")
        params.extend(category2_values)
    instruction_values = split_filter_values(instruction)
    if instruction_values:
        placeholders = ','.join(['?'] * len(instruction_values))
        where_clauses.append(f"UPPER(TRIM(COALESCE(wi.instruction, ''))) IN ({placeholders})")
        params.extend(instruction_values)
    if quality == 'missing_price':
        where_clauses.append("wi.inventory > 0")
        where_clauses.append("COALESCE(pm.unit_price, 0) <= 0")
    elif quality == 'missing_image':
        where_clauses.append("wi.inventory > 0")
        where_clauses.append("COALESCE(pimg.image_path, simg.image_path, '') = ''")
    elif quality == 'missing_inbound':
        where_clauses.append("wi.inventory > 0")
        where_clauses.append("COALESCE(wi.last_inbound_date, '') = ''")

    where = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
    offset = (page - 1) * per_page
    inventory_from = f"""
        FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        LEFT JOIN sku_master simg ON wi.bom_code = simg.bom_code AND NOT {LOCAL_WI_BOM_SQL}
        LEFT JOIN sku_master pimg ON {LOCAL_WI_BOM_SQL}
                                 AND wi.product_number = pimg.bom_code
    """
    sort_columns = {
        'bom_code': 'wi.bom_code',
        'product_number': 'wi.product_number',
        'product_description': 'pm.product_description',
        'category': 'UPPER(TRIM(COALESCE(pm.category, "")))',
        'category_2': 'UPPER(TRIM(COALESCE(pm.category_2, "")))',
        'instruction': 'UPPER(TRIM(COALESCE(wi.instruction, "")))',
        'inventory': 'wi.inventory',
        'unit_price': 'pm.unit_price',
        'ttl_amount': 'ttl_amount',
        'last_inbound_date': 'wi.last_inbound_date',
        'last_outbound_date': 'wi.last_outbound_date',
        'dos': 'dos',
        'days_without_stock': 'days_without_stock',
        'updated_at': 'wi.updated_at'
    }
    order_expr = sort_columns.get(sort_by, 'wi.updated_at')

    total = d.execute(f"""
        SELECT COUNT(*) FROM warehouse_inventory wi
        LEFT JOIN product_master pm ON wi.product_number = pm.product_number
        LEFT JOIN sku_master simg ON wi.bom_code = simg.bom_code AND NOT {LOCAL_WI_BOM_SQL}
        LEFT JOIN sku_master pimg ON {LOCAL_WI_BOM_SQL}
                                 AND wi.product_number = pimg.bom_code
        {where}
    """, params).fetchone()[0]
    last_updated_row = d.execute(f"""
        SELECT MAX(wi.updated_at) AS last_updated_at
        {inventory_from}
        {where}
    """, params).fetchone()

    rows = d.execute(f"""
        SELECT wi.id, wi.warehouse, wi.bom_code,
               wi.product_number AS product_number,
               wi.inventory, wi.last_inbound_date, wi.last_outbound_date, wi.comment, wi.updated_at,
               pm.product_description,
               UPPER(TRIM(COALESCE(pm.category, ''))) AS category,
               UPPER(TRIM(COALESCE(pm.category_2, ''))) AS category_2,
               UPPER(TRIM(COALESCE(wi.instruction, ''))) AS instruction,
               pm.unit_price, COALESCE(pimg.image_path, simg.image_path) AS image_path,
               pm.unit_price * wi.inventory AS ttl_amount,
               CAST(JULIANDAY('now') - JULIANDAY(wi.last_inbound_date) AS INTEGER) AS dos,
               CAST(JULIANDAY('now') - JULIANDAY(wi.last_outbound_date) AS INTEGER) AS days_without_stock
        {inventory_from}
        {where}
        ORDER BY {order_expr} {sort_dir}, wi.updated_at DESC
        LIMIT ? OFFSET ?
    """, params + [per_page, offset]).fetchall()

    return jsonify({
        'data': [dict(r) for r in rows], 'total': total,
        'page': page, 'per_page': per_page, 'warehouse': warehouse,
        'last_updated_at': last_updated_row['last_updated_at'] if last_updated_row else ''
    })


@inventory_core_bp.route('/api/inventory/<int:inv_id>', methods=['PUT'])
def update_inventory(inv_id):
    d = get_db()
    data = request.get_json()
    fields = []
    params = []
    for key in ['instruction', 'inventory', 'last_inbound_date', 'last_outbound_date', 'comment']:
        if key in data:
            fields.append(f"{key} = ?")
            params.append(data[key])
    if not fields:
        return jsonify({'error': 'No fields to update'}), 400
    fields.append("updated_at = CURRENT_TIMESTAMP")
    params.append(inv_id)
    d.execute(f"UPDATE warehouse_inventory SET {', '.join(fields)} WHERE id = ?", params)
    d.commit()
    return jsonify({'success': True})


@inventory_core_bp.route('/api/inventory/bulk', methods=['POST'])
def bulk_inventory():
    d = get_db()
    data = request.get_json()
    warehouse = data.get('warehouse', '')
    items = data.get('items', [])
    count = 0
    for item in items:
        product_number, bom_code = resolve_product_identity(d, item.get('product_number', ''), item.get('bom_code', ''))
        if not product_number:
            continue
        d.execute("""INSERT INTO warehouse_inventory (warehouse, bom_code, product_number, instruction, inventory, last_inbound_date, comment)
                     VALUES (?, ?, ?, ?, ?, ?, ?)
                     ON CONFLICT(warehouse, product_number) DO UPDATE SET
                     bom_code = excluded.bom_code,
                     instruction = COALESCE(excluded.instruction, instruction),
                     inventory = COALESCE(excluded.inventory, inventory),
                     last_inbound_date = COALESCE(excluded.last_inbound_date, last_inbound_date),
                     comment = COALESCE(excluded.comment, comment),
                     updated_at = CURRENT_TIMESTAMP""",
                  (warehouse, bom_code, product_number, item.get('instruction', ''),
                   item.get('inventory', 0), item.get('last_inbound_date', ''),
                   item.get('comment', '')))
        count += 1
    d.commit()
    return jsonify({'success': True, 'count': count})
