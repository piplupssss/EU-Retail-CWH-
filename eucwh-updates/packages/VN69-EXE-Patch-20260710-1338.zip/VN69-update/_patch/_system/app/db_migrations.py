def table_exists(cursor, table):
    return cursor.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (table,),
    ).fetchone() is not None


def table_columns(cursor, table):
    if not table_exists(cursor, table):
        return []
    return [r[1] for r in cursor.execute(f"PRAGMA table_info({table})").fetchall()]


def ensure_columns(cursor, table, columns, require_existing=False):
    if require_existing and not table_exists(cursor, table):
        return
    existing_cols = table_columns(cursor, table)
    for col_name, col_type in columns:
        if col_name not in existing_cols:
            cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
            existing_cols.append(col_name)
