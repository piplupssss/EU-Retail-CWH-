import re
from datetime import datetime

from flask import Blueprint, jsonify, request

from .logistics_service import calc_display_status, get_db
from .maintenance_service import maintenance_password_ok


shipment_actions_bp = Blueprint('shipment_actions', __name__)


@shipment_actions_bp.route('/api/shipments/mark_delivered', methods=['POST'])
def mark_delivered():
    data = request.get_json()
    booking_id = data.get('booking_id', '').strip()
    delivery_date = data.get('delivery_date', '').strip()
    if not booking_id:
        return jsonify({'error': 'Missing booking_id'}), 400
    db = get_db()
    row = db.execute("SELECT delivery_locked FROM shipments WHERE booking_id = ?", (booking_id,)).fetchone()
    if not row:
        return jsonify({'error': f'运单 {booking_id} 不存在'}), 404
    if row['delivery_locked']:
        return jsonify({'error': f'运单 {booking_id} 已锁定，请先撤销再重新标记'}), 409
    if not delivery_date:
        delivery_date = datetime.now().strftime('%Y-%m-%d')
    db.execute(
        "UPDATE shipments SET actual_delivery_date = ?, delivery_locked = 1 WHERE booking_id = ?",
        (delivery_date, booking_id)
    )
    db.commit()
    return jsonify({'success': True, 'booking_id': booking_id, 'actual_delivery_date': delivery_date})


@shipment_actions_bp.route('/api/shipments/unmark_delivered', methods=['POST'])
def unmark_delivered():
    data = request.get_json()
    booking_id = data.get('booking_id', '').strip()
    if not booking_id:
        return jsonify({'error': 'Missing booking_id'}), 400
    db = get_db()
    row = db.execute("SELECT delivery_locked FROM shipments WHERE booking_id = ?", (booking_id,)).fetchone()
    if not row:
        return jsonify({'error': f'运单 {booking_id} 不存在'}), 404
    if not row['delivery_locked']:
        return jsonify({'error': f'运单 {booking_id} 未锁定，无需撤销'}), 409
    db.execute(
        "UPDATE shipments SET actual_delivery_date = '', delivery_locked = 0 WHERE booking_id = ?",
        (booking_id,)
    )
    db.commit()
    return jsonify({'success': True, 'booking_id': booking_id})


@shipment_actions_bp.route('/api/shipments/mark_abnormal', methods=['POST'])
def mark_abnormal():
    data = request.get_json()
    booking_id = data.get('booking_id', '').strip()
    if not booking_id:
        return jsonify({'error': 'Missing booking_id'}), 400
    db = get_db()
    row = db.execute("SELECT delivery_locked, shipment_status FROM shipments WHERE booking_id = ?", (booking_id,)).fetchone()
    if not row:
        return jsonify({'error': f'运单 {booking_id} 不存在'}), 404
    if row['delivery_locked']:
        return jsonify({'error': f'运单 {booking_id} 已标记已交付，请先撤销'}), 409
    if row['shipment_status'] == 'Canceled':
        return jsonify({'error': '已取消单无需标记异常'}), 409
    db.execute(
        "UPDATE shipments SET manual_status = 'abnormal' WHERE booking_id = ?",
        (booking_id,)
    )
    db.commit()
    return jsonify({'success': True, 'booking_id': booking_id})


@shipment_actions_bp.route('/api/shipments/unmark_abnormal', methods=['POST'])
def unmark_abnormal():
    data = request.get_json()
    booking_id = data.get('booking_id', '').strip()
    if not booking_id:
        return jsonify({'error': 'Missing booking_id'}), 400
    db = get_db()
    db.execute(
        "UPDATE shipments SET manual_status = NULL WHERE booking_id = ?",
        (booking_id,)
    )
    db.commit()
    return jsonify({'success': True, 'booking_id': booking_id})


@shipment_actions_bp.route('/api/shipments/demand_country', methods=['POST'])
def update_shipment_demand_country():
    data = request.get_json(silent=True) or {}
    booking_ids = data.get('booking_ids') or data.get('booking_id') or []
    if isinstance(booking_ids, str):
        booking_ids = [booking_ids]
    booking_ids = list(dict.fromkeys(str(x).strip() for x in booking_ids if str(x).strip()))
    demand_country = (data.get('demand_country') or '').strip().upper()
    password = data.get('password') or ''

    if not maintenance_password_ok(password, allow_admin=True):
        return jsonify({'error': '密码错误'}), 403
    if not booking_ids:
        return jsonify({'error': '请选择需要修改的运单'}), 400
    if not demand_country or not re.fullmatch(r'[A-Z]{2,3}', demand_country):
        return jsonify({'error': '请输入正确的需求国家代码，例如 DE / PL / FR'}), 400

    db = get_db()
    placeholders = ','.join(['?'] * len(booking_ids))
    cursor = db.execute(f"""
        UPDATE shipments
        SET demand_country = ?, demand_country_source = 'manual'
        WHERE booking_id IN ({placeholders})
          AND COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
    """, [demand_country] + booking_ids)
    db.commit()
    return jsonify({'success': True, 'updated': cursor.rowcount, 'demand_country': demand_country})


@shipment_actions_bp.route('/api/shipments/recycle', methods=['POST'])
def recycle_shipments():
    data = request.get_json(silent=True) or {}
    booking_ids = data.get('booking_ids') or []
    if isinstance(booking_ids, str):
        booking_ids = [booking_ids]
    booking_ids = list(dict.fromkeys(str(x).strip() for x in booking_ids if str(x).strip()))
    reason = (data.get('reason') or '').strip()
    password = data.get('password') or ''

    if not maintenance_password_ok(password, allow_admin=True):
        return jsonify({'error': '密码错误'}), 403
    if not booking_ids:
        return jsonify({'error': '请选择需要移入回收站的异常运单'}), 400
    if not reason:
        return jsonify({'error': '请填写移入回收站原因'}), 400

    db = get_db()
    placeholders = ','.join(['?'] * len(booking_ids))
    rows = db.execute(f"""
        SELECT *
        FROM shipments
        WHERE booking_id IN ({placeholders})
          AND COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
    """, booking_ids).fetchall()
    found_ids = {r['booking_id'] for r in rows}
    missing_ids = [bid for bid in booking_ids if bid not in found_ids]
    not_abnormal = [r['booking_id'] for r in rows if calc_display_status(r) != '异常单']
    if missing_ids or not_abnormal:
        return jsonify({
            'error': '只有当前显示为异常单的运单可以移入回收站',
            'missing': missing_ids,
            'not_abnormal': not_abnormal,
        }), 400

    recycled_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor = db.execute(f"""
        UPDATE shipments
        SET recycled_at = ?, recycle_reason = ?, recycle_operator = ?
        WHERE booking_id IN ({placeholders})
          AND recycled_at IS NULL
    """, [recycled_at, reason, 'Qiteng'] + booking_ids)
    db.commit()
    return jsonify({'success': True, 'recycled': cursor.rowcount, 'requested': len(booking_ids), 'recycled_at': recycled_at})


@shipment_actions_bp.route('/api/shipments/recycle_bin')
def shipment_recycle_bin():
    db = get_db()
    search = (request.args.get('search') or '').strip()
    params = []
    where = "recycled_at IS NOT NULL"
    if search:
        where += " AND (booking_id LIKE ? OR stt_number LIKE ? OR recycle_reason LIKE ? OR consignee_country_code LIKE ?)"
        params.extend([f'%{search}%', f'%{search}%', f'%{search}%', f'%{search}%'])
    rows = db.execute(f"""
        SELECT *
        FROM shipments
        WHERE {where}
        ORDER BY recycled_at DESC, pickup_date DESC
        LIMIT 500
    """, params).fetchall()
    items = []
    for r in rows:
        d = dict(r)
        d['display_status'] = calc_display_status(r)
        items.append(d)
    return jsonify({'shipments': items, 'total': len(items)})


@shipment_actions_bp.route('/api/shipments/recycle/restore', methods=['POST'])
def restore_recycled_shipments():
    data = request.get_json(silent=True) or {}
    booking_ids = data.get('booking_ids') or []
    if isinstance(booking_ids, str):
        booking_ids = [booking_ids]
    booking_ids = [str(x).strip() for x in booking_ids if str(x).strip()]
    if not maintenance_password_ok(data.get('password'), allow_admin=True):
        return jsonify({'error': '密码错误'}), 403
    if not booking_ids:
        return jsonify({'error': '请选择需要恢复的运单'}), 400

    db = get_db()
    placeholders = ','.join(['?'] * len(booking_ids))
    cur = db.execute(f"""
        UPDATE shipments
        SET recycled_at = NULL, recycle_reason = NULL, recycle_operator = NULL
        WHERE booking_id IN ({placeholders})
          AND recycled_at IS NOT NULL
    """, booking_ids)
    db.commit()
    return jsonify({'success': True, 'restored': cur.rowcount})
