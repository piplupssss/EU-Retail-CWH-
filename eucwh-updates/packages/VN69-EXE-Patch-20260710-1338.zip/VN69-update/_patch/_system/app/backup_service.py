import os
import re
import sqlite3

from flask import current_app

from . import db as db_module
from .logistics_service import get_db
from .maintenance_service import (
    app_base_dir,
    dir_size_bytes,
    maintenance_password_ok,
    remove_tree_contents,
    source_file_to_disk_name,
    upload_dir_path,
)
from .update_service import APP_VERSION, software_root_dir, version_number


def slim_local_package_result(data):
    if not maintenance_password_ok(data.get('password'), allow_admin=False):
        return {'error': '瘦身密码错误'}, 403

    clear_inventory = bool(data.get('clear_inventory', False))
    clear_images = bool(data.get('clear_images', False))
    clear_non_business_uploads = bool(data.get('clear_non_business_uploads', False))
    clear_logistics_uploads = bool(data.get('clear_logistics_uploads', False))
    clear_invoice_uploads = bool(data.get('clear_invoice_uploads', False))
    clear_cache = bool(data.get('clear_cache', False))
    clear_update_downloads = bool(data.get('clear_update_downloads', False))
    clear_backups = bool(data.get('clear_backups', False))
    base_dir = app_base_dir()
    package_root = software_root_dir()
    size_before = dir_size_bytes(package_root)

    result = {
        'success': True,
        'kept': ['物流数据', '发票/验收数据', '运单手动状态', '异常/回收站记录'],
        'deleted': {},
        'failed': [],
        'backups': [],
        'size_before': size_before,
    }

    if clear_inventory:
        _clear_inventory_records(result)

    if clear_images:
        _clear_image_files(result)

    if clear_non_business_uploads or clear_logistics_uploads or clear_invoice_uploads:
        _clear_upload_files(result, clear_non_business_uploads, clear_logistics_uploads, clear_invoice_uploads)

    if clear_cache:
        _clear_cache_files(result, base_dir)

    if clear_update_downloads:
        _clear_update_downloads(result, package_root)

    if clear_backups:
        _clear_backups_and_old_launchers(result, base_dir, package_root)

    result['size_after'] = dir_size_bytes(package_root)
    result['freed_bytes'] = max(0, result['size_before'] - result['size_after'])
    return result, 200


def _clear_inventory_records(result):
    backup = db_module.backup_sqlite_db(current_app.config['WMS_DATABASE'], 'before_slim_inventory')
    if backup:
        result['backups'].append(backup)
    wms = sqlite3.connect(current_app.config['WMS_DATABASE'])
    try:
        cur = wms.cursor()
        tables = [
            'delivery_order_items',
            'delivery_orders',
            'inventory_transactions',
            'inventory_movements',
            'warehouse_inventory',
            'product_master',
            'sku_master',
        ]
        table_counts = {}
        for table in tables:
            exists = cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            if not exists:
                continue
            count = cur.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            cur.execute(f"DELETE FROM {table}")
            table_counts[table] = count
        wms.commit()
        cur.execute("VACUUM")
        result['deleted']['inventory_records'] = table_counts
    finally:
        wms.close()


def _clear_image_files(result):
    image_folder = current_app.config['UPLOAD_FOLDER']
    deleted_images, failed_images = remove_tree_contents(image_folder)
    wms = sqlite3.connect(current_app.config['WMS_DATABASE'])
    try:
        cur = wms.cursor()
        cur.execute("UPDATE sku_master SET image_path = NULL, updated_at = CURRENT_TIMESTAMP WHERE COALESCE(image_path, '') <> ''")
        result['deleted']['image_mappings'] = cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
        wms.commit()
    finally:
        wms.close()
    result['deleted']['image_files'] = deleted_images
    result['failed'].extend(failed_images)


def _clear_upload_files(result, clear_non_business_uploads, clear_logistics_uploads, clear_invoice_uploads):
    main_db = get_db()
    logistics_files = set()
    for row in main_db.execute("""
        SELECT DISTINCT source_file FROM shipments
        WHERE source_file IS NOT NULL AND TRIM(source_file) != ''
    """).fetchall():
        logistics_files.add(row['source_file'])
        logistics_files.add(source_file_to_disk_name(row['source_file']))
    invoice_files = set()
    for row in main_db.execute("""
        SELECT DISTINCT source_file FROM invoice_headers
        WHERE source_file IS NOT NULL AND TRIM(source_file) != ''
    """).fetchall():
        invoice_files.add(row['source_file'])
        invoice_files.add(source_file_to_disk_name(row['source_file']))

    upload_dir = upload_dir_path()
    deleted_uploads = 0
    kept_uploads = 0
    deleted_logistics = 0
    deleted_invoice = 0
    deleted_other = 0
    failed_uploads = []
    for name in os.listdir(upload_dir):
        path = os.path.abspath(os.path.join(upload_dir, name))
        if not path.startswith(os.path.abspath(upload_dir) + os.sep) or not os.path.isfile(path):
            continue
        is_logistics = name in logistics_files
        is_invoice = name in invoice_files
        should_delete = (
            (is_logistics and clear_logistics_uploads)
            or (is_invoice and clear_invoice_uploads)
            or (not is_logistics and not is_invoice and clear_non_business_uploads)
        )
        if not should_delete:
            kept_uploads += 1
            continue
        try:
            os.remove(path)
            deleted_uploads += 1
            if is_logistics:
                deleted_logistics += 1
            elif is_invoice:
                deleted_invoice += 1
            else:
                deleted_other += 1
        except OSError:
            failed_uploads.append(path)
    result['deleted']['upload_files_total'] = deleted_uploads
    result['deleted']['logistics_upload_files'] = deleted_logistics
    result['deleted']['invoice_upload_files'] = deleted_invoice
    result['deleted']['other_upload_files'] = deleted_other
    result['deleted']['kept_upload_files'] = kept_uploads
    result['failed'].extend(failed_uploads)


def _clear_cache_files(result, base_dir):
    cache_targets = [
        os.path.join(base_dir, 'app', '__pycache__'),
        os.path.join(base_dir, '__pycache__'),
        os.path.join(base_dir, 'app', 'data', 'tmp'),
    ]
    removed = 0
    failed = []
    for target in cache_targets:
        count, bad = remove_tree_contents(target)
        removed += count
        failed.extend(bad)
        try:
            if os.path.isdir(target) and not os.listdir(target):
                os.rmdir(target)
        except OSError:
            pass
    result['deleted']['cache_files'] = removed
    result['failed'].extend(failed)


def _clear_update_downloads(result, package_root):
    update_targets = [
        os.path.join(package_root, '_downloaded_updates'),
        os.path.join(package_root, '_update_staging'),
    ]
    removed = 0
    failed = []
    removed_dirs = 0
    current_version_num = version_number(APP_VERSION)
    for target in update_targets:
        count, bad = remove_tree_contents(target)
        removed += count
        failed.extend(bad)
        try:
            if os.path.isdir(target) and not os.listdir(target):
                os.rmdir(target)
                removed_dirs += 1
        except OSError:
            pass
    for name in os.listdir(package_root):
        lower = name.lower()
        path = os.path.join(package_root, name)
        file_version = version_number(name)
        is_update_extract = (
            os.path.isdir(path)
            and lower.startswith('vn')
            and ('patch' in lower or 'update' in lower)
            and (not file_version or file_version <= current_version_num)
        )
        if not is_update_extract:
            continue
        count, bad = remove_tree_contents(path)
        removed += count
        failed.extend(bad)
        try:
            os.rmdir(path)
            removed_dirs += 1
        except OSError:
            pass
    result['deleted']['downloaded_update_files'] = removed
    result['deleted']['downloaded_update_dirs'] = removed_dirs
    result['failed'].extend(failed)


def _clear_backups_and_old_launchers(result, base_dir, package_root):
    backup_targets = [
        os.path.join(base_dir, 'backups'),
        os.path.join(base_dir, 'app', 'data', 'backups'),
    ]
    removed = 0
    failed = []
    for target in backup_targets:
        count, bad = remove_tree_contents(target)
        removed += count
        failed.extend(bad)
        try:
            if os.path.isdir(target) and not os.listdir(target):
                os.rmdir(target)
        except OSError:
            pass

    old_patch_files = 0
    old_patch_dirs = 0
    current_version_label = APP_VERSION.upper()
    current_version_num = version_number(current_version_label)
    current_keep = {
        'start.bat',
        'rollback_to_previous.bat',
        'stop_system.bat',
        f'EUCWH-{current_version_label}.exe',
        f'start_{current_version_label.lower()}.bat',
        f'debug_start_{current_version_label.lower()}.bat',
        f'launch_hidden_{current_version_label.lower()}.vbs',
        f'PATCH_NOTES_{current_version_label}.txt',
        f'{current_version_label}_GUIDE.txt',
    }
    current_keep_lower = {item.lower() for item in current_keep}
    scan_dirs = [base_dir]
    parent_dir = os.path.dirname(base_dir)
    if os.path.basename(base_dir).lower() == '_system' and parent_dir and parent_dir not in scan_dirs:
        scan_dirs.append(parent_dir)
    if package_root and package_root not in scan_dirs:
        scan_dirs.append(package_root)
    for scan_dir in scan_dirs:
        if not os.path.isdir(scan_dir):
            continue
        for name in os.listdir(scan_dir):
            lower = name.lower()
            path = os.path.join(scan_dir, name)
            file_version = version_number(name)
            is_main_executable = lower.startswith('eucwh-') and lower.endswith('.exe')
            is_current_launcher = is_main_executable or file_version == current_version_num or lower in current_keep_lower
            is_old_version_file = file_version and file_version < current_version_num
            should_delete_file = (
                (
                    (re.fullmatch(r'(start|stop)_vn\d+\.bat', lower) is not None)
                    or (re.fullmatch(r'launch(_vn\d+)?_hidden(_vn\d+)?\.vbs', lower) is not None)
                    or (re.fullmatch(r'patch_notes_vn\d+\.txt', lower) is not None)
                    or (re.fullmatch(r'vn\d+_applied\.txt', lower) is not None)
                    or (re.fullmatch(r'vn\d+_(guide|操作指南)\.txt', lower) is not None)
                    or (re.fullmatch(r'.*vn\d+.*\.exe', lower) is not None)
                    or (re.fullmatch(r'(debug启动|debug_start)_vn\d+\.bat', lower) is not None)
                    or (re.fullmatch(r'upgrade_to_vn\d+\.exe', lower) is not None)
                )
                and is_old_version_file
                and not is_current_launcher
            )
            should_delete_dir = (
                lower.startswith('backup_before_vn')
                or lower in {'_downloaded_updates', '_update_staging'}
                or (lower.startswith('vn') and ('patch' in lower or 'update' in lower))
            )
            if os.path.isfile(path) and should_delete_file:
                try:
                    os.remove(path)
                    old_patch_files += 1
                except OSError:
                    failed.append(path)
            elif os.path.isdir(path) and should_delete_dir:
                count, bad = remove_tree_contents(path)
                removed += count
                failed.extend(bad)
                try:
                    os.rmdir(path)
                    old_patch_dirs += 1
                except OSError:
                    pass
    result['deleted']['backup_files'] = removed
    result['deleted']['old_patch_files'] = old_patch_files
    result['deleted']['old_patch_dirs'] = old_patch_dirs
    result['failed'].extend(failed)
