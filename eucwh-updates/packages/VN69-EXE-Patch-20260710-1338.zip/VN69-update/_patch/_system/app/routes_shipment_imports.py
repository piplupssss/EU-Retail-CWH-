from flask import Blueprint, current_app, jsonify, request

from .shipment_import_service import (
    import_shipments_auto_files,
    import_shipments_file,
    validate_shipment_excel_file,
    validate_shipment_excel_files,
)


shipment_imports_bp = Blueprint('shipment_imports', __name__)


@shipment_imports_bp.route('/api/shipments/import', methods=['POST'])
def import_shipments():
    """导入 Excel 文件，type 参数指定来源：warehouse / pl_domestic / intl_direct"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file_storage = request.files['file']
    error = validate_shipment_excel_file(file_storage)
    if error:
        if error == '请上传物流 Excel 文件':
            return jsonify({'error': 'No file uploaded'}), 400
        if '必须是 Excel 文件' in error:
            return jsonify({'error': 'Only Excel files supported'}), 400
        return jsonify({'error': error}), 400

    upload_type = request.form.get('type', '')
    try:
        result = import_shipments_file(file_storage, upload_type, current_app.config['DATABASE'])
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001 - preserve route-level JSON error behavior
        return jsonify({'error': str(exc)}), 500


@shipment_imports_bp.route('/api/shipments/import-auto', methods=['POST'])
def import_shipments_auto():
    """一口上传多个物流 Excel，并按 Pickup City 自动归为中央仓、家具仓、调拨。"""
    files = [f for f in request.files.getlist('files') if f and f.filename]
    single = request.files.get('file')
    if single and single.filename:
        files.append(single)

    error = validate_shipment_excel_files(files)
    if error:
        return jsonify({'error': error}), 400

    try:
        result = import_shipments_auto_files(files, current_app.config['DATABASE'])
        return jsonify(result)
    except Exception as exc:  # noqa: BLE001 - preserve route-level JSON error behavior
        return jsonify({'error': str(exc)}), 500
