import re
from datetime import datetime

from flask import Blueprint, jsonify, request

from .logistics_service import calc_display_status, effective_demand_country, get_db

logistics_bp = Blueprint('logistics', __name__)


@logistics_bp.route('/api/shipments')
def shipments_list():
    """运单列表，支持筛选，支持业务状态(ds)和仓库(warehouse)筛选"""
    db = get_db()

    ds = request.args.get('ds', '')  # 业务状态：已交付/运输中/异常单
    verify = request.args.get('verify', '')  # 验收状态：已验收/待验收/未关联
    type_ = request.args.get('type', '')
    country = request.args.get('country', '')
    warehouse = request.args.get('warehouse', '')
    month = request.args.get('month', '')
    pickup_month = request.args.get('pickup_month', '') or month
    actual_delivery_month = request.args.get('actual_delivery_month', '')
    sort_by = request.args.get('sort_by', '')
    sort_dir = request.args.get('sort_dir', 'desc')
    search = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 20))

    where_clauses = ["COALESCE(shipment_status, '') != 'Canceled'", "recycled_at IS NULL"]
    params = []

    if type_:
        where_clauses.append('shipment_type = ?')
        params.append(type_)
    if country:
        where_clauses.append("COALESCE(NULLIF(UPPER(TRIM(demand_country)), ''), UPPER(TRIM(consignee_country_code))) = ?")
        params.append(country.strip().upper())
    if warehouse:
        where_clauses.append('warehouse = ?')
        params.append(warehouse)
    if pickup_month == 'annual':
        where_clauses.append("SUBSTR(pickup_date, 1, 4) = ?")
        params.append(str(datetime.now().year))
    elif pickup_month.startswith('year:') and re.match(r'^year:\d{4}$', pickup_month):
        where_clauses.append("SUBSTR(pickup_date, 1, 4) = ?")
        params.append(pickup_month.split(':', 1)[1])
    elif pickup_month:
        where_clauses.append("SUBSTR(pickup_date, 1, 7) = ?")
        params.append(pickup_month)
    if actual_delivery_month:
        where_clauses.append("SUBSTR(actual_delivery_date, 1, 7) = ?")
        params.append(actual_delivery_month)
    if search:
        where_clauses.append('(booking_id LIKE ? OR stt_number LIKE ? OR consignee_name LIKE ? OR consignee_city LIKE ?)')
        params.extend([f'%{search}%', f'%{search}%', f'%{search}%', f'%{search}%'])

    where_sql = ' AND '.join(where_clauses)

    all_rows = db.execute(f"SELECT * FROM shipments WHERE {where_sql} ORDER BY pickup_date DESC", params).fetchall()

    if ds:
        all_rows = [r for r in all_rows if calc_display_status(r) == ds]

    verified_stts = set()
    pending_stts = set()
    verified_amounts = {}
    verified_invoices = {}
    try:
        inv_rows = db.execute("""SELECT i.stt_number,
                                         COALESCE(NULLIF(i.acceptance_status, ''), h.status) AS status,
                                         h.invoice_number,
                                         COALESCE(i.accepted_amount, i.net_amount, 0) AS net_amount
                                  FROM invoice_items i
                                  JOIN invoice_headers h ON i.invoice_id = h.id""").fetchall()
        for ir in inv_rows:
            if ir['status'] == 'verified':
                verified_stts.add(ir['stt_number'])
                verified_amounts[ir['stt_number']] = verified_amounts.get(ir['stt_number'], 0) + float(ir['net_amount'] or 0)
                verified_invoices.setdefault(ir['stt_number'], set()).add(ir['invoice_number'])
            elif ir['status'] == 'pending':
                pending_stts.add(ir['stt_number'])
    except Exception:
        pass

    if verify:
        def get_verify_status(r):
            stt = r['stt_number'] if 'stt_number' in r.keys() else ''
            if stt in verified_stts:
                return '已验收'
            elif stt in pending_stts:
                return '待验收'
            else:
                return '未关联'
        all_rows = [r for r in all_rows if get_verify_status(r) == verify]

    type_labels = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    }

    def shipment_verify_status(row):
        stt = row['stt_number'] if 'stt_number' in row.keys() else ''
        if stt in verified_stts:
            return '已验收'
        if stt in pending_stts:
            return '待验收'
        return '未关联'

    def shipment_sort_value(row, field):
        keys = row.keys()
        if field == 'stt_number':
            return (row['stt_number'] if 'stt_number' in keys else '') or (row['booking_id'] if 'booking_id' in keys else '')
        if field == 'display_status':
            return calc_display_status(row)
        if field == 'shipment_type':
            raw = row['shipment_type'] if 'shipment_type' in keys else ''
            return type_labels.get(raw, raw or '')
        if field == 'country':
            return effective_demand_country(row)
        if field == 'consignee_city':
            return row['consignee_city'] if 'consignee_city' in keys else ''
        if field in ('pickup_date', 'delivery_date', 'actual_delivery_date'):
            return row[field] if field in keys else ''
        if field == 'total_weight':
            try:
                return float(row['total_weight'] or 0)
            except Exception:
                return 0
        if field == 'verify_status':
            return shipment_verify_status(row)
        if field == 'accepted_amount':
            stt = row['stt_number'] if 'stt_number' in keys else ''
            return verified_amounts.get(stt, 0)
        return ''

    sortable_fields = {
        'stt_number', 'display_status', 'shipment_type', 'country',
        'consignee_city', 'pickup_date', 'delivery_date', 'actual_delivery_date',
        'total_weight', 'verify_status', 'accepted_amount'
    }
    if sort_by in sortable_fields:
        reverse = str(sort_dir).lower() != 'asc'
        if sort_by == 'accepted_amount':
            all_rows = sorted(
                all_rows,
                key=lambda r: (
                    0 if (r['stt_number'] if 'stt_number' in r.keys() else '') in verified_amounts else 1,
                    shipment_sort_value(r, sort_by)
                ),
                reverse=False
            )
            if reverse:
                verified = [r for r in all_rows if (r['stt_number'] if 'stt_number' in r.keys() else '') in verified_amounts]
                missing = [r for r in all_rows if (r['stt_number'] if 'stt_number' in r.keys() else '') not in verified_amounts]
                all_rows = sorted(verified, key=lambda r: shipment_sort_value(r, sort_by), reverse=True) + missing
        else:
            non_empty = [r for r in all_rows if shipment_sort_value(r, sort_by) not in ('', None)]
            empty = [r for r in all_rows if shipment_sort_value(r, sort_by) in ('', None)]
            all_rows = sorted(non_empty, key=lambda r: shipment_sort_value(r, sort_by), reverse=reverse) + empty

    total = len(all_rows)
    start = (page - 1) * per_page
    page_rows = all_rows[start:start + per_page]

    shipments = []
    for r in page_rows:
        d = dict(r)
        d['shipment_type_label'] = type_labels.get(d['shipment_type'], d['shipment_type'])
        d['display_status'] = calc_display_status(r)
        stt = d.get('stt_number', '')
        if stt in verified_stts:
            d['verify_status'] = '已验收'
            d['accepted_amount'] = round(verified_amounts.get(stt, 0), 2)
            d['accepted_invoices'] = sorted(verified_invoices.get(stt, []))
        elif stt in pending_stts:
            d['verify_status'] = '待验收'
            d['accepted_amount'] = None
            d['accepted_invoices'] = []
        else:
            d['verify_status'] = '未关联'
            d['accepted_amount'] = None
            d['accepted_invoices'] = []
        shipments.append(d)

    return jsonify({
        'shipments': shipments,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': (total + per_page - 1) // per_page if total else 1
    })
