import os

from flask import Blueprint, current_app, jsonify, request
from werkzeug.utils import secure_filename

from .inventory_service import (
    allowed_file,
    clear_image_folder,
    get_db,
    image_code_candidates,
    maintenance_password_ok,
    repair_image_mappings,
    resolve_image_bom,
    uploaded_file_size,
)


inventory_images_bp = Blueprint('inventory_images', __name__)

# ==================== 图片上传 ====================

@inventory_images_bp.route('/api/inventory/images/upload', methods=['POST'])
def upload_images():
    uploaded = []
    not_found = []
    d = get_db()

    files = request.files.getlist('files')
    for f in files:
        if not f or not allowed_file(f.filename):
            continue
        if uploaded_file_size(f) > 5 * 1024 * 1024:
            not_found.append(f"{f.filename} (超过5MB)")
            continue
        original_code = image_code_candidates(f.filename)[0] if image_code_candidates(f.filename) else ''
        bom_code = resolve_image_bom(d, f.filename)
        if not bom_code:
            not_found.append(original_code or f.filename)
            continue
        ext = f.filename.rsplit('.', 1)[1].lower()
        filename = secure_filename(f"{bom_code}.{ext}")
        filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        f.save(filepath)
        d.execute("""INSERT INTO sku_master (bom_code, image_path, updated_at)
                     VALUES (?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(bom_code) DO UPDATE SET image_path = excluded.image_path, updated_at = CURRENT_TIMESTAMP""",
                  (bom_code, filename))
        uploaded.append(bom_code)

    repaired = repair_image_mappings(d)
    d.commit()
    return jsonify({'success': True, 'uploaded': uploaded, 'not_found': not_found, 'repaired': repaired})


@inventory_images_bp.route('/api/inventory/images', methods=['DELETE'])
def clear_inventory_images():
    data = request.get_json(silent=True) or {}
    if not maintenance_password_ok(data.get('password'), allow_admin=True):
        return jsonify({'error': '清理密码错误'}), 403

    folder = current_app.config['UPLOAD_FOLDER']
    deleted, failed = clear_image_folder(folder)

    d = get_db()
    d.execute("UPDATE sku_master SET image_path = NULL, updated_at = CURRENT_TIMESTAMP WHERE COALESCE(image_path, '') <> ''")
    d.commit()
    return jsonify({'success': True, 'deleted': deleted, 'failed': failed})
