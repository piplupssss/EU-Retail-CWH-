"""Shipment import business logic.

Routes should only validate HTTP shape and return responses. This module owns
the Excel parsing, shipment-type classification, duplicate handling, and manual
field protection for logistics imports.
"""

from __future__ import annotations

import os
import re
import sqlite3
import unicodedata
from datetime import datetime
from typing import Any

import pandas as pd

from . import db as db_module
from .maintenance_service import remove_file_safely, safe_upload_filename, uploaded_file_size


MIN_SHIPMENT_DATE = '2026-01-01'
MAX_EXCEL_BYTES = 20 * 1024 * 1024


def validate_shipment_excel_file(file_storage, label: str = 'Excel') -> str | None:
    if not file_storage or not file_storage.filename:
        return '请上传物流 Excel 文件'
    if not file_storage.filename.lower().endswith(('.xlsx', '.xls')):
        return f'{label} 文件必须是 Excel 文件'
    if uploaded_file_size(file_storage) > MAX_EXCEL_BYTES:
        return f'{label} 文件不能超过 20MB'
    return None


def validate_shipment_excel_files(files) -> str | None:
    valid_files = [f for f in files if f and f.filename]
    if not valid_files:
        return '请上传物流 Excel 文件'
    bad = [f.filename for f in valid_files if not f.filename.lower().endswith(('.xlsx', '.xls'))]
    if bad:
        return '只支持 .xlsx / .xls 文件：' + ', '.join(bad[:5])
    if any(uploaded_file_size(f) > MAX_EXCEL_BYTES for f in valid_files):
        return '单个物流 Excel 文件不能超过 20MB'
    return None


def import_shipments_file(file_storage, upload_type: str, database_path: str) -> dict[str, Any]:
    """Import a single legacy logistics Excel file."""
    upload_dir = _upload_dir(database_path)
    saved_filename = safe_upload_filename(file_storage.filename)
    filepath = os.path.join(upload_dir, saved_filename)
    file_storage.save(filepath)

    try:
        db_module.backup_sqlite_db(database_path, f"shipments_import_{upload_type or 'unknown'}")
        df = pd.read_excel(filepath, header=18)
        conn = sqlite3.connect(database_path)
        cursor = conn.cursor()
        report = {
            'success': True,
            'imported': 0,
            'inserted': 0,
            'updated': 0,
            'skipped_date': 0,
            'skipped_missing_stt': 0,
            'type': upload_type,
        }
        try:
            for _, row in df.iterrows():
                result = _import_shipment_row(cursor, row, upload_type, saved_filename, mode='legacy')
                if result == 'skipped_missing_stt':
                    report['skipped_missing_stt'] += 1
                elif result == 'skipped_date':
                    report['skipped_date'] += 1
                elif result == 'inserted':
                    report['inserted'] += 1
                    report['imported'] += 1
                elif result == 'updated':
                    report['updated'] += 1
                    report['imported'] += 1
            conn.commit()
            return report
        finally:
            conn.close()
    finally:
        remove_file_safely(filepath)


def import_shipments_auto_files(files, database_path: str) -> dict[str, Any]:
    """Import multiple logistics Excel files and classify by pickup city."""
    upload_dir = _upload_dir(database_path)
    db_module.backup_sqlite_db(database_path, 'shipments_import_auto')
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    saved_paths: list[str] = []
    summary = {
        'imported': 0,
        'inserted': 0,
        'updated': 0,
        'skipped_date': 0,
        'skipped_missing_stt': 0,
        'type_counts': {'warehouse_central': 0, 'warehouse_furniture': 0, 'direct': 0},
    }
    file_reports = []

    try:
        for file_storage in files:
            if not file_storage or not file_storage.filename:
                continue
            saved_filename = safe_upload_filename(file_storage.filename)
            filepath = os.path.join(upload_dir, saved_filename)
            file_storage.save(filepath)
            saved_paths.append(filepath)
            report = {
                'filename': file_storage.filename,
                'source_file': 'logistics_auto_' + saved_filename,
                'imported': 0,
                'inserted': 0,
                'updated': 0,
                'skipped_date': 0,
                'skipped_missing_stt': 0,
                'type_counts': {'warehouse_central': 0, 'warehouse_furniture': 0, 'direct': 0},
            }
            try:
                df = pd.read_excel(filepath, header=18)
                for _, row in df.iterrows():
                    shipment_type, _ = classify_by_pickup_city(_clean_nan(row.get('Pickup City')))
                    result = _import_shipment_row(cursor, row, '', saved_filename, mode='auto')
                    if result == 'skipped_missing_stt':
                        report['skipped_missing_stt'] += 1
                    elif result == 'skipped_date':
                        report['skipped_date'] += 1
                    elif result in ('inserted', 'updated'):
                        report[result] += 1
                        report['imported'] += 1
                        report['type_counts'][shipment_type] = report['type_counts'].get(shipment_type, 0) + 1
            except Exception as exc:  # noqa: BLE001 - keep per-file import report behavior
                report['error'] = str(exc)
            add_counts(summary, report)
            file_reports.append(report)

        conn.commit()
        return {'success': True, 'file_count': len([f for f in files if f and f.filename]), 'summary': summary, 'files': file_reports}
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
        for path in saved_paths:
            remove_file_safely(path)


def classify_by_pickup_city(value):
    key = _city_key(value)
    if 'bydgoszcz' in key:
        return 'warehouse_furniture', 'Bydgoszcz'
    if 'lodz' in key:
        return 'warehouse_central', 'Łódź'
    return 'direct', ''


def add_counts(target, source):
    for key, value in source.items():
        if isinstance(value, dict):
            target.setdefault(key, {})
            add_counts(target[key], value)
        else:
            try:
                target[key] = target.get(key, 0) + int(value or 0)
            except (TypeError, ValueError):
                pass


def _upload_dir(database_path: str) -> str:
    upload_dir = os.path.join(os.path.dirname(database_path), 'uploads')
    os.makedirs(upload_dir, exist_ok=True)
    return upload_dir


def _clean_nan(val):
    if val is None or (isinstance(val, float) and str(val) == 'nan'):
        return ''
    s = str(val).strip()
    return '' if s == 'nan' or s == '' else s


def _parse_excel_date(val):
    if pd.isna(val) or str(val).strip() == '':
        return None
    if hasattr(val, 'strftime'):
        return val.strftime('%Y-%m-%d %H:%M')
    s = str(val).strip()
    for fmt in ['%d.%m.%Y %H:%M:%S', '%d.%m.%Y %H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d.%m.%Y', '%Y-%m-%d']:
        try:
            return datetime.strptime(s, fmt).strftime('%Y-%m-%d %H:%M')
        except ValueError:
            continue
    return s


def _city_key(value):
    raw = str(value or '').replace('Ł', 'L').replace('ł', 'l')
    text = unicodedata.normalize('NFKD', raw).encode('ascii', 'ignore').decode('ascii')
    return re.sub(r'[^a-z0-9]+', '', text.lower())


def _legacy_shipment_type(row, upload_type: str):
    if upload_type in ('pl_domestic', 'intl_direct'):
        return 'direct'
    if upload_type.startswith('warehouse'):
        pickup_city_lower = str(row.get('Pickup City', '')).strip().lower()
        return 'warehouse_furniture' if 'bydgoszcz' in pickup_city_lower else 'warehouse_central'

    user_group = str(row.get('User group name', ''))
    pickup_city_lower = str(row.get('Pickup City', '')).strip().lower()
    if 'PLdom' in user_group:
        return 'direct'
    if 'PLint' in user_group:
        if 'bydgoszcz' in pickup_city_lower:
            return 'warehouse_furniture'
        if 'lodz' in pickup_city_lower or 'łódź' in pickup_city_lower:
            return 'warehouse_central'
        return 'direct'
    return 'unknown'


def _warehouse_from_pickup_city(row):
    pickup_city_lower = str(row.get('Pickup City', '')).strip().lower()
    if 'bydgoszcz' in pickup_city_lower:
        return 'Bydgoszcz'
    if 'lodz' in pickup_city_lower or 'łódź' in pickup_city_lower:
        return 'Łódź'
    return ''


def _as_float(value):
    if pd.isna(value):
        return 0.0
    try:
        return float(str(value).replace(',', '').replace(' ', ''))
    except Exception:
        return 0.0


def _import_shipment_row(cursor, row, upload_type: str, saved_filename: str, mode: str) -> str:
    booking_id = _clean_nan(row.get('Booking ID', ''))
    stt_number = _clean_nan(row.get('STT Number', ''))
    if not stt_number:
        return 'skipped_missing_stt'
    if not booking_id or booking_id == 'nan':
        booking_id = stt_number
    if not booking_id or booking_id == 'nan':
        return 'skipped_missing_stt'

    pickup_date = _parse_excel_date(row.get('Pickup Date'))
    if pickup_date:
        pd_date = pickup_date[:10] if len(pickup_date) >= 10 else pickup_date
        if pd_date < MIN_SHIPMENT_DATE:
            return 'skipped_date'

    if mode == 'auto':
        pickup_city = _clean_nan(row.get('Pickup City'))
        shipment_type, warehouse = classify_by_pickup_city(pickup_city)
        source_file = 'logistics_auto_' + saved_filename
        shipment_status = _clean_nan(row.get('Shipment Status')) or 'Active'
    else:
        shipment_type = _legacy_shipment_type(row, upload_type)
        warehouse = _warehouse_from_pickup_city(row)
        pickup_city = _clean_nan(row.get('Pickup City'))
        source_file = upload_type + '_' + saved_filename if upload_type else 'upload_' + saved_filename
        shipment_status = _clean_nan(row.get('Shipment Status'))

    consignee_country_code = _clean_nan(row.get('Consignee Country Code')).strip().upper()
    demand_country = consignee_country_code
    demand_country_source = 'default' if demand_country else ''

    shipment_values = (
        booking_id,
        stt_number,
        _clean_nan(row.get('Consignment/Waybill No.')),
        shipment_status,
        _clean_nan(row.get('Transport Mode')),
        shipment_type,
        warehouse,
        _clean_nan(row.get('Shipper Name', '')),
        _clean_nan(row.get('Consignee Name')),
        _clean_nan(row.get('Consignee Name2', '')),
        _clean_nan(row.get('Consignee Street', '')),
        _clean_nan(row.get('Consignee Street2', '')),
        _clean_nan(row.get('Consignee Address')) or _clean_nan(row.get('Delivery Address', '')),
        _clean_nan(row.get('Consignee City')),
        consignee_country_code,
        demand_country,
        demand_country_source,
        pickup_city,
        _clean_nan(row.get('Pickup Country Code', '')),
        _clean_nan(row.get('Delivery City', '')),
        _clean_nan(row.get('Delivery Country Code', '')),
        _parse_excel_date(row.get('Creation Date', '')),
        pickup_date,
        _parse_excel_date(row.get('Delivery Date')),
        _as_float(row.get('Total Pieces', 0)),
        _as_float(row.get('Total Weight', 0)),
        _as_float(row.get('Total Volume', 0)),
        _as_float(row.get('Price without VAT', 0)),
        _clean_nan(row.get('Incoterm', '')),
        _clean_nan(row.get('Service Type', '')),
        _clean_nan(row.get('Product', '')),
        _clean_nan(row.get('Cargo Description')),
        _clean_nan(row.get('References', '')),
        source_file,
    )
    return _upsert_shipment(cursor, booking_id, stt_number, shipment_values)


def _upsert_shipment(cursor, booking_id: str, stt_number: str, shipment_values: tuple) -> str:
    existing = cursor.execute(
        """SELECT id, demand_country_source FROM shipments
           WHERE booking_id = ?
              OR (stt_number IS NOT NULL AND stt_number != '' AND stt_number = ?)
           ORDER BY CASE WHEN booking_id = ? THEN 0 ELSE 1 END
           LIMIT 1""",
        (booking_id, stt_number, booking_id),
    ).fetchone()

    if existing:
        cursor.execute("""
            UPDATE shipments SET
                booking_id=?, stt_number=?, waybill_no=?, shipment_status=?,
                transport_mode=?, shipment_type=?, warehouse=?,
                shipper_name=?, consignee_name=?, consignee_name2=?,
                consignee_street=?, consignee_street2=?, consignee_address=?,
                consignee_city=?, consignee_country_code=?,
                demand_country=CASE
                    WHEN COALESCE(demand_country_source, '') = 'manual' THEN demand_country
                    ELSE ?
                END,
                demand_country_source=CASE
                    WHEN COALESCE(demand_country_source, '') = 'manual' THEN demand_country_source
                    ELSE ?
                END,
                pickup_city=?, pickup_country_code=?,
                delivery_city=?, delivery_country_code=?,
                creation_date=?, pickup_date=?, delivery_date=?,
                total_pieces=?, total_weight=?, total_volume=?,
                price_without_vat=?, incoterm=?, service_type=?,
                product=?, cargo_description=?, references_text=?, source_file=?,
                import_time=CURRENT_TIMESTAMP
            WHERE id=?
        """, shipment_values + (existing[0],))
        return 'updated'

    cursor.execute("""
        INSERT INTO shipments (
            booking_id, stt_number, waybill_no, shipment_status,
            transport_mode, shipment_type, warehouse,
            shipper_name, consignee_name, consignee_name2,
            consignee_street, consignee_street2, consignee_address,
            consignee_city, consignee_country_code,
            demand_country, demand_country_source,
            pickup_city, pickup_country_code,
            delivery_city, delivery_country_code,
            creation_date, pickup_date, delivery_date,
            total_pieces, total_weight, total_volume,
            price_without_vat, incoterm, service_type,
            product, cargo_description, references_text, source_file
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, shipment_values)
    return 'inserted'
