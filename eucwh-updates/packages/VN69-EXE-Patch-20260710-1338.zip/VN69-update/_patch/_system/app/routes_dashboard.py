import os
from collections import defaultdict
from datetime import datetime, timedelta

from flask import Blueprint, jsonify, request

from .maintenance_service import source_file_to_disk_name, upload_dir_path
from .logistics_service import calc_display_status, get_db

dashboard_bp = Blueprint('dashboard', __name__)


def dashboard_month_filter(alias=''):
    """Return SQL snippet/params for dashboard-level pickup month filtering."""
    month = (request.args.get('month') or '').strip()
    if not month:
        return '', []
    prefix = f"{alias}." if alias else ''
    return f" AND SUBSTR({prefix}pickup_date, 1, 7) = ?", [month]


@dashboard_bp.route('/api/dashboard/summary')
def dashboard_summary():
    """总览数据，基于业务状态计算"""
    db = get_db()
    month_sql, params = dashboard_month_filter()
    rows = db.execute(f"""
        SELECT booking_id, delivery_date, pickup_date, shipment_status,
               actual_delivery_date, delivery_locked, manual_status,
               total_pieces, total_weight, total_volume, price_without_vat
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
          {month_sql}
    """, params).fetchall()
    total = len(rows)
    status_counts = {'已交付': 0, '待核实': 0, '运输中': 0, '异常单': 0}
    total_pieces = total_weight = total_volume = total_price = 0
    for r in rows:
        ds = calc_display_status(r)
        status_counts[ds] = status_counts.get(ds, 0) + 1
        total_pieces += r['total_pieces'] or 0
        total_weight += r['total_weight'] or 0
        total_volume += r['total_volume'] or 0
        total_price += r['price_without_vat'] or 0
    latest_logistics_upload = ''
    upload_dir = upload_dir_path()
    upload_rows = db.execute("""
        SELECT DISTINCT source_file
        FROM shipments
        WHERE source_file IS NOT NULL AND source_file != ''
          AND recycled_at IS NULL
    """).fetchall()
    for r in upload_rows:
        disk_name = source_file_to_disk_name(r['source_file'])
        path = os.path.join(upload_dir, disk_name)
        if os.path.exists(path):
            modified_at = datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M:%S')
            if not latest_logistics_upload or modified_at > latest_logistics_upload:
                latest_logistics_upload = modified_at
    return jsonify({
        'total_shipments': total,
        'delivered': status_counts['已交付'],
        'pending_verify': status_counts['待核实'],
        'in_transit': status_counts['运输中'],
        'exception': status_counts['异常单'],
        'total_pieces': total_pieces,
        'total_weight': total_weight,
        'total_volume': total_volume,
        'total_price': total_price,
        'latest_logistics_upload': latest_logistics_upload,
    })


@dashboard_bp.route('/api/dashboard/status_distribution')
def status_distribution():
    """运单状态分布（业务状态：已交付/运输中/异常单）"""
    db = get_db()
    month_sql, params = dashboard_month_filter()
    rows = db.execute(f"""
        SELECT booking_id, delivery_date, pickup_date, shipment_status,
               actual_delivery_date, delivery_locked, manual_status
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
          {month_sql}
    """, params).fetchall()
    counts = {}
    for r in rows:
        ds = calc_display_status(r)
        counts[ds] = counts.get(ds, 0) + 1
    result = [{'shipment_status': k, 'count': v} for k, v in sorted(counts.items(), key=lambda x: -x[1])]
    return jsonify(result)


@dashboard_bp.route('/api/dashboard/type_distribution')
def type_distribution():
    """运单类型分布"""
    db = get_db()
    month_sql, params = dashboard_month_filter()
    type_labels = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    }
    rows = db.execute(f"""
        SELECT shipment_type, COUNT(*) as count
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled'
          AND recycled_at IS NULL
          {month_sql}
        GROUP BY shipment_type
        ORDER BY count DESC
    """, params).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d['label'] = type_labels.get(d['shipment_type'], d['shipment_type'])
        result.append(d)
    return jsonify(result)


@dashboard_bp.route('/api/dashboard/country_ranking')
def country_ranking():
    """各国发货量排名，含重量和平均交付时长（工作日），按取货/发货月份筛选。"""
    month = request.args.get('month', '')
    db = get_db()

    demand_expr = "COALESCE(NULLIF(UPPER(TRIM(demand_country)), ''), UPPER(TRIM(consignee_country_code)))"
    where = f"COALESCE(shipment_status, '') != 'Canceled' AND recycled_at IS NULL AND {demand_expr} IS NOT NULL AND {demand_expr} != ''"
    params = []
    if month:
        where += " AND SUBSTR(pickup_date, 1, 7) = ?"
        params.append(month)

    rows = db.execute(f"""
        SELECT {demand_expr} as country, COUNT(*) as count,
               COALESCE(SUM(total_weight), 0) as weight,
               COALESCE(SUM(price_without_vat), 0) as price
        FROM shipments
        WHERE {where}
        GROUP BY {demand_expr}
        ORDER BY count DESC
    """, params).fetchall()

    def calc_workdays(start_str, end_str):
        try:
            s = datetime.strptime(start_str[:10], '%Y-%m-%d')
            e = datetime.strptime(end_str[:10], '%Y-%m-%d')
            count = 0
            cur = s
            while cur < e:
                if cur.weekday() < 5:
                    count += 1
                cur += timedelta(days=1)
            return count
        except Exception:
            return None

    country_data = {}
    for r in rows:
        d = dict(r)
        d['avg_delivery_days'] = None
        country_data[d['country']] = d

    delivered_rows = db.execute(f"""
        SELECT {demand_expr} as demand_country, pickup_date, actual_delivery_date
        FROM shipments
        WHERE {where}
          AND actual_delivery_date IS NOT NULL AND actual_delivery_date != ''
          AND pickup_date IS NOT NULL AND pickup_date != ''
    """, params).fetchall()

    country_workdays = defaultdict(list)
    for r in delivered_rows:
        wd = calc_workdays(r['pickup_date'], r['actual_delivery_date'])
        if wd is not None:
            country_workdays[r['demand_country']].append(wd)

    for country, wds in country_workdays.items():
        if country in country_data:
            country_data[country]['avg_delivery_days'] = round(sum(wds) / len(wds), 1) if wds else None

    result = list(country_data.values())

    if not month:
        month_rows = db.execute("""
            SELECT DISTINCT SUBSTR(pickup_date, 1, 7) as month
            FROM shipments
            WHERE COALESCE(shipment_status, '') != 'Canceled'
              AND recycled_at IS NULL
              AND pickup_date IS NOT NULL AND pickup_date != ''
            ORDER BY month DESC
        """).fetchall()
        available_months = [r['month'] for r in month_rows]
        return jsonify({'data': result, 'available_months': available_months})

    return jsonify({'data': result, 'available_months': []})


@dashboard_bp.route('/api/dashboard/monthly_trend')
def monthly_trend():
    """月度趋势（按发货日期）"""
    db = get_db()
    rows = db.execute("""
        SELECT
            SUBSTR(pickup_date, 1, 7) as month,
            COUNT(*) as count,
            COALESCE(SUM(total_weight), 0) as weight,
            COALESCE(SUM(total_volume), 0) as volume,
            COALESCE(SUM(price_without_vat), 0) as price
        FROM shipments
        WHERE pickup_date IS NOT NULL AND pickup_date != '' AND COALESCE(shipment_status, '') != 'Canceled' AND recycled_at IS NULL
        GROUP BY SUBSTR(pickup_date, 1, 7)
        ORDER BY month
    """).fetchall()
    return jsonify([dict(r) for r in rows])


@dashboard_bp.route('/api/dashboard/warehouse_distribution')
def warehouse_distribution():
    """仓库发货分布"""
    db = get_db()
    rows = db.execute("""
        SELECT warehouse, COUNT(*) as count,
               COALESCE(SUM(total_weight), 0) as weight
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled' AND recycled_at IS NULL AND warehouse IS NOT NULL AND warehouse != ''
        GROUP BY warehouse
        ORDER BY count DESC
    """).fetchall()
    return jsonify([dict(r) for r in rows])
