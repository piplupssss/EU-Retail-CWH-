import re
from datetime import datetime

from flask import Blueprint, current_app, jsonify, request

from . import db as db_module
from .export_service import (
    add_summary_sheet,
    cell,
    clean_cell,
    date_cell,
    find_header,
    short_export_filename,
    style_report_sheet,
    style_simple_sheet,
    xlsx_response,
)
from .logistics_service import calc_display_status, effective_demand_country, get_db
from .maintenance_service import uploaded_file_size


logistics_exports_bp = Blueprint('logistics_exports', __name__)
@logistics_exports_bp.route('/api/export/logistics')
def export_logistics_list():
    """Export active logistics shipment list as a styled XLSX workbook."""
    from openpyxl import Workbook
    db = get_db()
    invoice_rows = db.execute("""
        SELECT i.stt_number,
               COALESCE(i.accepted_amount, i.net_amount, 0) AS net_amount,
               h.invoice_number,
               COALESCE(NULLIF(i.acceptance_status, ''), h.status) AS status
        FROM invoice_items i
        JOIN invoice_headers h ON i.invoice_id = h.id
    """).fetchall()
    stt_status = {}
    verified_amounts = {}
    verified_invoices = {}
    for r in invoice_rows:
        stt = r['stt_number'] or ''
        if not stt:
            continue
        status = r['status'] or 'pending'
        if status == 'verified':
            stt_status[stt] = '已验收'
            verified_amounts[stt] = verified_amounts.get(stt, 0) + float(r['net_amount'] or 0)
            verified_invoices.setdefault(stt, set()).add(r['invoice_number'])
        elif stt not in stt_status:
            stt_status[stt] = '待验收' if status == 'pending' else '已拒绝'

    ds = request.args.get('ds', '').strip()
    type_filter = request.args.get('type', '').strip()
    country = request.args.get('country', '').strip().upper()
    pickup_month = request.args.get('pickup_month', '').strip()
    where = []
    params = []
    if type_filter:
        where.append('shipment_type = ?')
        params.append(type_filter)
    if country:
        where.append("COALESCE(NULLIF(UPPER(TRIM(demand_country)), ''), UPPER(TRIM(consignee_country_code))) = ?")
        params.append(country)
    if pickup_month.startswith('year:') and re.match(r'^year:\d{4}$', pickup_month):
        where.append("SUBSTR(pickup_date, 1, 4) = ?")
        params.append(pickup_month.split(':', 1)[1])
    elif pickup_month == 'annual':
        where.append("SUBSTR(pickup_date, 1, 4) = ?")
        params.append(str(datetime.now().year))
    elif pickup_month:
        where.append("SUBSTR(pickup_date, 1, 7) = ?")
        params.append(pickup_month)
    where_sql = 'WHERE ' + ' AND '.join(where) if where else ''
    rows = db.execute(f"""
        SELECT *
        FROM shipments
        {where_sql}
        ORDER BY pickup_date DESC, booking_id
    """, params).fetchall()
    if ds:
        rows = [r for r in rows if calc_display_status(r) == ds]
    type_labels = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    }
    headers = [
        'Booking ID', 'STT Number', 'Waybill No', 'Supplier Status', 'Display Status',
        'Manual Status', 'Delivery Locked', 'Shipment Type', 'Warehouse',
        'Demand Country', 'Demand Country Source', 'Consignee Country',
        'Consignee Name', 'Consignee City', 'Pickup Date', 'ETA Delivery Date',
        'Actual Delivery Date', 'Pieces', 'Weight', 'Volume', 'Price Without VAT',
        'Product', 'Service Type', 'Verify Status', 'Accepted Amount PLN',
        'Accepted Invoice', 'Recycle Status', 'Recycle Reason', 'Recycle Time',
        'Recycle Operator', 'Source File'
    ]
    data_rows = []
    status_summary = {'已交付': 0, '待核实': 0, '运输中': 0, '异常单': 0}
    total_weight = total_volume = total_price = accepted_total = 0
    for r in rows:
        stt = r['stt_number'] or ''
        display_status = calc_display_status(r)
        status_summary[display_status] = status_summary.get(display_status, 0) + 1
        total_weight += float(r['total_weight'] or 0)
        total_volume += float(r['total_volume'] or 0)
        total_price += float(r['price_without_vat'] or 0)
        accepted_amount = round(verified_amounts.get(stt, 0), 2) if stt in verified_amounts else ''
        if accepted_amount != '':
            accepted_total += accepted_amount
        data_rows.append([
            r['booking_id'], stt, r['waybill_no'], r['shipment_status'], display_status,
            r['manual_status'], 'Y' if r['delivery_locked'] else '',
            type_labels.get(r['shipment_type'], r['shipment_type']), r['warehouse'],
            effective_demand_country(r), r['demand_country_source'], r['consignee_country_code'],
            r['consignee_name'], r['consignee_city'], r['pickup_date'], r['delivery_date'],
            r['actual_delivery_date'], r['total_pieces'], r['total_weight'], r['total_volume'],
            r['price_without_vat'], r['product'], r['service_type'], stt_status.get(stt, '未关联'),
            accepted_amount,
            ', '.join(sorted(verified_invoices.get(stt, []))),
            '回收站' if r['recycled_at'] else '',
            r['recycle_reason'], r['recycled_at'], r['recycle_operator'], r['source_file']
        ])

    wb = Workbook()
    ws = wb.active
    ws.title = 'Logistics'
    summary = [
        ('总运单数', len(rows)),
        ('已交付 / 待核实 / 运输中 / 异常单', f"{status_summary.get('已交付', 0)} / {status_summary.get('待核实', 0)} / {status_summary.get('运输中', 0)} / {status_summary.get('异常单', 0)}"),
        ('总重量 kg', round(total_weight, 2)),
        ('总体积', round(total_volume, 2)),
        ('物流费用', round(total_price, 2)),
        ('已验收金额 PLN', round(accepted_total, 2)),
    ]
    style_report_sheet(ws, '零售中央仓 - 全量物流清单', f'导出时间：{datetime.now().strftime("%Y-%m-%d %H:%M:%S")} · 包含人工调整、回收站和验收金额', headers, data_rows, summary)
    add_summary_sheet(wb, summary, title='Summary')
    return xlsx_response(wb, short_export_filename('logistics'))


@logistics_exports_bp.route('/api/export/logistics-calibration')
def export_logistics_calibration():
    """Export a controlled logistics status calibration workbook."""
    from openpyxl import Workbook
    db = get_db()
    rows = db.execute("""
        SELECT booking_id, stt_number, shipment_status, manual_status, pickup_date, delivery_date, actual_delivery_date,
               delivery_locked, demand_country, consignee_country_code,
               recycled_at, recycle_reason, recycle_operator
        FROM shipments
        WHERE COALESCE(shipment_status, '') != 'Canceled'
        ORDER BY pickup_date DESC, booking_id
    """).fetchall()
    headers = [
        'STT Number', 'Booking ID', '当前显示状态', '手动物流状态',
        '实际交付日期', '锁定交付日期', '需求国家', '收货国家',
        '回收站状态', '回收站备注', '回收站操作人'
    ]
    wb = Workbook()
    ws = wb.active
    ws.title = 'Logistics Calibration'
    ws.append(headers)
    for r in rows:
        ws.append([
            r['stt_number'] or '',
            r['booking_id'] or '',
            calc_display_status(r),
            r['manual_status'] or '',
            r['actual_delivery_date'] or '',
            'Y' if r['delivery_locked'] else '',
            effective_demand_country(r),
            r['consignee_country_code'] or '',
            'Y' if r['recycled_at'] else '',
            r['recycle_reason'] or '',
            r['recycle_operator'] or '',
        ])
    style_simple_sheet(ws)
    return xlsx_response(wb, short_export_filename('logistics_cal'))


@logistics_exports_bp.route('/api/shipments/import-calibration', methods=['POST'])
def import_logistics_calibration():
    """Import logistics status calibration. Only controlled/manual fields are updated."""
    import openpyxl
    file = request.files.get('file')
    if not file or not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'error': '请上传物流状态校准 Excel'}), 400
    if uploaded_file_size(file) > 20 * 1024 * 1024:
        return jsonify({'error': 'Excel 文件不能超过 20MB'}), 400
    db_module.backup_sqlite_db(current_app.config['DATABASE'], 'logistics_calibration_import')
    wb = openpyxl.load_workbook(file, data_only=True)
    ws = wb.active
    required = ['STT Number', 'Booking ID']
    aliases = {
        '当前显示状态': ['Display Status', '物流状态'],
        '手动物流状态': ['Manual Status', 'Manual Logistics Status'],
        '实际交付日期': ['Actual Delivery Date'],
        '锁定交付日期': ['Delivery Locked'],
        '需求国家': ['Demand Country'],
        '回收站状态': ['Recycle Status'],
        '回收站备注': ['Recycle Reason'],
        '回收站操作人': ['Recycle Operator']
    }
    header_row, col_map = find_header(ws, required, aliases={**aliases, 'STT Number': ['STT'], 'Booking ID': ['Booking']}, scan_rows=8)
    if not header_row:
        return jsonify({'error': '未找到物流校准表头，请确认包含 STT Number / Booking ID'}), 400
    db = get_db()
    updated = skipped = recycled = restored = 0
    for row_idx in range(header_row + 1, ws.max_row + 1):
        stt = clean_cell(cell(ws, row_idx, col_map, 'STT Number'))
        booking = clean_cell(cell(ws, row_idx, col_map, 'Booking ID'))
        if not stt and not booking:
            continue
        row = db.execute("""
            SELECT booking_id FROM shipments
            WHERE (? != '' AND stt_number = ?) OR (? != '' AND booking_id = ?)
            ORDER BY CASE WHEN booking_id = ? THEN 0 ELSE 1 END
            LIMIT 1
        """, (stt, stt, booking, booking, booking)).fetchone()
        if not row:
            skipped += 1
            continue
        booking_id = row['booking_id']
        manual_status = clean_cell(cell(ws, row_idx, col_map, '手动物流状态'))
        actual_delivery = date_cell(cell(ws, row_idx, col_map, '实际交付日期'))
        delivery_locked_raw = clean_cell(cell(ws, row_idx, col_map, '锁定交付日期')).upper()
        demand_country = clean_cell(cell(ws, row_idx, col_map, '需求国家')).upper()
        recycle_status = clean_cell(cell(ws, row_idx, col_map, '回收站状态')).upper()
        recycle_reason = clean_cell(cell(ws, row_idx, col_map, '回收站备注'))
        recycle_operator = clean_cell(cell(ws, row_idx, col_map, '回收站操作人'))
        db.execute("""
            UPDATE shipments
            SET manual_status = COALESCE(NULLIF(?, ''), manual_status),
                actual_delivery_date = COALESCE(NULLIF(?, ''), actual_delivery_date),
                delivery_locked = CASE WHEN ? IN ('Y','YES','1','TRUE','是') THEN 1 ELSE delivery_locked END,
                demand_country = CASE WHEN ? != '' THEN ? ELSE demand_country END,
                demand_country_source = CASE WHEN ? != '' THEN 'manual' ELSE demand_country_source END
            WHERE booking_id = ?
        """, (manual_status, actual_delivery, delivery_locked_raw, demand_country, demand_country, demand_country, booking_id))
        if recycle_status in ('Y', 'YES', '1', 'TRUE', '是'):
            db.execute("""
                UPDATE shipments SET recycled_at = COALESCE(recycled_at, CURRENT_TIMESTAMP),
                    recycle_reason = COALESCE(NULLIF(?, ''), recycle_reason),
                    recycle_operator = COALESCE(NULLIF(?, ''), recycle_operator)
                WHERE booking_id = ?
            """, (recycle_reason, recycle_operator, booking_id))
            recycled += 1
        elif recycle_status in ('N', 'NO', '0', 'FALSE', '否'):
            db.execute("UPDATE shipments SET recycled_at = NULL, recycle_reason = NULL, recycle_operator = NULL WHERE booking_id = ?", (booking_id,))
            restored += 1
        updated += 1
    db.commit()
    return jsonify({'success': True, 'updated': updated, 'skipped': skipped, 'recycled': recycled, 'restored': restored})
