import os
import re
from datetime import datetime

from flask import current_app, g
from werkzeug.utils import secure_filename

from . import db as db_module

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
CALIBRATION_HEADERS = [
    'Bom Code',
    'Product Number',
    'Product Description',
    'Category',
    'Category 2',
    'Instruction',
    'Inventory (Pcs)',
    'Unit Price (USD)',
    'TTL Amount (USD)',
    '最近入库时间 Last Inbound date',
    '最近出库时间 Last Outbound date',
    '库龄 Dos (Days of Supply)',
    '库存静置时长 Days without Stock',
    '备注 comment',
    'SKU条目创建时间',
    '图片 Photo',
]
CALIBRATION_SHEETS = {
    'Lodz': 'Lodz warehouse',
    'Bydgoszcz': 'Bydgoszcz warehouse',
}
SUPPLIER_INVENTORY_REQUIRED_HEADERS = [
    'Product Number',
    'Instruction',
    'Category',
    'Category 2',
    'Product Description',
    'Sum of Quantity',
]
SUPPLIER_INVENTORY_ALIASES = {
    'Instruction': ['Instructions', 'Instruction Code', 'InstructionCode'],
    'Category 2': ['Category2', 'Category II', 'Product Category', 'Applicable Product'],
    'Product Description': ['Production Description', 'Description', 'Product Desc', 'Item Description'],
    'Sum of Quantity': ['Sum Quantity', 'Quantity', 'Qty', 'SUMA Z QUANTITY', 'Suma z Quantity', 'Suma of Quantity', 'Sum z Quantity', 'Sum of Qty'],
}
INVENTORY_MAINTENANCE_REQUIRED_HEADERS = [
    'Product Number',
    'Bom Code',
    'Unit Price',
    'Last Inbound Date',
    'Last Outbound Date',
    'Remark',
    'DOS Threshold',
    'Idle Threshold',
]
INVENTORY_MAINTENANCE_ALIASES = {
    'Bom Code': ['BOM Code', 'BomCode', 'BOM', 'BOM No'],
    'Unit Price': ['UnitPrice', 'Price', 'Unit Cost'],
    'Last Inbound Date': ['Last Inbound', 'Inbound Date', 'Last Receipt Date'],
    'Last Outbound Date': ['Last Outbound', 'Outbound Date', 'Last Issue Date'],
    'Remark': ['Remarks', 'Comment', 'Comments', 'Notes'],
    'DOS Threshold': ['DOS', 'DOS Days', 'DOS Line'],
    'Idle Threshold': ['Idle', 'Idle Days', 'Idle Line'],
}
SPECYFIKACJA_REQUIRED_HEADERS = ['DATA RUCHU', 'SKU', 'ID_OPERACJI', 'ILOŚĆ', 'UoM']
SPECYFIKACJA_ALIASES = {
    'DATA RUCHU': ['DATA', 'Data ruchu', 'Movement Date'],
    'SKU': ['Product Number', 'PRODUCT NUMBER', 'Indeks', 'Towar'],
    'ID_OPERACJI': ['ID OPERACJI', 'ID', 'Operation ID'],
    'ILOŚĆ': ['ILOSC', 'ILOSĆ', 'Quantity', 'Qty'],
    'UoM': ['UOM', 'Unit', 'Unit of Measure'],
}
SUMMARY_ROW_MARKERS = {'TOTAL', 'GRAND TOTAL', 'SUMA KONCOWA', 'SUMA KOŃCOWA'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def uploaded_file_size(file):
    pos = file.stream.tell()
    file.stream.seek(0, os.SEEK_END)
    size = file.stream.tell()
    file.stream.seek(pos)
    return size

def save_uploaded_source_file(file, prefix):
    upload_dir = os.path.join(os.path.dirname(current_app.config['DATABASE']), 'uploads')
    os.makedirs(upload_dir, exist_ok=True)
    safe_name = secure_filename(file.filename or 'upload.xlsx') or 'upload.xlsx'
    filename = f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{safe_name}"
    path = os.path.join(upload_dir, filename)
    file.save(path)
    try:
        file.stream.seek(0)
    except Exception:
        pass
    return filename, path

def remove_uploaded_source_file(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except OSError:
        pass

def get_db():
    return db_module.get_wms_db()

def query_db(query, args=(), one=False):
    d = db_module.get_wms_db()
    cur = d.execute(query, args)
    rows = cur.fetchall()
    cur.close()
    return (rows[0] if rows else None) if one else rows

def resolve_product_identity(d, product_number='', bom_code=''):
    product_number = (product_number or '').strip()
    bom_code = (bom_code or '').strip()
    if product_number and bom_code:
        return product_number, bom_code
    if product_number:
        row = d.execute("""
            SELECT bom_code FROM warehouse_inventory
            WHERE product_number = ?
            ORDER BY updated_at DESC LIMIT 1
        """, (product_number,)).fetchone()
        if row:
            return product_number, row['bom_code']
        row = d.execute("""
            SELECT bom_code FROM product_master
            WHERE product_number = ?
            ORDER BY updated_at DESC LIMIT 1
        """, (product_number,)).fetchone()
        if row:
            return product_number, row['bom_code']
        row = d.execute("""
            SELECT bom_code FROM sku_master
            WHERE product_number = ?
            ORDER BY updated_at DESC LIMIT 1
        """, (product_number,)).fetchone()
        return product_number, row['bom_code'] if row else product_number
    if bom_code:
        row = d.execute("SELECT product_number FROM product_master WHERE bom_code = ? ORDER BY updated_at DESC LIMIT 1", (bom_code,)).fetchone()
        if not row:
            row = d.execute("SELECT product_number FROM sku_master WHERE bom_code = ?", (bom_code,)).fetchone()
        return (row['product_number'] if row and row['product_number'] else bom_code), bom_code
    return '', ''

def clean_text(value):
    return str(value or '').strip()

def clean_upper(value):
    return clean_text(value).upper()

def split_filter_values(value):
    return [normalize_dimension(v, 'category2') for v in re.split(r'[,;，；]+', str(value or '')) if v.strip()]

def split_dimension_filter(value, kind='generic'):
    return [normalize_dimension(v, kind) for v in re.split(r'[,;，；]+', str(value or '')) if v.strip()]

def safe_export_part(value, fallback='all'):
    text = re.sub(r'[^A-Za-z0-9\u4e00-\u9fff_-]+', '_', str(value or '').strip()).strip('_')
    return (text[:40] or fallback)

def maintenance_password_ok(password, allow_admin=True):
    if allow_admin and bool(getattr(g, 'is_admin', False)):
        return True
    return (password or '') == 'Q84405995'

def normalize_dimension(value, kind='generic'):
    text = re.sub(r'\s+', ' ', clean_upper(value)).strip()
    compact = re.sub(r'[\s/_-]+', '', text)
    if kind == 'category2':
        fixes = {
            'ADUIO': 'AUDIO',
            'AUDIO': 'AUDIO',
            'IOT': 'IOT',
            'OTHER': 'OTHER',
            'PHONE': 'PHONE',
            'TABLET': 'TABLET',
            'WEARABLE': 'WEARABLE',
        }
        return fixes.get(compact, text)
    if kind == 'category':
        fixes = {
            'ACRYLICPROP': 'ACRYLIC PROP',
            'DUMMY': 'DUMMY',
            'FURNITURE': 'FURNITURE',
            'GIFT': 'GIFT',
            'PROP': 'PROP',
            'SECURITYSYSTEM': 'SECURITY SYSTEM',
            'TOOLS/ACCESSORIES': 'TOOLS/ACCESSORIES',
            'TOOLSACCESSORIES': 'TOOLS/ACCESSORIES',
            'TOOLACCESSORIES': 'TOOLS/ACCESSORIES',
            'TRAININGMATERIALS': 'TRAINING MATERIALS',
            'UNIFORM': 'UNIFORM',
            'WOODENOVERLAY': 'WOODEN OVERLAY',
        }
        return fixes.get(compact, text)
    if kind == 'instruction':
        return compact if compact else text
    return text

def is_local_bom_code(value):
    text = clean_upper(value)
    compact = re.sub(r'[\s/_-]+', '', text)
    return text in {'/', '／'} or compact in {'本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', 'NOBOM', 'NOBOMCODE'}

LOCAL_BOM_SQL_EXPR = "REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, ''))), ' ', ''), '_', ''), '-', '')"
LOCAL_BOM_SQL_VALUES = "('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')"
LOCAL_WI_BOM_SQL = f"({LOCAL_BOM_SQL_EXPR} IN {LOCAL_BOM_SQL_VALUES} OR COALESCE(NULLIF(wi.bom_code, ''), '') = '')"

def clean_code(value):
    text = clean_upper(value)
    if re.fullmatch(r'.+\.0+', text):
        text = re.sub(r'\.0+$', '', text)
    return text

def code_match_expr(column):
    return f"REPLACE(REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE({column}, ''))), ' ', ''), '_', ''), '-', ''), '.0', '')"

def code_match_value(value):
    return re.sub(r'[\s_-]+', '', clean_code(value)).replace('.0', '')

def parse_operation_id(value):
    raw = clean_text(value)
    if not raw:
        return '', '', ''
    parts = [p for p in raw.split('_') if p]
    prefix = parts[0].upper() if parts else ''
    order_date = ''
    target_parts = parts[1:]
    if parts and re.fullmatch(r'\d{8}', parts[-1]):
        ddmmyyyy = parts[-1]
        order_date = f"{ddmmyyyy[4:8]}-{ddmmyyyy[2:4]}-{ddmmyyyy[0:2]}"
        target_parts = parts[1:-1]
    target = ' '.join(target_parts).strip()
    return prefix, target, order_date

def header_key(value):
    return clean_text(value).lower().replace(' ', '').replace('_', '')

def find_header_row(ws, required_headers, max_scan_rows=30, aliases=None):
    aliases = aliases or {}
    required = {header_key(h) for h in required_headers}
    alias_to_canonical = {}
    for canonical, names in aliases.items():
        canonical_key = header_key(canonical)
        for name in [canonical] + list(names):
            alias_to_canonical[header_key(name)] = canonical_key
    for row_idx in range(1, min(ws.max_row, max_scan_rows) + 1):
        values = [clean_text(ws.cell(row_idx, col).value) for col in range(1, ws.max_column + 1)]
        col_map = {}
        for idx, value in enumerate(values):
            if not value:
                continue
            key = header_key(value)
            col_map[key] = idx + 1
            if key in alias_to_canonical:
                col_map[alias_to_canonical[key]] = idx + 1
        if required.issubset(set(col_map)):
            return row_idx, col_map
    return None, {}

def get_cell(ws, row_idx, col_map, header_name):
    col = col_map.get(header_key(header_name))
    return ws.cell(row_idx, col).value if col else None

def to_int(value, default=0):
    try:
        if value is None or str(value).strip() == '':
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default

def to_int_strict(value):
    if value is None or str(value).strip() == '':
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None

def to_float(value, default=0):
    try:
        if value is None or str(value).strip() == '':
            return default
        return float(value)
    except (TypeError, ValueError):
        return default

def date_text(value):
    if value is None:
        return ''
    if hasattr(value, 'strftime'):
        return value.strftime('%Y-%m-%d')
    return clean_text(value)[:10]

def normalized_header(value):
    return re.sub(r'[^A-Z0-9]+', '', clean_text(value).upper())

def is_summary_row_value(value):
    text = clean_upper(value)
    normalized = normalized_header(text)
    return text in SUMMARY_ROW_MARKERS or normalized in {normalized_header(v) for v in SUMMARY_ROW_MARKERS}

def get_row_value_by_headers(row, header_map, header_name):
    idx = header_map.get(normalized_header(header_name))
    if idx is None or idx >= len(row):
        return None
    return row[idx]

def parse_date_text(value):
    if value is None or clean_text(value) == '':
        return ''
    if hasattr(value, 'strftime'):
        return value.strftime('%Y-%m-%d')
    text = clean_text(value)
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%d.%m.%Y', '%d/%m/%Y', '%m/%d/%Y'):
        try:
            return datetime.strptime(text[:10], fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    return text[:10]

def find_exact_header_map(ws, headers, max_scan_rows=10):
    required = [normalized_header(h) for h in headers]
    for row_idx in range(1, min(ws.max_row, max_scan_rows) + 1):
        values = [ws.cell(row_idx, col).value for col in range(1, ws.max_column + 1)]
        header_map = {}
        for idx, value in enumerate(values):
            key = normalized_header(value)
            if key:
                header_map[key] = idx
        if all(key in header_map for key in required[:8]):
            return row_idx, header_map
    return None, {}

def upsert_inventory_calibration_row(d, warehouse, data, report):
    bom_code = clean_code(data.get('Bom Code'))
    product_number = clean_code(data.get('Product Number'))
    if not product_number:
        report['skipped'] += 1
        return
    if is_summary_row_value(product_number) or is_summary_row_value(bom_code):
        report['skipped'] += 1
        return
    product_description = clean_text(data.get('Product Description'))
    category = normalize_dimension(data.get('Category'), 'category')
    category_2 = normalize_dimension(data.get('Category 2'), 'category2')
    instruction = normalize_dimension(data.get('Instruction'), 'instruction')
    inventory = to_int(data.get('Inventory (Pcs)'), 0)
    unit_price = to_float(data.get('Unit Price (USD)'), 0)
    ttl_amount = to_float(data.get('TTL Amount (USD)'), None)
    if ttl_amount is None:
        ttl_amount = inventory * unit_price
    last_inbound = parse_date_text(data.get('最近入库时间 Last Inbound date'))
    last_outbound = parse_date_text(data.get('最近出库时间 Last Outbound date'))
    comment = clean_text(data.get('备注 comment'))
    sku_created_at = parse_date_text(data.get('SKU条目创建时间'))
    if not last_inbound and sku_created_at:
        last_inbound = sku_created_at
    if not bom_code:
        bom_code = product_number

    existing_product = d.execute("SELECT 1 FROM product_master WHERE product_number = ?", (product_number,)).fetchone()
    existing_inv = d.execute("SELECT inventory FROM warehouse_inventory WHERE warehouse = ? AND product_number = ?",
                             (warehouse, product_number)).fetchone()
    old_qty = existing_inv['inventory'] if existing_inv else None

    d.execute("""INSERT INTO product_master
                    (product_number, bom_code, product_description, category, category_2, unit_price,
                     last_inbound_date, last_outbound_date, remark, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, COALESCE(NULLIF(?, ''), CURRENT_TIMESTAMP), CURRENT_TIMESTAMP)
                 ON CONFLICT(product_number) DO UPDATE SET
                    bom_code=excluded.bom_code,
                    product_description=excluded.product_description,
                    category=excluded.category,
                    category_2=excluded.category_2,
                    unit_price=CASE
                        WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                        ELSE product_master.unit_price
                    END,
                    last_inbound_date=COALESCE(excluded.last_inbound_date, product_master.last_inbound_date),
                    last_outbound_date=COALESCE(excluded.last_outbound_date, product_master.last_outbound_date),
                    remark=excluded.remark,
                    updated_at=CURRENT_TIMESTAMP""",
              (product_number, bom_code, product_description, category, category_2, unit_price,
               last_inbound or None, last_outbound or None, comment, sku_created_at or None))
    if not is_local_bom_code(bom_code):
        d.execute("""INSERT INTO sku_master
                        (bom_code, product_number, product_description, category, category_2, unit_price, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(bom_code) DO UPDATE SET
                        product_number=excluded.product_number,
                        product_description=excluded.product_description,
                        category=excluded.category,
                        category_2=excluded.category_2,
                        unit_price=CASE
                            WHEN COALESCE(excluded.unit_price, 0) > 0 THEN excluded.unit_price
                            ELSE sku_master.unit_price
                        END,
                        updated_at=CURRENT_TIMESTAMP""",
                  (bom_code, product_number, product_description, category, category_2, unit_price))
    d.execute("""INSERT INTO warehouse_inventory
                    (warehouse, bom_code, product_number, instruction, inventory, last_inbound_date, last_outbound_date, comment, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                 ON CONFLICT(warehouse, product_number) DO UPDATE SET
                    bom_code=excluded.bom_code,
                    instruction=excluded.instruction,
                    inventory=excluded.inventory,
                    last_inbound_date=COALESCE(excluded.last_inbound_date, warehouse_inventory.last_inbound_date),
                    last_outbound_date=COALESCE(excluded.last_outbound_date, warehouse_inventory.last_outbound_date),
                    comment=excluded.comment,
                    updated_at=CURRENT_TIMESTAMP""",
              (warehouse, bom_code, product_number, instruction, inventory, last_inbound or None, last_outbound or None, comment))
    if old_qty != inventory:
        report['inventory_changed'] += 1
        if old_qty is not None:
            d.execute("""INSERT INTO inventory_transactions (warehouse, bom_code, product_number, change_type, quantity_change, comment)
                         VALUES (?, ?, ?, 'calibration', ?, ?)""",
                      (warehouse, bom_code, product_number, inventory - old_qty, f"库存校准 Excel: {old_qty} → {inventory}"))
    if existing_product:
        report['updated'] += 1
    else:
        report['created'] += 1
    report['imported'] += 1

def code_key(value):
    return re.sub(r'[^A-Z0-9]+', '', clean_code(value))

def image_code_candidates(filename_or_code):
    stem = os.path.splitext(os.path.basename(clean_text(filename_or_code)))[0].strip()
    stem = re.sub(r'\s*\(\d+\)$', '', stem).strip()
    candidates = [stem]
    if '_' in stem:
        candidates.append(stem.split('_', 1)[1].strip())
    if '-' in stem:
        candidates.append(stem.split('-', 1)[1].strip())
    seen = set()
    result = []
    for c in candidates:
        key = code_key(c)
        if c and key and key not in seen:
            result.append(clean_code(c))
            seen.add(key)
    return result

def is_summary_product_number(product_number):
    text = clean_upper(product_number)
    summary_tokens = ('SUMA', 'TOTAL', '汇总', 'KONCOWA', 'KOŃCOWA', 'GRANDTOTAL')
    compact = header_key(text)
    return any(token in text for token in summary_tokens) or 'grandtotal' in compact

def find_existing_image_filename(code):
    target = code_key(code)
    if not target:
        return None
    folder = current_app.config['UPLOAD_FOLDER']
    if not os.path.exists(folder):
        return None
    for name in os.listdir(folder):
        if not allowed_file(name):
            continue
        stem_key = code_key(os.path.splitext(name)[0])
        if stem_key == target or stem_key.endswith(target):
            return name
    return None

def clear_image_folder(folder):
    deleted = 0
    failed = []
    if not folder or not os.path.exists(folder):
        return deleted, failed
    base = os.path.abspath(folder)
    for root, dirs, files in os.walk(base, topdown=False):
        for name in files:
            path = os.path.abspath(os.path.join(root, name))
            if not path.startswith(base + os.sep):
                continue
            try:
                os.remove(path)
                deleted += 1
            except OSError:
                failed.append(name)
        for name in dirs:
            path = os.path.abspath(os.path.join(root, name))
            if not path.startswith(base + os.sep):
                continue
            try:
                os.rmdir(path)
            except OSError:
                pass
    return deleted, failed

def image_key_for_sku(bom_code, product_number):
    bom_code = clean_code(bom_code)
    product_number = clean_code(product_number)
    if product_number and (not bom_code or is_local_bom_code(bom_code)):
        return product_number
    return bom_code or product_number

def repair_image_mappings(d):
    rows = d.execute("""
        SELECT bom_code, product_number
        FROM product_master
        UNION
        SELECT bom_code, product_number
        FROM warehouse_inventory
    """).fetchall()
    repaired = 0
    for row in rows:
        bom_code = clean_code(row['bom_code'])
        product_number = clean_code(row['product_number'])
        match_code = image_key_for_sku(bom_code, product_number)
        if not match_code:
            continue
        filename = find_existing_image_filename(match_code)
        if not filename:
            continue
        image_bom_key = image_key_for_sku(bom_code, product_number)
        d.execute("""INSERT INTO sku_master (bom_code, product_number, image_path, updated_at)
                     VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                     ON CONFLICT(bom_code) DO UPDATE SET
                         product_number=COALESCE(NULLIF(excluded.product_number, ''), product_number),
                         image_path=excluded.image_path,
                         updated_at=CURRENT_TIMESTAMP""",
                  (image_bom_key, product_number, filename))
        repaired += 1
    return repaired

def resolve_image_bom(d, filename_or_code):
    candidates = image_code_candidates(filename_or_code)
    for candidate in candidates:
        row = d.execute("""
            SELECT product_number, bom_code FROM product_master WHERE UPPER(TRIM(product_number)) = UPPER(TRIM(?))
            UNION
            SELECT product_number, bom_code FROM warehouse_inventory WHERE UPPER(TRIM(product_number)) = UPPER(TRIM(?))
            LIMIT 1
        """, (candidate, candidate)).fetchone()
        if row:
            return image_key_for_sku(row['bom_code'], row['product_number'])
        row = d.execute("""
            SELECT bom_code FROM sku_master WHERE UPPER(TRIM(bom_code)) = UPPER(TRIM(?))
            UNION
            SELECT bom_code FROM product_master WHERE UPPER(TRIM(bom_code)) = UPPER(TRIM(?))
            UNION
            SELECT bom_code FROM product_master WHERE UPPER(TRIM(product_number)) = UPPER(TRIM(?))
            UNION
            SELECT bom_code FROM warehouse_inventory WHERE UPPER(TRIM(product_number)) = UPPER(TRIM(?))
            LIMIT 1
        """, (candidate, candidate, candidate, candidate)).fetchone()
        if row:
            return row['bom_code']
        key = code_key(candidate)
        row = d.execute("""
            SELECT product_number, bom_code FROM product_master WHERE {expr_product} = ?
            UNION
            SELECT product_number, bom_code FROM warehouse_inventory WHERE {expr_inv} = ?
            LIMIT 1
        """.format(expr_product=code_match_expr('product_number'), expr_inv=code_match_expr('product_number')),
            (key, key)).fetchone()
        if row:
            return image_key_for_sku(row['bom_code'], row['product_number'])
        row = d.execute("""
            SELECT bom_code FROM sku_master WHERE REPLACE(REPLACE(REPLACE(UPPER(TRIM(bom_code)), ' ', ''), '_', ''), '-', '') = ?
            UNION
            SELECT bom_code FROM product_master WHERE REPLACE(REPLACE(REPLACE(UPPER(TRIM(bom_code)), ' ', ''), '_', ''), '-', '') = ?
            LIMIT 1
        """, (key, key)).fetchone()
        if row:
            return row['bom_code']
        rows = d.execute("""
            SELECT bom_code FROM sku_master
            UNION
            SELECT bom_code FROM product_master
            UNION
            SELECT bom_code FROM warehouse_inventory
        """).fetchall()
        for row in rows:
            if code_key(row['bom_code']) == key:
                return row['bom_code']
    return None
