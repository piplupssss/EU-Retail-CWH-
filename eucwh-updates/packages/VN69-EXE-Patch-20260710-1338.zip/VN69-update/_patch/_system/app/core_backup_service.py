import io
import os
import re
import sqlite3
import tempfile
import zipfile
from datetime import datetime

from flask import current_app
from werkzeug.utils import secure_filename

from . import db as db_module
from .export_service import short_export_filename, style_simple_sheet, workbook_bytes
from .logistics_service import get_db
from .update_service import APP_VERSION


class CoreBackupImportError(Exception):
    def __init__(self, message, status_code=400):
        super().__init__(message)
        self.status_code = status_code


def backup_is_local_bom(value):
    text = str(value or '').strip().upper()
    compact = re.sub(r'[\s/_-]+', '', text)
    return text in {'/', '／'} or compact in {'本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', 'NOBOM', 'NOBOMCODE'}


def normalize_backup_bom(value):
    text = str(value or '').strip()
    return '/' if not text or backup_is_local_bom(text) else text


def table_columns(conn, table):
    return {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def rows_from_sheet(wb, title):
    if title not in wb.sheetnames:
        return []
    ws = wb[title]
    headers = [str(c.value or '').strip() for c in ws[1]]
    rows = []
    for values in ws.iter_rows(min_row=2, values_only=True):
        if not any(v not in (None, '') for v in values):
            continue
        rows.append({headers[i]: values[i] if i < len(values) else '' for i in range(len(headers)) if headers[i]})
    return rows


def upsert_by_key(conn, table, key_cols, row):
    cols = table_columns(conn, table)
    data = {k: v for k, v in row.items() if k in cols and k != 'id'}
    if not all(str(data.get(k) or '').strip() for k in key_cols):
        return 'skipped'
    where = ' AND '.join([f"{k}=?" for k in key_cols])
    keys = [data[k] for k in key_cols]
    exists = conn.execute(f"SELECT 1 FROM {table} WHERE {where} LIMIT 1", keys).fetchone()
    if exists:
        update_cols = [c for c in data.keys() if c not in key_cols]
        if update_cols:
            assignments = []
            values = []
            for col in update_cols:
                if table == 'product_master' and col == 'unit_price':
                    assignments.append("unit_price = CASE WHEN COALESCE(?, 0) > 0 THEN ? ELSE unit_price END")
                    values.extend([data[col], data[col]])
                elif table == 'shipments' and col in ('actual_delivery_date', 'manual_status'):
                    assignments.append(f"{col} = COALESCE(NULLIF(?, ''), {col})")
                    values.append(data[col])
                elif table == 'shipments' and col == 'delivery_locked':
                    assignments.append("delivery_locked = CASE WHEN COALESCE(?, 0) IN (1, '1', 'Y', 'YES', 'TRUE', '是') THEN 1 ELSE delivery_locked END")
                    values.append(data[col])
                else:
                    assignments.append(col + '=?')
                    values.append(data[col])
            conn.execute(f"UPDATE {table} SET {', '.join(assignments)} WHERE {where}", values + keys)
        return 'updated'
    insert_cols = list(data.keys())
    conn.execute(f"INSERT INTO {table} ({', '.join(insert_cols)}) VALUES ({', '.join(['?'] * len(insert_cols))})",
                 [data[col] for col in insert_cols])
    return 'created'


def collect_full_package_image_paths(wms_database_path):
    conn = sqlite3.connect(wms_database_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("""
            SELECT DISTINCT COALESCE(pimg.image_path, sm.image_path) AS image_path
            FROM warehouse_inventory wi
            LEFT JOIN product_master pm ON wi.product_number = pm.product_number
            LEFT JOIN sku_master sm ON COALESCE(NULLIF(wi.bom_code, ''), pm.bom_code) = sm.bom_code
                AND NOT (
                    REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                    OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
                )
            LEFT JOIN sku_master pimg ON (
                REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
            ) AND wi.product_number = pimg.bom_code
            WHERE COALESCE(COALESCE(pimg.image_path, sm.image_path), '') <> ''
        """).fetchall()
        return [r['image_path'] for r in rows if r['image_path']]
    finally:
        conn.close()


def create_full_package_zip(scope='all', warehouse=''):
    export_all = scope == 'all' or not warehouse
    label = 'full_all' if export_all else 'full_current'
    zip_path = os.path.join(tempfile.gettempdir(), short_export_filename(label, 'zip', include_time=True))
    image_files = collect_full_package_image_paths(current_app.config['WMS_DATABASE'])

    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        backup_wb = build_core_backup_workbook()
        zf.writestr('core_backup_no_images.xlsx', workbook_bytes(backup_wb))
        upload_dir = current_app.config['UPLOAD_FOLDER']
        for image_path in sorted(set(image_files)):
            source = os.path.join(upload_dir, image_path)
            if os.path.exists(source) and os.path.isfile(source):
                zf.write(source, f'images/{os.path.basename(image_path)}')
    return zip_path


def build_core_backup_workbook():
    from openpyxl import Workbook
    main_db = get_db()
    wms_conn = sqlite3.connect(current_app.config['WMS_DATABASE'])
    wms_conn.row_factory = sqlite3.Row
    wb = Workbook()

    def add_sheet(title, headers, rows):
        ws = wb.active if len(wb.sheetnames) == 1 and wb.active.max_row == 1 and wb.active.max_column == 1 and wb.active['A1'].value is None else wb.create_sheet()
        ws.title = title[:31]
        for col_idx, header in enumerate(headers, 1):
            ws.cell(1, col_idx, str(header))
        for row in rows:
            ws.append([row.get(h, '') if isinstance(row, dict) else row[h] if h in row.keys() else '' for h in headers])
        style_simple_sheet(ws)
        return ws

    try:
        shipment_headers = ['booking_id', 'stt_number', 'waybill_no', 'shipment_status', 'manual_status', 'shipment_type', 'warehouse', 'demand_country', 'demand_country_source', 'consignee_country_code', 'consignee_name', 'consignee_city', 'pickup_date', 'delivery_date', 'actual_delivery_date', 'delivery_locked', 'total_pieces', 'total_weight', 'total_volume', 'price_without_vat', 'product', 'source_file', 'recycled_at', 'recycle_reason', 'import_time']
        add_sheet('物流底表', shipment_headers, main_db.execute(f"SELECT {', '.join(shipment_headers)} FROM shipments ORDER BY pickup_date DESC, booking_id").fetchall())

        invoice_headers = ['invoice_number', 'invoice_date', 'invoice_type', 'currency', 'status', 'stt_number', 'net_amount', 'ref_date', 'matched_booking_id', 'accepted_amount', 'acceptance_status', 'exception_reason', 'acceptance_remark']
        add_sheet('发票验收底表', invoice_headers, main_db.execute("""
            SELECT h.invoice_number, h.invoice_date, h.invoice_type, h.currency, h.status,
                   i.stt_number, i.net_amount, i.ref_date, i.matched_booking_id,
                   i.accepted_amount, i.acceptance_status, i.exception_reason, i.acceptance_remark
            FROM invoice_items i JOIN invoice_headers h ON i.invoice_id = h.id
            ORDER BY h.invoice_date DESC, h.invoice_number, i.id
        """).fetchall())

        inventory_headers = ['warehouse', 'bom_code', 'product_number', 'product_description', 'category', 'category_2', 'instruction', 'inventory', 'unit_price', 'ttl_amount', 'last_inbound_date', 'last_outbound_date', 'dos_threshold', 'idle_threshold', 'comment', 'updated_at']
        add_sheet('库存底表', inventory_headers, wms_conn.execute("""
            SELECT wi.warehouse, wi.bom_code, wi.product_number, pm.product_description, pm.category, pm.category_2,
                   wi.instruction, wi.inventory, pm.unit_price, COALESCE(pm.unit_price,0) * COALESCE(wi.inventory,0) AS ttl_amount,
                   wi.last_inbound_date, wi.last_outbound_date, pm.dos_threshold, pm.idle_threshold, wi.comment, wi.updated_at
            FROM warehouse_inventory wi LEFT JOIN product_master pm ON wi.product_number = pm.product_number
            ORDER BY wi.warehouse, wi.product_number
        """).fetchall())

        sku_headers = ['product_number', 'bom_code', 'product_description', 'category', 'category_2', 'unit_price', 'last_inbound_date', 'last_outbound_date', 'remark', 'dos_threshold', 'idle_threshold', 'created_at', 'updated_at']
        add_sheet('SKU主数据', sku_headers, wms_conn.execute(f"SELECT {', '.join(sku_headers)} FROM product_master ORDER BY product_number").fetchall())

        movement_headers = ['movement_type', 'sheet_name', 'product_number', 'movement_date', 'operation_id', 'operation_prefix', 'operation_target', 'order_date', 'quantity', 'uom', 'source_file', 'created_at']
        add_sheet('出入库流水', movement_headers, wms_conn.execute(f"SELECT {', '.join(movement_headers)} FROM inventory_movements ORDER BY movement_date DESC, product_number").fetchall())

        meta = [{'key': 'version', 'value': APP_VERSION}, {'key': 'export_time', 'value': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}, {'key': 'images', 'value': 'not included'}]
        add_sheet('版本信息', ['key', 'value'], meta)
        return wb
    finally:
        wms_conn.close()


def load_core_backup_workbook(file_storage, filename):
    from openpyxl import load_workbook

    extracted_zip_images = []
    if filename.lower().endswith('.zip'):
        raw = file_storage.read()
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            candidate = None
            for name in zf.namelist():
                if os.path.basename(name).lower() == 'core_backup_no_images.xlsx':
                    candidate = name
                    break
            if not candidate:
                raise CoreBackupImportError('ZIP 中未找到 core_backup_no_images.xlsx', 400)
            for name in zf.namelist():
                base = os.path.basename(name)
                ext = base.rsplit('.', 1)[-1].lower() if '.' in base else ''
                if not name.lower().startswith('images/') or not base or ext not in {'png', 'jpg', 'jpeg', 'gif', 'webp'}:
                    continue
                extracted_zip_images.append((base, zf.read(name)))
            return load_workbook(io.BytesIO(zf.read(candidate)), data_only=True), extracted_zip_images
    return load_workbook(file_storage, data_only=True), extracted_zip_images


def restore_zip_images(wms_conn, extracted_zip_images):
    image_report = {'extracted': 0, 'mapped': 0, 'skipped': 0}
    if not extracted_zip_images:
        return image_report

    image_dir = current_app.config['UPLOAD_FOLDER']
    os.makedirs(image_dir, exist_ok=True)
    for base, content in extracted_zip_images:
        safe_name = secure_filename(base) or base
        ext = safe_name.rsplit('.', 1)[-1].lower() if '.' in safe_name else ''
        if ext not in {'png', 'jpg', 'jpeg', 'gif', 'webp'}:
            image_report['skipped'] += 1
            continue
        target = os.path.abspath(os.path.join(image_dir, safe_name))
        if not target.startswith(os.path.abspath(image_dir) + os.sep):
            image_report['skipped'] += 1
            continue
        with open(target, 'wb') as img_file:
            img_file.write(content)
        image_report['extracted'] += 1
    try:
        from .inventory_service import repair_image_mappings
        image_report['mapped'] = repair_image_mappings(wms_conn)
    except Exception as image_error:
        image_report['error'] = str(image_error)
    return image_report


def import_core_backup_file(file_storage, filename):
    db_module.backup_sqlite_db(current_app.config['DATABASE'], 'before_core_backup_import_main')
    db_module.backup_sqlite_db(current_app.config['WMS_DATABASE'], 'before_core_backup_import_wms')

    wms_conn = None
    wb, extracted_zip_images = load_core_backup_workbook(file_storage, filename)
    main_db = get_db()
    wms_conn = sqlite3.connect(current_app.config['WMS_DATABASE'])
    wms_conn.row_factory = sqlite3.Row
    report = {'shipments': {}, 'invoices': {}, 'inventory': {}, 'sku': {}, 'movements': {}}

    try:
        import_shipments(main_db, wb, report)
        import_invoices(main_db, wb, report)
        import_inventory(wms_conn, wb, report)
        import_sku_master(wms_conn, wb, report)
        import_movements(wms_conn, wb, report)
        report['images'] = restore_zip_images(wms_conn, extracted_zip_images)

        main_db.commit()
        wms_conn.commit()
        return report
    finally:
        if wms_conn is not None:
            wms_conn.close()


def increment_report(report, section, result):
    report[section][result] = report[section].get(result, 0) + 1


def import_shipments(main_db, wb, report):
    for row in rows_from_sheet(wb, '物流底表'):
        row = dict(row)
        if not str(row.get('shipment_status') or '').strip():
            row['shipment_status'] = 'Active'
        result = upsert_by_key(main_db, 'shipments', ['booking_id'], row)
        increment_report(report, 'shipments', result)


def import_invoices(main_db, wb, report):
    invoice_cache = {}
    for row in rows_from_sheet(wb, '发票验收底表'):
        invoice_number = str(row.get('invoice_number') or '').strip()
        stt = str(row.get('stt_number') or '').strip()
        if not invoice_number or not stt:
            increment_report(report, 'invoices', 'skipped')
            continue
        if invoice_number not in invoice_cache:
            main_db.execute("""
                INSERT INTO invoice_headers (invoice_number, invoice_date, invoice_type, currency, status, total_net, source_file)
                VALUES (?, ?, ?, ?, ?, 0, ?)
                ON CONFLICT(invoice_number) DO UPDATE SET
                    invoice_date=excluded.invoice_date,
                    invoice_type=excluded.invoice_type,
                    currency=excluded.currency,
                    status=excluded.status
            """, (invoice_number, row.get('invoice_date'), row.get('invoice_type') or 'logistics',
                  row.get('currency') or 'PLN', row.get('status') or 'pending', 'core_backup_import'))
            invoice_cache[invoice_number] = main_db.execute("SELECT id FROM invoice_headers WHERE invoice_number=?", (invoice_number,)).fetchone()['id']
        invoice_id = invoice_cache[invoice_number]
        exists = main_db.execute("SELECT id FROM invoice_items WHERE invoice_id=? AND stt_number=? AND COALESCE(ref_date,'')=COALESCE(?, '')",
                                 (invoice_id, stt, row.get('ref_date'))).fetchone()
        if exists:
            main_db.execute("""UPDATE invoice_items
                               SET net_amount=?, matched_booking_id=?, accepted_amount=?,
                                   acceptance_status=?, exception_reason=?, acceptance_remark=?
                               WHERE id=?""",
                            (
                                row.get('net_amount') or 0, row.get('matched_booking_id'),
                                row.get('accepted_amount'), row.get('acceptance_status'),
                                row.get('exception_reason'), row.get('acceptance_remark'), exists['id']
                            ))
            result = 'updated'
        else:
            main_db.execute("""INSERT INTO invoice_items (
                                  invoice_id, stt_number, net_amount, ref_date, matched_booking_id,
                                  accepted_amount, acceptance_status, exception_reason, acceptance_remark
                               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            (
                                invoice_id, stt, row.get('net_amount') or 0, row.get('ref_date'), row.get('matched_booking_id'),
                                row.get('accepted_amount'), row.get('acceptance_status'),
                                row.get('exception_reason'), row.get('acceptance_remark')
                            ))
            result = 'created'
        increment_report(report, 'invoices', result)
    for invoice_number, invoice_id in invoice_cache.items():
        total = main_db.execute("SELECT COALESCE(SUM(net_amount), 0) AS total FROM invoice_items WHERE invoice_id=?", (invoice_id,)).fetchone()['total']
        main_db.execute("UPDATE invoice_headers SET total_net=? WHERE id=?", (total, invoice_id))


def import_inventory(wms_conn, wb, report):
    for row in rows_from_sheet(wb, '库存底表'):
        product_number = str(row.get('product_number') or '').strip()
        warehouse = str(row.get('warehouse') or '').strip()
        if not product_number or not warehouse:
            increment_report(report, 'inventory', 'skipped')
            continue
        bom = normalize_backup_bom(row.get('bom_code'))
        pm = {
            'product_number': product_number,
            'bom_code': bom,
            'product_description': row.get('product_description'),
            'category': row.get('category'),
            'category_2': row.get('category_2'),
            'unit_price': row.get('unit_price') or 0,
            'last_inbound_date': row.get('last_inbound_date'),
            'last_outbound_date': row.get('last_outbound_date'),
            'remark': row.get('comment'),
            'dos_threshold': row.get('dos_threshold') or 180,
            'idle_threshold': row.get('idle_threshold') or 180,
        }
        inv = {
            'warehouse': warehouse,
            'product_number': product_number,
            'bom_code': bom,
            'instruction': row.get('instruction'),
            'inventory': row.get('inventory') or 0,
            'last_inbound_date': row.get('last_inbound_date'),
            'last_outbound_date': row.get('last_outbound_date'),
            'comment': row.get('comment'),
        }
        upsert_by_key(wms_conn, 'product_master', ['product_number'], pm)
        result = upsert_by_key(wms_conn, 'warehouse_inventory', ['warehouse', 'product_number'], inv)
        increment_report(report, 'inventory', result)


def import_sku_master(wms_conn, wb, report):
    for row in rows_from_sheet(wb, 'SKU主数据'):
        row['bom_code'] = normalize_backup_bom(row.get('bom_code'))
        result = upsert_by_key(wms_conn, 'product_master', ['product_number'], row)
        increment_report(report, 'sku', result)


def import_movements(wms_conn, wb, report):
    for row in rows_from_sheet(wb, '出入库流水'):
        product_number = str(row.get('product_number') or '').strip()
        if not product_number:
            increment_report(report, 'movements', 'skipped')
            continue
        exists = wms_conn.execute("""
            SELECT id FROM inventory_movements
            WHERE movement_type=? AND product_number=? AND COALESCE(movement_date,'')=COALESCE(?, '') AND COALESCE(operation_id,'')=COALESCE(?, '')
            LIMIT 1
        """, (row.get('movement_type'), product_number, row.get('movement_date'), row.get('operation_id'))).fetchone()
        if exists:
            increment_report(report, 'movements', 'skipped_existing')
            continue
        row = {k: v for k, v in row.items() if k in table_columns(wms_conn, 'inventory_movements') and k != 'id'}
        cols = list(row.keys())
        wms_conn.execute(f"INSERT INTO inventory_movements ({', '.join(cols)}) VALUES ({', '.join(['?'] * len(cols))})", [row[col] for col in cols])
        increment_report(report, 'movements', 'created')
