import re
from datetime import datetime

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from .inventory_service import (
    clean_text,
    clean_upper,
    get_db,
    normalize_dimension,
    split_dimension_filter,
)
from .export_service import excel_width_from_pixels, short_export_filename


def valid_date(value):
    value = clean_text(value)
    if not value:
        return ''
    try:
        return datetime.strptime(value, '%Y-%m-%d').strftime('%Y-%m-%d')
    except ValueError:
        return ''


def parse_movement_filters(args, include_pagination=False, include_sort=False):
    movement_type = clean_text(args.get('movement_type', '')).lower()
    if movement_type not in ('', 'inbound', 'outbound'):
        movement_type = ''
    filters = {
        'movement_type': movement_type,
        'search': clean_text(args.get('q', '')),
        'warehouse': clean_text(args.get('warehouse', '')),
        'start_date': valid_date(args.get('start_date', '')),
        'end_date': valid_date(args.get('end_date', '')),
        'category_values': split_dimension_filter(args.get('category', ''), 'category'),
        'category2_values': split_dimension_filter(args.get('category2', ''), 'category2'),
        'instruction_values': split_dimension_filter(args.get('instruction', ''), 'instruction'),
    }
    if include_pagination:
        filters['page'] = max(1, args.get('page', 1, type=int))
        filters['per_page'] = min(max(10, args.get('per_page', 20, type=int)), 100)
    if include_sort:
        filters['sort_by'] = clean_text(args.get('sort_by', 'movement_date'))
        filters['sort_dir'] = 'ASC' if clean_text(args.get('sort_dir', 'desc')).lower() == 'asc' else 'DESC'
    return filters


def build_movement_where(filters, include_search=False):
    where = ["1=1"]
    params = []
    if filters['movement_type']:
        where.append("LOWER(im.movement_type) = ?")
        params.append(filters['movement_type'])
    if filters['start_date']:
        where.append("date(im.movement_date) >= date(?)")
        params.append(filters['start_date'])
    if filters['end_date']:
        where.append("date(im.movement_date) <= date(?)")
        params.append(filters['end_date'])
    if filters['warehouse']:
        where.append("wi.warehouse = ?")
        params.append(filters['warehouse'])
    if filters['category_values']:
        where.append("UPPER(TRIM(COALESCE(pm.category, ''))) IN ({})".format(','.join('?' for _ in filters['category_values'])))
        params.extend(filters['category_values'])
    if filters['category2_values']:
        where.append("UPPER(TRIM(COALESCE(pm.category_2, ''))) IN ({})".format(','.join('?' for _ in filters['category2_values'])))
        params.extend(filters['category2_values'])
    if filters['instruction_values']:
        where.append("UPPER(TRIM(COALESCE(wi.instruction, ''))) IN ({})".format(','.join('?' for _ in filters['instruction_values'])))
        params.extend(filters['instruction_values'])
    if include_search and filters.get('search'):
        like = f"%{filters['search'].upper()}%"
        where.append("""(
            UPPER(COALESCE(im.product_number, '')) LIKE ?
            OR UPPER(COALESCE(im.operation_id, '')) LIKE ?
            OR UPPER(COALESCE(im.operation_target, '')) LIKE ?
            OR UPPER(COALESCE(pm.product_description, '')) LIKE ?
            OR UPPER(COALESCE(pm.bom_code, wi.bom_code, '')) LIKE ?
        )""")
        params.extend([like] * 5)
    return where, params


def movement_base_sql(where):
    return f"""
        FROM inventory_movements im
        LEFT JOIN product_master pm ON im.product_number = pm.product_number
        LEFT JOIN warehouse_inventory wi ON im.product_number = wi.product_number
        WHERE {' AND '.join(where)}
        GROUP BY im.id
    """


def movement_label(value):
    value = clean_text(value).lower()
    if value == 'inbound':
        return '入库'
    if value == 'outbound':
        return '出库'
    return value or '/'


def query_inventory_movements(args):
    filters = parse_movement_filters(args, include_pagination=True, include_sort=True)
    where, params = build_movement_where(filters, include_search=True)
    d = get_db()
    base_sql = movement_base_sql(where)
    total = d.execute(f"SELECT COUNT(*) AS cnt FROM (SELECT im.id {base_sql})", params).fetchone()['cnt']
    sort_columns = {
        'movement_date': 'date(im.movement_date)',
        'movement_type': 'LOWER(im.movement_type)',
        'product_number': 'UPPER(im.product_number)',
        'product_description': 'UPPER(pm.product_description)',
        'category': 'UPPER(pm.category)',
        'category_2': 'UPPER(pm.category_2)',
        'instruction': "UPPER(GROUP_CONCAT(DISTINCT UPPER(TRIM(COALESCE(wi.instruction, '')))))",
        'warehouse': 'UPPER(GROUP_CONCAT(DISTINCT wi.warehouse))',
        'operation_id': 'UPPER(im.operation_id)',
        'operation_target': 'UPPER(im.operation_target)',
        'quantity': 'CAST(im.quantity AS REAL)',
        'current_inventory': 'SUM(COALESCE(wi.inventory, 0))',
        'value_usd': '(COALESCE(pm.unit_price, 0) * ABS(CAST(COALESCE(im.quantity, 0) AS REAL)))',
    }
    order_expr = sort_columns.get(filters['sort_by'], 'date(im.movement_date)')
    rows = d.execute(f"""
        SELECT im.id,
               im.movement_type,
               im.sheet_name,
               im.product_number,
               im.movement_date,
               im.operation_id,
               im.operation_prefix,
               im.operation_target,
               im.quantity,
               im.source_file,
               COALESCE(pm.bom_code, wi.bom_code, '') AS bom_code,
               COALESCE(pm.product_description, '') AS product_description,
               COALESCE(pm.category, '') AS category,
               COALESCE(pm.category_2, '') AS category_2,
               GROUP_CONCAT(DISTINCT wi.warehouse) AS warehouses,
               GROUP_CONCAT(DISTINCT UPPER(TRIM(COALESCE(wi.instruction, '')))) AS instructions,
               SUM(COALESCE(wi.inventory, 0)) AS current_inventory,
               COALESCE(pm.unit_price, 0) AS unit_price
        {base_sql}
        ORDER BY {order_expr} {filters['sort_dir']}, im.id DESC
        LIMIT ? OFFSET ?
    """, params + [filters['per_page'], (filters['page'] - 1) * filters['per_page']]).fetchall()

    items = []
    for row in rows:
        item = dict(row)
        item['movement_label'] = movement_label(item.get('movement_type'))
        item['value_usd'] = round(float(item.get('unit_price') or 0) * abs(float(item.get('quantity') or 0)), 2)
        items.append(item)

    return {
        'items': items,
        'total': total,
        'page': filters['page'],
        'per_page': filters['per_page'],
        'pages': (total + filters['per_page'] - 1) // filters['per_page'] if filters['per_page'] else 1
    }


def query_inventory_movement_export_rows(filters):
    where, params = build_movement_where(filters, include_search=False)
    d = get_db()
    rows = d.execute(f"""
        SELECT im.id,
               im.movement_type,
               im.sheet_name,
               im.product_number,
               im.movement_date,
               im.operation_id,
               im.operation_prefix,
               im.operation_target,
               im.order_date,
               im.quantity,
               im.uom,
               im.source_file,
               im.created_at,
               COALESCE(pm.bom_code, wi.bom_code, '') AS bom_code,
               COALESCE(pm.product_description, '') AS product_description,
               COALESCE(pm.category, '') AS category,
               COALESCE(pm.category_2, '') AS category_2,
               GROUP_CONCAT(DISTINCT wi.warehouse) AS warehouses,
               GROUP_CONCAT(DISTINCT UPPER(TRIM(COALESCE(wi.instruction, '')))) AS instructions,
               SUM(COALESCE(wi.inventory, 0)) AS current_inventory,
               COALESCE(pm.unit_price, 0) AS unit_price
        FROM inventory_movements im
        LEFT JOIN product_master pm ON im.product_number = pm.product_number
        LEFT JOIN warehouse_inventory wi ON im.product_number = wi.product_number
        WHERE {' AND '.join(where)}
        GROUP BY im.id
        ORDER BY date(im.movement_date) DESC, im.id DESC
    """, params).fetchall()
    return [dict(r) for r in rows]


def order_type_label(prefix, operation_id):
    prefix_text = clean_upper(prefix)
    operation_text = clean_text(operation_id)
    if prefix_text == 'PL':
        label = 'PL订单'
    elif prefix_text == 'EU':
        label = '地区部订单'
    else:
        label = clean_text(prefix) or '/'
    return '/' if operation_text and operation_text == label else label


def movement_export_filename(warehouse, start_date, end_date):
    return short_export_filename('movements')


def build_inventory_movements_workbook(args):
    filters = parse_movement_filters(args)
    rows = query_inventory_movement_export_rows(filters)
    wb = openpyxl.Workbook()
    summary_ws = wb.active
    summary_ws.title = '统计总览'
    detail_ws = wb.create_sheet('出入库流水')
    detail_ws.sheet_format.defaultRowHeight = 42

    dark = '1F2937'
    blue = '2563EB'
    green = '059669'
    orange = 'D97706'
    muted = '64748B'
    header_fill = PatternFill('solid', fgColor=dark)
    detail_header_fill = PatternFill('solid', fgColor='EAF1FF')
    sub_fill = PatternFill('solid', fgColor='EAF1FF')
    thin = Side(style='thin', color='CBD5E1')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    inbound_qty = sum(float(r.get('quantity') or 0) for r in rows if clean_text(r.get('movement_type')).lower() == 'inbound')
    outbound_qty = sum(float(r.get('quantity') or 0) for r in rows if clean_text(r.get('movement_type')).lower() == 'outbound')
    sku_count = len({clean_upper(r.get('product_number')) for r in rows if r.get('product_number')})
    value_total = sum(float(r.get('unit_price') or 0) * abs(float(r.get('quantity') or 0)) for r in rows)
    wh_label = filters['warehouse'] or '全部仓库'
    date_label = f"{filters['start_date'] or '不限'} 至 {filters['end_date'] or '不限'}"

    summary_ws.merge_cells('A1:H1')
    summary_ws['A1'] = '出入库流水导出'
    summary_ws['A1'].font = Font(bold=True, size=18, color='FFFFFF')
    summary_ws['A1'].fill = header_fill
    summary_ws['A1'].alignment = Alignment(horizontal='center')
    summary_ws.merge_cells('A2:H2')
    summary_ws['A2'] = f"仓库：{wh_label}    时间段：{date_label}    导出时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}"
    summary_ws['A2'].font = Font(color=muted)
    summary_ws['A2'].alignment = Alignment(horizontal='center')

    kpis = [
        ('流水条数', len(rows)),
        ('SKU 数', sku_count),
        ('入库数量 PCS', inbound_qty),
        ('出库数量 PCS', outbound_qty),
        ('涉及货值 USD', value_total),
    ]
    for idx, (label, value) in enumerate(kpis, start=1):
        col = 1 + (idx - 1) * 2
        summary_ws.cell(4, col, label)
        summary_ws.cell(5, col, value)
        summary_ws.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col + 1)
        summary_ws.merge_cells(start_row=5, start_column=col, end_row=5, end_column=col + 1)
        summary_ws.cell(4, col).fill = sub_fill
        summary_ws.cell(4, col).font = Font(bold=True, color=dark)
        summary_ws.cell(5, col).font = Font(bold=True, size=15, color=green if '入库' in label else orange if '出库' in label else blue)
        summary_ws.cell(4, col).alignment = Alignment(horizontal='center')
        summary_ws.cell(5, col).alignment = Alignment(horizontal='center')
        summary_ws.cell(5, col).number_format = '$#,##0.00' if 'USD' in label else '#,##0'

    type_summary = {}
    for row in rows:
        label = movement_label(row.get('movement_type'))
        cur = type_summary.setdefault(label, {'rows': 0, 'qty': 0, 'value': 0})
        qty = float(row.get('quantity') or 0)
        cur['rows'] += 1
        cur['qty'] += qty
        cur['value'] += float(row.get('unit_price') or 0) * abs(qty)

    summary_ws.append([])
    summary_ws.append(['流水类型', '条数', '数量 PCS', '涉及货值 USD', '条数占比', '货值占比'])
    summary_header_row = summary_ws.max_row
    for cell_obj in summary_ws[summary_header_row]:
        cell_obj.fill = detail_header_fill
        cell_obj.font = Font(bold=True, color='FFFFFF')
        cell_obj.alignment = Alignment(horizontal='center')
        cell_obj.border = border
    for label, values in sorted(type_summary.items()):
        row_idx = summary_ws.max_row + 1
        summary_ws.append([
            label,
            values['rows'],
            values['qty'],
            round(values['value'], 2),
            values['rows'] / len(rows) if rows else 0,
            values['value'] / value_total if value_total else 0,
        ])
        for cell_obj in summary_ws[row_idx]:
            cell_obj.border = border
        summary_ws.cell(row_idx, 4).number_format = '$#,##0.00'
        summary_ws.cell(row_idx, 5).number_format = '0.0%'
        summary_ws.cell(row_idx, 6).number_format = '0.0%'

    headers = [
        'DATA RUCHU', '流水类型', 'Sheet', 'Product Number', 'Bom Code', 'Product Description',
        '物料品类', '适用产品', '归属国家', '仓库', '当前库存 PCS', 'Unit Price USD', '涉及货值 USD',
        'ID_OPERACJI', '订单类型', '对象/国家城市', '下单日期', '数量', 'UoM', 'Source File', '导入时间'
    ]
    detail_ws.append(headers)
    detail_ws.row_dimensions[1].height = 44
    for cell_obj in detail_ws[1]:
        cell_obj.fill = header_fill
        cell_obj.font = Font(name='Arial', bold=True, color='172033')
        cell_obj.alignment = Alignment(horizontal='center', vertical='center')
        cell_obj.border = border

    for row in rows:
        qty = float(row.get('quantity') or 0)
        row_idx = detail_ws.max_row + 1
        detail_ws.append([
            row.get('movement_date') or '',
            movement_label(row.get('movement_type')),
            row.get('sheet_name') or '',
            row.get('product_number') or '',
            row.get('bom_code') or '',
            row.get('product_description') or '',
            normalize_dimension(row.get('category'), 'category') or '',
            normalize_dimension(row.get('category_2'), 'category2') or '',
            row.get('instructions') or '',
            row.get('warehouses') or '',
            row.get('current_inventory') or 0,
            row.get('unit_price') or 0,
            round(float(row.get('unit_price') or 0) * abs(qty), 2),
            row.get('operation_id') or '',
            order_type_label(row.get('operation_prefix'), row.get('operation_id')),
            row.get('operation_target') or '',
            row.get('order_date') or '',
            qty,
            row.get('uom') or '',
            row.get('source_file') or '',
            row.get('created_at') or '',
        ])
        for cell_obj in detail_ws[row_idx]:
            cell_obj.border = border
            cell_obj.font = Font(name='Arial', size=10, color='172033')
            cell_obj.alignment = Alignment(vertical='center', wrap_text=cell_obj.column in (6, 14, 20))
        detail_ws.row_dimensions[row_idx].height = 42
        detail_ws.cell(row_idx, 11).number_format = '#,##0'
        detail_ws.cell(row_idx, 12).number_format = '$#,##0.00'
        detail_ws.cell(row_idx, 13).number_format = '$#,##0.00'
        detail_ws.cell(row_idx, 18).number_format = '#,##0'

    if rows:
        table_ref = f"A1:U{detail_ws.max_row}"
        tab = Table(displayName='InventoryMovementTable', ref=table_ref)
        tab.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        detail_ws.add_table(tab)
    detail_ws.freeze_panes = 'A2'
    detail_ws.auto_filter.ref = f"A1:U{max(detail_ws.max_row, 1)}"
    detail_ws.sheet_view.showGridLines = False
    summary_ws.sheet_view.showGridLines = False

    for idx, width in enumerate([16, 12, 18, 18, 16, excel_width_from_pixels(70), 16, 14, 18, 24, 14, 14, 14, 28, 14, 20, 14, 12, 10, 26, 20], start=1):
        detail_ws.column_dimensions[get_column_letter(idx)].width = width
    for idx, width in enumerate([18, 14, 14, 16, 12, 12, 12, 12, 12, 12], start=1):
        summary_ws.column_dimensions[get_column_letter(idx)].width = width
    summary_ws.freeze_panes = 'A8'

    return wb, movement_export_filename(filters['warehouse'], filters['start_date'], filters['end_date'])
