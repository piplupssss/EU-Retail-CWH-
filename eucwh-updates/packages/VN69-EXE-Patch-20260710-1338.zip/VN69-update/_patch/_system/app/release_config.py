import json
import os


_DEFAULT_RELEASE_INFO = {
    'version': 'VN0',
    'build_time': 'unknown',
    'provider': 'Qiteng Liu 84405995',
    'channel_label': 'GitHub patch channel',
    'update_source_label': 'Qiteng的GitHub',
    'update_manifest_url': 'https://raw.githubusercontent.com/piplupssss/EU-Retail-CWH-/main/eucwh-updates/latest.json',
    'update_allowed_hosts': ['raw.githubusercontent.com', 'github.com'],
    'security_note': 'Only HTTPS GET requests to Qiteng GitHub update source are used. No logistics, inventory, invoice, image, database, account, or backup data is uploaded.',
}


def _release_info_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'release_info.json')


def load_release_info():
    info = dict(_DEFAULT_RELEASE_INFO)
    try:
        with open(_release_info_path(), 'r', encoding='utf-8-sig') as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            info.update({k: v for k, v in loaded.items() if v not in (None, '')})
    except (OSError, json.JSONDecodeError):
        pass
    info['version'] = str(info.get('version') or _DEFAULT_RELEASE_INFO['version']).upper()
    info['build_time'] = str(info.get('build_time') or _DEFAULT_RELEASE_INFO['build_time'])
    info['provider'] = str(info.get('provider') or _DEFAULT_RELEASE_INFO['provider'])
    info['channel_label'] = str(info.get('channel_label') or _DEFAULT_RELEASE_INFO['channel_label'])
    info['update_source_label'] = str(info.get('update_source_label') or _DEFAULT_RELEASE_INFO['update_source_label'])
    hosts = info.get('update_allowed_hosts')
    info['update_allowed_hosts'] = [str(h).lower() for h in hosts] if isinstance(hosts, list) else list(_DEFAULT_RELEASE_INFO['update_allowed_hosts'])
    return info


RELEASE_INFO = load_release_info()
APP_VERSION = RELEASE_INFO['version']
APP_BUILD_TIME = RELEASE_INFO['build_time']
APP_PROVIDER = RELEASE_INFO['provider']
UPDATE_SOURCE_LABEL = RELEASE_INFO['update_source_label']
UPDATE_CHANNEL_LABEL = RELEASE_INFO['channel_label']
UPDATE_SECURITY_NOTE = RELEASE_INFO['security_note']
