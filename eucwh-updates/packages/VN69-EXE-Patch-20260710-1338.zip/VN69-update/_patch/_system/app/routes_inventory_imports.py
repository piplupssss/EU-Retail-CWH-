from flask import Blueprint, current_app, jsonify, request

inventory_bp = Blueprint('inventory', __name__)

from .inventory_calibration_import_service import import_inventory_calibration_file
from .inventory_import_errors import InventoryImportError
from .inventory_supplier_import_service import import_supplier_inventory_files
from .inventory_movement_import_service import import_specyfikacja_files
from .inventory_service import get_db


@inventory_bp.route('/api/inventory/upload-list', methods=['POST'])
def upload_inventory_list():
    return jsonify({
        'error': '旧 Stock List 导入已停用。请使用“供应商库存 + 维护表”导入，以 Product Number 作为库存主键。'
    }), 410


@inventory_bp.route('/api/inventory/import-supplier', methods=['POST'])
def import_supplier_inventory():
    supplier_file = request.files.get('supplier_file')
    maintenance_file = request.files.get('maintenance_file')
    try:
        report = import_supplier_inventory_files(
            supplier_file,
            maintenance_file,
            current_app.config['WMS_DATABASE'],
        )
        return jsonify({'success': True, 'report': report})
    except InventoryImportError as exc:
        return jsonify({'error': str(exc)}), exc.status_code


@inventory_bp.route('/api/inventory/import-calibration', methods=['POST'])
def import_inventory_calibration():
    f = request.files.get('file')
    try:
        report = import_inventory_calibration_file(f, current_app.config['WMS_DATABASE'])
        return jsonify({'success': True, 'report': report})
    except InventoryImportError as exc:
        return jsonify({'error': str(exc)}), exc.status_code
    except Exception as e:
        try:
            get_db().rollback()
        except Exception:
            pass
        return jsonify({'error': f'库存校准导入失败：{str(e)}'}), 500


@inventory_bp.route('/api/inventory/import-specyfikacja', methods=['POST'])
def import_specyfikacja_movements():
    files = [f for f in request.files.getlist('files') if f and f.filename]
    single = request.files.get('file')
    if single and single.filename:
        files.append(single)
    try:
        report = import_specyfikacja_files(files, current_app.config['WMS_DATABASE'])
        return jsonify({'success': True, 'report': report})
    except InventoryImportError as exc:
        return jsonify({'error': str(exc)}), exc.status_code
