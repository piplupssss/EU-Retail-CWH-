import sqlite3

from app.db_backup import backup_sqlite_db
from app.db_connections import close_db, get_db, get_wms_db, query_db
from app.db_migrations import ensure_columns, table_columns
from app.db_normalization import run_wms_post_schema_tasks
from app.db_schema import SCHEMA_SQL, WMS_SCHEMA


def init_db(app):
    db_path = app.config['DATABASE']
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA_SQL)
    # 增量迁移：添加新字段（不影响已有数据）
    new_cols = ['consignee_name2 TEXT', 'consignee_street TEXT', 'consignee_street2 TEXT',
                'last_checked TEXT', 'manual_status TEXT DEFAULT NULL',
                'recycled_at TEXT', 'recycle_reason TEXT', 'recycle_operator TEXT',
                'demand_country TEXT', "demand_country_source TEXT DEFAULT 'default'"]
    cur = conn.cursor()
    existing = [r[1] for r in cur.execute("PRAGMA table_info(shipments)").fetchall()]
    for col_def in new_cols:
        col_name = col_def.split()[0]
        if col_name not in existing:
            cur.execute(f"ALTER TABLE shipments ADD COLUMN {col_def}")
    invoice_item_cols = [r[1] for r in cur.execute("PRAGMA table_info(invoice_items)").fetchall()]
    for col_def in [
        "accepted_amount REAL",
        "acceptance_status TEXT",
        "exception_reason TEXT",
        "acceptance_remark TEXT",
    ]:
        col_name = col_def.split()[0]
        if col_name not in invoice_item_cols:
            cur.execute(f"ALTER TABLE invoice_items ADD COLUMN {col_def}")
    cur.execute("""
        UPDATE shipments
        SET demand_country = UPPER(TRIM(consignee_country_code)),
            demand_country_source = COALESCE(NULLIF(demand_country_source, ''), 'default')
        WHERE (demand_country IS NULL OR TRIM(demand_country) = '')
          AND consignee_country_code IS NOT NULL
          AND TRIM(consignee_country_code) != ''
    """)
    cur.execute("""
        UPDATE shipments
        SET shipment_status = 'Active'
        WHERE shipment_status IS NULL OR TRIM(shipment_status) = ''
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_shipments_demand_country ON shipments(demand_country)")
    conn.commit()
    conn.close()


def init_wms_db(app):
    conn = sqlite3.connect(app.config['WMS_DATABASE'])
    pre_cur = conn.cursor()

    # Old PC databases may have early VN tables without these columns. Add them
    # before running WMS_SCHEMA, because CREATE INDEX statements reference them.
    ensure_columns(pre_cur, "sku_master", (
        ("product_number", "TEXT"),
        ("product_description", "TEXT"),
        ("category", "TEXT"),
        ("category_2", "TEXT"),
        ("unit_price", "REAL DEFAULT 0"),
        ("image_path", "TEXT"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ), require_existing=True)
    ensure_columns(pre_cur, "product_master", (
        ("bom_code", "TEXT"),
        ("product_description", "TEXT"),
        ("category", "TEXT"),
        ("category_2", "TEXT"),
        ("unit_price", "REAL DEFAULT 0"),
        ("last_inbound_date", "DATE"),
        ("last_outbound_date", "DATE"),
        ("remark", "TEXT"),
        ("dos_threshold", "INTEGER DEFAULT 180"),
        ("idle_threshold", "INTEGER DEFAULT 180"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ), require_existing=True)
    ensure_columns(pre_cur, "warehouse_inventory", (
        ("bom_code", "TEXT"),
        ("product_number", "TEXT"),
        ("instruction", "TEXT"),
        ("inventory", "INTEGER DEFAULT 0"),
        ("last_inbound_date", "DATE"),
        ("last_outbound_date", "DATE"),
        ("comment", "TEXT"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ), require_existing=True)
    ensure_columns(pre_cur, "delivery_orders", (
        ("destination_country", "TEXT"),
        ("status", "TEXT DEFAULT 'pending'"),
        ("stt_number", "TEXT"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("confirmed_at", "TIMESTAMP"),
        ("shipped_at", "TIMESTAMP"),
        ("delivered_at", "TIMESTAMP"),
    ), require_existing=True)
    ensure_columns(pre_cur, "delivery_order_items", (("product_number", "TEXT"),), require_existing=True)
    ensure_columns(pre_cur, "inventory_transactions", (("product_number", "TEXT"),), require_existing=True)
    ensure_columns(pre_cur, "inventory_movements", (
        ("movement_type", "TEXT"),
        ("sheet_name", "TEXT"),
        ("product_number", "TEXT"),
        ("movement_date", "DATE"),
        ("operation_id", "TEXT"),
        ("operation_prefix", "TEXT"),
        ("operation_target", "TEXT"),
        ("order_date", "DATE"),
        ("quantity", "REAL DEFAULT 0"),
        ("uom", "TEXT"),
        ("source_file", "TEXT"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ), require_existing=True)
    conn.commit()
    conn.executescript(WMS_SCHEMA)
    cur = conn.cursor()

    ensure_columns(cur, "sku_master", (
        ("product_number", "TEXT"),
        ("product_description", "TEXT"),
        ("category", "TEXT"),
        ("category_2", "TEXT"),
        ("unit_price", "REAL DEFAULT 0"),
        ("image_path", "TEXT"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ))
    ensure_columns(cur, "product_master", (
        ("bom_code", "TEXT"),
        ("product_description", "TEXT"),
        ("category", "TEXT"),
        ("category_2", "TEXT"),
        ("unit_price", "REAL DEFAULT 0"),
        ("last_inbound_date", "DATE"),
        ("last_outbound_date", "DATE"),
        ("remark", "TEXT"),
        ("dos_threshold", "INTEGER DEFAULT 180"),
        ("idle_threshold", "INTEGER DEFAULT 180"),
        ("created_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ))
    ensure_columns(cur, "warehouse_inventory", (
        ("bom_code", "TEXT"),
        ("product_number", "TEXT"),
        ("instruction", "TEXT"),
        ("inventory", "INTEGER DEFAULT 0"),
        ("last_inbound_date", "DATE"),
        ("last_outbound_date", "DATE"),
        ("comment", "TEXT"),
        ("updated_at", "TIMESTAMP DEFAULT CURRENT_TIMESTAMP"),
    ))

    for table in ("warehouse_inventory", "delivery_order_items", "inventory_transactions"):
        if "product_number" not in table_columns(cur, table):
            cur.execute(f"ALTER TABLE {table} ADD COLUMN product_number TEXT")

    product_cols = table_columns(cur, "product_master")
    for col_name, col_type in (
        ("last_inbound_date", "DATE"),
        ("last_outbound_date", "DATE"),
        ("remark", "TEXT"),
    ):
        if col_name not in product_cols:
            cur.execute(f"ALTER TABLE product_master ADD COLUMN {col_name} {col_type}")

    run_wms_post_schema_tasks(conn, cur)
    conn.commit()
    conn.close()
