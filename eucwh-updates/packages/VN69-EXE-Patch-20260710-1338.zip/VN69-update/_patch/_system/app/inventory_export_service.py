"""Inventory export workbook builders."""

from __future__ import annotations

import os
import re
import sqlite3

from .export_service import add_summary_sheet, excel_width_from_pixels


INVENTORY_EXPORT_HEADERS = [
    'Bom Code',
    'Product Number',
    'Product Description',
    'Category',
    'Category 2',
    'Instruction',
    'Inventory (Pcs)',
    'Unit Price (USD)',
    'TTL Amount (USD)',
    '最近入库时间 Last Inbound date',
    '最近出库时间 Last Outbound date',
    '库龄 Dos (Days of Supply)',
    '库存静置时长 Days without Stock',
    '备注 comment',
    'SKU条目创建时间',
    '图片 Photo',
]

INVENTORY_EXPORT_SHEETS = [
    ('Lodz', 'Lodz warehouse'),
    ('Bydgoszcz', 'Bydgoszcz warehouse'),
]


def style_calibration_sheet(ws, row_count, headers):
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo

    header_fill = PatternFill('solid', fgColor='EAF1FF')
    header_font = Font(name='Arial', color='172033', bold=True)
    thin = Side(style='thin', color='D9E2F3')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for cell_obj in ws[1]:
        cell_obj.fill = header_fill
        cell_obj.font = header_font
        cell_obj.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        cell_obj.border = border
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    widths = [16, 22, excel_width_from_pixels(70), 18, 18, 16, 15, 16, 16, 24, 24, 22, 24, 30, 20, 24]
    for idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    for row in ws.iter_rows(min_row=2, max_row=max(row_count, 2), max_col=len(headers)):
        ws.row_dimensions[row[0].row].height = 42
        for cell_obj in row:
            cell_obj.border = border
            cell_obj.font = Font(name='Arial', size=10, color='172033')
            cell_obj.alignment = Alignment(vertical='center', wrap_text=cell_obj.column == 3)
    if row_count >= 2:
        ref = f"A1:{get_column_letter(len(headers))}{row_count}"
        table = Table(displayName=re.sub(r'[^A-Za-z0-9_]', '_', f"{ws.title}_Inventory"), ref=ref)
        style = TableStyleInfo(name='TableStyleMedium2', showFirstColumn=False, showLastColumn=False, showRowStripes=True, showColumnStripes=False)
        table.tableStyleInfo = style
        ws.add_table(table)
    ws.sheet_view.showGridLines = False


def build_inventory_list_workbook(
    wms_database,
    database_path,
    *,
    include_images=False,
    warehouse_filter='',
    category_values=None,
    category2_values=None,
    instruction_values=None,
):
    from openpyxl import Workbook
    from openpyxl.drawing.image import Image as ExcelImage

    category_values = category_values or []
    category2_values = category2_values or []
    instruction_values = instruction_values or []
    wms_conn = sqlite3.connect(wms_database)
    wms_conn.row_factory = sqlite3.Row
    image_dir = os.path.join(os.path.dirname(database_path), '..', 'static', 'images')
    wb = Workbook()
    try:
        created_sheets = 0
        summary_rows = []
        for sheet_title, warehouse in INVENTORY_EXPORT_SHEETS:
            if warehouse_filter and warehouse_filter != warehouse:
                continue
            ws = wb.active if created_sheets == 0 else wb.create_sheet()
            created_sheets += 1
            ws.title = sheet_title
            ws.append(INVENTORY_EXPORT_HEADERS)
            where = ["wi.warehouse = ?"]
            params = [warehouse]
            if category_values:
                placeholders = ','.join(['?'] * len(category_values))
                where.append(f"UPPER(TRIM(COALESCE(pm.category, sm.category, ''))) IN ({placeholders})")
                params.extend(category_values)
            if category2_values:
                placeholders = ','.join(['?'] * len(category2_values))
                where.append(f"UPPER(TRIM(COALESCE(pm.category_2, sm.category_2, ''))) IN ({placeholders})")
                params.extend(category2_values)
            if instruction_values:
                placeholders = ','.join(['?'] * len(instruction_values))
                where.append(f"UPPER(TRIM(COALESCE(wi.instruction, ''))) IN ({placeholders})")
                params.extend(instruction_values)
            rows = wms_conn.execute(f"""
                SELECT wi.warehouse,
                       COALESCE(NULLIF(wi.bom_code, ''), pm.bom_code, sm.bom_code) AS bom_code,
                       wi.product_number,
                       COALESCE(pm.product_description, sm.product_description) AS product_description,
                       COALESCE(pm.category, sm.category) AS category,
                       COALESCE(pm.category_2, sm.category_2) AS category_2,
                       wi.instruction,
                       wi.inventory,
                       COALESCE(pm.unit_price, sm.unit_price, 0) AS unit_price,
                       COALESCE(wi.last_inbound_date, pm.last_inbound_date, DATE(pm.created_at)) AS last_inbound_date,
                       COALESCE(wi.last_outbound_date, pm.last_outbound_date) AS last_outbound_date,
                       wi.comment,
                       DATE(pm.created_at) AS sku_created_at,
                       COALESCE(pimg.image_path, sm.image_path) AS image_path
                FROM warehouse_inventory wi
                LEFT JOIN product_master pm ON wi.product_number = pm.product_number
                LEFT JOIN sku_master sm ON COALESCE(NULLIF(wi.bom_code, ''), pm.bom_code) = sm.bom_code
                    AND NOT (
                        REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                        OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
                    )
                LEFT JOIN sku_master pimg ON (
                    REPLACE(REPLACE(REPLACE(UPPER(TRIM(COALESCE(wi.bom_code, pm.bom_code, ''))), ' ', ''), '_', ''), '-', '') IN ('本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', '/', 'NOBOM', 'NOBOMCODE')
                    OR COALESCE(NULLIF(wi.bom_code, ''), NULLIF(pm.bom_code, ''), '') = ''
                ) AND wi.product_number = pimg.bom_code
                WHERE {' AND '.join(where)}
                ORDER BY wi.product_number
            """, params).fetchall()
            sheet_pcs = 0
            sheet_value = 0.0
            for row in rows:
                inventory = float(row['inventory'] or 0)
                unit_price = float(row['unit_price'] or 0)
                ttl_amount = inventory * unit_price
                sheet_pcs += inventory
                sheet_value += ttl_amount
                last_inbound = row['last_inbound_date'] or ''
                last_outbound = row['last_outbound_date'] or ''
                dos = ''
                idle = ''
                if last_inbound:
                    days = wms_conn.execute("SELECT CAST(JULIANDAY('now') - JULIANDAY(?) AS INTEGER)", (last_inbound,)).fetchone()[0]
                    dos = days if days is not None else ''
                if last_outbound:
                    days = wms_conn.execute("SELECT CAST(JULIANDAY('now') - JULIANDAY(?) AS INTEGER)", (last_outbound,)).fetchone()[0]
                    idle = days if days is not None else ''
                ws.append([
                    row['bom_code'] or '',
                    row['product_number'] or '',
                    row['product_description'] or '',
                    row['category'] or '',
                    row['category_2'] or '',
                    row['instruction'] or '',
                    int(inventory),
                    unit_price,
                    ttl_amount,
                    last_inbound,
                    last_outbound,
                    dos,
                    idle,
                    row['comment'] or '',
                    row['sku_created_at'] or '',
                    '',
                ])
                row_idx = ws.max_row
                ws.row_dimensions[row_idx].height = 58
                if include_images and row['image_path']:
                    img_path = os.path.abspath(os.path.join(image_dir, row['image_path']))
                    if img_path.startswith(os.path.abspath(image_dir) + os.sep) and os.path.exists(img_path):
                        try:
                            img = ExcelImage(img_path)
                            img.width = 72
                            img.height = 52
                            ws.add_image(img, f'P{row_idx}')
                        except Exception:
                            pass
                for money_cell in (ws.cell(row_idx, 8), ws.cell(row_idx, 9)):
                    money_cell.number_format = '$#,##0.00'
                ws.cell(row_idx, 7).number_format = '#,##0'
            style_calibration_sheet(ws, ws.max_row, INVENTORY_EXPORT_HEADERS)
            summary_rows.extend([
                (f'{sheet_title} SKU 条目', len(rows)),
                (f'{sheet_title} 库存 PCS', int(sheet_pcs)),
                (f'{sheet_title} 货值 USD', round(sheet_value, 2)),
            ])
        if created_sheets == 0:
            ws = wb.active
            ws.title = 'No Data'
            ws.append(INVENTORY_EXPORT_HEADERS)
            style_calibration_sheet(ws, ws.max_row, INVENTORY_EXPORT_HEADERS)
            summary_rows.append(('导出结果', '无数据'))
        add_summary_sheet(wb, summary_rows, title='Summary')
        return wb
    finally:
        wms_conn.close()
