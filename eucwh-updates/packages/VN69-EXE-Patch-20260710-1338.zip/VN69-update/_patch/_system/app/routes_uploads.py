import os
from datetime import datetime

from flask import Blueprint, jsonify, request

from .maintenance_service import (
    maintenance_password_ok,
    remove_file_safely,
    source_file_to_disk_name,
    upload_dir_path,
)
from .logistics_service import get_db

uploads_bp = Blueprint('uploads', __name__)


@uploads_bp.route('/api/uploads')
def list_uploaded_files():
    """List uploaded source files and their linked business records."""
    db = get_db()
    upload_dir = upload_dir_path()
    file_map = {}

    def ensure_item(disk_name):
        disk_name = os.path.basename(disk_name or '')
        if not disk_name:
            return None
        path = os.path.join(upload_dir, disk_name)
        item = file_map.setdefault(disk_name, {
            'filename': disk_name,
            'exists': os.path.exists(path),
            'size': os.path.getsize(path) if os.path.exists(path) else 0,
            'modified_at': datetime.fromtimestamp(os.path.getmtime(path)).strftime('%Y-%m-%d %H:%M:%S') if os.path.exists(path) else '',
            'shipment_records': 0,
            'invoice_records': 0,
            'invoice_number': '',
            'invoice_status': '',
            'types': set(),
        })
        return item

    for filename in os.listdir(upload_dir):
        path = os.path.join(upload_dir, filename)
        if os.path.isfile(path):
            item = ensure_item(filename)
            if item:
                item['types'].add('file')

    shipment_rows = db.execute("""
        SELECT source_file, COUNT(*) AS cnt
        FROM shipments
        WHERE source_file IS NOT NULL AND source_file != ''
        GROUP BY source_file
    """).fetchall()
    for r in shipment_rows:
        disk_name = source_file_to_disk_name(r['source_file'])
        item = ensure_item(disk_name)
        if not item:
            continue
        item['shipment_records'] += r['cnt'] or 0
        item['types'].add('logistics')

    invoice_rows = db.execute("""
        SELECT source_file, invoice_number, status
        FROM invoice_headers
        WHERE source_file IS NOT NULL AND source_file != ''
    """).fetchall()
    for r in invoice_rows:
        disk_name = source_file_to_disk_name(r['source_file'])
        item = ensure_item(disk_name)
        if not item:
            continue
        item['invoice_records'] += 1
        item['invoice_number'] = r['invoice_number'] or item['invoice_number']
        item['invoice_status'] = r['status'] or item['invoice_status']
        item['types'].add('invoice')

    records = []
    for item in file_map.values():
        item['types'] = sorted(item['types'])
        records.append(item)
    records.sort(key=lambda x: (not x['exists'], x['modified_at']), reverse=True)
    return jsonify({'files': records})


@uploads_bp.route('/api/uploads/<path:filename>', methods=['DELETE'])
def delete_uploaded_file(filename):
    data = request.get_json(silent=True) or {}
    return _delete_uploaded_file_by_name(filename, data)


@uploads_bp.route('/api/uploads/delete', methods=['POST'])
def delete_uploaded_file_json():
    data = request.get_json(silent=True) or {}
    return _delete_uploaded_file_by_name(data.get('filename', ''), data)


def _delete_uploaded_file_by_name(filename, data):
    if not maintenance_password_ok(data.get('password'), allow_admin=True):
        return jsonify({'error': '删除密码错误'}), 403
    safe_name = os.path.basename(filename or '')
    if not safe_name or safe_name in ('.', '..'):
        return jsonify({'error': '文件名无效'}), 400
    upload_dir = upload_dir_path()
    path = os.path.abspath(os.path.join(upload_dir, safe_name))
    if not path.startswith(os.path.abspath(upload_dir) + os.sep):
        return jsonify({'error': '文件路径无效'}), 400
    if not os.path.exists(path):
        return jsonify({'error': '文件不存在或已删除'}), 404
    remove_file_safely(path)
    return jsonify({'success': True, 'filename': safe_name})
