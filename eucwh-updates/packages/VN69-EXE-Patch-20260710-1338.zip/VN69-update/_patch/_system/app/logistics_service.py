from datetime import datetime, timedelta

from . import db as db_module


def get_db():
    return db_module.get_db()


def add_workdays(date_str, days):
    """Add N working days to a YYYY-MM-DD style date string."""
    dt = datetime.strptime(date_str[:10], '%Y-%m-%d')
    added = 0
    while added < days:
        dt += timedelta(days=1)
        if dt.weekday() < 5:
            added += 1
    return dt.strftime('%Y-%m-%d')


def calc_display_status(row):
    """Calculate the user-facing logistics status from raw and manual fields."""
    status = row['shipment_status']
    actual_dd = row['actual_delivery_date']
    delivery_locked = row['delivery_locked'] if 'delivery_locked' in row.keys() else 0
    if delivery_locked or (actual_dd and actual_dd.strip()):
        return '已交付'
    if status == 'Canceled':
        return 'Canceled'
    manual = row['manual_status'] or ''
    if manual == 'abnormal':
        return '异常单'
    if manual in ('auto_in_transport', 'auto_booked'):
        return '运输中'
    delivery_date = row['delivery_date']
    pickup_date = row['pickup_date']
    today_str = datetime.now().strftime('%Y-%m-%d')
    if delivery_date and delivery_date.strip():
        try:
            delivery_dt = delivery_date[:10]
            if delivery_dt <= today_str:
                return '待核实'
            return '运输中'
        except Exception:
            pass
    if pickup_date and pickup_date.strip():
        try:
            deadline = add_workdays(pickup_date, 10)
            return '异常单' if today_str > deadline else '运输中'
        except Exception:
            return '运输中'
    return '运输中'


def effective_demand_country(row):
    """Business demand country: manual/imported override, then consignee country."""
    try:
        demand = row['demand_country'] if 'demand_country' in row.keys() else ''
    except Exception:
        demand = ''
    try:
        consignee = row['consignee_country_code'] if 'consignee_country_code' in row.keys() else ''
    except Exception:
        consignee = ''
    return (demand or consignee or '').strip().upper()
