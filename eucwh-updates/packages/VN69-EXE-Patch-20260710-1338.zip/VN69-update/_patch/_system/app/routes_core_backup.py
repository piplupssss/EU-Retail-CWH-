import os

from flask import Blueprint, jsonify, request, send_file

from . import db as db_module
from .core_backup_service import (
    CoreBackupImportError,
    build_core_backup_workbook,
    create_full_package_zip,
    import_core_backup_file,
)
from .export_service import short_export_filename, xlsx_response


core_backup_bp = Blueprint('core_backup', __name__)


@core_backup_bp.teardown_request
def close_db(e=None):
    db_module.close_db(e)


@core_backup_bp.route('/api/export/full')
def export_full_package():
    """导出库存、物流、验收状态和库存图片到一个离线 ZIP。"""
    try:
        zip_path = create_full_package_zip(
            scope=request.args.get('scope', 'all'),
            warehouse=request.args.get('warehouse', '')
        )
        return send_file(
            zip_path,
            mimetype='application/zip',
            as_attachment=True,
            download_name=os.path.basename(zip_path)
        )
    except Exception as exc:  # noqa: BLE001
        return jsonify({'error': str(exc)}), 500


@core_backup_bp.route('/api/export/core-backup')
def export_core_backup():
    return xlsx_response(build_core_backup_workbook(), short_export_filename('core_backup'))


@core_backup_bp.route('/api/import/core-backup', methods=['POST'])
def import_core_backup():
    """Import the lightweight core backup workbook exported from the full package."""
    if request.form.get('password', '') != 'Q84405995':
        return jsonify({'error': '密码错误，请重新输入'}), 403
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    filename = file.filename or ''
    if not filename.lower().endswith(('.xlsx', '.xls', '.zip')):
        return jsonify({'error': 'Only Excel or full export ZIP files supported'}), 400

    try:
        report = import_core_backup_file(file, filename)
        return jsonify({'success': True, 'report': report})
    except CoreBackupImportError as exc:
        return jsonify({'error': str(exc)}), exc.status_code
    except Exception as exc:  # noqa: BLE001
        return jsonify({'error': str(exc)}), 500
