SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS shipments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id TEXT NOT NULL,
    stt_number TEXT,
    waybill_no TEXT,
    shipment_status TEXT,
    transport_mode TEXT,
    shipment_type TEXT,
    warehouse TEXT,
    shipper_name TEXT,
    consignee_name TEXT,
    consignee_name2 TEXT,
    consignee_street TEXT,
    consignee_street2 TEXT,
    consignee_address TEXT,
    consignee_city TEXT,
    consignee_country_code TEXT,
    demand_country TEXT,
    demand_country_source TEXT DEFAULT 'default',
    pickup_city TEXT,
    pickup_country_code TEXT,
    delivery_city TEXT,
    delivery_country_code TEXT,
    creation_date TEXT,
    pickup_date TEXT,
    delivery_date TEXT,
    actual_delivery_date TEXT,
    delivery_locked INTEGER DEFAULT 0,
    manual_status TEXT DEFAULT NULL,
    last_checked TEXT,
    total_pieces REAL,
    total_weight REAL,
    total_volume REAL,
    price_without_vat REAL,
    incoterm TEXT,
    service_type TEXT,
    product TEXT,
    cargo_description TEXT,
    references_text TEXT,
    source_file TEXT,
    recycled_at TEXT,
    recycle_reason TEXT,
    recycle_operator TEXT,
    import_time TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(booking_id)
);

CREATE INDEX IF NOT EXISTS idx_shipments_status ON shipments(shipment_status);
CREATE INDEX IF NOT EXISTS idx_shipments_type ON shipments(shipment_type);
CREATE INDEX IF NOT EXISTS idx_shipments_country ON shipments(consignee_country_code);
CREATE INDEX IF NOT EXISTS idx_shipments_creation ON shipments(creation_date);
CREATE INDEX IF NOT EXISTS idx_shipments_warehouse ON shipments(warehouse);

-- ========== Invoice Schema ==========
CREATE TABLE IF NOT EXISTS invoice_headers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT NOT NULL UNIQUE,
    invoice_date TEXT,
    invoice_type TEXT DEFAULT 'logistics',
    currency TEXT DEFAULT 'PLN',
    total_net REAL DEFAULT 0,
    total_vat REAL DEFAULT 0,
    total_gross REAL DEFAULT 0,
    status TEXT DEFAULT 'pending',
    source_file TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL,
    stt_number TEXT NOT NULL,
    net_amount REAL DEFAULT 0,
    ref_date TEXT,
    matched_booking_id TEXT,
    accepted_amount REAL,
    acceptance_status TEXT,
    exception_reason TEXT,
    acceptance_remark TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoice_headers(id)
);

CREATE INDEX IF NOT EXISTS idx_invoice_items_stt ON invoice_items(stt_number);
CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id);
"""


WMS_SCHEMA = """
CREATE TABLE IF NOT EXISTS sku_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bom_code TEXT UNIQUE NOT NULL,
    product_number TEXT,
    product_description TEXT,
    category TEXT,
    category_2 TEXT,
    unit_price REAL DEFAULT 0,
    image_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS product_master (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_number TEXT UNIQUE NOT NULL,
    bom_code TEXT NOT NULL,
    product_description TEXT,
    category TEXT,
    category_2 TEXT,
    unit_price REAL DEFAULT 0,
    last_inbound_date DATE,
    last_outbound_date DATE,
    remark TEXT,
    dos_threshold INTEGER DEFAULT 180,
    idle_threshold INTEGER DEFAULT 180,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS warehouse_inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    warehouse TEXT NOT NULL,
    bom_code TEXT NOT NULL,
    product_number TEXT,
    instruction TEXT,
    inventory INTEGER DEFAULT 0,
    last_inbound_date DATE,
    last_outbound_date DATE,
    comment TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(warehouse, product_number)
);

CREATE TABLE IF NOT EXISTS delivery_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT UNIQUE NOT NULL,
    warehouse TEXT NOT NULL,
    destination_country TEXT,
    status TEXT DEFAULT 'pending',
    stt_number TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP,
    shipped_at TIMESTAMP,
    delivered_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS delivery_order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    bom_code TEXT NOT NULL,
    product_number TEXT,
    requested_qty INTEGER DEFAULT 0,
    actual_qty INTEGER,
    FOREIGN KEY (order_id) REFERENCES delivery_orders(id)
);

CREATE TABLE IF NOT EXISTS inventory_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    warehouse TEXT NOT NULL,
    bom_code TEXT NOT NULL,
    product_number TEXT,
    change_type TEXT NOT NULL,
    quantity_change INTEGER NOT NULL,
    order_id INTEGER,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS inventory_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    movement_type TEXT NOT NULL,
    sheet_name TEXT,
    product_number TEXT NOT NULL,
    movement_date DATE,
    operation_id TEXT,
    operation_prefix TEXT,
    operation_target TEXT,
    order_date DATE,
    quantity REAL DEFAULT 0,
    uom TEXT,
    source_file TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sku_category ON sku_master(category);
CREATE INDEX IF NOT EXISTS idx_sku_category2 ON sku_master(category_2);
CREATE INDEX IF NOT EXISTS idx_product_bom ON product_master(bom_code);
CREATE INDEX IF NOT EXISTS idx_product_category ON product_master(category);
CREATE INDEX IF NOT EXISTS idx_product_category2 ON product_master(category_2);
CREATE INDEX IF NOT EXISTS idx_inv_warehouse ON warehouse_inventory(warehouse);
CREATE INDEX IF NOT EXISTS idx_inv_bom ON warehouse_inventory(bom_code);
CREATE INDEX IF NOT EXISTS idx_orders_status ON delivery_orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_stt ON delivery_orders(stt_number);
CREATE INDEX IF NOT EXISTS idx_items_order ON delivery_order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_txn_warehouse ON inventory_transactions(warehouse);
CREATE INDEX IF NOT EXISTS idx_txn_bom ON inventory_transactions(bom_code);
CREATE INDEX IF NOT EXISTS idx_movements_product ON inventory_movements(product_number);
CREATE INDEX IF NOT EXISTS idx_movements_date ON inventory_movements(movement_date);
"""
