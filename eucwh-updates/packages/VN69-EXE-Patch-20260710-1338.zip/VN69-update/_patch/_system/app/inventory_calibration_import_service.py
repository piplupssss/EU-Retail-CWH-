import openpyxl

from . import db as db_module
from .inventory_import_errors import InventoryImportError
from .inventory_service import (
    CALIBRATION_HEADERS,
    CALIBRATION_SHEETS,
    clean_text,
    find_exact_header_map,
    get_db,
    get_row_value_by_headers,
    remove_uploaded_source_file,
    save_uploaded_source_file,
    upsert_inventory_calibration_row,
    uploaded_file_size,
)


def import_inventory_calibration_file(file, wms_database_path):
    if not file or not file.filename.endswith(('.xlsx', '.xls')):
        raise InventoryImportError('请上传库存校准 Excel')
    if uploaded_file_size(file) > 25 * 1024 * 1024:
        raise InventoryImportError('Excel 文件不能超过 25MB')

    db_module.backup_sqlite_db(wms_database_path, 'inventory_calibration_import')
    saved_filename, saved_path = save_uploaded_source_file(file, 'inventory_calibration')
    wb = openpyxl.load_workbook(saved_path, data_only=True)
    d = get_db()
    report = {
        'source_file': saved_filename,
        'sheets': {},
        'imported': 0,
        'created': 0,
        'updated': 0,
        'inventory_changed': 0,
        'skipped': 0,
        'errors': [],
    }

    for sheet_title, warehouse in CALIBRATION_SHEETS.items():
        if sheet_title not in wb.sheetnames:
            report['sheets'][sheet_title] = {'warehouse': warehouse, 'missing': True, 'imported': 0, 'skipped': 0}
            report['errors'].append(f"缺少 Sheet: {sheet_title}")
            continue
        ws = wb[sheet_title]
        header_row, header_map = find_exact_header_map(ws, CALIBRATION_HEADERS)
        sheet_report = {
            'warehouse': warehouse,
            'header_row': header_row,
            'imported': 0,
            'created': 0,
            'updated': 0,
            'inventory_changed': 0,
            'skipped': 0,
        }
        if not header_row:
            sheet_report['error'] = '未找到校准表头'
            report['errors'].append(f"{sheet_title} 未找到校准表头")
            report['sheets'][sheet_title] = sheet_report
            continue
        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            before = dict(sheet_report)
            data = {header: get_row_value_by_headers(row, header_map, header) for header in CALIBRATION_HEADERS}
            if not any(clean_text(value) for value in data.values()):
                continue
            upsert_inventory_calibration_row(d, warehouse, data, sheet_report)
            for key in ('imported', 'created', 'updated', 'inventory_changed', 'skipped'):
                report[key] += sheet_report[key] - before[key]
        report['sheets'][sheet_title] = sheet_report

    d.commit()
    remove_uploaded_source_file(saved_path)
    return report
