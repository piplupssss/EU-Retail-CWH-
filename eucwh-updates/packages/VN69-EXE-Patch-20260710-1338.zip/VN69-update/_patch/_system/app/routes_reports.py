import os

from flask import Blueprint, current_app, jsonify, request

from .maintenance_service import remove_file_safely

reports_bp = Blueprint('reports', __name__)


def report_assets_dir():
    static_dir = os.path.join(os.path.dirname(os.path.dirname(current_app.config['DATABASE'])), 'static')
    path = os.path.join(static_dir, 'report_assets')
    os.makedirs(path, exist_ok=True)
    return path


@reports_bp.route('/api/reports/header-icon', methods=['GET'])
def get_report_header_icon():
    folder = report_assets_dir()
    for ext in ('png', 'jpg', 'jpeg', 'webp', 'gif'):
        filename = f'header_icon.{ext}'
        if os.path.exists(os.path.join(folder, filename)):
            return jsonify({'success': True, 'url': f'/static/report_assets/{filename}'})
    return jsonify({'success': True, 'url': ''})


@reports_bp.route('/api/reports/header-icon', methods=['POST'])
def upload_report_header_icon():
    file = request.files.get('file')
    if not file or not file.filename:
        return jsonify({'success': False, 'error': '请选择 icon 图片'}), 400
    ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in {'png', 'jpg', 'jpeg', 'webp', 'gif'}:
        return jsonify({'success': False, 'error': '仅支持 png / jpg / jpeg / webp / gif'}), 400
    folder = report_assets_dir()
    for old_ext in ('png', 'jpg', 'jpeg', 'webp', 'gif'):
        remove_file_safely(os.path.join(folder, f'header_icon.{old_ext}'))
    filename = f'header_icon.{ext}'
    file.save(os.path.join(folder, filename))
    return jsonify({'success': True, 'url': f'/static/report_assets/{filename}'})
