import hashlib
import json
import os
import re
import urllib.parse
import urllib.request
import zipfile

from .release_config import (
    APP_BUILD_TIME,
    APP_VERSION,
    RELEASE_INFO,
)

UPDATE_MANIFEST_URL = os.environ.get(
    'EUCWH_UPDATE_MANIFEST_URL',
    RELEASE_INFO.get('update_manifest_url') or 'https://raw.githubusercontent.com/piplupssss/EU-Retail-CWH-/main/eucwh-updates/latest.json'
)
UPDATE_FALLBACK_MANIFEST_URL = os.environ.get('EUCWH_UPDATE_FALLBACK_MANIFEST_URL', '')
UPDATE_ALLOWED_HOSTS = set(RELEASE_INFO.get('update_allowed_hosts') or ['raw.githubusercontent.com', 'github.com'])
UPDATE_MAX_BYTES = 300 * 1024 * 1024


def version_number(value):
    match = re.search(r'VN\s*(\d+)', str(value or ''), re.I)
    return int(match.group(1)) if match else 0


def app_base_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def software_root_dir():
    base = app_base_dir()
    return os.path.dirname(base) if os.path.basename(base).lower() == '_system' else base


def safe_filename_part(value, fallback='all'):
    text = str(value or '').strip()
    if not text:
        text = fallback
    text = re.sub(r'[\\/:*?"<>|]+', '_', text)
    text = re.sub(r'\s+', '_', text)
    text = re.sub(r'_+', '_', text).strip('._ ')
    return text or fallback


def remove_file_safely(filepath):
    try:
        if filepath and os.path.exists(filepath):
            os.remove(filepath)
    except OSError:
        pass


def validate_update_url(url, expected_path_prefix=None):
    parsed = urllib.parse.urlparse(str(url or '').strip())
    if parsed.scheme != 'https':
        raise ValueError('更新地址必须使用 HTTPS')
    host = (parsed.hostname or '').lower()
    if host not in UPDATE_ALLOWED_HOSTS:
        raise ValueError(f'更新来源不在白名单：{host or "-"}')
    if expected_path_prefix:
        path = parsed.path or ''
        if host == 'raw.githubusercontent.com':
            if '/EU-Retail-CWH-/' not in path or '/eucwh-updates/' not in path:
                raise ValueError('GitHub 更新路径不在允许目录内')
        elif host == 'github.com':
            if '/piplupssss/EU-Retail-CWH-/releases/download/' not in path:
                raise ValueError('GitHub Release 更新路径不在允许目录内')
    return parsed.geturl()


def fetch_update_manifest():
    errors = []
    raw = None
    for manifest_url in [u for u in [UPDATE_MANIFEST_URL, UPDATE_FALLBACK_MANIFEST_URL] if u]:
        try:
            url = validate_update_url(manifest_url, '/eucwh-updates/')
            req = urllib.request.Request(url, headers={'User-Agent': f'EUCWH-Updater/{APP_VERSION}'})
            with urllib.request.urlopen(req, timeout=12) as resp:
                if getattr(resp, 'status', 200) >= 400:
                    raise RuntimeError(f'HTTP {resp.status}')
                raw = resp.read(512 * 1024 + 1)
            break
        except Exception as e:
            errors.append(str(e))
    if raw is None:
        raise RuntimeError('更新清单读取失败：' + ' | '.join(errors))
    if len(raw) > 512 * 1024:
        raise RuntimeError('更新清单过大')
    data = json.loads(raw.decode('utf-8-sig'))
    if not isinstance(data, dict):
        raise RuntimeError('更新清单格式错误')
    package_url = validate_update_url(data.get('package_url'), '/eucwh-updates/packages/')
    data['package_url'] = package_url
    data['latest_version'] = str(data.get('latest_version') or data.get('version') or '').strip()
    data['sha256'] = str(data.get('sha256') or '').strip().lower()
    if not data['latest_version'] or not re.fullmatch(r'VN\d+', data['latest_version'], re.I):
        raise RuntimeError('更新清单缺少 latest_version')
    if not re.fullmatch(r'[0-9a-f]{64}', data['sha256']):
        raise RuntimeError('更新清单缺少合法 SHA256')
    notes = data.get('notes') or []
    data['notes'] = notes if isinstance(notes, list) else [str(notes)]
    return data


def download_update_zip(package_url, expected_sha256, version):
    update_dir = os.path.join(software_root_dir(), '_downloaded_updates')
    os.makedirs(update_dir, exist_ok=True)
    filename = safe_filename_part(os.path.basename(urllib.parse.urlparse(package_url).path), f'{version}_update.zip')
    if not filename.lower().endswith('.zip'):
        filename += '.zip'
    zip_path = os.path.join(update_dir, filename)
    req = urllib.request.Request(package_url, headers={'User-Agent': f'EUCWH-Updater/{APP_VERSION}'})
    digest = hashlib.sha256()
    total = 0
    with urllib.request.urlopen(req, timeout=60) as resp, open(zip_path, 'wb') as out:
        if getattr(resp, 'status', 200) >= 400:
            raise RuntimeError(f'HTTP {resp.status}')
        while True:
            chunk = resp.read(1024 * 512)
            if not chunk:
                break
            total += len(chunk)
            if total > UPDATE_MAX_BYTES:
                raise RuntimeError('更新包超过大小限制')
            digest.update(chunk)
            out.write(chunk)
    actual = digest.hexdigest()
    if actual.lower() != expected_sha256.lower():
        remove_file_safely(zip_path)
        raise RuntimeError('更新包 SHA256 校验失败')
    return zip_path, total, actual


def safe_extract_update_zip(zip_path):
    root = software_root_dir()
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        if not names:
            raise RuntimeError('更新包为空')
        top_dirs = {name.split('/')[0] for name in names if name and not name.startswith('../') and '/' in name}
        if len(top_dirs) != 1:
            raise RuntimeError('更新包结构错误：必须包含单一顶层目录')
        top_dir = next(iter(top_dirs))
        for member in names:
            target = os.path.abspath(os.path.join(root, member))
            if not target.startswith(os.path.abspath(root) + os.sep):
                raise RuntimeError('更新包包含非法路径')
        zf.extractall(root)
    extracted = os.path.join(root, top_dir)
    if not os.path.isfile(os.path.join(extracted, f'upgrade_to_{top_dir.split("-")[0].lower()}.exe')):
        candidates = [n for n in os.listdir(extracted) if n.lower().startswith('upgrade_to_') and n.lower().endswith('.exe')]
        if not candidates:
            raise RuntimeError('更新包缺少升级器 exe')
    return extracted
