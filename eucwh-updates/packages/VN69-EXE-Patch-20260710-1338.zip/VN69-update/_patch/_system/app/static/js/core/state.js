    // ===== 全局状态 =====
    const API = '';
    let currentFilterType = '';
    let currentFilterDs = '';
    let currentFilterCountry = '';
    let currentFilterWarehouse = '';
    let currentFilterVerify = '';
    let currentFilterMonth = '';
    let currentFilterPickupMonth = '';
    let currentFilterActualDeliveryMonth = '';
    let shipmentSortBy = '';
    let shipmentSortDir = 'desc';
    let currentEditShipment = null;
    let currentPage = 1;
    let shipmentPerPage = Number(localStorage.getItem('vn22_shipment_per_page') || 20);
    let charts = {};

    // WMS state
    let currentWarehouse = 'Lodz warehouse', currentOrderStatus = '', currentOrderConfirmId = null;
    let pendingImageFiles = [];
