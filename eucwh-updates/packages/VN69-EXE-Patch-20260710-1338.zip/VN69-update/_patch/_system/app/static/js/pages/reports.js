    let reportHeaderIconUrl = '';

    async function loadReportHeaderIcon() {
        const d = await apiFetch(API + '/api/reports/header-icon').catch(() => ({ url: '' }));
        reportHeaderIconUrl = d.url || '';
        const box = document.getElementById('reportLogoPreview');
        if (!box) return;
        box.innerHTML = reportHeaderIconUrl
            ? `<img src="${escapeHtml(reportHeaderIconUrl)}?v=${Date.now()}" alt="Report icon"><span>本地 Icon 已上传</span>`
            : '<span>未上传，使用文字抬头</span>';
    }

    async function loadReportMonths() {
        const select = document.getElementById('reportMonth');
        if (!select) return;
        const rows = await apiFetch(API + '/api/dashboard/monthly_trend').catch(() => []);
        const months = (rows || []).map(r => r.month).filter(Boolean).sort().reverse();
        select.innerHTML = months.length
            ? months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('')
            : '<option value="">暂无月份</option>';
    }

    async function uploadReportHeaderIcon(input) {
        const file = input.files && input.files[0];
        if (!file) return;
        const fd = new FormData();
        fd.append('file', file);
        const d = await apiFetch(API + '/api/reports/header-icon', { method: 'POST', body: fd }).catch(e => ({ error: e.message }));
        input.value = '';
        if (!d.success) return toast(d.error || '上传失败', 'error');
        reportHeaderIconUrl = d.url || '';
        await loadReportHeaderIcon();
        toast('报告抬头 Icon 已更新');
    }

    function updateReportTypeDescription() {
        const type = document.getElementById('reportModalType')?.value || 'monthly_ops';
        const descriptions = {
            monthly_ops: '月度经营总报告：汇总物流履约、库存健康、费用验收和关键风险，适合发给管理层做月度总览。',
            monthly_logistics: '月度物流报告：聚焦运单状态、运输类型、需求国家、代表处、重量体积和物流费用。',
            monthly_inventory: '月度库存报告：聚焦库存货值、PCS、物料品类、适用产品、归属国家和库存健康。',
            inventory_list: '库存清单：导出当前筛选范围内的 SKU 明细，适合盘点、核对和共享给业务同事。',
            monthly_acceptance: '月度验收报告：聚焦发票验收、匹配率、已验收金额、待验收金额和异常费用。',
            monthly_overdue: '月度超期物料报告：聚焦 DOS 超期和长期未使用物料，适合做月度清理跟进。',
            data_quality: '数据质量检查：检查缺图片、缺价格、缺分类、缺时间等问题，适合正式发报告前自检。'
        };
        const el = document.getElementById('reportTypeDescription');
        if (el) el.textContent = descriptions[type] || descriptions.monthly_ops;
        const monthGroup = document.getElementById('reportMonthGroup') || document.getElementById('reportModalMonth')?.closest('.form-group');
        const inventoryFilters = document.getElementById('reportInventoryFilters');
        const outputEl = document.getElementById('reportModalOutput');
        const submitBtn = document.getElementById('reportModalSubmitBtn');
        if (monthGroup) monthGroup.style.display = type === 'inventory_list' ? 'none' : '';
        if (inventoryFilters) inventoryFilters.style.display = type === 'inventory_list' ? 'block' : 'none';
        if (outputEl) {
            const current = outputEl.value;
            if (type === 'inventory_list') {
                outputEl.innerHTML = '<option value="pdf">PDF（默认，报告展示）</option><option value="excel">Excel（全量清单，不嵌入图片）</option><option value="excel_images">Excel（带图片展示，不建议回传）</option><option value="html">HTML（邮件/网页展示）</option><option value="png">长图 PNG</option>';
                outputEl.value = ['pdf', 'excel', 'excel_images', 'html', 'png'].includes(current) ? current : 'pdf';
            } else {
                outputEl.innerHTML = '<option value="preview">生成预览</option><option value="pdf">PDF</option><option value="html">HTML</option><option value="png">长图 PNG</option>';
                outputEl.value = ['preview', 'pdf', 'html', 'png'].includes(current) ? current : 'preview';
            }
        }
        if (submitBtn && outputEl) {
            submitBtn.textContent = outputEl.value === 'preview' ? '生成预览' : '导出';
        }
    }

    function openReportOptionsModal(type = '') {
        const typeEl = document.getElementById('reportModalType');
        const whEl = document.getElementById('reportModalWarehouse');
        const monthEl = document.getElementById('reportModalMonth');
        if (typeEl) typeEl.value = type || document.getElementById('reportType')?.value || 'monthly_ops';
        if (whEl) whEl.value = document.getElementById('reportWarehouse')?.value || '';
        if (monthEl) {
            const reportMonth = document.getElementById('reportMonth');
            const current = reportMonth?.value || new Date().toISOString().slice(0, 7);
            const monthValues = Array.from(reportMonth?.options || []).map(o => o.value).filter(Boolean);
            const years = [...new Set(monthValues.map(v => String(v).slice(0, 4)).filter(y => /^\d{4}$/.test(y)))].sort().reverse();
            const yearOptions = years.map(y => `<option value="year:${escapeHtml(y)}">${escapeHtml(y)}全年</option>`).join('');
            const monthOptions = Array.from(reportMonth?.options || [])
                .filter(o => o.value && o.value !== current)
                .map(o => `<option value="${escapeHtml(o.value)}">${escapeHtml(o.textContent || o.value)}</option>`)
                .join('');
            monthEl.innerHTML = `<option value="${escapeHtml(current)}">当月（${escapeHtml(reportMonthLabel(current))}）</option>${yearOptions}${monthOptions}`;
            monthEl.value = current;
        }
        fillSelectFromOptions('reportInventoryCategory', 'filterCategory', '全部物料品类');
        fillCheckMultiFromOptions('reportInventoryCategory2', 'filterCat2');
        fillSelectFromOptions('reportInventoryInstruction', 'filterInstruction', '全部归属国家');
        updateReportTypeDescription();
        openModal('reportOptionsModal');
    }

    async function runReportFromModal() {
        const type = document.getElementById('reportModalType')?.value || 'monthly_ops';
        const warehouse = document.getElementById('reportModalWarehouse')?.value || '';
        const month = document.getElementById('reportModalMonth')?.value || '';
        const output = document.getElementById('reportModalOutput')?.value || 'preview';
        if (type === 'inventory_list') {
            const filters = {
                warehouse,
                category: document.getElementById('reportInventoryCategory')?.value || '',
                category2: multiCheckValue('reportInventoryCategory2'),
                category2Label: multiCheckLabel('reportInventoryCategory2', '全部适用产品'),
                instruction: document.getElementById('reportInventoryInstruction')?.value || ''
            };
            closeModal('reportOptionsModal');
            if (output === 'excel' || output === 'excel_images') {
                await downloadInventoryExcel(filters, output);
                return;
            }
            await exportAllStockListPdf(filters, output === 'pdf');
            if (output === 'html') await exportReportHtml();
            if (output === 'png') await exportReportPng();
            return;
        }
        const effectiveType = type === 'inventory_list' || type === 'data_quality' ? 'monthly_inventory' : type;
        if (document.getElementById('reportType')) document.getElementById('reportType').value = effectiveType;
        if (document.getElementById('reportWarehouse')) document.getElementById('reportWarehouse').value = warehouse;
        const hiddenMonthEl = document.getElementById('reportMonth');
        if (hiddenMonthEl) {
            if ((month === 'annual' || /^year:\d{4}$/.test(month)) && !Array.from(hiddenMonthEl.options).some(o => o.value === month)) {
                hiddenMonthEl.insertAdjacentHTML('afterbegin', `<option value="${escapeHtml(month)}">${escapeHtml(reportMonthLabel(month))}</option>`);
            }
            hiddenMonthEl.value = month;
        }
        closeModal('reportOptionsModal');
        await generateReportPreview();
        if (output === 'pdf') await printReportPdf();
        if (output === 'html') await exportReportHtml();
        if (output === 'png') await exportReportPng();
    }

    let reportEuropeMap = null;
    let reportGeoJsonLayer = null;
    let reportCountryLabelLayer = null;

    function renderReportCountryMap(shipments, geoData) {
        const mapEl = document.getElementById('report-europe-map');
        if (!mapEl || !window.L) return;
        mapEl.innerHTML = '';
        const filtered = buildDashboardCountryRows(shipments);
        const totalCount = filtered.reduce((s, d) => s + d.count, 0);
        const maxCount = Math.max(...filtered.map(d => d.count), 1);
        const dataByISO3 = {};
        const nameByISO3 = {};
        filtered.forEach(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (iso3) {
                const existing = dataByISO3[iso3];
                if (existing) {
                    const prevCount = Number(existing.count || 0);
                    const nextCount = Number(d.count || 0);
                    const mergedCount = prevCount + nextCount;
                    existing.count = mergedCount;
                    existing.weight = Number(existing.weight || 0) + Number(d.weight || 0);
                    existing.price = Number(existing.price || 0) + Number(d.price || 0);
                    existing.avg_delivery_days = mergedCount
                        ? (((existing.avg_delivery_days || 0) * prevCount) + ((d.avg_delivery_days || 0) * nextCount)) / mergedCount
                        : null;
                    if (nextCount > prevCount) existing.clickCountry = d.country;
                } else {
                    dataByISO3[iso3] = { ...d, clickCountry: d.country };
                }
                nameByISO3[iso3] = ISO2_TO_NAME[d.country] || d.country;
            }
        });
        const sortedCounts = Object.values(dataByISO3).map(d => d.count).sort((a, b) => a - b);
        const minCount = sortedCounts[0] || 1;
        const logMin = Math.log(minCount);
        const logMax = Math.log(maxCount);
        const logRange = logMax - logMin || 1;
        const getColor = count => {
            if (!count) return '#edf2f7';
            const ratio = (Math.log(count) - logMin) / logRange;
            if (ratio > 0.78) return '#cf0a2c';
            if (ratio > 0.58) return '#d77a7d';
            if (ratio > 0.38) return '#7fa9bf';
            if (ratio > 0.18) return '#b8cdd9';
            return '#dce7ee';
        };

        if (reportEuropeMap) {
            reportEuropeMap.remove();
            reportEuropeMap = null;
            reportGeoJsonLayer = null;
            reportCountryLabelLayer = null;
        }
        reportEuropeMap = L.map('report-europe-map', {
            center: [50, 15],
            zoom: 4,
            minZoom: 3,
            maxZoom: 6,
            zoomControl: true,
            attributionControl: false,
            maxBounds: [[35, -15], [72, 45]],
        });

        const europeFeatures = (geoData?.features || []).filter(f => EUROPE_IDS.has(f.id));
        reportGeoJsonLayer = L.geoJSON({ type: 'FeatureCollection', features: europeFeatures }, {
            style: (feature) => {
                const d = dataByISO3[feature.id];
                return {
                    fillColor: getColor(d ? d.count : 0),
                    weight: 1,
                    opacity: 1,
                    color: '#ffffff',
                    fillOpacity: 0.92,
                };
            },
            onEachFeature: (feature, layer) => {
                const iso3 = feature.id;
                const d = dataByISO3[iso3];
                const count = d ? d.count : 0;
                const name = nameByISO3[iso3] || feature.properties.name || iso3;
                const pct = totalCount ? Math.round(count / totalCount * 100) : 0;
                let tooltipHtml = `<div class="tt-name">${name}</div>`;
                if (d && count > 0) {
                    tooltipHtml += `<div class="tt-count">${count} ${t('orderUnit')}</div>`;
                    tooltipHtml += `<div style="color:#64748b;font-size:11px">${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg</div>`;
                    if (d.avg_delivery_days != null) {
                        tooltipHtml += `<div style="color:#64748b;font-size:11px">${t('avgDelivery')}: ${Number(d.avg_delivery_days).toFixed(1)} ${t('workdays')}</div>`;
                    }
                    tooltipHtml += `<div class="tt-pct">${pct}%</div>`;
                } else {
                    tooltipHtml += `<div style="color:#94a3b8">${t('noData')}</div>`;
                }
                layer.bindTooltip(tooltipHtml, { className: 'map-tooltip report-map-tooltip', direction: 'auto', autoPan: true });
            }
        }).addTo(reportEuropeMap);

        reportCountryLabelLayer = L.layerGroup().addTo(reportEuropeMap);
        europeFeatures.filter(f => dataByISO3[f.id]).forEach(feature => {
            const d = dataByISO3[feature.id];
            const countryName = nameByISO3[feature.id] || feature.properties.name || feature.id;
            const layer = reportGeoJsonLayer.getLayers().find(l => l.feature && l.feature.id === feature.id);
            if (!layer) return;
            const bounds = layer.getBounds();
            if (!bounds || !bounds.isValid()) return;
            L.marker(bounds.getCenter(), {
                interactive: false,
                icon: L.divIcon({
                    className: 'map-country-label',
                    html: `${escapeHtml(countryName)} · ${d.count}单 · ${totalCount ? (d.count / totalCount * 100).toFixed(1) : '0.0'}%`,
                    iconSize: null
                })
            }).addTo(reportCountryLabelLayer);
        });
        setTimeout(() => reportEuropeMap?.invalidateSize(), 120);
    }

    function renderReportMonthlyChart(rows) {
        const canvas = document.getElementById('report-chart-monthly');
        if (!canvas || !window.Chart) return;
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        if (!selected.length) selected.push('count');
        const metricConfig = {
            count: { label: t('shipmentCount'), field: 'count', type: 'bar', yAxisID: 'y', color: 'rgba(64,111,181,0.48)', border: '#406fb5', order: 4, format: v => Number(v || 0).toLocaleString() },
            weight: { label: t('weightKg'), field: 'weight', type: 'line', yAxisID: 'y1', color: 'rgba(180,128,36,0.10)', border: '#b48024', order: 3, format: v => Number(v || 0).toLocaleString() + ' kg' },
            volume: { label: '体积 m³', field: 'volume', type: 'line', yAxisID: 'y2', color: 'rgba(42,117,129,0.10)', border: '#2a7581', order: 2, format: v => Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' m³' },
            price: { label: '费用', field: 'price', type: 'line', yAxisID: 'y3', color: 'rgba(207,10,44,0.08)', border: '#cf0a2c', order: 1, format: v => '$' + Number(v || 0).toLocaleString() }
        };
        const datasets = selected.map(key => {
            const cfg = metricConfig[key];
            return {
                label: cfg.label,
                data: (rows || []).map(d => Number(d[cfg.field] || 0)),
                type: cfg.type,
                backgroundColor: cfg.color,
                borderColor: cfg.border,
                borderWidth: cfg.type === 'line' ? 2 : 0,
                pointRadius: cfg.type === 'line' ? 4 : 0,
                pointBackgroundColor: cfg.border,
                borderRadius: cfg.type === 'bar' ? 6 : 0,
                fill: cfg.type === 'line',
                yAxisID: cfg.yAxisID,
                order: cfg.order,
                metricKey: key
            };
        });
        if (charts.reportMonthly) charts.reportMonthly.destroy();
        charts.reportMonthly = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: { labels: (rows || []).map(d => d.month), datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#334155' } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${metricConfig[ctx.dataset.metricKey]?.format(ctx.raw) || ctx.raw}` } }
                },
                scales: {
                    x: { grid: { color: '#e2e8f0' }, ticks: { color: '#64748b' } },
                    y: { display: selected.includes('count'), position: 'left', grid: { color: '#e2e8f0' }, ticks: { color: '#64748b' }, title: { display: true, text: t('shipmentCount'), color: '#64748b' } },
                    y1: { display: selected.includes('weight'), position: 'right', grid: { display: false }, ticks: { color: '#b48024', callback: v => Number(v).toLocaleString() + ' kg' }, title: { display: true, text: t('weightKg'), color: '#b48024' } },
                    y2: { display: selected.includes('volume'), position: 'right', grid: { display: false }, ticks: { color: '#2a7581', callback: v => Number(v).toLocaleString() + ' m³' }, title: { display: true, text: '体积', color: '#2a7581' } },
                    y3: { display: selected.includes('price'), position: 'right', grid: { display: false }, ticks: { color: '#cf0a2c', callback: v => '$' + Number(v).toLocaleString() }, title: { display: true, text: '费用', color: '#cf0a2c' } }
                }
            }
        });
    }

    async function generateReportPreview() {
        const type = document.getElementById('reportType')?.value || 'monthly_ops';
        const warehouse = document.getElementById('reportWarehouse')?.value || '';
        const reportMonth = document.getElementById('reportMonth')?.value || '';
        const queryMonth = reportMonth;
        const modal = document.getElementById('reportPreviewModal');
        const area = document.getElementById('reportPrintArea');
        if (modal) modal.style.display = 'flex';
        if (modal) modal.scrollTop = 0;
        if (area) area.innerHTML = '<div style="color:#64748b;padding:40px;text-align:center">正在生成报告预览...</div>';

        const [shipResp, monthlyRows, invoiceItems, invStats, dos, idle, health, reportGeoData] = await Promise.all([
            apiFetch(API + '/api/shipments?per_page=9999&month=' + encodeURIComponent(queryMonth)),
            apiFetch(API + '/api/dashboard/monthly_trend'),
            apiFetch(API + '/api/invoices/items?type=logistics').catch(() => ({ items: [], summary: {} })),
            apiGet('/api/inventory/stats?warehouse=' + encodeURIComponent(warehouse)),
            apiGet('/api/inventory/stats/dos180?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({ data: [] })),
            apiGet('/api/inventory/stats/idle180?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({ data: [] })),
            apiGet('/api/inventory/stats/health?warehouse=' + encodeURIComponent(warehouse)).catch(() => ({})),
            fetch('/static/europe.geojson').then(r => r.json()).catch(() => null),
        ]);

        const now = new Date();
        const monthText = reportMonthLabel(reportMonth);
        const reportMeta = {
            monthly_ops: { zh: '零售中央仓月度经营总报告', en: 'Retail Central Warehouse Monthly Business Summary Report', note: '本报告用于汇总当前系统中的物流、库存与费用验收状态。' },
            monthly_logistics: { zh: '零售中央仓月度物流报告', en: 'Retail Central Warehouse Monthly Logistics Report', note: '本报告用于整理当月物流履约、国家/代表处要货、重量体积与费用趋势。' },
            monthly_inventory: { zh: '零售中央仓月度库存报告', en: 'Retail Central Warehouse Monthly Inventory Report', note: '本报告用于整理库存货值、DOS 超期、长期未使用与主数据质量。' },
            monthly_acceptance: { zh: '零售中央仓月度验收报告', en: 'Retail Central Warehouse Monthly Acceptance Report', note: '本报告用于整理物流费用发票验收、匹配率、待验收金额与异常提醒。' },
            monthly_overdue: { zh: '零售中央仓月度超期物料报告', en: 'Retail Central Warehouse Monthly Overdue Materials Report', note: '本报告用于聚焦 DOS 超期与长期未使用物料。' }
        };
        const meta = reportMeta[type] || reportMeta.monthly_ops;
        const title = meta.en;
        const zhTitle = meta.zh;
        const showLogistics = type === 'monthly_ops' || type === 'monthly_logistics';
        const showInventory = type === 'monthly_ops' || type === 'monthly_inventory' || type === 'monthly_overdue';
        const showAcceptance = type === 'monthly_ops' || type === 'monthly_acceptance';
        const whText = warehouse || '全部仓库';
        const shipments = shipResp.shipments || [];
        const reportShipments = warehouse ? shipments.filter(s => (s.warehouse || '') === warehouse) : shipments;
        const logisticsBreakdown = buildReportLogisticsBreakdown(reportShipments);
        const statusRows = ['已交付', '待核实', '运输中', '异常单'].map(status => ({ status, count: reportShipments.filter(s => s.display_status === status).length })).filter(r => r.count);
        const typeRows = Object.values(reportShipments.reduce((m, s) => {
            const key = s.shipment_type || 'unknown';
            if (!m[key]) m[key] = { shipment_type: key, label: s.shipment_type_label || key, count: 0 };
            m[key].count += 1;
            return m;
        }, {}));
        const monthlyIndex = new Map((monthlyRows || []).map(r => [r.month, r]));
        const isYearReport = reportMonth === 'annual' || /^year:\d{4}$/.test(reportMonth);
        const currentMonthRow = isYearReport
            ? { month: 'annual', count: reportShipments.length, weight: reportShipments.reduce((s, r) => s + Number(r.total_weight || 0), 0), volume: reportShipments.reduce((s, r) => s + Number(r.total_volume || 0), 0), price: reportShipments.reduce((s, r) => s + Number(r.price_without_vat || 0), 0) }
            : (monthlyIndex.get(reportMonth) || { month: reportMonth, count: reportShipments.length, weight: 0, volume: 0, price: 0 });
        const recentMonthly = (monthlyRows || []).slice(-6);
        const statusTotal = (statusRows || []).reduce((s, r) => s + Number(r.count || 0), 0);
        const typeTotal = (typeRows || []).reduce((s, r) => s + Number(r.count || 0), 0);
        const invoiceMonthItems = (invoiceItems.items || []).filter(i => !queryMonth || String(i.pickup_date || i.ref_date || i.invoice_date || '').slice(0, 7) === queryMonth);
        const verifiedItems = invoiceMonthItems.filter(i => i.invoice_status === 'verified');
        const pendingItems = invoiceMonthItems.filter(i => i.invoice_status === 'pending');
        const verifiedPln = verifiedItems.reduce((s, i) => s + Number(i.net_amount || 0), 0);
        const pendingPln = pendingItems.reduce((s, i) => s + Number(i.net_amount || 0), 0);
        const matchedCount = invoiceMonthItems.filter(i => i.matched_booking_id).length;
        const dosRows = dos.data || [];
        const idleRows = idle.data || [];
        const overdueTotalValue = dosRows.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const missingPrice = health.missing_price || {};
        const missingImage = health.missing_image || {};
        const missingInbound = health.missing_inbound || {};
        const logoHtml = reportHeaderIconUrl
            ? `<img src="${escapeHtml(reportHeaderIconUrl)}?v=${Date.now()}" alt="Report icon">`
            : `<div style="font-size:28px;font-weight:900;color:#cf0a2c;letter-spacing:1px">HUAWEI</div>`;
        let reportSectionNo = 0;
        const logisticsSection = showLogistics ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 物流概览（${escapeHtml(monthText)}）</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">当月总运单</div><div class="value">${formatCount(reportShipments.length)}</div><div class="sub">${escapeHtml(reportMonth || '-')} 取货月份</div></div>
                    <div class="report-kpi"><div class="label">已交付</div><div class="value">${formatCount(statusRows.find(r => r.status === '已交付')?.count || 0)}</div><div class="sub">${statusTotal ? Math.round((statusRows.find(r => r.status === '已交付')?.count || 0) / statusTotal * 100) : 0}% of month</div></div>
                    <div class="report-kpi"><div class="label">当月重量</div><div class="value">${formatCount(currentMonthRow.weight || reportShipments.reduce((s, r) => s + Number(r.total_weight || 0), 0))}</div><div class="sub">kg</div></div>
                    <div class="report-kpi"><div class="label">当月费用</div><div class="value">${formatUsdWhole(currentMonthRow.price || reportShipments.reduce((s, r) => s + Number(r.price_without_vat || 0), 0))}</div><div class="sub">without VAT</div></div>
                </div>
                <div class="report-two-col" style="margin-top:14px">
                    <div class="report-card-print"><h2>运单状态分布</h2>${reportBarRows(statusRows || [], r => statusLabel(r.status || ''), r => r.count, '#3b82f6')}</div>
                    <div class="report-card-print"><h2>运单类型分布</h2>${reportBarRows(typeRows || [], r => typeLabel(r.shipment_type, r.label), r => r.count, '#22c55e')}</div>
                </div>
                <div class="report-two-col report-balanced-row" style="margin-top:14px">
                    <div class="report-card-print report-balanced-card">
                        <h2>代表处维度要货汇总</h2>
                        <table class="report-table">
                            <thead><tr><th>代表处</th><th style="text-align:right">订单数</th><th style="text-align:right">占比</th><th style="text-align:right">重量 kg</th><th style="text-align:right">体积 m³</th><th style="text-align:right">费用</th></tr></thead>
                            <tbody>${reportLogisticsRows(logisticsBreakdown.offices.map(r => ({ ...r, countryName: r.office })), reportShipments.length, false)}</tbody>
                        </table>
                        <h2 style="margin-top:16px">Top3 要货国家</h2>
                        ${reportTopCountryCards(logisticsBreakdown.countries, reportShipments.length)}
                    </div>
                    <div class="report-card-print report-balanced-card report-map-card">
                        <h2>各国订单信息一览</h2>
                        <div class="report-map-frame" id="report-europe-map"></div>
                        <div class="report-map-legend" id="report-map-legend"><span>少</span><div></div><span>多</span></div>
                    </div>
                </div>
                <div class="report-card-print" style="margin-top:14px">
                    <h2>月度运单趋势</h2>
                    <div class="report-chart-note">复用物流看板当前勾选指标：运单数 / 重量 / 体积 / 费用</div>
                    <div class="chart-container" style="height:300px"><canvas id="report-chart-monthly"></canvas></div>
                </div>
            </div>` : '';
        const inventorySection = showInventory ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 库存概览</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">SKU 总数</div><div class="value">${formatCount(invStats.total_skus)}</div><div class="sub">${escapeHtml(whText)}</div></div>
                    <div class="report-kpi"><div class="label">库存总件数</div><div class="value">${formatCount(invStats.total_pcs)}</div><div class="sub">PCS</div></div>
                    <div class="report-kpi"><div class="label">库存总货值</div><div class="value">${formatUsdWhole(invStats.total_value)}</div><div class="sub">USD</div></div>
                    <div class="report-kpi"><div class="label">超期物料总货值</div><div class="value">${formatUsdWhole(overdueTotalValue)}</div><div class="sub">DOS 超期物料 USD</div></div>
                </div>
                <div style="display:grid;grid-template-columns:1fr;gap:14px;margin-top:14px">
                    <div class="report-card-print"><h2>DOS 超期 Top 5</h2>${reportInventoryTopCards(dosRows, 'dos')}</div>
                    <div class="report-card-print"><h2>长期未使用 Top 5</h2>${reportInventoryTopCards(idleRows, 'idle')}</div>
                </div>
            </div>` : '';
        const acceptanceSection = showAcceptance ? `
            <div class="report-section">
                <h2>${++reportSectionNo}. 费用验收</h2>
                <div class="report-kpi-grid">
                    <div class="report-kpi"><div class="label">预算</div><div class="value">${formatUsdWhole(250000)}</div><div class="sub">年度预算</div></div>
                    <div class="report-kpi"><div class="label">当月已验收物流费</div><div class="value">${formatUsdWhole(verifiedPln * 0.25)}</div><div class="sub">${Number(verifiedPln || 0).toLocaleString('pl-PL', { maximumFractionDigits: 0 })} PLN</div></div>
                    <div class="report-kpi"><div class="label">当月待验收物流费</div><div class="value">${formatUsdWhole(pendingPln * 0.25)}</div><div class="sub">需人工确认</div></div>
                    <div class="report-kpi"><div class="label">当月发票匹配率</div><div class="value">${invoiceMonthItems.length ? (matchedCount / invoiceMonthItems.length * 100).toFixed(1) : '0.0'}%</div><div class="sub">${formatCount(matchedCount)} / ${formatCount(invoiceMonthItems.length)}</div></div>
                </div>
                <div class="report-note" style="margin-top:14px">
                    建议：优先核实待验收发票与未匹配 STT；月度报告中应同步检查超期库存是否仍有业务需求，避免库存货值长期沉淀。
                </div>
            </div>` : '';

        area.innerHTML = `
            <div class="report-header">
                <div>
                    <h1 class="report-title">${zhTitle} · ${escapeHtml(monthText)}</h1>
                    <div class="report-subtitle">${title}<br>报告月份：${escapeHtml(monthText)} · 统计范围：${escapeHtml(whText)} · 生成时间：${now.toLocaleString('zh-CN', { hour12:false })} · 版本：${APP_VERSION}</div>
                </div>
                <div>${logoHtml}</div>
            </div>

            <div class="report-note">
                ${meta.note} 数据来源为本地系统数据库，所有上传文件与图片均在本机环境内处理。
            </div>
            ${logisticsSection}
            ${inventorySection}
            ${acceptanceSection}

            <div class="report-footer"><span>Generated by ${APP_VERSION}</span><span>Local offline report preview</span></div>
        `;
        if (showLogistics) {
            renderReportCountryMap(reportShipments, reportGeoData);
            renderReportMonthlyChart(monthlyRows || []);
        }
    }

    function closeReportPreview() {
        document.getElementById('reportPreviewModal').style.display = 'none';
    }

    async function printReportPdf() {
        const modal = document.getElementById('reportPreviewModal');
        const area = document.getElementById('reportPrintArea');
        if (!area || !area.innerHTML.trim()) {
            await generateReportPreview();
        } else if (modal) {
            modal.style.display = 'flex';
        }
        setTimeout(() => window.print(), 250);
    }

    async function ensureReportReady() {
        const area = document.getElementById('reportPrintArea');
        if (!area || !area.innerHTML.trim()) {
            await generateReportPreview();
            await new Promise(resolve => setTimeout(resolve, 500));
        } else {
            const modal = document.getElementById('reportPreviewModal');
            if (modal) modal.style.display = 'flex';
        }
        return document.getElementById('reportPrintArea');
    }

    function reportExportFilename(ext) {
        const area = document.getElementById('reportPrintArea');
        if (area?.dataset?.exportBase) return `${area.dataset.exportBase}.${ext}`;
        const type = document.getElementById('reportType')?.value || 'monthly_ops';
        return exportFileName(type || 'report', ext);
    }

    function downloadReportBlob(blob, filename) {
        downloadLocalBlob(blob, filename);
    }

    function blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }

    async function cloneReportForExport(area) {
        const clone = area.cloneNode(true);
        const sourceCanvases = area.querySelectorAll('canvas');
        clone.querySelectorAll('canvas').forEach((canvas, idx) => {
            const srcCanvas = sourceCanvases[idx];
            if (!srcCanvas) return;
            const img = document.createElement('img');
            img.src = srcCanvas.toDataURL('image/png');
            img.alt = canvas.id || 'chart';
            img.style.width = '100%';
            img.style.height = canvas.style.height || 'auto';
            img.style.display = 'block';
            canvas.replaceWith(img);
        });
        for (const img of clone.querySelectorAll('img')) {
            const src = img.getAttribute('src') || '';
            if (src && !src.startsWith('data:')) {
                try {
                    const abs = new URL(src, location.href).href;
                    const res = await fetch(abs, { cache: 'no-store' });
                    if (res.ok) img.src = await blobToDataUrl(await res.blob());
                    else img.src = abs;
                } catch (_) {
                    img.src = new URL(src, location.href).href;
                }
            }
        }
        return clone;
    }

    async function exportReportHtml() {
        const area = await ensureReportReady();
        if (!area) return toast('请先生成报告预览', 'error');
        const clone = await cloneReportForExport(area);
        const styles = [...document.querySelectorAll('style')].map(s => s.textContent || '').join('\n');
        const links = [...document.querySelectorAll('link[rel="stylesheet"]')].map(l => `<link rel="stylesheet" href="${new URL(l.getAttribute('href'), location.href).href}">`).join('\n');
        const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(area.querySelector('.report-title')?.textContent || '零售中央仓月度报告')}</title>
${links}
<style>
${styles}
body { margin:0; background:#f1f5f9; padding:24px 0; }
.report-sheet { margin:0 auto !important; box-shadow:0 12px 36px rgba(15,23,42,0.16) !important; }
.report-preview-modal,.report-preview-shell { all: unset; }
@media print {
  body { background:#fff; padding:0; }
  .report-sheet { width:100% !important; box-shadow:none !important; padding:14mm !important; }
}
</style>
</head>
<body>
${clone.outerHTML}
</body>
</html>`;
        downloadReportBlob(new Blob(['\uFEFF' + html], { type: 'text/html;charset=utf-8' }), reportExportFilename('html'));
        toast('HTML 长报告已导出');
    }

    async function ensureHtml2Canvas() {
        if (window.html2canvas) return window.html2canvas;
        await new Promise((resolve, reject) => {
            const existing = document.querySelector('script[data-lib="html2canvas"]');
            if (existing) {
                existing.addEventListener('load', resolve, { once: true });
                existing.addEventListener('error', reject, { once: true });
                return;
            }
            const script = document.createElement('script');
            script.src = '/static/vendor/html2canvas.min.js';
            script.dataset.lib = 'html2canvas';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
        return window.html2canvas;
    }

    async function exportReportPng() {
        const area = await ensureReportReady();
        if (!area) return toast('请先生成报告预览', 'error');
        toast('正在生成长图，请稍等...');
        try {
            const render = await ensureHtml2Canvas();
            const exportScale = area.scrollHeight > 9000 ? 2.25 : 3;
            const canvas = await render(area, {
                backgroundColor: '#ffffff',
                scale: exportScale,
                useCORS: true,
                allowTaint: true,
                logging: false,
                windowWidth: area.scrollWidth,
                windowHeight: area.scrollHeight
            });
            canvas.toBlob(blob => {
                if (!blob) return toast('长图生成失败', 'error');
                downloadReportBlob(blob, reportExportFilename('png'));
                toast(`长图 PNG 已导出（${exportScale}x）`);
            }, 'image/png');
        } catch (e) {
            toast('长图生成失败：请检查网络或改用 HTML 导出', 'error');
            console.error(e);
        }
    }

    Object.assign(window, { loadReportHeaderIcon, uploadReportHeaderIcon, generateReportPreview, closeReportPreview, printReportPdf, exportReportHtml, exportReportPng });
