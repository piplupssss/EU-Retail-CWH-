    const LANG_KEY = 'vn8_lang';
    const THEME_KEY = 'vn12_theme';
    let APP_VERSION = 'VN69';
    let APP_VERSION_FULL = 'VN69 · 2026-07-10 13:38 CEST';
    let APP_BUILD_TIME = '2026-07-10 10:46 CEST';
    let APP_PROVIDER = 'Qiteng Liu 84405995';
    let currentLang = 'zh';
    const THEME_LIGHT_DEFAULT_KEY = 'vn52_apple_light_default_applied';
    let storedTheme = localStorage.getItem(THEME_KEY);
    if (localStorage.getItem(THEME_LIGHT_DEFAULT_KEY) !== '1' && (!storedTheme || storedTheme === 'dark')) {
        storedTheme = 'light';
        localStorage.setItem(THEME_KEY, storedTheme);
        localStorage.setItem(THEME_LIGHT_DEFAULT_KEY, '1');
    }
    let currentTheme = storedTheme || 'light';
    const I18N = {
        zh: {
            appName: '欧洲地区部零售物料管理系统',
            versionLine: '版本号：VN69 - 2026-07-10<br>13:38 CEST',
            topbarSubtitle: 'VN69 - 2026-07-10 13:38 CEST · 由Qiteng Liu 84405995 提供',
            providedByPenguin: 'Qiteng Liu 84405995 提供',
            footerCredit: 'Qiteng Liu 84405995 提供',
            username: '用户名',
            password: '密码',
            login: '登 录',
            navMain: '工作台',
            navLogistics: '物流看板',
            navInventory: '库存看板',
            navBudget: '发票看板',
            navDetails: '清单',
            navShipments: '物流清单',
            navStockList: '库存清单',
            navMovements: '出入流水',
            navAcceptanceList: '验收清单',
            navCostList: '费用列表',
            navReportsGroup: '报告',
            navReports: '报告中心',
            navImport: '数据',
            navDataCenter: '数据管理中心',
            navLogisticsImport: '物流数据维护',
            navInventoryImport: '库存数据维护',
            navInvoiceImport: '发票数据维护',
            navOther: '系统',
            navOrders: '发货管理',
            navOperations: '操作记录',
            navSettings: '系统设置',
            navVersionInfo: '版本信息',
            logisticsDashboard: '物流看板',
            logisticsSubtitle: '实时运单数据概览 · 数据更新至',
            trackPlaceholder: '输入 STT Number 或 Booking ID 追踪...',
            track: '追踪',
            inventoryOverview: '库存看板',
            inventorySubtitle: '库存数据分析 · SKU / 货值 / 库龄 / 静置',
            ordersTitle: '发货指令',
            ordersSubtitle: '创建和管理发货指令',
            backToDashboard: '← 返回看板',
            allShipments: '物流清单',
            shipmentSearchPlaceholder: '搜索 Booking / 国家...',
            clearFilters: '清除筛选',
            batchVerify: '批量核实',
            dataImportTitle: '数据管理中心',
            dataImportSubtitle: '集中导入、导出和备份',
            costListTitle: '费用列表',
            costListSubtitle: '物流费用与仓储操作费用明细',
            stockListTitle: '库存清单',
            stockListSubtitle: '点击 Product No 查看 SKU 详情',
            movementsListTitle: '出入流水',
            acceptanceListTitle: '验收清单',
            stockSearchPlaceholder: '搜索产品 / 描述...',
            export: '导出',
            operationsTitle: '库存操作',
            operationsSubtitle: '库存调整 · 报废出库 · 变动记录',
            settingsTitle: '系统设置',
            settingsSubtitle: '系统管理与版本维护',
            versionInfoTitle: '版本信息',
            versionInfoSubtitle: '当前版本 · 数据规则 · 更新纪要',
            inventoryImportTitle: '库存数据维护',
            inventoryImportSubtitle: '刷新库存、导入月度出入库明细与上传产品图片',
            budgetTitle: '发票看板',
            invoiceImportTitle: '发票数据维护',
            invoiceImportSubtitle: '物流费用发票上传与验收 · 仓储操作费用（开发中）',
            statusDistribution: '运单状态分布',
            typeDistribution: '运单类型分布',
            countryInfoOverview: '各国订单信息一览（按取货月份）',
            monthLabel: '月份：',
            all: '全部',
            less: '少',
            more: '多',
            countryDemandDistribution: '各国要货量分布',
            monthlyShipmentTrend: '月度运单趋势',
            clickToView: '点击查看',
            clickCountryToView: '点击国家查看',
            totalShipments: '总运单数',
            viewAll: '点击查看全部',
            delivered: '已交付',
            pendingVerify: '待核实',
            inTransit: '运输中',
            exception: '异常单',
            deliveredShipments: '已交付运单',
            pendingVerifyShipments: '待核实运单',
            inTransitShipments: '运输中运单',
            exceptionShipments: '异常运单',
            ratioClick: '占比 {pct}% · 点击查看',
            etaReached: 'ETA 已到需人工确认 · 点击查看',
            shipOverdue: '发货超 10 工作日未签收 · 点击查看',
            orderUnit: '单',
            weightLabel: '重量',
            avgDelivery: '平均交付',
            workdays: '工作日',
            shipmentCount: '运单数',
            weightKg: '重量(kg)',
            noData: '暂无数据',
            centralWarehouseOutbound: '中央仓发出',
            furnitureWarehouseOutbound: '家具仓发出',
            directShipment: '调拨',
            shipToCountry: '发货至 {country}',
            warehouseOutbound: '{warehouse} 发货'
        },
        en: {
            appName: 'EU RHQ Retail Materials Management System',
            versionLine: 'Version: VN69 - 2026-07-10<br>13:38 CEST',
            topbarSubtitle: 'VN69 - 2026-07-10 13:38 CEST · Provided by Qiteng Liu 84405995',
            providedByPenguin: 'Provided by Qiteng Liu 84405995',
            footerCredit: 'Provided by Qiteng Liu 84405995',
            username: 'Username',
            password: 'Password',
            login: 'Log In',
            navMain: 'Workspace',
            navLogistics: 'Logistics Dashboard',
            navInventory: 'Inventory Dashboard',
            navBudget: 'Invoice Dashboard',
            navDetails: 'Lists',
            navShipments: 'Shipment List',
            navStockList: 'Inventory List',
            navMovements: 'Movement List',
            navAcceptanceList: 'Acceptance List',
            navCostList: 'Cost List',
            navReportsGroup: 'Reports',
            navReports: 'Report Center',
            navImport: 'Data',
            navDataCenter: 'Data Center',
            navLogisticsImport: 'Logistics Data',
            navInventoryImport: 'Inventory Data',
            navInvoiceImport: 'Invoice Data',
            navOther: 'System',
            navOrders: 'Delivery Orders',
            navOperations: 'Operations Log',
            navSettings: 'Settings',
            navVersionInfo: 'Version Info',
            logisticsDashboard: 'Logistics Dashboard',
            logisticsSubtitle: 'Live shipment overview · Data updated to',
            trackPlaceholder: 'Track by STT Number or Booking ID...',
            track: 'Track',
            inventoryOverview: 'Inventory Overview',
            inventorySubtitle: 'Inventory analytics · SKU / Value / Age / Idle',
            ordersTitle: 'Delivery Orders',
            ordersSubtitle: 'Create and manage delivery orders',
            backToDashboard: '← Back to Dashboard',
            allShipments: 'All Shipments',
            shipmentSearchPlaceholder: 'Search booking / country...',
            clearFilters: 'Clear Filters',
            batchVerify: 'Batch Verify',
            dataImportTitle: 'Data Center',
            dataImportSubtitle: 'Centralized import, export, and backup.',
            costListTitle: 'Cost List',
            costListSubtitle: 'Logistics and warehouse operation cost details',
            stockListTitle: 'Inventory List',
            stockListSubtitle: 'Click Product No for SKU details',
            stockSearchPlaceholder: 'Search product / description...',
            export: 'Export',
            operationsTitle: 'Inventory Operations',
            operationsSubtitle: 'Inventory adjustment · Scrap outbound · Transaction history',
            settingsTitle: 'Settings',
            settingsSubtitle: 'Classification scan · thresholds · display preferences',
            versionInfoTitle: 'Version Info',
            versionInfoSubtitle: 'Current version · data rules · changelog',
            inventoryImportTitle: 'Inventory Data',
            inventoryImportSubtitle: 'Upload Excel inventory lists and SKU product images',
            budgetTitle: 'Invoice Dashboard',
            invoiceImportTitle: 'Invoice Data',
            invoiceImportSubtitle: 'Logistics invoice upload and acceptance · Warehouse operation cost in development',
            statusDistribution: 'Shipment Status Distribution',
            typeDistribution: 'Shipment Type Distribution',
            countryInfoOverview: 'Country Order Overview (Pickup Month)',
            monthLabel: 'Month:',
            all: 'All',
            less: 'Low',
            more: 'High',
            countryDemandDistribution: 'Country Demand Distribution',
            monthlyShipmentTrend: 'Monthly Shipment Trend',
            clickToView: 'Click to view',
            clickCountryToView: 'Click country to view',
            totalShipments: 'Total Shipments',
            viewAll: 'Click to view all',
            delivered: 'Delivered',
            pendingVerify: 'Pending Check',
            inTransit: 'In Transit',
            exception: 'Exceptions',
            deliveredShipments: 'Delivered Shipments',
            pendingVerifyShipments: 'Pending Check Shipments',
            inTransitShipments: 'In-Transit Shipments',
            exceptionShipments: 'Exception Shipments',
            ratioClick: 'Share {pct}% · click to view',
            etaReached: 'ETA reached, manual check needed · click to view',
            shipOverdue: 'No POD after 10 workdays · click to view',
            orderUnit: 'orders',
            weightLabel: 'Weight',
            avgDelivery: 'Avg delivery',
            workdays: 'workdays',
            shipmentCount: 'Shipments',
            weightKg: 'Weight (kg)',
            noData: 'No data',
            centralWarehouseOutbound: 'Central Warehouse',
            furnitureWarehouseOutbound: 'Furniture Warehouse',
            directShipment: 'Transfer',
            shipToCountry: 'Ship to {country}',
            warehouseOutbound: '{warehouse} outbound'
        }
    };

    function t(key) {
        return (I18N[currentLang] && I18N[currentLang][key]) || I18N.zh[key] || key;
    }
    function tf(key, vars = {}) {
        return t(key).replace(/\{(\w+)\}/g, (_, name) => vars[name] ?? '');
    }
    function tx(zh, en) {
        return currentLang === 'en' ? en : zh;
    }
    function formatBuildDateForLogin(buildTime) {
        const parts = String(buildTime || '').split(' ');
        if (parts.length >= 3) return `${parts[0]}<br>${parts.slice(1).join(' ')}`;
        return String(buildTime || '').replace(/\s+/, '<br>');
    }
    function syncReleaseI18n() {
        I18N.zh.versionLine = `版本号：${APP_VERSION} - ${formatBuildDateForLogin(APP_BUILD_TIME)}`;
        I18N.en.versionLine = `Version: ${APP_VERSION} - ${formatBuildDateForLogin(APP_BUILD_TIME)}`;
        I18N.zh.topbarSubtitle = `${APP_VERSION} - ${APP_BUILD_TIME} · 由${APP_PROVIDER} 提供`;
        I18N.en.topbarSubtitle = `${APP_VERSION} - ${APP_BUILD_TIME} · Provided by ${APP_PROVIDER}`;
        I18N.zh.providedByPenguin = `${APP_PROVIDER} 提供`;
        I18N.en.providedByPenguin = `Provided by ${APP_PROVIDER}`;
        I18N.zh.footerCredit = `${APP_PROVIDER} 提供`;
        I18N.en.footerCredit = `Provided by ${APP_PROVIDER}`;
    }
    async function loadReleaseInfo() {
        try {
            const res = await fetch('/static/release_info.json', { cache: 'no-store' });
            if (!res.ok) return;
            const info = await res.json();
            APP_VERSION = String(info.version || APP_VERSION).toUpperCase();
            APP_BUILD_TIME = String(info.build_time || APP_BUILD_TIME);
            APP_PROVIDER = String(info.provider || APP_PROVIDER);
            APP_VERSION_FULL = `${APP_VERSION} · ${APP_BUILD_TIME}`;
            syncReleaseI18n();
            applyLanguage();
            document.dispatchEvent(new CustomEvent('release-info-loaded', { detail: { version: APP_VERSION, build_time: APP_BUILD_TIME, provider: APP_PROVIDER } }));
        } catch (e) {
            console.warn('release_info load skipped', e);
        }
    }
    syncReleaseI18n();
    const UI_EN_TEXT = {
        '夜间': 'Dark',
        '白天': 'Light',
        '工作台': 'Workspace',
        '列表详情': 'Details',
        '数据': 'Data',
        '系统': 'System',
        '全部': 'All',
        '全部仓库': 'All warehouses',
        'Lodz 仓库': 'Lodz warehouse',
        'Bydgoszcz 仓库': 'Bydgoszcz warehouse',
        '库存范围': 'Inventory scope',
        '切换后同步刷新看板与清单入口': 'Switch warehouse scope for dashboards and lists',
        '库存健康': 'Inventory health',
        'DOS 超期': 'DOS overdue',
        '长期未使用': 'Long idle',
        '分析维度': 'Primary dimension',
        '拆分维度': 'Breakdown dimension',
        '物料品类': 'Category',
        '适用产品': 'Category 2',
        '归属国家': 'Instruction',
        '纵坐标': 'Y axis',
        '运单数': 'Shipments',
        '重量': 'Weight',
        '费用': 'Cost',
        '发票验收': 'Invoice Acceptance',
        '平均交付': 'Avg delivery',
        '排序方式': 'Sort mode',
        '全部国家': 'All countries',
        '按代表处排列': 'By office',
        '筛选单个代表处': 'Single office',
        '代表处': 'Office',
        '波兰代表处': 'Poland office',
        '德国代表处': 'Germany office',
        '法国代表处': 'France office',
        '南欧代表处': 'South Europe office',
        '东欧多国代表处': 'Eastern Europe office',
        '代表处内部订单对比': 'Office internal order split',
        '体积': 'Volume',
        '发货指令': 'Delivery orders',
        '开发中': 'In development',
        '待确认': 'Pending',
        '已确认': 'Confirmed',
        '已发货': 'Shipped',
        '已签收': 'Received',
        '+ 新建指令': '+ New order',
        '指令单号': 'Order No.',
        '目的国家': 'Destination',
        '请求数量': 'Requested qty',
        '实际数量': 'Actual qty',
        '状态': 'Status',
        '创建时间': 'Created at',
        '操作': 'Action',
        '全部物流查询与筛选 · 从看板点击可自动筛选': 'Search and filter all logistics records · dashboard clicks apply filters automatically',
        '20 条/页': '20 / page',
        '50 条/页': '50 / page',
        '100 条/页': '100 / page',
        '显示/隐藏详细列': 'Show/hide detail columns',
        '详细列': 'Detail columns',
        '一键导出物流清单': 'Export logistics list',
        '维护所选': 'Maintain selected',
        '点击 STT / Booking 查看详情和追踪；勾选后做批量维护': 'Click STT / Booking for details and tracking; select rows for batch maintenance',
        '回收站': 'Recycle bin',
        '移入回收站': 'Move to recycle bin',
        '点击 STT / Booking 查看详情和追踪；勾选后可批量核实或移入回收站': 'Click STT / Booking for details and tracking; selected rows can be batch verified or recycled',
        '物流状态': 'Shipment status',
        '类型': 'Type',
        '国家': 'Country',
        '城市': 'City',
        '地址信息': 'Address',
        '发货日期': 'Pickup date',
        '预计收货': 'ETA',
        '交付(工作日)': 'Delivery days',
        '实际交付': 'Actual delivery',
        '重量(kg)': 'Weight (kg)',
        '验收状态': 'Acceptance status',
        '验收金额': 'Accepted amount',
        '数据管理中心': 'Data Center',
        '物流数据': 'Logistics data',
        '库存数据': 'Inventory data',
        '发票数据': 'Invoice data',
        '数据校准&备份': 'Calibration & backup',
        '常用': 'Common',
        '非常用': 'Rare use',
        '谨慎操作': 'Caution',
        '选择文件': 'Choose file',
        '导入物流': 'Import logistics',
        '导入校准': 'Import calibration',
        '导入发票': 'Import invoice',
        '供应商库存刷新': 'Supplier inventory refresh',
        '图片管理': 'Image management',
        '上传图片': 'Upload images',
        '物流费用发票': 'Logistics invoice',
        '仓储操作费用发票': 'Warehouse operation invoice',
        '发票验收校准 Excel': 'Invoice calibration Excel',
        '恢复完整包': 'Restore full package',
        '导出全部仓库完整包': 'Export all-warehouse full package',
        '报告中心': 'Report Center',
        '生成 / 导出报告': 'Generate / export report',
        '系统设置': 'Settings',
        '版本信息': 'Version Info',
        '仓库库存': 'Warehouse inventory',
        '仓库': 'Warehouse',
        '库存': 'Inventory',
        '全部 SKU 库存明细': 'All SKU inventory details',
        '点击 Product No 查看详情 / 维护 SKU': 'Click Product No for details / SKU maintenance',
        '库存更新时间：-': 'Inventory updated: -',
        'Product No 详情': 'Product No Details',
        'BOM 编号': 'BOM Code',
        '图': 'Image',
        '一键导出库存清单': 'Export inventory list',
        '点击查看 Product No 明细': 'Click to view Product No details',
        '点击或双击查看大图': 'Click or double-click to view large image',
        '加载中...': 'Loading...',
        '上一页': 'Previous',
        '下一页': 'Next',
        '最近入库': 'Last inbound',
        '最近出库': 'Last outbound',
        '备注': 'Comment',
        '近期出入流水（按 DATA RUCHU）': 'Recent inbound/outbound records (by DATA RUCHU)',
        '入库': 'Inbound',
        '出库': 'Outbound',
        '订单类型': 'Order type',
        '对象/国家城市': 'Target / country or city',
        '数量': 'Qty',
        '暂无 Specyfikacja 流水': 'No Specyfikacja records',
        '暂无库存': 'No inventory',
        '维护 SKU': 'Maintain SKU',
        '单价': 'Unit price',
        '单击背景关闭': 'Click background to close',
        '取消': 'Cancel',
        '确认': 'Confirm',
        '导出': 'Export',
        '清除筛选': 'Clear filters',
        '中央仓发出': 'Central warehouse',
        '家具仓发出': 'Furniture warehouse',
        '调拨': 'Transfer',
        '已交付': 'Delivered',
        '运输中': 'In transit',
        '待核实': 'Pending check',
        '异常单': 'Exception',
        '已验收': 'Accepted',
        '待验收': 'Pending acceptance',
        '未关联': 'Unmatched',
        '已拒绝': 'Rejected'
    };
    function applyFallbackEnglish(root = document.body) {
        if (currentLang !== 'en' || !root) return;
        const shouldSkip = node => {
            const parent = node.parentElement;
            return !parent || ['SCRIPT', 'STYLE', 'TEXTAREA'].includes(parent.tagName);
        };
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                if (shouldSkip(node)) return NodeFilter.FILTER_REJECT;
                const trimmed = node.nodeValue.trim();
                return UI_EN_TEXT[trimmed] ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
            }
        });
        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);
        nodes.forEach(node => {
            const raw = node.nodeValue;
            const leading = raw.match(/^\s*/)?.[0] || '';
            const trailing = raw.match(/\s*$/)?.[0] || '';
            node.nodeValue = leading + UI_EN_TEXT[raw.trim()] + trailing;
        });
        root.querySelectorAll?.('[title]').forEach(el => {
            const title = (el.getAttribute('title') || '').trim();
            if (UI_EN_TEXT[title]) el.setAttribute('title', UI_EN_TEXT[title]);
        });
    }

    function setLanguage(lang) {
        currentLang = lang === 'en' ? 'en' : 'zh';
        applyLanguage();
    }

    function applyLanguage() {
        document.documentElement.lang = currentLang === 'en' ? 'en' : 'zh-CN';
        document.querySelectorAll('[data-i18n]').forEach(el => { el.textContent = t(el.dataset.i18n); });
        document.querySelectorAll('[data-i18n-html]').forEach(el => { el.innerHTML = t(el.dataset.i18nHtml); });
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => { el.placeholder = t(el.dataset.i18nPlaceholder); });
        document.querySelectorAll('.lang-btn[data-lang]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.lang === currentLang);
        });
        document.title = t('appName');
        applyFallbackEnglish();
        updateClock();
        if (document.getElementById('page-logistics')?.classList.contains('active') && getAuthToken()) {
            loadDashboard();
        }
    }

    function setThemeMode(mode) {
        currentTheme = mode === 'light' ? 'light' : 'dark';
        localStorage.setItem(THEME_KEY, currentTheme);
        applyTheme();
    }

    function applyTheme() {
        document.documentElement.dataset.theme = currentTheme;
        document.querySelectorAll('[data-theme-option]').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.themeOption === currentTheme);
        });
    }
