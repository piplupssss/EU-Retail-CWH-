// Shared presentation helpers for the inventory dashboard.

function buildInventoryHeatmap(rows, primary, secondary, totalValue) {
    const primaryLabels = groupInventoryRows(rows, primary).slice(0, 8).map(r => r.label);
    const secondaryLabels = groupInventoryRows(rows, secondary).slice(0, 7).map(r => r.label);
    const cellMap = new Map();
    rows.forEach(r => {
        const key = `${r[primary] || 'UNSPECIFIED'}|||${r[secondary] || 'UNSPECIFIED'}`;
        const cur = cellMap.get(key) || { ttl_amount: 0, total_pcs: 0, sku_count: 0 };
        cur.ttl_amount += Number(r.ttl_amount || 0);
        cur.total_pcs += Number(r.total_pcs || 0);
        cur.sku_count += Number(r.sku_count || 0);
        cellMap.set(key, cur);
    });
    const maxValue = Math.max(...[...cellMap.values()].map(v => v.ttl_amount), 1);
    const empty = `<td style="background:rgba(148,163,184,0.04)"><div class="heatmap-cell-main" style="color:var(--text-muted)">-</div></td>`;
    const body = primaryLabels.map(p => {
        const cells = secondaryLabels.map(s => {
            const c = cellMap.get(`${p}|||${s}`);
            if (!c) return empty;
            const intensity = Math.max(0.08, c.ttl_amount / maxValue);
            const pct = fmtPct(c.ttl_amount, totalValue);
            return `<td style="background:rgba(59,130,246,${Math.min(0.82, 0.10 + intensity * 0.72)})" title="${escapeHtml(p)} / ${escapeHtml(s)} · ${fmt$(c.ttl_amount)} · ${Number(c.total_pcs).toLocaleString()} PCS">
                <div class="heatmap-cell-main">${fmt$(c.ttl_amount)}</div>
                <div class="heatmap-cell-sub">${Number(c.total_pcs).toLocaleString()} PCS · ${pct}</div>
            </td>`;
        }).join('');
        return `<tr><th style="min-width:130px">${escapeHtml(p)}</th>${cells}</tr>`;
    }).join('');
    return `<div class="heatmap-wrap"><table class="heatmap-table"><thead><tr><th>${INVENTORY_DIMENSIONS[primary].short} × ${INVENTORY_DIMENSIONS[secondary].short}</th>${secondaryLabels.map(s => `<th>${escapeHtml(s)}</th>`).join('')}</tr></thead><tbody>${body || `<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:32px">暂无组合数据</td></tr>`}</tbody></table></div>`;
}

function buildInventoryDecisionCards(grouped, totalValue, totalPcs, pDef) {
    const buckets = { core: [], value: [], bulk: [], balanced: [] };
    grouped.forEach(r => {
        const pos = getInventoryGroupPosition(r, totalValue, totalPcs);
        buckets[pos.key].push({ ...r, pos, valueShare: totalValue ? r.ttl_amount / totalValue : 0, pcsShare: totalPcs ? r.total_pcs / totalPcs : 0 });
    });
    const pick = [
        buckets.core.sort((a, b) => (b.ttl_amount + b.total_pcs) - (a.ttl_amount + a.total_pcs))[0],
        buckets.value.sort((a, b) => (b.valueShare - b.pcsShare) - (a.valueShare - a.pcsShare))[0],
        buckets.bulk.sort((a, b) => (b.pcsShare - b.valueShare) - (a.pcsShare - a.valueShare))[0],
        buckets.balanced.sort((a, b) => b.ttl_amount - a.ttl_amount)[0]
    ].filter(Boolean);
    if (!pick.length) return '';
    return `<div class="inventory-decision-grid">${pick.map(r => `
        <div class="inventory-decision">
            <div class="tag" style="color:${r.pos.color};background:${r.pos.bg}">${r.pos.label}</div>
            <div class="name">${escapeHtml(r.label || '-')}</div>
            <div class="meta">
                ${pDef.label} · 货值 ${fmtPct(r.ttl_amount, totalValue)} / 件数 ${fmtPct(r.total_pcs, totalPcs)}<br>
                ${fmt$(r.ttl_amount)} · ${Number(r.total_pcs || 0).toLocaleString()} PCS · ${Number(r.sku_count || 0).toLocaleString()} SKU<br>
                ${r.pos.advice}
            </div>
            <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({${pDef.label === '物料品类' ? 'category' : pDef.label === '适用产品' ? 'category2' : 'instruction'}:${jsArg(r.label || '')}})">查看明细</button>
        </div>`).join('')}</div>`;
}

function buildInventoryPriorityPanel(title, rows, kind) {
    const list = (rows || []).slice(0, 3);
    if (!list.length) {
        return `<div class="inventory-priority-panel"><h3>${title}</h3><div class="inventory-priority-muted">暂无需要优先处理的 SKU</div></div>`;
    }
    const dayLabel = kind === 'idle' ? '未使用' : '库龄';
    return `<div class="inventory-priority-panel">
        <h3>${title}</h3>
        ${list.map(r => {
            const product = r.product_number || r.bom_code || '';
            const days = Number(kind === 'idle' ? (r.idle_days || 0) : (r.dos || 0));
            return `<div class="inventory-priority-item">
                <div class="inventory-priority-code">
                    <button type="button" class="link-btn" data-product-detail="${escapeHtml(product || '')}" onclick="openProductDetail(this.dataset.productDetail)" title="${escapeHtml(r.product_description || product)}">${escapeHtml(product || '-')}</button>
                </div>
                <div>${fmt$(r.ttl_amount)}</div>
                <div>${Number(r.inventory || 0).toLocaleString()} PCS</div>
                <div class="inventory-priority-muted">${dayLabel} ${days.toLocaleString()} 天</div>
            </div>`;
        }).join('')}
    </div>`;
}

function buildInventoryPriorityBoard(health) {
    return `<div class="inventory-priority-board">
        ${buildInventoryPriorityPanel('优先行动 · DOS 超期 Top3', health.top_dos, 'dos')}
        ${buildInventoryPriorityPanel('优先行动 · 长期未使用 Top3', health.top_idle, 'idle')}
    </div>`;
}

function buildInventoryActionRows(rows, type) {
    const list = (rows || []).slice(0, 6);
    if (!list.length) return '<div style="color:var(--text-muted);padding:18px 0">暂无需要提醒的物料</div>';
    const dayLabel = type === 'idle' ? '未使用天数' : 'DOS 天数';
    const header = `<div class="inventory-action-item inventory-action-header" aria-hidden="true">
        <div></div>
        <div class="item-main">物料</div>
        <div class="item-metric">货值</div>
        <div class="item-metric">单价</div>
        <div class="item-metric">库存</div>
        <div class="item-metric">${dayLabel}</div>
        <div class="item-advice">处理建议</div>
    </div>`;
    return `<div class="inventory-action-list">${header}${list.map(r => {
        const days = type === 'idle' ? (r.idle_days || 0) : (r.dos || 0);
        const advice = type === 'idle'
            ? (days >= 365 ? '超过 365 天未出库，建议和业务确认是否清理或转移。' : '长期未使用，建议确认后续需求。')
            : ((r.overdue_days || 0) >= 90 ? '超期严重，优先盘点并确认是否仍需保留。' : '已超过品类阈值，建议纳入定期跟进。');
        const imagePath = r.image_path || '';
        const remark = r.product_description || '';
        const imageArg = jsArg(imagePath);
        const remarkArg = jsArg(remark);
        const thumb = imagePath
            ? `<img class="inventory-action-thumb stock-thumb thumb-clickable" src="${escapeHtml(imageUrl(imagePath))}" data-image-path="${escapeHtml(imagePath)}" data-remark="${escapeHtml(remark)}" onclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" ondblclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="点击或双击查看大图">`
            : '<div class="inventory-action-noimg">无图</div>';
        return `<div class="inventory-action-item">
            ${thumb}
            <div class="item-main" title="${escapeHtml(r.product_description || r.product_number || '')}">
                <button type="button" class="link-btn inventory-action-title" data-product-detail="${escapeHtml(r.product_number || r.bom_code || '')}" onclick="openProductDetail(this.dataset.productDetail)" style="padding:0;font-weight:800;text-align:left">${escapeHtml(r.product_number || r.bom_code || '-')}</button>
                <div class="inventory-action-desc">${escapeHtml(r.product_description || '无描述')}</div>
                <div class="inventory-action-meta">仓库：${escapeHtml(r.warehouse || '-')} · BOM：${escapeHtml(displayBomCode(r.bom_code))}</div>
            </div>
            <div class="item-metric">${fmt$(r.ttl_amount)}</div>
            <div class="item-metric">${r.unit_price != null ? '$' + Number(r.unit_price || 0).toFixed(2) : '-'}</div>
            <div class="item-metric">${Number(r.inventory || 0).toLocaleString()} PCS</div>
            <div class="item-metric">${days} 天</div>
            <div class="item-advice">${advice}</div>
        </div>`;
    }).join('')}</div>`;
}

function buildInventoryRiskSnapshot(health) {
    const total = health.total || {};
    const dos = health.dos || {};
    const idle = health.idle || {};
    const neverOutbound = health.never_outbound || {};
    const dq = health.data_quality || {};
    const missingPrice = dq.missing_price || {};
    const missingImage = dq.missing_image || {};
    const missingInbound = dq.missing_inbound || {};
    const dosLevel = inventoryRiskLevel(dos.ttl_amount || 0, total.ttl_amount || 0);
    const idleLevel = inventoryRiskLevel(idle.ttl_amount || 0, total.ttl_amount || 0);
    const riskCard = (label, value, sub, cls, action = '') => `
        <div class="inventory-risk-card ${action ? 'inventory-risk-click clickable' : ''}" ${action}>
            <div class="risk-label">${label}</div>
            <div class="risk-value ${cls || ''}">${value}</div>
            <div class="risk-sub">${sub}</div>
        </div>`;
    return `<div class="inventory-risk-grid inventory-risk-snapshot">
        ${riskCard('DOS 超期', fmt$(dos.ttl_amount || 0), `${Number(dos.total_pcs || 0).toLocaleString()} PCS · ${Number(dos.sku_count || 0).toLocaleString()} SKU · ${dosLevel.text}`, 'danger', `onclick="document.querySelector('#invDashTabs .tab[data-dtab=dos180]')?.click()"`)}
        ${riskCard('长期未使用', fmt$(idle.ttl_amount || 0), `${Number(idle.total_pcs || 0).toLocaleString()} PCS · ${Number(idle.sku_count || 0).toLocaleString()} SKU · 含从未出库 ${Number(neverOutbound.sku_count || 0).toLocaleString()} SKU`, 'warning', `onclick="document.querySelector('#invDashTabs .tab[data-dtab=idle180]')?.click()"`)}
        ${riskCard('缺价格', Number(missingPrice.sku_count || 0).toLocaleString(), `${fmt$(missingPrice.ttl_amount || 0)} · ${Number(missingPrice.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'danger', `onclick="openStockListFromInventory({quality:'missing_price'})"`)}
        ${riskCard('缺图片', Number(missingImage.sku_count || 0).toLocaleString(), `${fmt$(missingImage.ttl_amount || 0)} · ${Number(missingImage.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'warning', `onclick="openStockListFromInventory({quality:'missing_image'})"`)}
        ${riskCard('缺入库时间', Number(missingInbound.sku_count || 0).toLocaleString(), `${fmt$(missingInbound.ttl_amount || 0)} · ${Number(missingInbound.total_pcs || 0).toLocaleString()} PCS · 点击处理`, 'warning', `onclick="openStockListFromInventory({quality:'missing_inbound'})"`)}
    </div>
    ${buildInventoryPriorityBoard(health)}`;
}

function buildInventoryHealthPanel(health) {
    const total = health.total || {};
    const dos = health.dos || {};
    const idle = health.idle || {};
    const neverOutbound = health.never_outbound || {};
    const dq = health.data_quality || {};
    const dosLevel = inventoryRiskLevel(dos.ttl_amount || 0, total.ttl_amount || 0);
    const idleLevel = inventoryRiskLevel(idle.ttl_amount || 0, total.ttl_amount || 0);
    const missingPrice = dq.missing_price || {};
    const missingImage = dq.missing_image || {};
    const missingInbound = dq.missing_inbound || {};
    return `
        <div class="inventory-health-panel">
            <h3>库存健康总览</h3>
            <div class="inventory-risk-grid">
                <div class="inventory-risk-card">
                    <div class="risk-label">当前库存规模</div>
                    <div class="risk-value">${fmt$(total.ttl_amount || 0)}</div>
                    <div class="risk-sub">${Number(total.total_pcs || 0).toLocaleString()} PCS · ${Number(total.sku_count || 0).toLocaleString()} SKU</div>
                </div>
                <div class="inventory-risk-card">
                    <div class="risk-label">DOS 超期货值</div>
                    <div class="risk-value" style="color:${dosLevel.color}">${fmt$(dos.ttl_amount || 0)}</div>
                    <div class="risk-sub">${dosLevel.text} · ${Number(dos.total_pcs || 0).toLocaleString()} PCS · ${Number(dos.sku_count || 0).toLocaleString()} SKU · 平均超期 ${dos.avg_overdue_days || 0} 天</div>
                </div>
                <div class="inventory-risk-card">
                    <div class="risk-label">长期未使用货值</div>
                    <div class="risk-value" style="color:${idleLevel.color}">${fmt$(idle.ttl_amount || 0)}</div>
                    <div class="risk-sub">${idleLevel.text} · ${Number(idle.total_pcs || 0).toLocaleString()} PCS · ${Number(idle.sku_count || 0).toLocaleString()} SKU · 平均超期 ${idle.avg_overdue_days || 0} 天</div>
                </div>
                <div class="inventory-risk-card">
                    <div class="risk-label">从未出库库存</div>
                    <div class="risk-value" style="color:var(--warning)">${fmt$(neverOutbound.ttl_amount || 0)}</div>
                    <div class="risk-sub">${Number(neverOutbound.total_pcs || 0).toLocaleString()} PCS · ${Number(neverOutbound.sku_count || 0).toLocaleString()} SKU · 建议确认新品、备品或无需求物料。</div>
                </div>
                <div class="inventory-risk-card">
                    <div class="risk-label">主数据缺失</div>
                    <div class="risk-value" style="color:var(--danger)">${Number(missingPrice.sku_count || 0) + Number(missingImage.sku_count || 0) + Number(missingInbound.sku_count || 0)}</div>
                    <div class="risk-sub">缺价格 ${Number(missingPrice.sku_count || 0)} SKU · 缺图片 ${Number(missingImage.sku_count || 0)} SKU · 缺入库时间 ${Number(missingInbound.sku_count || 0)} SKU</div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
                        <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_price'})">缺价格</button>
                        <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_image'})">缺图片</button>
                        <button class="btn btn-secondary btn-sm" onclick="openStockListFromInventory({quality:'missing_inbound'})">缺入库时间</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="charts-grid">
            <div class="chart-card full-width">
                <h3>优先处理 · DOS 超期物料</h3>
                ${buildInventoryActionRows(health.top_dos, 'dos')}
            </div>
            <div class="chart-card full-width">
                <h3>优先处理 · 长期未使用物料</h3>
                ${buildInventoryActionRows(health.top_idle, 'idle')}
            </div>
        </div>`;
}
