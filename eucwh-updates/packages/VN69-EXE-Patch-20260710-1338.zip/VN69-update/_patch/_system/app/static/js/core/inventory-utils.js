// Shared inventory helpers and constants used by inventory dashboard, stock list, and reports.
const TTL_COLORS = ['#3b82f6','#06b6d4','#22c55e','#eab308','#ef4444','#8b5cf6','#ec4899','#f97316','#14b8a6','#6366f1','#a855f7','#f43f5e'];
const DEFAULT_CATEGORY_OPTIONS = ['ACRYLIC PROP','DUMMY','FURNITURE','GIFT','PROP','SECURITY SYSTEM','TOOLS/ACCESSORIES','TRAINING MATERIALS','UNIFORM','WOODEN OVERLAY'];
const DEFAULT_CATEGORY2_OPTIONS = ['AUDIO','IOT','OTHER','PHONE','TABLET','WEARABLE'];
const DEFAULT_INSTRUCTION_OPTIONS = ['DE','ITALY','PL','RHQ','UK','ES','FR','NL','BE','AT','CH','SE','NO','DK','FI'];
const MANAGED_OPTIONS_KEY = 'vn12_managed_options';
const INVENTORY_BREAKDOWN_KEY = 'vn12_inventory_breakdowns';
const INVENTORY_DIMENSIONS = {
    category: { label: '物料品类', short: '品类' },
    category_2: { label: '适用产品', short: '产品' },
    instruction: { label: '归属国家', short: '国家' }
};

function formatStockUpdatedAt(value) {
    if (!value) return '-';
    const raw = String(value).replace('T', ' ').slice(0, 19);
    const parsed = new Date(raw.replace(' ', 'T'));
    if (Number.isNaN(parsed.getTime())) return raw;
    return parsed.toLocaleString('zh-CN', { hour12: false });
}

function imageUrl(path) {
    if (!path) return '';
    const clean = String(path).replace(/^\/+/, '');
    return window.location.protocol === 'file:' ? 'images/' + clean : '/static/images/' + clean;
}

function isLocalBomCode(value) {
    const text = String(value || '').trim().toUpperCase();
    const compact = text.replace(/[\s/_-]+/g, '');
    return ['/', '／'].includes(text) || ['本地', 'LOCAL', 'LOCALSKU', 'LOCALITEM', 'NOBOM', 'NOBOMCODE'].includes(compact);
}

function displayBomCode(value) {
    const text = String(value || '').trim();
    return (!text || isLocalBomCode(text)) ? '/' : text;
}

function groupInventoryRows(rows, field) {
    const map = new Map();
    (rows || []).forEach(r => {
        const label = r[field] || 'UNSPECIFIED';
        const cur = map.get(label) || { label, sku_count: 0, total_pcs: 0, ttl_amount: 0, avg_unit_value: 0 };
        cur.sku_count += Number(r.sku_count || 0);
        cur.total_pcs += Number(r.total_pcs || 0);
        cur.ttl_amount += Number(r.ttl_amount || 0);
        map.set(label, cur);
    });
    return [...map.values()].map(r => ({ ...r, avg_unit_value: r.total_pcs ? r.ttl_amount / r.total_pcs : 0 }))
        .sort((a, b) => b.ttl_amount - a.ttl_amount);
}

function getInventoryGroupPosition(row, totalValue, totalPcs) {
    const valueShare = totalValue ? Number(row.ttl_amount || 0) / totalValue : 0;
    const pcsShare = totalPcs ? Number(row.total_pcs || 0) / totalPcs : 0;
    const gap = valueShare - pcsShare;
    if (valueShare >= 0.15 && pcsShare >= 0.15) return { key: 'core', label: '重点库存', color: '#3b82f6', bg: 'rgba(59,130,246,0.16)', advice: '货值和件数都高，优先做盘点、图片和价格维护。' };
    if (gap >= 0.04) return { key: 'value', label: '高货值低件数', color: '#f59e0b', bg: 'rgba(245,158,11,0.16)', advice: '金额占比高于件数占比，适合重点关注单价、丢失风险和库龄。' };
    if (gap <= -0.04) return { key: 'bulk', label: '数量大低货值', color: '#22c55e', bg: 'rgba(34,197,94,0.15)', advice: '件数占比高于金额占比，重点看占用空间、呆滞和清理机会。' };
    return { key: 'balanced', label: '结构均衡', color: '#94a3b8', bg: 'rgba(148,163,184,0.14)', advice: '货值和件数比例接近，按正常库存节奏维护。' };
}

function inventoryRiskLevel(amount, total) {
    const pct = total ? amount / total : 0;
    if (pct >= 0.25) return { color: 'var(--danger)', text: '高风险' };
    if (pct >= 0.10) return { color: 'var(--warning)', text: '需关注' };
    return { color: 'var(--success)', text: '可控' };
}
