    // ===== 数据导入 =====
    function updateSelectedFileLabel(input, targetId, emptyText) {
        const el = document.getElementById(targetId);
        if (!el) return;
        const files = Array.from(input?.files || []);
        if (!files.length) {
            el.textContent = emptyText || '选择文件';
            return;
        }
        el.textContent = files.length === 1
            ? files[0].name
            : files.map(f => f.name).slice(0, 2).join('；') + (files.length > 2 ? ` 等 ${files.length} 个文件` : '');
    }

    function submitLogisticsAutoImport() {
        const input = document.getElementById('file-logistics_auto');
        if (!input?.files?.length) return toast('请先选择物流 Excel 文件', 'error');
        uploadLogisticsAuto(input);
    }

    function handleLogisticsAutoFileSelected(input) {
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
        if (input?.files?.length) submitLogisticsAutoImport();
    }

    function submitInvoiceImport(type) {
        const input = document.getElementById('logistics-invoice-file');
        if (!input?.files?.length) return toast('请先选择发票 PDF 文件', 'error');
        uploadInvoice(input, type);
    }

    function inferInvoiceTypeFromFile(file) {
        const name = String(file?.name || '').toLowerCase();
        const warehouseKeywords = ['warehouse', 'warehousing', 'storage', 'handling', 'operation', 'operacja', 'magazyn', '仓储', '仓库', '操作'];
        return warehouseKeywords.some(k => name.includes(k)) ? 'warehouse' : 'logistics';
    }

    function invoiceTypeLabel(type) {
        return type === 'warehouse' ? '仓储操作费用发票' : '物流累计发票';
    }

    function selectedInvoiceType() {
        const input = document.getElementById('logistics-invoice-file');
        return inferInvoiceTypeFromFile(input?.files?.[0]);
    }

    function selectInvoicePdfFile() {
        document.getElementById('logistics-invoice-file')?.click();
    }

    function handleInvoicePdfSelected() {
        syncInvoicePdfSelectionLabel();
        submitSelectedInvoiceImport();
    }

    function submitSelectedInvoiceImport() {
        const input = document.getElementById('logistics-invoice-file');
        if (!input?.files?.length) return toast('请先选择发票 PDF 文件', 'error');
        uploadInvoice(input, 'auto');
    }

    function syncInvoicePdfSelectionLabel() {
        const input = document.getElementById('logistics-invoice-file');
        updateSelectedFileLabel(input, 'invoicePdfFileName', '发票 PDF');
        const hint = document.getElementById('invoiceAutoTypeHint');
        if (!hint) return;
        if (!input?.files?.length) {
            hint.textContent = '自动识别发票类型';
            return;
        }
        const type = inferInvoiceTypeFromFile(input.files[0]);
        hint.textContent = `自动识别：${invoiceTypeLabel(type)}`;
    }

    async function uploadWithType(input, type) {
        if (!input.files.length) return;
        const file = input.files[0];
        if (!file.name.toLowerCase().endsWith('.xlsx') && !file.name.toLowerCase().endsWith('.xls')) {
            toast('请上传 Excel 文件（.xlsx 或 .xls）', 'error');
            input.value = '';
            return;
        }
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);
        const resultDiv = document.getElementById('result-' + type);
        if (!resultDiv) { toast('上传区域未找到: ' + type, 'error'); return; }
        resultDiv.className = 'import-result loading';
        resultDiv.textContent = '⏳ 导入中...';
        resultDiv.style.display = 'block';

        try {
            const data = await uploadFormWithProgress(API + '/api/shipments/import', formData, 'progress-' + type);
            if (data.error) {
                resultDiv.className = 'import-result error';
                resultDiv.textContent = '❌ ' + data.error;
            } else {
                resultDiv.className = 'import-result success';
                resultDiv.textContent = '✅ 成功导入 ' + (data.imported || 0) + ' 条';
                await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters()]);
                loadUploadRecords();
            }
        } catch (e) {
            resultDiv.className = 'import-result error';
            resultDiv.textContent = '❌ ' + (e.message || '上传失败');
            console.error('Upload error:', e);
        }
        input.value = '';
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
    }

    async function uploadLogisticsAuto(input) {
        const files = Array.from(input.files || []);
        const resultDiv = document.getElementById('result-logistics_auto');
        if (!resultDiv) return toast('物流一键导入区域未找到', 'error');
        if (!files.length) return;
        const bad = files.filter(file => !file.name.match(/\.(xlsx|xls)$/i));
        if (bad.length) {
            toast('请只上传 Excel 文件（.xlsx 或 .xls）', 'error');
            input.value = '';
            updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
            return;
        }
        const formData = new FormData();
        files.forEach(file => formData.append('files', file));
        resultDiv.className = 'import-result loading';
        resultDiv.textContent = `⏳ 正在自动识别并导入 ${files.length} 个物流文件...`;
        resultDiv.style.display = 'block';
        try {
            const data = await uploadFormWithProgress(API + '/api/shipments/import-auto', formData, 'progress-logistics_auto');
            if (data.error) {
                resultDiv.className = 'import-result error';
                resultDiv.textContent = '❌ ' + data.error;
            } else {
                const s = data.summary || {};
                const fileLines = (data.files || []).map(f => {
                    if (f.error) return `<div>${escapeHtml(f.filename || '-')}：${escapeHtml(f.error)}</div>`;
                    const c = f.type_counts || {};
                    return `<div>${escapeHtml(f.filename || '-')}：导入 ${f.imported || 0} 条，新增 ${f.inserted || 0}，更新 ${f.updated || 0}，中央仓 ${c.warehouse_central || 0}，家具仓 ${c.warehouse_furniture || 0}，调拨 ${c.direct || 0}</div>`;
                }).join('');
                resultDiv.className = 'import-result success';
                resultDiv.innerHTML = `
                    <div><b>✅ 物流一键导入完成</b></div>
                    <div>文件 ${data.file_count || files.length} 个；导入 ${s.imported || 0} 条；新增 ${s.inserted || 0}；更新 ${s.updated || 0}；跳过无 STT ${s.skipped_missing_stt || 0}；跳过旧日期 ${s.skipped_date || 0}</div>
                    <div>中央仓 ${s.type_counts?.warehouse_central || 0}；家具仓 ${s.type_counts?.warehouse_furniture || 0}；调拨 ${s.type_counts?.direct || 0}</div>
                    ${fileLines ? `<div style="margin-top:6px">${fileLines}</div>` : ''}
                `;
                await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters(), loadUploadRecords()]);
            }
        } catch (e) {
            resultDiv.className = 'import-result error';
            resultDiv.textContent = '❌ ' + (e.message || '上传失败');
            console.error('Logistics auto upload error:', e);
        }
        input.value = '';
        updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
    }

    // ===== 拖拽上传 =====
    ['warehouse', 'pl_domestic', 'intl_direct', 'logistics_auto'].forEach(type => {
        const zone = document.getElementById('import-' + type);
        if (!zone) return;
        zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.style.borderColor = 'var(--accent)'; });
        zone.addEventListener('dragleave', () => { zone.style.borderColor = 'var(--border)'; });
        zone.addEventListener('drop', (e) => {
            e.preventDefault();
            zone.style.borderColor = 'var(--border)';
            const input = document.getElementById('file-' + type);
            input.files = e.dataTransfer.files;
            if (type === 'logistics_auto') {
                updateSelectedFileLabel(input, 'logisticsAutoFileName', '选择物流 Excel（可多选）');
                uploadLogisticsAuto(input);
            }
            else uploadWithType(input, type);
        });
    });


    // ===== Upload List =====
    function askRareUploadPassword() {
        const pwd = prompt('非常用数据校准入口，请输入密码');
        if (pwd == null) return null;
        if (!pwd.trim()) {
            toast('请输入密码', 'error');
            return null;
        }
        return pwd.trim();
    }
    async function submitCoreBackupImport() {
        const fileInput = document.getElementById('coreBackupFile');
        const reportEl = document.getElementById('coreBackupImportReport') || document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择完整包 ZIP / 底层备份 Excel', 'error');
        const password = askRareUploadPassword();
        if (password == null) return;
        if (!confirm('确认恢复完整包？系统会按备份内容更新/新增物流、发票、库存、SKU 和出入库流水。')) return;
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        fd.append('password', password);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在恢复完整包 / 底层备份 Excel...';
        const data = await uploadFormWithProgress(API + '/api/import/core-backup', fd, 'progress-coreBackup').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '完整包恢复失败';
            return toast(data.error || '完整包恢复失败', 'error');
        }
        const r = data.report || {};
        const line = (label, obj) => `<div>${label}：新建 ${Number(obj?.created || 0)}，更新 ${Number(obj?.updated || 0)}，跳过 ${Number((obj?.skipped || 0) + (obj?.skipped_existing || 0))}</div>`;
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>完整包恢复完成</b></div>
            ${line('物流底表', r.shipments)}
            ${line('发票验收底表', r.invoices)}
            ${line('库存底表', r.inventory)}
            ${line('SKU 主数据', r.sku)}
            ${line('出入库流水', r.movements)}
            <div>图片文件：还原 ${Number(r.images?.extracted || 0)}，映射 ${Number(r.images?.mapped || 0)}，跳过 ${Number(r.images?.skipped || 0)}</div>
        </div>`;
        fileInput.value = '';
        document.getElementById('coreBackupFileName').textContent = '选择完整包 ZIP / 底层备份 Excel';
        currentFilterMonth = '';
        currentFilterPickupMonth = '';
        currentPage = 1;
        stockPage = 1;
        await Promise.allSettled([
            loadDashboard(),
            loadSummary(),
            loadShipments(),
            loadStockFilters(),
            loadStockList(),
            loadUploadRecords()
        ]);
        toast(`恢复完成：物流 ${Number(r.shipments?.created || 0) + Number(r.shipments?.updated || 0)} 条，图片 ${Number(r.images?.extracted || 0)} 张`);
        toast('完整包恢复完成');
        await Promise.allSettled([loadDashboard(), loadStockFilters(), loadStockList(), loadInvDashboard(), loadBudgetPage()]);
        loadUploadRecords();
    }
    async function submitInventoryCalibrationImport() {
        const fileInput = document.getElementById('calibrationInventoryFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择库存校准 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在导入库存校准 Excel...';
        const data = await uploadFormWithProgress(API + '/api/inventory/import-calibration', fd, 'progress-calibrationImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '库存校准导入失败';
            return toast(data.error || '库存校准导入失败', 'error');
        }
        const r = data.report || {};
        const sheets = Object.entries(r.sheets || {}).map(([name, s]) => {
            if (s.missing) return `<div>${escapeHtml(name)}：缺少 Sheet</div>`;
            if (s.error) return `<div>${escapeHtml(name)}：${escapeHtml(s.error)}</div>`;
            return `<div>${escapeHtml(name)}：导入 ${s.imported || 0} 行，新建 ${s.created || 0}，更新 ${s.updated || 0}，库存变化 ${s.inventory_changed || 0}，跳过 ${s.skipped || 0}</div>`;
        }).join('');
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>库存校准完成</b></div>
            <div>本地源文件：${escapeHtml(r.source_file || '-')}</div>
            <div>合计导入 ${r.imported || 0} 行，新建 ${r.created || 0}，更新 ${r.updated || 0}，库存变化 ${r.inventory_changed || 0}，跳过 ${r.skipped || 0}</div>
            ${sheets}
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 6).join('；'))}${r.errors.length > 6 ? '；...' : ''}</div>` : ''}
        </div>`;
        fileInput.value = '';
        document.getElementById('calibrationInventoryFileName').textContent = '选择库存校准 Excel';
        toast('库存校准导入完成');
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleInventoryCalibrationFileSelected(input) {
        updateSelectedFileLabel(input, 'calibrationInventoryFileName', '选择库存校准 Excel');
        if (input?.files?.length) submitInventoryCalibrationImport();
    }

    async function submitSpecyfikacjaImport() {
        const fileInput = document.getElementById('specyfikacjaFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!fileInput.files[0]) return toast('请选择 Specyfikacja Excel', 'error');
        const fd = new FormData();
        Array.from(fileInput.files).forEach(f => fd.append('files', f, f.name));
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = `正在导入 ${fileInput.files.length} 个 Specyfikacja 出入库流水文件...`;
        const data = await uploadFormWithProgress(API + '/api/inventory/import-specyfikacja', fd, 'progress-specyfikacjaImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || 'Specyfikacja 导入失败';
            return toast(data.error || 'Specyfikacja 导入失败', 'error');
        }
        const r = data.report || {};
        const files = (r.files || []).map(f => {
            if (f.error) return `<div>${escapeHtml(f.source_file || '-')}：${escapeHtml(f.error)}</div>`;
            return `<div>${escapeHtml(f.source_file || '-')}：入库 ${f.inbound_rows || 0} 行，出库 ${f.outbound_rows || 0} 行，跳过 ${f.skipped || 0} 行</div>`;
        }).join('');
        const sheets = Object.entries(r.sheets || {}).slice(0, 12).map(([name, s]) => {
            if (s.ignored) return `<div>${escapeHtml(name)}：已忽略${s.reason ? '（' + escapeHtml(s.reason) + '）' : ''}</div>`;
            if (s.error) return `<div>${escapeHtml(name)}：${escapeHtml(s.error)}</div>`;
            return `<div>${escapeHtml(name)}：${escapeHtml(s.type || '')} ${s.rows || 0} 行，跳过 ${s.skipped || 0}</div>`;
        }).join('');
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>出入库流水导入完成</b></div>
            <div>本地源文件：${escapeHtml((r.source_files || []).join('；') || r.source_file || '-')}</div>
            <div>文件数 ${r.file_count || (r.source_files || []).length || 1}</div>
            <div>入库流水 ${r.inbound_rows || 0} 行；出库流水 ${r.outbound_rows || 0} 行；更新主数据 ${r.updated_products || 0} 条；更新库存记录 ${r.updated_inventory_rows || 0} 条；跳过 ${r.skipped || 0} 行</div>
            ${files}
            ${sheets}
            ${Object.keys(r.sheets || {}).length > 12 ? '<div>Sheet 明细较多，仅显示前 12 条。</div>' : ''}
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 6).join('；'))}${r.errors.length > 6 ? '；...' : ''}</div>` : ''}
        </div>`;
        fileInput.value = '';
        document.getElementById('specyfikacjaFileName').textContent = '选择 Specyfikacja Excel（可多选）';
        toast('出入库流水已导入');
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleSpecyfikacjaFileSelected(input) {
        updateSelectedFileLabel(input, 'specyfikacjaFileName', '选择 Specyfikacja Excel（可多选）');
        if (input?.files?.length) submitSpecyfikacjaImport();
    }

    async function submitLogisticsCalibrationImport() {
        const fileInput = document.getElementById('logisticsCalibrationFile');
        if (!fileInput.files[0]) return toast('请选择物流状态校准 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        const data = await uploadFormWithProgress(API + '/api/shipments/import-calibration', fd, 'progress-logisticsCalibration').catch(e => ({ error: e.message }));
        if (!data.success) return toast(data.error || '物流状态校准导入失败', 'error');
        fileInput.value = '';
        document.getElementById('logisticsCalibrationFileName').textContent = '选择物流状态校准 Excel';
        toast(`物流状态校准完成：更新 ${data.updated || 0} 条，跳过 ${data.skipped || 0} 条`);
        await Promise.allSettled([loadDashboard(), loadShipments(), initShipmentHeaderFilters()]);
        loadUploadRecords();
    }

    async function submitInvoiceCalibrationImport() {
        const fileInput = document.getElementById('invoiceCalibrationFile');
        const resultEl = document.getElementById('invoice-calibration-result');
        if (!fileInput.files[0]) return toast('请选择验收明细 Excel', 'error');
        const fd = new FormData();
        fd.append('file', fileInput.files[0]);
        if (resultEl) {
            resultEl.className = 'import-result import-file-name loading';
            resultEl.textContent = '正在导入验收明细...';
        }
        const data = await uploadFormWithProgress(API + '/api/invoices/import-calibration', fd, 'progress-invoiceCalibration').catch(e => ({ error: e.message }));
        if (!data.success) {
            if (resultEl) {
                resultEl.className = 'import-result import-file-name error';
                resultEl.textContent = data.error || '验收明细导入失败';
            }
            return toast(data.error || '验收明细导入失败', 'error');
        }
        fileInput.value = '';
        document.getElementById('invoiceCalibrationFileName').textContent = '';
        if (resultEl) {
            resultEl.className = 'import-result import-file-name success';
            resultEl.textContent = `验收明细导入完成：发票 ${data.updated_headers || 0} 张，明细 ${data.updated_items || 0} 行`;
        }
        toast(`验收明细导入完成：发票 ${data.updated_headers || 0} 张，明细 ${data.updated_items || 0} 行`);
        await Promise.allSettled([loadInvoicePage(), loadBudgetPage(), loadShipments()]);
        loadUploadRecords();
    }

    function handleInvoiceCalibrationFileSelected(input) {
        updateSelectedFileLabel(input, 'invoiceCalibrationFileName', '');
        if (input?.files?.length) submitInvoiceCalibrationImport();
    }

    async function submitSupplierInventoryImport() {
        const supplier = document.getElementById('supplierInventoryFile');
        const maintenance = document.getElementById('maintenanceInventoryFile');
        const reportEl = document.getElementById('supplierImportReport');
        if (!supplier.files[0] && !maintenance.files[0]) return toast('请选择供应商库存表或维护表', 'error');
        const fd = new FormData();
        if (supplier.files[0]) fd.append('supplier_file', supplier.files[0]);
        if (maintenance.files[0]) fd.append('maintenance_file', maintenance.files[0]);
        fd.append('warehouse', document.getElementById('supplierImportWarehouse').value);
        reportEl.style.display = 'block';
        reportEl.className = 'import-result loading';
        reportEl.textContent = '正在导入/刷新...';
        const data = await uploadFormWithProgress(API + '/api/inventory/import-supplier', fd, 'progress-supplierImport').catch(e => ({ error: e.message }));
        if (!data.success) {
            reportEl.className = 'import-result error';
            reportEl.textContent = data.error || '导入失败';
            return toast(data.error || '导入失败', 'error');
        }
        const r = data.report;
        reportEl.className = 'import-result success';
        reportEl.innerHTML = `<div style="font-size:13px;line-height:1.7;text-align:left">
            <div><b>${escapeHtml(r.warehouse)}</b> 导入/刷新完成</div>
            <div>供应商表头行：${r.supplier_header_row ? '第 ' + r.supplier_header_row + ' 行' : '未上传'}；维护表头行：${r.maintenance_header_row ? '第 ' + r.maintenance_header_row + ' 行' : '未上传'}</div>
            <div>供应商库存 ${r.supplier_rows || 0} 行，刷新库存 ${r.imported || 0} 行，跳过无效行 ${r.skipped_supplier_rows || 0} 行，移除旧库存 ${r.removed_inventory || 0} 行</div>
            <div>维护表 ${r.maintenance_rows || 0} 行；新建主数据 ${r.created_products || 0}；更新主数据 ${r.updated_products || 0}</div>
            <div>沿用已有维护数据：${r.used_existing_maintenance || 0} 行；自动推断 Bom Code：${r.inferred_bom?.length ? escapeHtml(r.inferred_bom.join(', ')) : '无'}</div>
            <div>库存校准：${r.updated_inventory || 0}</div>
            <div>缺维护/BOM：${r.missing_bom?.length ? escapeHtml(r.missing_bom.join(', ')) : '无'}</div>
            <div>缺图片：${r.missing_images.length ? escapeHtml(r.missing_images.join(', ')) : '无'}</div>
            ${r.errors?.length ? `<div style="color:var(--warning)">提示：${escapeHtml(r.errors.slice(0, 5).join('；'))}${r.errors.length > 5 ? '；...' : ''}</div>` : ''}
        </div>`;
        supplier.value = '';
        maintenance.value = '';
        document.getElementById('supplierInventoryFileName').textContent = '选择供应商库存表';
        document.getElementById('maintenanceInventoryFileName').textContent = '选择库存维护表';
        toast('导入/刷新成功');
        currentWarehouse = r.warehouse;
        syncStockWarehouseTabs();
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
        loadUploadRecords();
    }

    function handleSupplierInventoryFileSelected(input) {
        updateSelectedFileLabel(input, 'supplierInventoryFileName', '选择供应商库存表');
        if (input?.files?.length) submitSupplierInventoryImport();
    }

    function handleMaintenanceInventoryFileSelected(input) {
        updateSelectedFileLabel(input, 'maintenanceInventoryFileName', '选择库存维护表');
        if (input?.files?.length) submitSupplierInventoryImport();
    }

    // ===== Upload Images =====
    function handleImageFiles(files) {
        pendingImageFiles = Array.from(files).filter(f => /\.(png|jpg|jpeg|gif|webp)$/i.test(f.name));
        document.getElementById('imagePreviewList').innerHTML = pendingImageFiles.length ? `<div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px">已选择 ${pendingImageFiles.length} 个文件：</div>` + pendingImageFiles.slice(0, 20).map(f => `<div style="padding:2px 0;color:var(--text-muted);font-size:11px">${f.webkitRelativePath || f.name}</div>`).join('') : '';
        document.getElementById('imageUploadFileName').textContent = pendingImageFiles.length ? `已选择 ${pendingImageFiles.length} 张图片` : '请选择图片文件';
        const uploadBtn = document.getElementById('uploadImagesBtn');
        if (uploadBtn) uploadBtn.style.display = 'none';
    }
    function handleAndSubmitImageFiles(files) {
        handleImageFiles(files);
        if (pendingImageFiles.length) submitImageUpload();
    }
    async function submitImageUpload() {
        if (!pendingImageFiles.length) return toast('请先选择图片文件', 'error');
        const fd = new FormData(); pendingImageFiles.forEach(f => fd.append('files', f, f.name));
        const d = await uploadFormWithProgress(API + '/api/inventory/images/upload', fd, 'progress-images').catch(e => ({ error: e.message }));
        if (d.success) { let msg = `已上传 ${d.uploaded.length} 张图片`; if (d.repaired) msg += `，修复映射 ${d.repaired} 条`; if (d.not_found.length) msg += `。未匹配: ${d.not_found.join(', ')}`; toast(msg); pendingImageFiles = []; document.getElementById('imageFileInput').value = ''; document.getElementById('imagePreviewList').innerHTML = ''; document.getElementById('imageUploadFileName').textContent = '请选择图片文件'; const uploadBtn = document.getElementById('uploadImagesBtn'); if (uploadBtn) uploadBtn.style.display = 'none'; loadStockList(); loadUploadRecords(); }
        else toast(d.error || '上传失败', 'error');
    }

    async function clearInventoryImages() {
        if (!confirm('确认清理全部库存图片？库存、物流和发票数据不会删除。')) return;
        const password = askMaintenancePassword('请输入清理密码');
        if (password == null) return;
        const d = await apiFetch(API + '/api/inventory/images', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password })
        }).catch(e => ({ error: e.message }));
        if (!d.success) return toast(d.error || '清理失败', 'error');
        pendingImageFiles = [];
        document.getElementById('imageFileInput').value = '';
        document.getElementById('imagePreviewList').innerHTML = '';
        document.getElementById('imageUploadFileName').textContent = '请选择图片文件';
        const uploadBtn = document.getElementById('uploadImagesBtn');
        if (uploadBtn) uploadBtn.style.display = 'none';
        toast(`已清理 ${d.deleted || 0} 张图片`);
        loadStockList();
        loadInvDashboard();
    }

    async function runSlimMaintenance() {
        const clearSourceCache = document.getElementById('slimClearSourceCache')?.checked === true;
        const clearInventoryImages = document.getElementById('slimClearInventoryImages')?.checked === true;
        const clearHistoryBackups = document.getElementById('slimClearHistoryBackups')?.checked === true;
        const options = {
            clear_inventory: clearInventoryImages,
            clear_images: clearInventoryImages,
            clear_non_business_uploads: clearSourceCache,
            clear_logistics_uploads: clearSourceCache,
            clear_invoice_uploads: clearSourceCache,
            clear_cache: clearSourceCache,
            clear_update_downloads: clearSourceCache,
            clear_backups: clearHistoryBackups,
        };
        if (!Object.values(options).some(Boolean)) return toast('请至少选择一个清理项', 'error');
        const warnings = [];
        if (clearInventoryImages) warnings.push('库存基础数据、出入流水和图片会被清理；物流与发票/验收数据会保留。');
        if (clearHistoryBackups) warnings.push('历史备份和旧补丁会被清理，可能影响本机回档。');
        warnings.push('当前 EXE、停止脚本、数据库、账号、物流数据、发票/验收数据不会被删除。');
        if (!confirm('确认执行一键瘦身？\n\n' + warnings.join('\n'))) return;
        const password = prompt('请输入维护密码');
        if (password == null) return;
        const box = document.getElementById('slimMaintenanceResult');
        if (box) {
            box.style.display = 'block';
            box.innerHTML = '正在瘦身，请稍候...';
        }
        const d = await apiFetch(API + '/api/maintenance/slim', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ password, ...options })
        }).catch(e => ({ error: e.message }));
        if (!d.success) {
            if (box) box.innerHTML = `<div style="color:var(--danger)">${escapeHtml(d.error || '瘦身失败')}</div>`;
            return toast(d.error || '瘦身失败', 'error');
        }
        const inv = d.deleted?.inventory_records || {};
        const invCount = Object.values(inv).reduce((sum, n) => sum + (Number(n) || 0), 0);
        const freedMb = Number(d.freed_bytes || 0) / 1024 / 1024;
        const lines = [
            `释放空间：${freedMb.toFixed(1)} MB`,
            `库存相关记录：${invCount} 条`,
            `库存图片：${Number(d.deleted?.image_files || 0)} 个`,
            `源文件缓存：${Number(d.deleted?.upload_files_total || 0)} 个`,
            `缓存文件：${Number(d.deleted?.cache_files || 0)} 个`,
            `已下载更新包/临时文件：${Number(d.deleted?.downloaded_update_files || 0)} 个`,
            `历史备份文件：${Number(d.deleted?.backup_files || 0)} 个`,
            `旧版本辅助文件：${Number(d.deleted?.old_patch_files || 0)} 个`,
            `旧补丁/备份文件夹：${Number(d.deleted?.old_patch_dirs || 0)} 个`,
            `失败项：${(d.failed || []).length} 个`,
        ];
        if (box) {
            box.innerHTML = `<b>瘦身完成</b><br>${lines.map(escapeHtml).join('<br>')}`;
        }
        toast('一键瘦身完成');
        loadUploadRecords();
        loadStockFilters();
        loadStockList();
        loadInvDashboard();
    }
