    // ===== API 请求包装（统一错误处理） =====
    // ===== Token 认证 =====
    const AUTH_TOKEN_KEY = 'claw_auth_token';
    const AUTH_USER_KEY = 'claw_auth_user';
    const AUTH_ENABLED = true;

    function getAuthToken() {
        return localStorage.getItem(AUTH_TOKEN_KEY) || '';
    }
    function setAuthToken(token) {
        localStorage.setItem(AUTH_TOKEN_KEY, token);
    }
    function setAuthUser(user) {
        localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user || {}));
    }
    function getAuthUser() {
        try { return JSON.parse(localStorage.getItem(AUTH_USER_KEY) || '{}'); } catch { return {}; }
    }
    function isAdminUser() {
        return getAuthUser().role === 'admin';
    }
    function clearAuthToken() {
        localStorage.removeItem(AUTH_TOKEN_KEY);
        localStorage.removeItem(AUTH_USER_KEY);
    }
    function askMaintenancePassword(promptText = '请输入操作密码：', allowAdminBypass = true) {
        if (allowAdminBypass && isAdminUser()) return '';
        return prompt(promptText);
    }
    function showLogin() {
        document.getElementById('login-overlay').classList.remove('hidden');
    }
    function hideLogin() {
        document.getElementById('login-overlay').classList.add('hidden');
    }

    async function doLogin() {
        const user = document.getElementById('login-user').value.trim();
        const pass = document.getElementById('login-pass').value;
        const btn = document.getElementById('login-btn');
        const errEl = document.getElementById('login-error');
        if (!user || !pass) { errEl.textContent = '请输入用户名和密码'; return; }
        btn.disabled = true;
        errEl.textContent = '';
        try {
            const res = await fetch(API + '/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: user, password: pass })
            });
            const data = await res.json();
            if (data.success && data.token) {
                setAuthToken(data.token);
                setAuthUser(data.user || {});
                hideLogin();
                initApp();
            } else {
                errEl.textContent = data.error || '登录失败';
            }
        } catch (e) {
            errEl.textContent = '网络错误，请重试';
        } finally {
            btn.disabled = false;
        }
    }

    // 回车键登录
	    document.addEventListener('keydown', e => {
	        if (e.key === 'Escape' && document.getElementById('imgModal')?.classList.contains('show')) {
	            closeImageModal();
	            return;
	        }
	        if (e.key === 'Escape' && document.getElementById('invoice-detail-modal')?.style.display === 'flex') {
	            closeInvoiceDetail();
	            return;
	        }
	        if (e.key === 'Escape' && document.getElementById('budget-invoice-detail-modal')?.style.display === 'flex') {
	            closeBudgetInvoiceDetail();
	            return;
	        }
	        if (e.key === 'Enter' && !document.getElementById('login-overlay').classList.contains('hidden')) {
	            doLogin();
	        }
	    });

    // 页面加载时检查 Token
    async function checkAuth() {
        const token = getAuthToken();
        if (!token) { showLogin(); return; }
        try {
            const res = await fetch(API + '/api/auth/check', {
                headers: { 'Authorization': 'Bearer ' + token }
            });
            if (res.ok) {
                const data = await res.json().catch(() => ({}));
                setAuthUser(data.user || getAuthUser());
                hideLogin();
            } else {
                clearAuthToken();
                showLogin();
            }
        } catch {
            hideLogin();
        }
    }

    async function apiFetch(url, options = {}) {
        options.credentials = 'same-origin';
        const token = getAuthToken();
        if (token) {
            if (!options.headers) options.headers = {};
            options.headers['Authorization'] = 'Bearer ' + token;
        }
        const res = await fetch(url, options);
        if (res.status === 401) {
            clearAuthToken();
            showLogin();
            throw new Error('登录已过期，请重新登录');
        }
        if (!res.ok) {
            const text = await res.text().catch(() => '');
            throw new Error(`API 请求失败 (${res.status}): ${text}`);
        }
        return res.json();
    }

    function apiAuthHeaders(extra = {}) {
        const token = getAuthToken();
        return token ? { ...extra, Authorization: 'Bearer ' + token } : { ...extra };
    }

    function filenameFromContentDisposition(contentDisposition, fallbackName) {
        const cd = contentDisposition || '';
        const encoded = cd.match(/filename\*=UTF-8''([^;]+)/i);
        if (encoded?.[1]) {
            try { return decodeURIComponent(encoded[1]); } catch { return encoded[1]; }
        }
        const quoted = cd.match(/filename="([^"]+)"/i);
        if (quoted?.[1]) return quoted[1];
        const plain = cd.match(/filename=([^;]+)/i);
        if (plain?.[1]) return plain[1].trim();
        return fallbackName;
    }

    function exportDateStamp() {
        return new Date().toISOString().slice(0, 10).replace(/-/g, '');
    }

    function safeDownloadFilename(filename, fallbackName = `${APP_VERSION}_download`, maxLength = 96) {
        const raw = String(filename || fallbackName || `${APP_VERSION}_download`).trim();
        const fallback = String(fallbackName || `${APP_VERSION}_download`).trim();
        const source = raw || fallback || `${APP_VERSION}_download`;
        const dot = source.lastIndexOf('.');
        const ext = dot > 0 && dot >= source.length - 8 ? source.slice(dot).replace(/[<>:"/\\|?*\x00-\x1F]/g, '') : '';
        const fallbackDot = fallback.lastIndexOf('.');
        const fallbackExt = fallbackDot > 0 && fallbackDot >= fallback.length - 8 ? fallback.slice(fallbackDot).replace(/[<>:"/\\|?*\x00-\x1F]/g, '') : '';
        const finalExt = ext || fallbackExt;
        const baseSource = finalExt && source.toLowerCase().endsWith(finalExt.toLowerCase()) ? source.slice(0, -finalExt.length) : source;
        let base = baseSource
            .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
            .replace(/\s+/g, '_')
            .replace(/_+/g, '_')
            .replace(/^\.+/, '')
            .replace(/[._-]+$/g, '')
            .trim();
        if (!base) base = `${APP_VERSION}_download`;
        const limit = Math.max(16, maxLength - finalExt.length);
        if (base.length > limit) base = base.slice(0, limit).replace(/[._-]+$/g, '');
        return `${base}${finalExt}`;
    }

    function exportFileName(kind, ext = 'xlsx') {
        const cleanKind = String(kind || 'export')
            .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
            .replace(/\s+/g, '_')
            .replace(/_+/g, '_')
            .replace(/^_|_$/g, '')
            .slice(0, 34) || 'export';
        const cleanExt = String(ext || 'xlsx').replace(/^\./, '').replace(/[^A-Za-z0-9]/g, '') || 'xlsx';
        return safeDownloadFilename(`${APP_VERSION}_${cleanKind}_${exportDateStamp()}.${cleanExt}`);
    }

    function downloadLocalBlob(blob, filename, revokeDelay = 800) {
        const safeName = safeDownloadFilename(filename);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = safeName;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            URL.revokeObjectURL(a.href);
            a.remove();
        }, revokeDelay);
    }

    async function downloadApiBlob(url, options = {}) {
        const {
            fallbackName = `${APP_VERSION}_download`,
            successText = '导出成功',
            errorText = '导出失败',
            preferFallbackName = true,
            toastOnSuccess = true
        } = options;
        const absoluteUrl = /^https?:\/\//i.test(url) ? url : API + url;
        const res = await fetch(absoluteUrl, { headers: apiAuthHeaders() }).catch(e => ({ ok: false, error: e.message }));
        if (!res || !res.ok) {
            let detail = res?.error || '';
            if (res?.json) {
                const err = await res.json().catch(() => ({}));
                detail = err.error || detail;
            }
            toast(detail || errorText, 'error');
            return null;
        }
        const blob = await res.blob();
        const responseName = filenameFromContentDisposition(res.headers.get('Content-Disposition'), fallbackName);
        const selectedName = safeDownloadFilename(preferFallbackName ? fallbackName : responseName, fallbackName);
        downloadLocalBlob(blob, selectedName);
        if (toastOnSuccess) toast(successText);
        return { blob, filename: selectedName };
    }

    function uploadFormWithProgress(url, formData, progressId) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            const progress = document.getElementById(progressId);
            const fill = progress ? progress.querySelector('.upload-progress-fill') : null;
            if (progress && fill) {
                progress.style.display = 'block';
                fill.style.width = '0%';
            }
            xhr.open('POST', url);
            const token = getAuthToken();
            if (token) xhr.setRequestHeader('Authorization', 'Bearer ' + token);
            xhr.upload.onprogress = (evt) => {
                if (!evt.lengthComputable || !fill) return;
                fill.style.width = Math.max(3, Math.round(evt.loaded / evt.total * 100)) + '%';
            };
            xhr.onload = () => {
                if (fill) fill.style.width = '100%';
                setTimeout(() => { if (progress) progress.style.display = 'none'; }, 700);
                let data = {};
                try { data = JSON.parse(xhr.responseText || '{}'); } catch { data = { error: xhr.responseText || '上传失败' }; }
                if (xhr.status >= 200 && xhr.status < 300) resolve(data);
                else reject(new Error(data.error || `上传失败 (${xhr.status})`));
            };
            xhr.onerror = () => {
                if (progress) progress.style.display = 'none';
                reject(new Error('网络连接失败'));
            };
            xhr.send(formData);
        });
    }

    // WMS API helpers (compatible with old merged style)
    function apiHeaders() { const t = getAuthToken(); return t ? { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + t } : { 'Content-Type': 'application/json' }; }
    function apiGet(url) { return fetch(API + url, { headers: apiHeaders() }).then(r => r.json()); }
    function apiPost(url, data) { return fetch(API + url, { method: 'POST', headers: apiHeaders(), body: JSON.stringify(data) }).then(r => r.json()); }
    function apiPut(url, data) { return fetch(API + url, { method: 'PUT', headers: apiHeaders(), body: JSON.stringify(data) }).then(r => r.json()); }
    function apiDelete(url) { return fetch(API + url, { method: 'DELETE', headers: apiHeaders() }).then(r => r.json()); }
