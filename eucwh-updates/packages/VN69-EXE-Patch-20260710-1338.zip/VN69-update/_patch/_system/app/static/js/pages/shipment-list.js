    // ===== 物流清单 =====
    async function loadShipments() {
        const search = document.getElementById('search-input')?.value || '';
        const params = new URLSearchParams({
            page: currentPage,
            per_page: shipmentPerPage,
            ds: currentFilterDs,
            type: currentFilterType,
            country: currentFilterCountry,
            warehouse: currentFilterWarehouse,
            verify: currentFilterVerify,
            pickup_month: currentFilterPickupMonth || currentFilterMonth,
            actual_delivery_month: currentFilterActualDeliveryMonth,
            sort_by: shipmentSortBy,
            sort_dir: shipmentSortDir,
            search: search
        });
        const data = await apiFetch(API + '/api/shipments?' + params);
        renderShipmentsTable(data);
        renderPagination(data);
    }

    function setShipmentPerPage(value) {
        shipmentPerPage = Number(value || 20);
        localStorage.setItem('vn22_shipment_per_page', String(shipmentPerPage));
        currentPage = 1;
        loadShipments();
    }

    function updateShipmentFiltersUI() {
        const dsSelect = document.getElementById('th-filter-ds');
        const typeSelect = document.getElementById('th-filter-type');
        const countrySelect = document.getElementById('th-filter-country');
        const verifySelect = document.getElementById('th-filter-verify');
        const pickupSelect = document.getElementById('th-filter-pickup-month');
        const actualSelect = document.getElementById('th-filter-actual-month');
        const perPageSelect = document.getElementById('shipmentPerPage');
        if (dsSelect) { dsSelect.value = currentFilterDs; listSetHasValue(dsSelect); }
        if (typeSelect) { typeSelect.value = currentFilterType; listSetHasValue(typeSelect); }
        if (countrySelect) { countrySelect.value = currentFilterCountry; listSetHasValue(countrySelect); }
        if (verifySelect) { verifySelect.value = currentFilterVerify; listSetHasValue(verifySelect); }
        if (pickupSelect) { pickupSelect.value = currentFilterPickupMonth || currentFilterMonth; listSetHasValue(pickupSelect); }
        if (actualSelect) { actualSelect.value = currentFilterActualDeliveryMonth; listSetHasValue(actualSelect); }
        if (perPageSelect) perPageSelect.value = String(shipmentPerPage);
        listUpdateSortIndicators('#shipmentsTable th.sortable', shipmentSortBy, shipmentSortDir);
    }

    function renderShipmentsTable(data) {
        const tbody = document.getElementById('shipments-tbody');
        const selectAll = document.getElementById('shipment-select-all');
        if (selectAll) selectAll.checked = false;
        if (!data.shipments.length) {
            setTableEmpty(tbody, 14, '暂无物流数据，请先在数据管理中心导入物流 Excel', 32);
            return;
        }
        tbody.innerHTML = data.shipments.map(s => {
            const ds = s.display_status || '运输中';
            const statusClass = ds === '已交付' ? 'status-delivered' : ds === '待核实' ? 'status-pending_verify' : ds === '异常单' ? 'status-canceled' : 'status-in_transport';
            const typeClass = 'type-' + (s.shipment_type || '');
            const dd = s.delivery_date || '';
            const ddDate = dd ? dd.split(' ')[0] : '-';
            const actualDd = s.actual_delivery_date || '';
            const actualDdDate = actualDd ? actualDd.split(' ')[0] : '';
            const isLocked = s.delivery_locked == 1;
            const stt = s.stt_number || '';
            const bid = s.booking_id || '';
            const bidAttr = escapeHtml(bid);
            const trackUrl = stt ? `https://www.dbschenker.com/app/tracking-public/?refNumber=${encodeURIComponent(stt)}` : '';
            const primaryId = stt || bid || '-';
            const detailId = stt || bid || '';

            const addrParts = [
                s.consignee_name || '',
                s.consignee_name2 || '',
                s.consignee_street || '',
                s.consignee_street2 || ''
            ].filter(p => p.trim());
            const addrInfo = addrParts.join(', ') || '-';

            let workdays = '-';
            if (actualDdDate && actualDdDate !== '-' && s.pickup_date) {
                workdays = calcWorkdays(s.pickup_date.split(' ')[0], actualDdDate);
            }

            const actualDisplay = actualDdDate ? `${actualDdDate} 🔒` : '-';
            const selectable = true;
            const detailAttr = escapeHtml(detailId);
            const sttDisplay = detailId ? `<button type="button" class="link-btn" data-shipment-detail="${detailAttr}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" title="查看物流详情 / 维护状态" style="padding:0;font-family:monospace;font-size:12px;font-weight:700">${escapeHtml(primaryId)}</button>` : escapeHtml(primaryId);
            return `<tr>
                <td style="text-align:center"><input type="checkbox" class="shipment-select" value="${bidAttr}" ${selectable ? '' : 'disabled'} title="选择后可批量核实或移入回收站"></td>
                <td style="font-family:monospace;font-size:12px;color:var(--text-secondary)">${sttDisplay}</td>
                <td><span class="status-badge ${statusClass}">${escapeHtml(ds)}</span></td>
                <td><span class="type-tag ${typeClass}">${escapeHtml(s.shipment_type_label || s.shipment_type || '')}</span></td>
                <td>${shipmentCountryDisplay(s)}</td>
                <td class="col-detail">${escapeHtml(s.consignee_city || '-')}</td>
                <td class="col-detail" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;color:var(--text-secondary)" title="${escapeHtml(addrInfo)}">${escapeHtml(addrInfo)}</td>
                <td>${escapeHtml((s.pickup_date || '').split(' ')[0] || '-')}</td>
                <td class="col-detail">${escapeHtml(ddDate)}</td>
                <td class="col-detail" style="font-size:12px;font-weight:500;color:${workdays !== '-' ? 'var(--accent)' : 'var(--text-muted)'}">${workdays}</td>
                <td style="font-size:12px;color:${actualDdDate ? 'var(--success)' : 'var(--text-muted)'}">${escapeHtml(actualDisplay)}</td>
                <td class="col-detail">${s.total_weight ? Number(s.total_weight).toLocaleString() : '-'}</td>
                <td><span class="badge ${s.verify_status === '已验收' ? 'badge-delivered' : s.verify_status === '待验收' ? 'badge-pending' : ''}" style="${s.verify_status === '未关联' ? 'color:var(--text-muted)' : ''}">${escapeHtml(s.verify_status || '未关联')}</span></td>
                <td style="text-align:right;font-weight:500;color:${s.accepted_amount != null ? 'var(--success)' : 'var(--text-muted)'}" title="${escapeHtml((s.accepted_invoices || []).join(', '))}">${s.accepted_amount != null ? Number(s.accepted_amount).toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' PLN' : '-'}</td>
            </tr>`;
        }).join('');
    }

    function calcWorkdays(startStr, endStr) {
        if (!startStr || !endStr || startStr === '-' || endStr === '-') return '-';
        const start = new Date(startStr);
        const end = new Date(endStr);
        if (isNaN(start) || isNaN(end)) return '-';
        let count = 0;
        const cur = new Date(start);
        while (cur < end) {
            const day = cur.getDay();
            if (day !== 0 && day !== 6) count++;
            cur.setDate(cur.getDate() + 1);
        }
        return count;
    }

    function renderPagination(data) {
        const div = document.getElementById('pagination');
        if (data.total_pages <= 1) { div.innerHTML = ''; return; }
        let html = `<button class="page-btn" ${data.page <= 1 ? 'disabled' : ''} onclick="goPage(${data.page - 1})">上一页</button>`;
        for (let i = 1; i <= data.total_pages; i++) {
            if (data.total_pages > 7 && Math.abs(i - data.page) > 2 && i !== 1 && i !== data.total_pages) {
                if (i === data.page - 3 || i === data.page + 3) html += '<span style="color:var(--text-muted);padding:6px">...</span>';
                continue;
            }
            html += `<button class="page-btn ${i === data.page ? 'active' : ''}" onclick="goPage(${i})">${i}</button>`;
        }
        html += `<button class="page-btn" ${data.page >= data.total_pages ? 'disabled' : ''} onclick="goPage(${data.page + 1})">下一页</button>`;
        div.innerHTML = html;
    }

    function goPage(p) { currentPage = p; loadShipments(); }
    function toggleShipmentDetailCols() { document.getElementById('shipmentsTable').classList.toggle('compact'); }

    function setShipmentSort(key) {
        if (!key) return;
        if (shipmentSortBy === key) shipmentSortDir = shipmentSortDir === 'asc' ? 'desc' : 'asc';
        else {
            shipmentSortBy = key;
            shipmentSortDir = ['stt_number', 'display_status', 'shipment_type', 'country', 'consignee_city', 'verify_status'].includes(key) ? 'asc' : 'desc';
        }
        currentPage = 1;
        updateShipmentFiltersUI();
        loadShipments();
    }

    function filterByDsVal(val) {
        currentFilterDs = val;
        listSetHasValue(document.getElementById('th-filter-ds'), val);
        currentPage = 1;
        loadShipments();
    }
    function filterByTypeVal(val) {
        currentFilterType = val;
        listSetHasValue(document.getElementById('th-filter-type'), val);
        currentPage = 1;
        loadShipments();
    }
    function filterByCountryVal(val) {
        currentFilterCountry = val;
        currentFilterMonth = '';
        listSetHasValue(document.getElementById('th-filter-country'), val);
        currentPage = 1;
        loadShipments();
    }
    function filterByVerifyVal(val) {
        currentFilterVerify = val;
        listSetHasValue(document.getElementById('th-filter-verify'), val);
        currentPage = 1;
        loadShipments();
    }
    function filterByPickupMonth(val) {
        currentFilterPickupMonth = val;
        currentFilterMonth = val;
        listSetHasValue(document.getElementById('th-filter-pickup-month'), val);
        currentPage = 1;
        loadShipments();
    }
    function filterByActualDeliveryMonth(val) {
        currentFilterActualDeliveryMonth = val;
        listSetHasValue(document.getElementById('th-filter-actual-month'), val);
        currentPage = 1;
        loadShipments();
    }
    function clearFilters() {
        currentFilterDs = '';
        currentFilterType = '';
        currentFilterCountry = '';
        currentFilterWarehouse = '';
        currentFilterVerify = '';
        currentFilterMonth = '';
        currentFilterPickupMonth = '';
        currentFilterActualDeliveryMonth = '';
        shipmentSortBy = '';
        shipmentSortDir = 'desc';
        currentPage = 1;
        document.getElementById('search-input').value = '';
        document.getElementById('shipments-title').textContent = '物流清单';
        listClearControls(['th-filter-ds', 'th-filter-type', 'th-filter-country', 'th-filter-verify', 'th-filter-pickup-month', 'th-filter-actual-month']);
        loadShipments();
    }

    function filterShipments() { currentPage = 1; loadShipments(); }

    // ===== 快捷追踪 =====
    function trackShipment() {
        const val = document.getElementById('track-input').value.trim();
        if (!val) return;
        window.open(`https://www.dbschenker.com/app/my-shipments/overview`, '_blank');
    }
    document.getElementById('track-input')?.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') trackShipment();
    });

    async function openSelectedShipmentEditor() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) {
            showToast('请先勾选运单，或直接点击 STT / Booking 查看详情和追踪', 'error');
            return;
        }
        if (ids.length > 1) {
            openShipmentBatchEditor(ids);
            return;
        }
        openShipmentEditorById(ids[0]);
    }

    function openShipmentBatchEditor(bookingIds = []) {
        const ids = [...new Set((bookingIds || []).map(x => String(x || '').trim()).filter(Boolean))];
        if (!ids.length) {
            showToast('请先勾选需要批量编辑的运单', 'error');
            return;
        }
        document.getElementById('shipmentBatchEditTitle').textContent = `批量编辑运单（${ids.length} 条）`;
        document.getElementById('shipmentBatchEditBody').innerHTML = `
            <div class="modal-detail-summary">
                <div>
                    <div class="modal-detail-title">已选择 ${ids.length} 条运单</div>
                    <div class="modal-detail-subtitle">批量维护只处理共性字段；单条详情和追踪请点击 STT / Booking。</div>
                </div>
                <span class="badge badge-pending">批量</span>
            </div>
            <div class="modal-detail-field" style="margin-bottom:12px">
                <div class="modal-detail-label">已选运单</div>
                <div class="modal-detail-value mono" style="max-height:76px;overflow:auto">${ids.map(escapeHtml).join(' / ')}</div>
            </div>
            <div class="batch-action-grid">
                <div class="batch-action-card">
                    <h4>批量修改需求国家</h4>
                    <p>用于少数需求国和收货国不同的订单，保留原始收货国家。</p>
                    <button class="btn btn-primary btn-sm" onclick="batchChangeDemandCountry()">修改需求国家</button>
                </div>
                <div class="batch-action-card">
                    <h4>批量标记已交付</h4>
                    <p>为所选运单设置同一个实际交付日期，并锁定状态。</p>
                    <button class="btn btn-success btn-sm" onclick="batchMarkDeliveredWithDate()">标记已交付</button>
                </div>
                <div class="batch-action-card">
                    <h4>批量标记异常</h4>
                    <p>将未交付的所选运单标记为异常单。</p>
                    <button class="btn btn-secondary btn-sm" onclick="batchMarkAbnormal()">标记异常</button>
                </div>
                <div class="batch-action-card">
                    <h4>移入回收站</h4>
                    <p>用于错误、无效或不应统计的异常运单，需要填写原因。</p>
                    <button class="btn btn-danger btn-sm" onclick="closeModal('shipmentBatchEditModal');openShipmentRecycleDialog()">移入回收站</button>
                </div>
            </div>`;
        document.getElementById('shipmentBatchEditActions').innerHTML = `
            <div class="modal-action-group">
                <button class="btn btn-secondary btn-sm" onclick="closeModal('shipmentBatchEditModal')">关闭</button>
            </div>`;
        openModal('shipmentBatchEditModal');
    }

    async function openShipmentEditorById(shipmentId) {
        const normalizedId = String(shipmentId || '').trim();
        if (!normalizedId) {
            showToast('缺少运单编号，无法打开详情', 'error');
            return;
        }
        const data = await apiFetch(API + '/api/shipments?search=' + encodeURIComponent(normalizedId) + '&per_page=20');
        const shipment = (data.shipments || []).find(s => s.booking_id === normalizedId || s.stt_number === normalizedId) || (data.shipments || [])[0];
        if (!shipment) {
            showToast('未找到对应运单', 'error');
            return;
        }
        currentEditShipment = shipment;
        const ds = shipment.display_status || '运输中';
        const stt = shipment.stt_number || '-';
        const demand = demandCountryOfShipment(shipment) || '-';
        const consignee = consigneeCountryOfShipment(shipment) || '-';
        const bookingId = shipment.booking_id || '';
        const bookingAttr = escapeHtml(shipment.booking_id || '');
        const demandAttr = escapeHtml(demand === '-' ? '' : demand);
        const trackingUrl = stt && stt !== '-' ? `https://www.dbschenker.com/app/tracking-public/?refNumber=${encodeURIComponent(stt)}` : '';
        const trackingAttr = escapeHtml(trackingUrl);
        const shipmentTypeText = shipment.shipment_type_label || shipment.shipment_type || '-';
        const pickupDateText = (shipment.pickup_date || '').split(' ')[0] || '-';
        const deliveryDateText = (shipment.actual_delivery_date || '').split(' ')[0] || '-';
        const weightText = Number(shipment.total_weight || 0) ? `${Number(shipment.total_weight || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })} kg` : '-';
        const volumeText = Number(shipment.total_volume || 0) ? `${Number(shipment.total_volume || 0).toLocaleString(undefined, { maximumFractionDigits: 3 })} m³` : '-';
        const amountText = shipment.accepted_amount != null ? Number(shipment.accepted_amount).toLocaleString('pl-PL', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' PLN' : '-';
        const trackButton = trackingUrl ? `<button class="btn btn-secondary btn-sm" data-shipment-action="track" data-tracking-url="${trackingAttr}">追踪网页</button>` : '';
        const demandButton = `<button class="btn btn-primary btn-sm" data-shipment-action="demand-country" data-booking-id="${bookingAttr}" data-current-demand="${demandAttr}">修改需求国家</button>`;
        let statusButtons = '';
        if (ds === '异常单') {
            statusButtons = `
                <button class="btn btn-secondary btn-sm" data-shipment-action="unmark-abnormal" data-booking-id="${bookingAttr}">取消异常</button>
                <button class="btn btn-danger btn-sm" data-shipment-action="recycle" data-booking-id="${bookingAttr}">移入回收站</button>`;
        } else if (ds !== '已交付') {
            statusButtons = `<button class="btn btn-danger btn-sm" data-shipment-action="mark-abnormal" data-booking-id="${bookingAttr}">标记异常</button>`;
        }
        let deliveryButtons = '';
        if (ds === '已交付') {
            deliveryButtons = `<button class="btn btn-warning btn-sm" data-shipment-action="unmark-delivered" data-booking-id="${bookingAttr}">撤销交付</button>`;
        } else if (ds !== '异常单') {
            deliveryButtons = `
                <button class="btn btn-primary btn-sm" data-shipment-action="delivery-date" data-booking-id="${bookingAttr}">到货时间</button>
                <button class="btn btn-success btn-sm" data-shipment-action="mark-delivered" data-booking-id="${bookingAttr}">已交付</button>`;
        }
        document.getElementById('shipmentEditTitle').textContent = '运单详情';
        document.getElementById('shipmentEditBody').innerHTML = `
            <div class="modal-detail-summary">
                <div>
                    <div class="modal-detail-title">${escapeHtml(bookingId || stt || '-')}</div>
                    <div class="modal-detail-subtitle">单条运单详情与状态维护</div>
                </div>
                <div class="modal-summary-actions">
                    ${trackButton}
                    <span class="status-badge ${ds === '已交付' ? 'status-delivered' : ds === '待核实' ? 'status-pending_verify' : ds === '异常单' ? 'status-canceled' : 'status-in_transport'}">${escapeHtml(ds)}</span>
                    ${statusButtons}
                </div>
            </div>
            <div class="modal-detail-grid shipment-detail-grid">
                <div class="modal-detail-field"><div class="modal-detail-label">物流类型</div><div class="modal-detail-value">${escapeHtml(shipmentTypeText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">需求国家 / 收货国家</div><div class="modal-detail-value">${escapeHtml(demand)} / ${escapeHtml(consignee)}</div><div class="modal-field-actions">${demandButton}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">发货日期</div><div class="modal-detail-value">${escapeHtml(pickupDateText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">实际交付</div><div class="modal-detail-value">${escapeHtml(deliveryDateText)}</div>${deliveryButtons ? `<div class="modal-field-actions">${deliveryButtons}</div>` : ''}</div>
                <div class="modal-detail-field"><div class="modal-detail-label">体积 / 重量</div><div class="modal-detail-value">${escapeHtml(volumeText)} / ${escapeHtml(weightText)}</div></div>
                <div class="modal-detail-field"><div class="modal-detail-label">验收金额</div><div class="modal-detail-value">${escapeHtml(amountText)}</div></div>
            </div>
        `;
        document.getElementById('shipmentEditActions').innerHTML = `<div class="modal-action-group"><button class="btn btn-secondary btn-sm" onclick="closeModal('shipmentEditModal')">关闭</button></div>`;
        openModal('shipmentEditModal');
    }

    // ===== 标记已交付 / 撤销 =====
    let pendingBookingId = null;

	    async function openDeliveryDateDialog(bookingId) {
	        pendingBookingId = bookingId;
	        openModal('delivery-date-dialog');
	        document.getElementById('delivery-date-input').value = new Date().toISOString().split('T')[0];
	        document.getElementById('delivery-date-input').focus();
	    }

	    function closeDeliveryDateDialog() {
	        closeModal('delivery-date-dialog');
	        pendingBookingId = null;
	    }

    async function confirmDeliveryDate() {
        const dateVal = document.getElementById('delivery-date-input').value;
        if (!dateVal || !pendingBookingId) return;
        const bid = pendingBookingId;
        closeDeliveryDateDialog();
        try {
            const data = await apiFetch(API + '/api/shipments/mark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bid, delivery_date: dateVal })
            });
            if (data.success) {
                showToast('已标记为已交付', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }

    async function markDelivered(bookingId) {
        if (!confirm('确认标记该运单为已交付（日期为今天）？')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/mark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已标记为已交付', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }
    async function unmarkDelivered(bookingId) {
        if (!confirm('确认撤销已交付标记？撤销后该单将变为待核实状态。')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/unmark_delivered', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已撤销交付标记', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '撤销失败', 'error');
            }
        } catch (e) {
            showToast('撤销失败: ' + e.message, 'error');
        }
    }
    async function markAbnormal(bookingId) {
        if (!confirm('确认将该运单标记为异常单？')) return;
        try {
            const data = await apiFetch(API + '/api/shipments/mark_abnormal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已标记为异常单', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '标记失败', 'error');
            }
        } catch (e) {
            showToast('标记失败: ' + e.message, 'error');
        }
    }
	    async function unmarkAbnormal(bookingId) {
	        if (!confirm('确认取消异常标记？')) return;
	        try {
	            const data = await apiFetch(API + '/api/shipments/unmark_abnormal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_id: bookingId })
            });
            if (data.success) {
                showToast('已取消异常标记', 'success');
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '取消失败', 'error');
            }
	        } catch (e) {
	            showToast('取消失败: ' + e.message, 'error');
	        }
	    }

	    function getSelectedShipmentIds() {
	        return [...new Set([...document.querySelectorAll('.shipment-select:checked:not(:disabled)')].map(el => el.value).filter(Boolean))];
	    }

    function toggleShipmentSelectAll(checked) {
        document.querySelectorAll('.shipment-select:not(:disabled)').forEach(el => { el.checked = checked; });
    }

	    async function openShipmentRecycleDialog(bookingId) {
	        const selectedIds = getSelectedShipmentIds();
	        const bookingIds = selectedIds.length ? selectedIds : (bookingId ? [bookingId] : []);
	        if (!bookingIds.length) {
	            showToast('请先选择异常单', 'error');
	            return;
	        }
        const reason = prompt(`请输入移入回收站原因（${bookingIds.length} 条）：`);
        if (reason === null) return;
        if (!reason.trim()) {
            showToast('必须填写原因', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/recycle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: bookingIds, reason, password })
                });
                if (data.success) {
                    showToast(`已移入回收站：${data.recycled} 条`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '移入失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('移入失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function openRecycleBin() {
        openModal('shipmentRecycleModal');
        await loadRecycleBin();
    }

    async function loadRecycleBin() {
        const tbody = document.getElementById('recycleBinBody');
        if (!tbody) return;
        const search = document.getElementById('recycleSearchInput')?.value || '';
        setTableLoading(tbody, 7, '加载中...', 20);
        try {
            const data = await apiFetch(API + '/api/shipments/recycle_bin?search=' + encodeURIComponent(search));
            const rows = data.shipments || [];
            if (!rows.length) {
                setTableEmpty(tbody, 7, '回收站为空', 20);
                return;
            }
            tbody.innerHTML = rows.map(s => `
                <tr>
                    <td style="font-family:monospace">${escapeHtml(s.booking_id || '-')}</td>
                    <td style="font-family:monospace">${escapeHtml(s.stt_number || '-')}</td>
                    <td>${escapeHtml(s.consignee_country_code || '-')}</td>
                    <td><span class="status-badge status-canceled">${escapeHtml(s.display_status || '异常单')}</span></td>
                    <td>${escapeHtml(s.recycled_at || '-')}</td>
                    <td style="max-width:280px;white-space:normal">${escapeHtml(s.recycle_reason || '-')}</td>
                    <td><button class="btn btn-secondary btn-sm" onclick="restoreShipmentFromRecycle(${jsArg(s.booking_id || '')})">恢复</button></td>
                </tr>
            `).join('');
        } catch (e) {
            setTableError(tbody, 7, `加载失败：${e.message}`, 20);
        }
    }

    async function restoreShipmentFromRecycle(bookingId) {
        if (!bookingId) return;
        const password = askMaintenancePassword('请输入恢复密码：');
        if (password === null) return;
        try {
            const data = await apiFetch(API + '/api/shipments/recycle/restore', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ booking_ids: [bookingId], password })
            });
            if (data.success) {
                showToast('已恢复运单', 'success');
                loadRecycleBin();
                loadShipments();
                loadDashboard();
            } else {
                showToast(data.error || '恢复失败', 'error');
            }
        } catch (e) {
            showToast('恢复失败: ' + e.message, 'error');
        }
    }

    async function changeDemandCountry(bookingId, currentDemand = '') {
        if (!bookingId) return;
        const demand = prompt('请输入需求国家代码，例如 DE / PL / FR：', currentDemand || '');
        if (demand === null) return;
        const normalized = demand.trim().toUpperCase();
        if (!/^[A-Z]{2,3}$/.test(normalized)) {
            showToast('请输入正确的国家代码，例如 DE / PL / FR', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/demand_country', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: [bookingId], demand_country: normalized, password })
                });
                if (data.success) {
                    showToast(`需求国家已改为 ${data.demand_country}`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '修改失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('修改失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function batchChangeDemandCountry() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要修改的运单', 'error');
        const demand = prompt(`请输入需求国家代码（${ids.length} 条），例如 DE / PL / FR：`, '');
        if (demand === null) return;
        const normalized = demand.trim().toUpperCase();
        if (!/^[A-Z]{2,3}$/.test(normalized)) {
            showToast('请输入正确的国家代码，例如 DE / PL / FR', 'error');
            return;
        }
        let passwordPrompt = '请输入操作密码：';
        while (true) {
            const password = askMaintenancePassword(passwordPrompt);
            if (password === null) return;
            try {
                const data = await apiFetch(API + '/api/shipments/demand_country', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ booking_ids: ids, demand_country: normalized, password })
                });
                if (data.success) {
                    closeModal('shipmentBatchEditModal');
                    showToast(`已更新需求国家：${data.updated || 0} 条`, 'success');
                    loadShipments();
                    loadDashboard();
                } else {
                    showToast(data.error || '批量修改失败', 'error');
                }
                return;
            } catch (e) {
                const msg = e.message || '';
                if (msg.includes('密码错误') || msg.includes('(403)')) {
                    alert('密码错误，请重新输入');
                    passwordPrompt = '密码错误，请重新输入：';
                    continue;
                }
                showToast('批量修改失败: ' + msg, 'error');
                return;
            }
        }
    }

    async function batchMarkDeliveredWithDate() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要标记的运单', 'error');
        const today = new Date().toISOString().split('T')[0];
        const deliveryDate = prompt(`请输入实际交付日期（${ids.length} 条）：`, today);
        if (deliveryDate === null) return;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(deliveryDate.trim())) {
            showToast('日期格式应为 YYYY-MM-DD', 'error');
            return;
        }
        if (!confirm(`确认将 ${ids.length} 条运单标记为已交付？`)) return;
        const result = await runShipmentBatchRequests(ids, '/api/shipments/mark_delivered', id => ({ booking_id: id, delivery_date: deliveryDate.trim() }));
        closeModal('shipmentBatchEditModal');
        showToast(`批量已交付完成：成功 ${result.ok} 条，失败 ${result.fail} 条`, result.fail ? 'error' : 'success');
        loadShipments();
        loadDashboard();
    }

    async function batchMarkAbnormal() {
        const ids = getSelectedShipmentIds();
        if (!ids.length) return showToast('请先勾选需要标记的运单', 'error');
        if (!confirm(`确认将 ${ids.length} 条运单标记为异常单？`)) return;
        const result = await runShipmentBatchRequests(ids, '/api/shipments/mark_abnormal', id => ({ booking_id: id }));
        closeModal('shipmentBatchEditModal');
        showToast(`批量异常标记完成：成功 ${result.ok} 条，失败 ${result.fail} 条`, result.fail ? 'error' : 'success');
        loadShipments();
        loadDashboard();
    }

    async function runShipmentBatchRequests(ids, url, payloadFactory) {
        let ok = 0;
        let fail = 0;
        for (const id of ids) {
            try {
                const data = await apiFetch(API + url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payloadFactory(id))
                });
                if (data && data.success) ok += 1;
                else fail += 1;
            } catch (e) {
                fail += 1;
            }
        }
        return { ok, fail };
    }

	    document.addEventListener('click', (event) => {
	        const btn = event.target.closest('[data-shipment-action]');
	        if (!btn) return;
	        event.preventDefault();
	        event.stopPropagation();
	        const action = btn.dataset.shipmentAction;
            if (action === 'track') {
                const url = btn.dataset.trackingUrl || '';
                if (url) window.open(url, '_blank');
                return;
            }
	        const bookingId = btn.dataset.bookingId || '';
	        if (!bookingId) {
	            showToast('缺少 Booking ID，无法操作', 'error');
	            return;
	        }
	        closeModal('shipmentEditModal');
	        if (action === 'delivery-date') {
	            openDeliveryDateDialog(bookingId);
	        } else if (action === 'mark-delivered') {
	            markDelivered(bookingId);
	        } else if (action === 'mark-abnormal') {
	            markAbnormal(bookingId);
	        } else if (action === 'unmark-delivered') {
	            unmarkDelivered(bookingId);
	        } else if (action === 'unmark-abnormal') {
	            unmarkAbnormal(bookingId);
	        } else if (action === 'recycle') {
	            openShipmentRecycleDialog(bookingId);
	        } else if (action === 'demand-country') {
	            changeDemandCountry(bookingId, btn.dataset.currentDemand || '');
	        }
	    });

	    Object.assign(window, {
	        openDeliveryDateDialog,
	        closeDeliveryDateDialog,
	        confirmDeliveryDate,
	        markDelivered,
	        unmarkDelivered,
	        markAbnormal,
	        unmarkAbnormal,
	        openShipmentRecycleDialog,
            openShipmentBatchEditor,
            batchChangeDemandCountry,
            batchMarkDeliveredWithDate,
            batchMarkAbnormal,
	        toggleShipmentSelectAll,
	        openRecycleBin,
	        loadRecycleBin,
	        restoreShipmentFromRecycle
	    });

	    // ===== 批量自动核实 =====
    let verifyPolling = null;
    async function startVerify() {
        const btn = document.getElementById('verify-btn');
        const progressWrap = document.getElementById('verify-progress-wrap');
        const progressFill = document.getElementById('verify-progress-fill');
        const verifyText = document.getElementById('verify-text');
        btn.disabled = true;
        btn.textContent = '启动中...';
        progressWrap.style.display = 'block';
        try {
            const data = await apiFetch(API + '/api/shipments/verify', { method: 'POST' });
            if (data.error) {
                // 核实任务卡住（409），自动重置
                if (data.progress !== undefined && data.total !== undefined) {
                    verifyText.textContent = `任务卡住 (${data.progress}/${data.total})，正在重置...`;
                    await apiFetch(API + '/api/shipments/verify/reset', { method: 'POST' });
                    await new Promise(r => setTimeout(r, 500));
                    btn.disabled = false;
                    btn.textContent = '批量核实';
                    verifyText.textContent = '已重置，请重新点击核实';
                    progressWrap.style.display = 'none';
                    return;
                }
                btn.textContent = '批量核实';
                btn.disabled = false;
                verifyText.textContent = data.error;
                return;
            }
            if (data.total === 0) {
                btn.disabled = false;
                btn.textContent = '批量核实';
                verifyText.textContent = '没有需要核实的运单';
                progressWrap.style.display = 'none';
                return;
            }
            btn.textContent = '核实中...';
            verifyPolling = setInterval(async () => {
                const status = await apiFetch(API + '/api/shipments/verify/status');
                const pct = status.total ? Math.round(status.progress / status.total * 100) : 0;
                progressFill.style.width = pct + '%';
                verifyText.textContent = `${status.progress} / ${status.total}`;
                if (!status.running) {
                    clearInterval(verifyPolling);
                    btn.disabled = false;
                    btn.textContent = '批量核实';
                    const delivered = status.delivered_count || 0;
                    const inTransport = status.in_transport_count || 0;
                    const cancelled = status.cancelled_count || 0;
                    const unresolved = status.unresolved_count || 0;
                    const failed = status.failed_count || 0;
                    if (status.error) {
                        verifyText.textContent = '核实出错: ' + status.error;
                    } else {
                        let msg = `核实完成，新增 ${delivered} 单已交付`;
                        if (inTransport > 0) msg += `，${inTransport} 单仍在运输`;
                        if (cancelled > 0) msg += `，${cancelled} 单已取消`;
                        if (unresolved > 0) msg += `，${unresolved} 单未识别`;
                        if (failed > 0) msg += `，${failed} 单抓取失败`;
                        if (unresolved > 0 || failed > 0) msg += '（状态未改动）';
                        verifyText.textContent = msg;
                    }
                    progressFill.style.width = '100%';
                    loadShipments();
                    loadDashboard();
                }
            }, 3000);
        } catch (e) {
            btn.disabled = false;
            btn.textContent = '批量核实';
            verifyText.textContent = '启动失败: ' + e.message;
        }
    }
