    // ===== 页面切换 =====
    function switchPage(page, filters) {
        const legacyPageAliases = {
            invoice: 'import',
            uploadlist: 'import',
            uploadimages: 'import',
            costlist: 'acceptance-list',
            reports: 'logistics',
            orders: 'versioninfo',
            settings: 'versioninfo'
        };
        if (legacyPageAliases[page]) {
            const sourcePage = page;
            const targetPage = legacyPageAliases[page];
            switchPage(targetPage, filters);
            if (sourcePage === 'reports') {
                setTimeout(() => openReportOptionsModal(), 0);
            }
            return;
        }
        document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const pageEl = document.getElementById('page-' + page);
        if (!pageEl) {
            switchPage('logistics');
            return;
        }
        pageEl.classList.add('active');
        const navItem = document.querySelector(`.nav-item[data-page="${page}"]`);
        if (navItem) navItem.classList.add('active');
        const mobileSelect = document.getElementById('mobilePageSelect');
        if (mobileSelect && Array.from(mobileSelect.options).some(opt => opt.value === page)) {
            mobileSelect.value = page;
        }
        if (page === 'logistics') loadDashboard();
        if (page === 'shipments') {
            if (filters) {
                currentFilterDs = filters.ds || '';
                currentFilterType = filters.type || '';
                currentFilterCountry = filters.country || '';
                currentFilterWarehouse = filters.warehouse || '';
                currentFilterMonth = filters.month || '';
                currentFilterPickupMonth = filters.pickup_month || filters.month || '';
                currentFilterActualDeliveryMonth = filters.actual_delivery_month || '';
                shipmentSortBy = filters.sort_by || '';
                shipmentSortDir = filters.sort_dir || 'desc';
                currentPage = 1;
            }
            loadShipments();
            updateShipmentFiltersUI();
        }
        if (page === 'inventory') loadInvDashboard();
        if (page === 'stocklist') {
            loadStockFilters().then(() => {
                applyPendingStockListFilters();
                loadStockList();
            });
        }
        if (page === 'import') { assembleImportCenter(); loadInvoicePage(); loadUploadRecords(); }
        if (page === 'budget') { loadBudgetPage(); }
        if (page === 'movements') { loadMovementList(); }
        if (page === 'acceptance-list') { loadAcceptanceList(); }
        if (page === 'operations') { switchOpsTab(document.querySelector('#opsTabs .tab[data-otab="adjust"]')); }
        if (page === 'orders') loadOrders();
        if (page === 'settings') initSettings();
        if (page === 'versioninfo') loadVersionChangelog();
        setTimeout(() => applyUnifiedUi(document.getElementById('page-' + page) || document), 0);
    }

    function assembleImportCenter() {
        const commonGrid = document.getElementById('commonDataGrid');
        const backupGrid = document.getElementById('backupRestoreGrid');
        const moveCard = (card, target) => {
            if (card && target && card.parentElement !== target) target.appendChild(card);
        };
        const setCardOrder = (card, order) => {
            if (card) card.style.order = String(order);
        };
        const inventoryMount = document.getElementById('import-section-inventory');
        const inventoryPage = document.getElementById('page-uploadlist');
        const commonBlock = document.querySelector('#page-import .maintenance-common');
        if (inventoryMount && inventoryPage && !inventoryMount.dataset.mounted) {
            const inventoryGrid = inventoryPage.querySelector('.import-grid');
            const importReport = inventoryPage.querySelector('#supplierImportReport');
            const dangerZone = inventoryPage.querySelector('.danger-zone');
            if (inventoryGrid) inventoryMount.appendChild(inventoryGrid);
            if (importReport && commonBlock) commonBlock.appendChild(importReport);
            if (dangerZone) inventoryMount.appendChild(dangerZone);
            inventoryMount.dataset.mounted = '1';
        }
        moveCard(document.getElementById('import-logistics_auto'), commonGrid);
        moveCard(document.getElementById('supplierInventoryFile')?.closest('.import-section'), commonGrid);
        moveCard(document.getElementById('specyfikacjaFile')?.closest('.import-section'), commonGrid);
        moveCard(document.getElementById('import-logistics-invoice'), commonGrid);
        moveCard(document.getElementById('imageFileInput')?.closest('.import-section'), commonGrid);
        setCardOrder(document.getElementById('import-logistics_auto'), 1);
        setCardOrder(document.getElementById('supplierInventoryFile')?.closest('.import-section'), 2);
        setCardOrder(document.getElementById('specyfikacjaFile')?.closest('.import-section'), 3);
        setCardOrder(document.getElementById('import-logistics-invoice'), 4);
        setCardOrder(document.getElementById('imageFileInput')?.closest('.import-section'), 5);
        moveCard(document.getElementById('fullPackageExportCard'), backupGrid);
        moveCard(document.getElementById('coreBackupImportCard'), backupGrid);
    }

    function focusImportCard(cardId) {
        const card = document.getElementById(cardId);
        if (!card) return;
        card.scrollIntoView({ behavior: 'smooth', block: 'center' });
        card.classList.add('focus-pulse');
        setTimeout(() => card.classList.remove('focus-pulse'), 1600);
    }

    function openInvoiceDataManagement() {
        switchPage('import');
        setTimeout(() => {
            assembleImportCenter();
            focusImportCard('import-logistics-invoice');
        }, 80);
    }

    function openBackupRestoreManagement() {
        switchPage('import');
        setTimeout(() => {
            assembleImportCenter();
            focusImportCard('coreBackupImportCard');
        }, 80);
    }

    function formatFileSize(bytes) {
        const n = Number(bytes || 0);
        if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + ' MB';
        if (n >= 1024) return (n / 1024).toFixed(1) + ' KB';
        return n + ' B';
    }

    function uploadTypeLabel(types) {
        const set = new Set(types || []);
        const labels = [];
        if (set.has('logistics')) labels.push('物流源文件');
        if (set.has('invoice')) labels.push('发票源文件');
        if (!labels.length && set.has('file')) labels.push('其他源文件');
        return labels.join(' / ') || '-';
    }

    let uploadRecordSortBy = 'modified_at';
    let uploadRecordSortDir = 'desc';

    function setUploadRecordSort(field) {
        if (uploadRecordSortBy === field) {
            uploadRecordSortDir = uploadRecordSortDir === 'asc' ? 'desc' : 'asc';
        } else {
            uploadRecordSortBy = field;
            uploadRecordSortDir = field === 'filename' || field === 'type' ? 'asc' : 'desc';
        }
        loadUploadRecords();
    }

    function clearUploadRecordFilters() {
        const typeFilter = document.getElementById('uploadRecordTypeFilter');
        if (typeFilter) typeFilter.value = '';
        uploadRecordSortBy = 'modified_at';
        uploadRecordSortDir = 'desc';
        loadUploadRecords();
    }

    function uploadRecordSortValue(file, field) {
        if (field === 'type') return uploadTypeLabel(file.types).toUpperCase();
        if (field === 'size') return Number(file.size || 0);
        if (field === 'shipment_records') return Number(file.shipment_records || 0);
        if (field === 'invoice_records') return Number(file.invoice_records || 0);
        if (field === 'modified_at') return file.modified_at || '';
        return String(file.filename || '').toUpperCase();
    }

    function updateUploadRecordSortHeaders() {
        document.querySelectorAll('[data-upload-sort]').forEach(th => {
            const active = th.dataset.uploadSort === uploadRecordSortBy;
            th.classList.toggle('active', active);
            const base = th.textContent.replace(/\s*[↑↓]$/, '');
            th.textContent = active ? `${base} ${uploadRecordSortDir === 'asc' ? '↑' : '↓'}` : base;
        });
    }

    async function loadUploadRecords() {
        const body = document.getElementById('uploadRecordsBody');
        if (!body) return;
        body.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        const data = await apiGet('/api/uploads').catch(e => ({ error: e.message }));
        if (data.error) {
            body.innerHTML = `<tr><td colspan="8" style="text-align:center;color:var(--danger);padding:24px">${escapeHtml(data.error)}</td></tr>`;
            return;
        }
        const typeFilter = document.getElementById('uploadRecordTypeFilter')?.value || '';
        const files = (data.files || [])
            .filter(f => {
                const types = new Set(f.types || []);
                if (!typeFilter) return true;
                if (typeFilter === 'unlinked') return types.has('file') && !types.has('logistics') && !types.has('invoice');
                return types.has(typeFilter);
            })
            .sort((a, b) => {
                const av = uploadRecordSortValue(a, uploadRecordSortBy);
                const bv = uploadRecordSortValue(b, uploadRecordSortBy);
                const result = typeof av === 'number' && typeof bv === 'number'
                    ? av - bv
                    : String(av).localeCompare(String(bv), 'zh-Hans-CN', { numeric: true, sensitivity: 'base' });
                return uploadRecordSortDir === 'asc' ? result : -result;
            });
        updateUploadRecordSortHeaders();
        body.innerHTML = files.length ? files.map(f => `
            <tr>
                <td style="font-weight:500;max-width:360px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${escapeHtml(f.filename)}">${escapeHtml(f.filename)}</td>
                <td>${escapeHtml(uploadTypeLabel(f.types))}</td>
                <td style="text-align:right">${f.exists ? formatFileSize(f.size) : '-'}</td>
                <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(f.modified_at || '-')}</td>
                <td style="text-align:right">${f.shipment_records || 0}</td>
                <td style="text-align:right">${f.invoice_records || 0}</td>
                <td>${f.exists ? '<span class="badge badge-delivered">源文件存在</span>' : '<span class="badge badge-pending">源文件已清理</span>'}</td>
                <td>${f.exists ? `<button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="deleteUploadedFile(${jsArg(f.filename)})">删除源文件</button>` : '-'}</td>
            </tr>
        `).join('') : '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:24px">暂无源文件记录</td></tr>';
    }

    async function deleteUploadedFile(filename) {
        const password = askMaintenancePassword(`请输入删除密码，确认删除源文件：\\n${filename}\\n\\n此操作只释放文件体积，不撤销已导入的物流、发票或库存数据。`);
        if (password == null) return;
        const data = await apiFetch(API + '/api/uploads/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filename, password })
        }).catch(e => ({ error: e.message }));
        if (data.success) {
            toast('源文件已删除，业务数据未撤销');
            loadUploadRecords();
        } else {
            toast(data.error || '删除失败', 'error');
        }
    }

    function switchImportCenterSection(el) {
        document.querySelectorAll('#importCenterTabs .tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
        const section = el.dataset.importSection;
        document.querySelectorAll('.import-center-section').forEach(panel => {
            panel.style.display = panel.id === 'import-section-' + section ? 'block' : 'none';
        });
        if (section === 'invoice') loadInvoicePage();
        loadUploadRecords();
    }

    // ===== 下钻：从看板跳转到物流清单 =====
    function selectedLogisticsMonth() {
        return document.getElementById('map-month-filter')?.value || '';
    }
    function drillDown(ds, title) {
        const month = selectedLogisticsMonth();
        document.getElementById('shipments-title').textContent = title || ds;
        switchPage('shipments', { ds: ds || '', month });
    }
    function drillDownType(type, title) {
        const month = selectedLogisticsMonth();
        document.getElementById('shipments-title').textContent = title || type;
        switchPage('shipments', { type: type || '', month });
    }
    function drillDownCountry(country) {
        const month = selectedLogisticsMonth();
        country = String(country || '').trim().toUpperCase();
        document.getElementById('shipments-title').textContent = month ? `${tf('shipToCountry', { country })} · ${month}` : tf('shipToCountry', { country });
        switchPage('shipments', { country: country, month });
    }
    function drillDownWarehouse(warehouse) {
        document.getElementById('shipments-title').textContent = tf('warehouseOutbound', { warehouse });
        switchPage('shipments', { warehouse: warehouse });
    }

    // ===== 企鹅动画 =====
    function spawnPenguin() {
        document.querySelectorAll('.penguin-wrap').forEach(el => el.remove());

        const wrap = document.createElement('div');
        wrap.className = 'penguin-wrap';
        wrap.innerHTML = `
            <div class="penguin-body" style="position:relative;display:inline-block;">
                <div class="penguin-sign">Welcome to Join the Conference</div>
                <img src="/static/penguin.gif" alt="QQ Penguin" style="width:200px;height:166px;object-fit:contain;margin-top:8px;" />
            </div>
        `;
        document.body.appendChild(wrap);

        setTimeout(() => {
            wrap.classList.add('hide');
            setTimeout(() => wrap.remove(), 700);
        }, 5000);
    }

    // ===== Operations =====
    function switchOpsTab(el) {
        document.querySelectorAll('#opsTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active');
        const tab = el.dataset.otab;
        if (tab === 'adjust') renderOpsAdjust();
        else if (tab === 'scrap') renderOpsScrap();
        else if (tab === 'history') renderOpsHistory();
    }

    async function renderOpsAdjust() {
        document.getElementById('opsTabContent').innerHTML = `<div style="display:grid;grid-template-columns:340px 1fr;gap:24px"><div><div class="table-section"><div class="form-group"><label>仓库</label><select class="wms-select" id="adjWarehouse" style="width:100%"><option value="Lodz warehouse">Lodz 仓库</option><option value="Bydgoszcz warehouse">Bydgoszcz 仓库</option></select></div><div class="form-group"><label>类型</label><select class="wms-select" id="adjType" style="width:100%"><option value="inbound">入库</option><option value="outbound">出库</option><option value="adjustment">调整</option></select></div><div class="form-group"><label>Product Number</label><input class="wms-input" id="adjProductNumber" style="width:100%" placeholder="输入仓库产品编号/CWH号..."></div><div class="form-group"><label>数量</label><input class="wms-input" id="adjQty" type="number" min="0" style="width:100%" placeholder="0"></div><div class="form-group"><label>备注</label><textarea class="wms-textarea" id="adjComment" rows="2" style="width:100%" placeholder="原因说明..."></textarea></div><button class="btn btn-primary" style="width:100%" onclick="submitAdjustment()">提 交</button></div></div><div><div class="table-section"><h3 style="font-size:15px;font-weight:600;margin-bottom:12px">变动记录</h3><div style="overflow-x:auto"><table><thead><tr><th>时间</th><th>仓库</th><th>Product Number</th><th>BOM 编号</th><th>描述</th><th>类型</th><th style="text-align:right">数量变动</th><th>备注</th></tr></thead><tbody id="adjTxnBody"></tbody></table></div></div></div></div>`;
        loadAdjustTransactions();
    }

    async function loadAdjustTransactions() {
        const d = await apiGet('/api/inventory/transactions?per_page=50');
        const typeColors = { inbound: 'badge-delivered', outbound: 'badge-danger', adjustment: 'badge-pending', order_ship: 'badge-confirmed', scrap: 'badge-danger', calibration: 'badge-confirmed' };
        const typeLabels = { inbound: '入库', outbound: '出库', adjustment: '调整', order_ship: '发货指令', scrap: '报废', calibration: '校准' };
        document.getElementById('adjTxnBody').innerHTML = d.data.map(r => `<tr><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td>${escapeHtml(r.warehouse || '')}</td><td style="font-weight:500">${escapeHtml(r.product_number || '')}</td><td>${escapeHtml(r.bom_code || '')}</td><td>${escapeHtml(r.product_description || '')}</td><td><span class="badge ${typeColors[r.change_type] || ''}">${escapeHtml(typeLabels[r.change_type] || r.change_type)}</span></td><td style="text-align:right;color:${r.quantity_change >= 0 ? 'var(--success)' : 'var(--danger)'}">${r.quantity_change > 0 ? '+' : ''}${r.quantity_change}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
    }

    async function submitAdjustment() {
        const data = { warehouse: document.getElementById('adjWarehouse').value, product_number: document.getElementById('adjProductNumber').value.trim(), change_type: document.getElementById('adjType').value, quantity: parseInt(document.getElementById('adjQty').value) || 0, comment: document.getElementById('adjComment').value.trim() };
        if (!data.product_number || !data.quantity) return toast('请填写 Product Number 和数量', 'error');
        const d = await apiPost('/api/inventory/adjust', data);
        if (d.success) { toast('库存已更新'); document.getElementById('adjProductNumber').value = ''; document.getElementById('adjQty').value = ''; document.getElementById('adjComment').value = ''; loadAdjustTransactions(); loadStockList(); }
        else toast(d.error || '操作失败', 'error');
    }

    async function renderOpsScrap() {
        document.getElementById('opsTabContent').innerHTML = `<div style="display:grid;grid-template-columns:340px 1fr;gap:24px"><div><div class="table-section"><h4 style="font-size:13px;color:var(--danger);margin-bottom:12px">报废出库</h4><div class="form-group"><label>仓库</label><select class="wms-select" id="scrapWarehouse" style="width:100%"><option value="Lodz warehouse">Lodz 仓库</option><option value="Bydgoszcz warehouse">Bydgoszcz 仓库</option></select></div><div class="form-group"><label>Product Number</label><input class="wms-input" id="scrapProductNumber" style="width:100%" placeholder="输入仓库产品编号/CWH号..."></div><div class="form-group"><label>报废数量</label><input class="wms-input" id="scrapQty" type="number" min="1" style="width:100%" placeholder="0"></div><div class="form-group"><label>报废原因</label><select class="wms-select" id="scrapReason" style="width:100%"><option value="">请选择...</option><option value="损坏">损坏</option><option value="过期">过期</option><option value="质量问题">质量问题</option><option value="滞销报废">滞销报废</option><option value="其他">其他</option></select></div><div class="form-group"><label>备注</label><textarea class="wms-textarea" id="scrapComment" rows="2" style="width:100%"></textarea></div><button class="btn btn-danger" style="width:100%" onclick="submitScrap()">确认报废</button></div></div></div>`;
        loadScrapStats();
    }

    async function submitScrap() {
        const data = { warehouse: document.getElementById('scrapWarehouse').value, product_number: document.getElementById('scrapProductNumber').value.trim(), change_type: 'scrap', quantity: parseInt(document.getElementById('scrapQty').value) || 0, comment: `[${document.getElementById('scrapReason').value}] ${document.getElementById('scrapComment').value.trim()}` };
        if (!data.product_number || data.quantity <= 0) return toast('请填写完整信息', 'error');
        const d = await apiPost('/api/inventory/adjust', data);
        if (d.success) toast('已报废 ' + data.quantity + ' 件'); else toast(d.error || '操作失败', 'error');
    }

    async function loadScrapStats() { const d = await apiGet('/api/inventory/stats/scrap'); }

    async function renderOpsHistory() {
        document.getElementById('opsTabContent').innerHTML = `<div class="table-section"><div style="overflow-x:auto"><table><thead><tr><th>时间</th><th>仓库</th><th>Product Number</th><th>BOM 编号</th><th>描述</th><th>类型</th><th style="text-align:right">数量变动</th><th>备注</th></tr></thead><tbody id="allTxnBody"></tbody></table></div></div>`;
        const d = await apiGet('/api/inventory/transactions?per_page=100');
        const typeColors = { inbound: 'badge-delivered', outbound: 'badge-danger', adjustment: 'badge-pending', order_ship: 'badge-confirmed', scrap: 'badge-danger', calibration: 'badge-confirmed' };
        const typeLabels = { inbound: '入库', outbound: '出库', adjustment: '调整', order_ship: '发货指令', scrap: '报废', calibration: '校准' };
        document.getElementById('allTxnBody').innerHTML = d.data.map(r => `<tr><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td>${escapeHtml(r.warehouse || '')}</td><td style="font-weight:500">${escapeHtml(r.product_number || '')}</td><td>${escapeHtml(r.bom_code || '')}</td><td>${escapeHtml(r.product_description || '')}</td><td><span class="badge ${typeColors[r.change_type] || ''}">${escapeHtml(typeLabels[r.change_type] || r.change_type)}</span></td><td style="text-align:right;color:${r.quantity_change >= 0 ? 'var(--success)' : 'var(--danger)'}">${r.quantity_change > 0 ? '+' : ''}${r.quantity_change}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
    }

    // ===== Edit Inventory =====
    function openEditInv(id, bom, qty, inbound, outbound, instruction, comment) { document.getElementById('invEditId').value = id; document.getElementById('invEditBom').value = bom; document.getElementById('invEditQty').value = qty || 0; document.getElementById('invEditInbound').value = inbound || ''; document.getElementById('invEditOutbound').value = outbound || ''; document.getElementById('invEditInstruction').value = instruction || ''; document.getElementById('invEditComment').value = comment || ''; openModal('invEditModal'); }
    async function saveInvEdit() { const id = document.getElementById('invEditId').value; const d = await apiPut('/api/inventory/' + id, { inventory: parseInt(document.getElementById('invEditQty').value) || 0, last_inbound_date: document.getElementById('invEditInbound').value, last_outbound_date: document.getElementById('invEditOutbound').value, instruction: document.getElementById('invEditInstruction').value, comment: document.getElementById('invEditComment').value }); if (d.success) { toast('库存已更新'); closeModal('invEditModal'); loadStockList(); } else toast(d.error || '操作失败', 'error'); }

    // ===== Orders =====
    let orderPage = 1;
    function filterOrders(el, status) { document.querySelectorAll('#orderTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active'); currentOrderStatus = status; orderPage = 1; loadOrders(); }

    async function loadOrders() {
        const d = await apiGet(`/api/orders?status=${encodeURIComponent(currentOrderStatus)}&page=${orderPage}`);
        const sb = { pending: 'badge-pending', confirmed: 'badge-confirmed', shipped: 'badge-shipped', delivered: 'badge-delivered' };
        const sl = { pending: '待确认', confirmed: '已确认', shipped: '已发货', delivered: '已签收' };
        document.getElementById('orderTableBody').innerHTML = d.data.map(r => `<tr><td style="font-weight:500">${escapeHtml(r.order_number)}</td><td>${escapeHtml(r.warehouse)}</td><td>${escapeHtml(r.destination_country || '')}</td><td style="text-align:center">${r.item_count || 0}</td><td style="text-align:right">${r.total_requested || 0}</td><td style="text-align:right">${r.total_actual || '-'}</td><td><span class="badge ${sb[r.status] || ''}">${escapeHtml(sl[r.status] || r.status)}</span></td><td>${r.stt_number ? escapeHtml(r.stt_number) : '<span style="color:var(--text-muted)">-</span>'}</td><td style="white-space:nowrap">${escapeHtml(r.created_at || '')}</td><td><button class="btn btn-ghost btn-sm" onclick="viewOrder(${r.id})">详情</button></td></tr>`).join('');
        const total = d.total, perPage = d.per_page, pages = Math.ceil(total / perPage);
        document.getElementById('orderPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">共 ${total} 条，第 ${d.page}/${pages} 页</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="orderPage=Math.max(1,${d.page}-1);loadOrders()" ${d.page <= 1 ? 'disabled' : ''}>上一页</button><button class="page-btn" onclick="orderPage=Math.min(${pages},${d.page}+1);loadOrders()" ${d.page >= pages ? 'disabled' : ''}>下一页</button></div>`;
    }

    function openCreateOrder() { document.getElementById('orderItemsList').innerHTML = ''; addOrderItemRow(); openModal('createOrderModal'); }
    function addOrderItemRow() { const div = document.getElementById('orderItemsList'), row = document.createElement('div'); row.style.cssText = 'display:grid;grid-template-columns:1fr 120px 40px;gap:8px;margin-bottom:8px;align-items:center'; row.innerHTML = `<input class="wms-input order-item-product" placeholder="搜索 Product Number..." autocomplete="off"><input class="wms-input order-item-qty" type="number" min="1" placeholder="数量" value="1"><button class="btn btn-ghost btn-sm" onclick="this.parentElement.remove()" style="color:var(--danger)">X</button>`; div.appendChild(row); }
    async function submitCreateOrder() { const items = []; document.querySelectorAll('#orderItemsList > div').forEach(row => { const product = row.querySelector('.order-item-product').value.trim(), qty = parseInt(row.querySelector('.order-item-qty').value) || 0; if (product && qty > 0) items.push({ product_number: product, requested_qty: qty }); }); if (!items.length) return toast('请至少添加一条物料', 'error'); const d = await apiPost('/api/orders', { warehouse: document.getElementById('orderWarehouse').value, destination_country: document.getElementById('orderCountry').value, items }); if (d.success) { toast(`指令已创建：${d.order_number}`); closeModal('createOrderModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }

    async function viewOrder(id) {
        const d = await apiGet('/api/orders/' + id); const o = d.order, items = d.items;
        const sb = { pending: 'badge-pending', confirmed: 'badge-confirmed', shipped: 'badge-shipped', delivered: 'badge-delivered' };
        const sl = { pending: '待确认', confirmed: '已确认', shipped: '已发货', delivered: '已签收' };
        let actionsHtml = '';
        if (o.status === 'pending') actionsHtml = `<button class="btn btn-primary btn-sm" onclick="closeModal('orderDetailModal');openConfirmOrder(${id})">确认指令</button>`;
        if (o.status === 'confirmed') actionsHtml = `<button class="btn btn-primary btn-sm" onclick="closeModal('orderDetailModal');openShipOrder(${id})">确认发货</button>`;
        if (o.status === 'shipped') actionsHtml = `<button class="btn btn-success btn-sm" onclick="deliverOrder(${id})">标记签收</button>`;
        document.getElementById('orderDetailBody').innerHTML = `<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:20px"><div><div style="font-size:11px;color:var(--text-muted)">指令单号</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.order_number)}</div></div><div><div style="font-size:11px;color:var(--text-muted)">状态</div><div><span class="badge ${sb[o.status]}">${escapeHtml(sl[o.status])}</span></div></div><div><div style="font-size:11px;color:var(--text-muted)">仓库</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.warehouse)}</div></div><div><div style="font-size:11px;color:var(--text-muted)">目的国家</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.destination_country || 'N/A')}</div></div><div><div style="font-size:11px;color:var(--text-muted)">STT 运单号</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.stt_number || '-')}</div></div><div><div style="font-size:11px;color:var(--text-muted)">创建时间</div><div style="font-size:14px;font-weight:500">${escapeHtml(o.created_at || '')}</div></div></div><div style="margin-bottom:12px">${actionsHtml}</div><table style="width:100%"><thead><tr><th>Product Number</th><th>BOM 编号</th><th>描述</th><th style="text-align:right">请求数量</th><th style="text-align:right">实际数量</th></tr></thead><tbody>${items.map(i => `<tr><td style="font-weight:500">${escapeHtml(i.product_number || '')}</td><td>${escapeHtml(i.bom_code || '')}</td><td>${escapeHtml(i.product_description || '')}</td><td style="text-align:right">${i.requested_qty}</td><td style="text-align:right">${i.actual_qty != null ? i.actual_qty : '-'}</td></tr>`).join('')}</tbody></table>`;
        document.getElementById('orderDetailTitle').textContent = '指令 ' + o.order_number; openModal('orderDetailModal');
    }

    async function openConfirmOrder(id) { currentOrderConfirmId = id; const d = await apiGet('/api/orders/' + id); document.getElementById('confirmOrderBody').innerHTML = `<input type="hidden" id="confirmOrderId" value="${id}"><table style="width:100%"><thead><tr><th>Product Number</th><th>BOM 编号</th><th>描述</th><th style="text-align:right">请求数量</th><th style="text-align:right">实际数量 *</th></tr></thead><tbody>${d.items.map(i => `<tr><td style="font-weight:500">${escapeHtml(i.product_number || '')}</td><td>${escapeHtml(i.bom_code || '')}</td><td>${escapeHtml(i.product_description || '')}</td><td style="text-align:right">${i.requested_qty}</td><td><input class="wms-input confirm-actual-qty" type="number" min="0" data-product="${escapeHtml(i.product_number || '')}" value="${i.requested_qty}" style="width:80px;text-align:right"></td></tr>`).join('')}</tbody></table>`; openModal('confirmOrderModal'); }
    async function submitConfirmOrder() { const id = document.getElementById('confirmOrderId').value, items = []; document.querySelectorAll('.confirm-actual-qty').forEach(inp => items.push({ product_number: inp.dataset.product, actual_qty: parseInt(inp.value) || 0 })); const d = await apiPut('/api/orders/' + id + '/confirm', { items }); if (d.success) { toast('指令已确认，库存已扣减'); closeModal('confirmOrderModal'); loadOrders(); loadStockList(); } else toast(d.error || '操作失败', 'error'); }
    function openShipOrder(id) { document.getElementById('shipSttNumber').value = ''; document.getElementById('shipSubmitBtn').dataset.orderId = id; openModal('shipOrderModal'); }
    async function submitShipOrder() { const id = document.getElementById('shipSubmitBtn').dataset.orderId, stt = document.getElementById('shipSttNumber').value.trim(); if (!stt) return toast('请输入 STT 运单号', 'error'); const d = await apiPut('/api/orders/' + id + '/ship', { stt_number: stt }); if (d.success) { toast('已发货，STT: ' + stt); closeModal('shipOrderModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }
    async function deliverOrder(id) { if (!confirm('确认标记为已签收？')) return; const d = await apiPut('/api/orders/' + id + '/deliver', {}); if (d.success) { toast('已标记签收'); closeModal('orderDetailModal'); loadOrders(); } else toast(d.error || '操作失败', 'error'); }

    // ===== Init Shipment Header Filters =====
    const SHIPMENT_TYPE_LABELS = {
        'warehouse_central': '中央仓发出',
        'warehouse_furniture': '家具仓发出',
        'direct': '调拨',
    };
    const SHIPMENT_STATUS_ORDER = ['已交付', '运输中', '待核实', '异常单'];
    async function initShipmentHeaderFilters() {
        try {
            const data = await apiFetch(API + '/api/shipments?per_page=999');
            const statuses = [...new Set(data.shipments.map(s => s.display_status).filter(Boolean))];
            statuses.sort((a, b) => {
                const ai = SHIPMENT_STATUS_ORDER.indexOf(a), bi = SHIPMENT_STATUS_ORDER.indexOf(b);
                return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
            });
            document.getElementById('th-filter-ds').innerHTML = '<option value="">全部</option>' + statuses.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');

            const types = [...new Set(data.shipments.map(s => s.shipment_type).filter(Boolean))];
            document.getElementById('th-filter-type').innerHTML = '<option value="">全部</option>' + types.map(t => `<option value="${escapeHtml(t)}">${escapeHtml(SHIPMENT_TYPE_LABELS[t] || t)}</option>`).join('');

            const countries = [...new Set(data.shipments.map(s => demandCountryOfShipment(s)).filter(Boolean))].sort();
            document.getElementById('th-filter-country').innerHTML = '<option value="">全部</option>' + countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');

            const pickupMonths = [...new Set(data.shipments.map(s => (s.pickup_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
            document.getElementById('th-filter-pickup-month').innerHTML = '<option value="">全部</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            const actualMonths = [...new Set(data.shipments.map(s => (s.actual_delivery_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
            document.getElementById('th-filter-actual-month').innerHTML = '<option value="">全部</option>' + actualMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');

            // 验收状态筛选
            const verifyStatuses = ['已验收', '待验收', '未关联'];
            document.getElementById('th-filter-verify').innerHTML = '<option value="">全部</option>' + verifyStatuses.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
            updateShipmentFiltersUI();
        } catch(e) { console.error('Failed to init shipment header filters:', e); }
    }

    // ===== 费用列表 =====
    function switchCostTab(el) {
        if (el.style.opacity === '0.4') return;
        document.querySelectorAll('#costTabs .tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active');
        const tab = el.dataset.ctab;
        document.getElementById('cost-logistics-panel').style.display = tab === 'logistics' ? 'block' : 'none';
        document.getElementById('cost-warehouse-panel').style.display = tab === 'warehouse' ? 'block' : 'none';
    }

    async function loadCostList() {
        try {
            const status = document.getElementById('costStatusFilter')?.value || '';
            const data = await apiFetch(API + '/api/invoices/items?type=logistics&status=' + encodeURIComponent(status));
            const summary = data.summary || {};
            const plnToUsd = summary.pln_to_usd || 0.25;
            const tbody = document.getElementById('cost-logistics-body');
            const summaryEl = document.getElementById('cost-logistics-summary');
            const allItems = data.items || [];

            if (!allItems.length) {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无费用数据</td></tr>';
                if (summaryEl) summaryEl.textContent = '-';
                return;
            }

            tbody.innerHTML = allItems.map(item => {
                const usd = (item.net_amount * plnToUsd).toFixed(2);
                const matchBadge = item.matched_booking_id
                    ? `<span class="badge badge-delivered">${escapeHtml(item.matched_booking_id)}</span>`
                    : '<span style="color:var(--text-muted)">未匹配</span>';
                const statusBadge = item.invoice_status === 'verified'
                    ? '<span class="badge badge-delivered">已验收</span>'
                    : item.invoice_status === 'rejected'
                        ? '<span class="badge badge-danger">已拒绝</span>'
                        : '<span class="badge badge-pending">待验收</span>';
                return `<tr>
                    <td style="font-family:monospace;font-size:12px">${escapeHtml(item.stt_number)}</td>
                    <td style="text-align:right">${Number(item.net_amount).toLocaleString('pl-PL', {minimumFractionDigits: 2})}</td>
                    <td style="text-align:right">$${Number(usd).toLocaleString('en-US', {minimumFractionDigits: 2})}</td>
                    <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(item.ref_date || '-')}</td>
                    <td>${matchBadge}</td>
                    <td>${escapeHtml(item.consignee_country_code || '-')}</td>
                    <td style="font-size:12px">${escapeHtml(item.invoice_number)}</td>
                    <td style="font-size:12px">${escapeHtml(item.invoice_date || '-')}</td>
                    <td>${statusBadge}</td>
                </tr>`;
            }).join('');

            if (summaryEl) {
                summaryEl.textContent = `共 ${summary.item_count || allItems.length} 条物流费用 · 已匹配 ${summary.matched_count || 0} 条 · 待验收 ${summary.pending_count || 0} 条 · 已验收 ${summary.verified_count || 0} 条 · 合计 ${Number(summary.total_pln || 0).toLocaleString('pl-PL', {minimumFractionDigits: 2})} PLN ≈ $${Number(summary.total_usd || 0).toLocaleString('en-US', {minimumFractionDigits: 2})} USD`;
            }
        } catch(e) {
            console.error('Failed to load cost list:', e);
            const tbody = document.getElementById('cost-logistics-body');
            if (tbody) tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--danger);padding:24px">加载失败</td></tr>';
        }
    }

    // ===== Init App =====
    function initApp() {
        // Populate shipment header filters
        loadReleaseInfo?.();
        applyTheme();
        expandSidebarOnEntry();
        initShipmentHeaderFilters();
        currentWarehouse = 'Lodz warehouse';
        if (document.getElementById('settingLang')) document.getElementById('settingLang').value = currentLang;
        if (document.getElementById('settingWarehouse')) document.getElementById('settingWarehouse').value = currentWarehouse;
        initSettings();
        assembleImportCenter();
        loadReportHeaderIcon();
        loadReportMonths();
        loadStockFilters();
        applyUnifiedUi();
        switchPage('logistics');
        setTimeout(() => {
            loadDashboard();
            Object.values(charts || {}).forEach(chart => chart?.resize?.());
        }, 180);
    }

    // ===== 初始加载 =====
    checkAuth().then(() => {
        if (getAuthToken()) {
            initApp();
        }
    });
    
