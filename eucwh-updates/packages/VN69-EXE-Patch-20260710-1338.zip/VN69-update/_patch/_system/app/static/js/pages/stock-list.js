    // ===== Stock List =====
    let stockPage = 1, stockSortBy = 'updated_at', stockSortDir = 'desc', searchTimer = null, stockRequestSeq = 0;
    function debounceSearch() {
        clearTimeout(searchTimer);
        stockPage = 1;
        searchTimer = setTimeout(loadStockList, 260);
    }
    function toggleDetailCols() { document.getElementById('stockTable').classList.toggle('compact'); }
    function setStockSort(key) {
        if (stockSortBy === key) stockSortDir = stockSortDir === 'asc' ? 'desc' : 'asc';
        else { stockSortBy = key; stockSortDir = 'asc'; }
        stockPage = 1;
        loadStockList();
    }
    function updateStockSortHeader() {
        listUpdateSortIndicators('#stockTable th.sortable', stockSortBy, stockSortDir);
    }
    function clearStockFilters() {
        document.getElementById('stockSearch').value = '';
        listClearControls(['filterCategory', 'filterCat2', 'filterInstruction']);
        stockQualityFilter = '';
        stockPage = 1;
        loadStockList();
    }
    function stockQualityLabel(value) {
        return ({
            missing_image: '仅看缺图片 SKU',
            missing_price: '仅看缺价格 SKU',
            missing_inbound: '仅看缺入库时间 SKU'
        })[value] || '';
    }
    function syncStockWarehouseTabs() {
        document.querySelectorAll('#page-stocklist .tab[data-warehouse]').forEach(t => {
            t.classList.toggle('active', t.dataset.warehouse === currentWarehouse);
        });
        const select = document.getElementById('stockWarehouseSelect');
        if (select) select.value = currentWarehouse || '';
    }
    function switchWarehouse(el) { document.querySelectorAll('#page-stocklist .tab').forEach(t => t.classList.remove('active')); el.classList.add('active'); currentWarehouse = el.dataset.warehouse; stockPage = 1; loadStockFilters(); loadStockList(); }
    function setStockWarehouseFilter(value) {
        currentWarehouse = value || '';
        stockPage = 1;
        loadStockFilters();
        loadStockList();
    }
    async function loadStockList() {
        syncStockWarehouseTabs();
        bindStockImagePreviewEvents();
        const q = document.getElementById('stockSearch').value, cat = document.getElementById('filterCategory').value, cat2 = document.getElementById('filterCat2').value, inst = document.getElementById('filterInstruction').value;
        const perPage = document.getElementById('stockPerPage')?.value || 20;
        const qualityLabelEl = document.getElementById('stockQualityFilterLabel');
        if (qualityLabelEl) {
            const label = stockQualityLabel(stockQualityFilter);
            qualityLabelEl.textContent = label;
            qualityLabelEl.style.display = label ? 'inline-flex' : 'none';
            qualityLabelEl.className = label ? 'badge badge-warning' : '';
        }
        const seq = ++stockRequestSeq;
        const tableBody = document.getElementById('stockTableBody');
        setTableLoading(tableBody, 15, tx('加载中...', 'Loading...'), 28);
        const d = await apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&q=${encodeURIComponent(q)}&category=${encodeURIComponent(cat)}&category2=${encodeURIComponent(cat2)}&instruction=${encodeURIComponent(inst)}&quality=${encodeURIComponent(stockQualityFilter)}&sort_by=${encodeURIComponent(stockSortBy)}&sort_dir=${encodeURIComponent(stockSortDir)}&page=${stockPage}&per_page=${perPage}`);
        if (seq !== stockRequestSeq) return;
        const updatedEl = document.getElementById('stockLastUpdated');
        if (updatedEl) updatedEl.textContent = `${tx('库存更新时间', 'Inventory updated')}: ${formatStockUpdatedAt(d.last_updated_at)}`;
        updateStockSortHeader();
        if (!d.data.length) {
            const hasFilter = q || cat || cat2 || inst || stockQualityFilter;
            const message = `${tx('当前', 'Current')} ${currentWarehouse || tx('全部仓库', 'All warehouses')} ${tx('没有可显示库存。', 'has no displayable inventory.')}${hasFilter ? tx('请清除搜索/筛选后再看。', 'Please clear search/filter and try again.') : tx('如刚刚只上传了维护表，这是正常的；库存列表需要上传供应商库存表后才会产生数量。', 'If only the maintenance file was uploaded, this is normal; stock quantity appears after supplier inventory is uploaded.')}`;
            setTableEmpty(tableBody, 15, message, 36);
            document.getElementById('stockPagination').innerHTML = `<span style="font-size:12px;color:var(--text-secondary)">${tx('共 0 条', '0 records')}</span>`;
            applyFallbackEnglish(document.getElementById('page-stocklist'));
            return;
        }
        document.getElementById('stockTableBody').innerHTML = d.data.map(r => {
            const imagePath = r.image_path ? escapeHtml(r.image_path) : '';
            const imageArg = jsArg(r.image_path || '');
            const remarkArg = jsArg(r.comment || '');
            const imgSrc = imagePath ? imageUrl(r.image_path) : '';
            const bomDisplay = displayBomCode(r.bom_code || '');
            const thumb = imagePath ? `<img class="thumb stock-thumb thumb-clickable" src="${escapeHtml(imgSrc)}" data-image-path="${escapeHtml(r.image_path || '')}" data-remark="${escapeHtml(r.comment || '')}" onclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" ondblclick="event.preventDefault();showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="${tx('点击或双击查看大图', 'Click or double-click to view large image')}">` : '<span style="color:var(--text-muted);font-size:12px">-</span>';
            return `<tr><td data-product-detail="${escapeHtml(r.product_number || '')}" style="max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer" title="${tx('点击查看 Product No 明细', 'Click to view Product No details')}"><button type="button" class="link-btn" data-product-detail="${escapeHtml(r.product_number || '')}" style="padding:0;font-weight:700">${escapeHtml(r.product_number || '')}</button></td><td class="thumb-col">${thumb}</td><td style="font-weight:500;max-width:110px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${escapeHtml(bomDisplay)}">${escapeHtml(bomDisplay)}</td><td style="min-width:260px;max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(r.product_description || '')}">${escapeHtml(r.product_description || '')}</td><td style="max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text-primary);font-weight:500;font-size:12px">${escapeHtml(r.category || '')}</td><td style="max-width:110px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(r.category_2 || '')}</td><td style="max-width:90px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(r.instruction || '')}</td><td style="text-align:right;max-width:90px"><span class="stock-inventory-value">${Number(r.inventory || 0).toLocaleString()}</span></td><td class="col-detail" style="text-align:right">${r.unit_price != null ? '$' + Number(r.unit_price).toFixed(2) : ''}</td><td class="col-detail" style="text-align:right;font-weight:500">${r.ttl_amount != null ? '$' + Number(r.ttl_amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : ''}</td><td class="col-detail">${escapeHtml(r.last_inbound_date || '')}</td><td class="col-detail">${escapeHtml(r.last_outbound_date || '')}</td><td class="col-detail" style="text-align:center">${r.dos || ''}</td><td class="col-detail" style="text-align:center">${r.days_without_stock || ''}</td><td class="col-detail" style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(r.comment || '')}">${escapeHtml(r.comment || '')}</td></tr>`;
        }).join('');
        const total = d.total, pageSize = d.per_page, pages = listPageCount(total, pageSize);
        listRenderPagination('stockPagination', {
            total,
            page: d.page,
            pages,
            lang: currentLang,
            prevAction: `stockPage=Math.max(1,${d.page}-1);loadStockList()`,
            nextAction: `stockPage=Math.min(${pages},${d.page}+1);loadStockList()`
        });
        applyFallbackEnglish(document.getElementById('page-stocklist'));
    }
    async function openProductDetail(productNumber) {
        if (!productNumber) return toast(tx('Product Number 为空，无法打开明细', 'Product Number is empty, unable to open details'), 'error');
        const body = document.getElementById('productDetailBody');
        openModal('productDetailModal');
        setPanelLoading(body, tx('加载中...', 'Loading...'));
        const d = await apiGet('/api/inventory/product/' + encodeURIComponent(productNumber)).catch(e => ({ error: e.message }));
        if (d.error) { setPanelError(body, tx('明细加载失败', 'Failed to load details'), d.error, tx('请检查该 Product Number 是否已进入库存主数据。', 'Please check whether this Product Number exists in inventory master data.')); toast(tx('Product No 明细加载失败', 'Failed to load Product No details'), 'error'); return; }
        const p = d.product || {};
        window.currentProductDetailData = d;
        const detailImagePath = p.image_path || '';
        const detailImageArg = jsArg(detailImagePath);
        const detailRemarkArg = jsArg(p.product_description || p.remark || '');
        const image = detailImagePath ? `<img class="product-detail-image" src="${escapeHtml(imageUrl(detailImagePath))}" data-detail-image="1" data-image-path="${escapeHtml(detailImagePath)}" data-remark="${escapeHtml(p.product_description || p.remark || '')}" onclick="event.preventDefault();event.stopPropagation();showImage(${detailImageArg}, ${detailRemarkArg})" title="${tx('点击查看大图', 'Click to view large image')}" style="width:160px;height:120px;object-fit:cover;border-radius:8px;border:1px solid var(--border);cursor:zoom-in">` : `<div style="width:160px;height:120px;border:1px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;color:var(--text-muted)">${tx('无图', 'No image')}</div>`;
        const invRows = (d.inventory || []).map(r => `<tr><td>${escapeHtml(r.warehouse || '')}</td><td>${escapeHtml(r.instruction || '')}</td><td style="text-align:right">${r.inventory || 0}</td><td>${escapeHtml(r.last_inbound_date || '')}</td><td>${escapeHtml(r.last_outbound_date || '')}</td><td>${escapeHtml(r.comment || '')}</td></tr>`).join('');
        const movementOrderType = (prefix) => {
            const pfx = String(prefix || '').trim().toUpperCase();
            if (pfx === 'PL') return tx('PL订单', 'PL order');
            if (pfx === 'EU') return tx('地区部订单', 'Regional order');
            return prefix || '';
        };
        const movementOrderTypeDisplay = (r) => {
            const operationId = String(r.operation_id || '').trim().toUpperCase();
            const orderType = movementOrderType(r.operation_prefix);
            if (operationId && operationId === String(orderType || '').trim().toUpperCase()) return '/';
            return orderType || '/';
        };
        const movementRows = (d.movements || []).map(r => `<tr><td>${escapeHtml(r.movement_date || '')}</td><td style="font-weight:700">${escapeHtml(r.product_number || '')}</td><td><span class="badge ${r.movement_type === 'inbound' ? 'badge-delivered' : 'badge-confirmed'}">${r.movement_type === 'inbound' ? tx('入库', 'Inbound') : tx('出库', 'Outbound')}</span></td><td style="min-width:160px">${escapeHtml(r.operation_id || '')}</td><td style="width:70px;max-width:70px;text-align:center;color:var(--text-secondary)">${escapeHtml(movementOrderTypeDisplay(r))}</td><td>${escapeHtml(r.operation_target || '')}</td><td style="text-align:right">${Number(r.quantity || 0).toLocaleString()}</td></tr>`).join('');
        const matched = (d.matched_product_numbers || []).filter(x => x && x !== (p.product_number || productNumber));
        const bomDisplay = displayBomCode(p.bom_code || '');
        body.innerHTML = `<div style="display:grid;grid-template-columns:180px 1fr;gap:18px;margin-bottom:18px">${image}<div><div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start"><h3 style="margin:0 0 8px">${escapeHtml(p.product_number || productNumber)}</h3><button class="btn btn-primary btn-sm" onclick="openSkuMaintenance()">${tx('维护 SKU', 'Maintain SKU')}</button></div><div style="color:var(--text-secondary);line-height:1.8">${escapeHtml(p.product_description || '')}<br>BOM: <b>${escapeHtml(bomDisplay)}</b><br>${tx('物料品类', 'Category')}: ${escapeHtml(p.category || '')} · ${tx('适用产品', 'Category 2')}: ${escapeHtml(p.category_2 || '')}<br>${tx('单价', 'Unit price')}: $${Number(p.unit_price || 0).toFixed(2)} · ${tx('备注', 'Comment')}: ${escapeHtml(p.remark || '')}${matched.length ? `<br>${tx('关联编号', 'Related Product No')}: ${matched.map(escapeHtml).join(' / ')}` : ''}</div></div></div>
            <h4 style="margin:14px 0 8px">${tx('仓库库存', 'Warehouse inventory')}</h4><div style="overflow:auto"><table><thead><tr><th>${tx('仓库', 'Warehouse')}</th><th>${tx('归属国家', 'Instruction')}</th><th style="text-align:right">${tx('库存', 'Inventory')}</th><th>${tx('最近入库', 'Last inbound')}</th><th>${tx('最近出库', 'Last outbound')}</th><th>${tx('备注', 'Comment')}</th></tr></thead><tbody>${invRows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">${tx('暂无库存', 'No inventory')}</td></tr>`}</tbody></table></div>
            <h4 style="margin:16px 0 8px">${tx('近期出入流水（按 DATA RUCHU）', 'Recent inbound/outbound records (by DATA RUCHU)')}</h4><div style="overflow:auto;max-height:320px"><table><thead><tr><th>DATA RUCHU</th><th>Product No</th><th>${tx('类型', 'Type')}</th><th>ID_OPERACJI</th><th style="width:70px;max-width:70px;text-align:center">${tx('订单类型', 'Order type')}</th><th>${tx('对象/国家城市', 'Target / country or city')}</th><th style="text-align:right">${tx('数量', 'Qty')}</th></tr></thead><tbody>${movementRows || `<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">${tx('暂无 Specyfikacja 流水', 'No Specyfikacja records')}</td></tr>`}</tbody></table></div>`;
        applyFallbackEnglish(body);
    }
    function closeProductDetail() { closeModal('productDetailModal'); }
    window.openProductDetail = openProductDetail;
    window.showImage = showImage;
    window.closeImageModal = closeImageModal;
    function fillSkuMaintenanceSelect(id, values, selectedValue, placeholder) {
        const select = document.getElementById(id);
        if (!select) return;
        const norm = v => String(v || '').trim().toUpperCase();
        const selected = norm(selectedValue);
        const unique = [...new Set((values || []).map(norm).filter(Boolean))].sort();
        if (selected && !unique.includes(selected)) unique.unshift(selected);
        select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>` + unique.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
        select.value = selected;
    }
    function populateSkuMaintenanceOptions(product) {
        const p = product || {};
        const managed = getManagedOptions();
        const selectValues = id => Array.from(document.getElementById(id)?.options || []).map(o => o.value).filter(Boolean);
        const categories = [...managed.category, ...selectValues('filterCategory'), p.category];
        const category2s = [...managed.category2, ...selectValues('filterCat2'), p.category_2];
        fillSkuMaintenanceSelect('skuMaintCategory', categories, p.category, '请选择物料品类');
        fillSkuMaintenanceSelect('skuMaintCategory2', category2s, p.category_2, '请选择适用产品');
    }
    function openSkuMaintenance() {
        const d = window.currentProductDetailData || {};
        const p = d.product || {};
        if (!p.product_number) return toast('缺少 Product Number，无法维护', 'error');
        populateSkuMaintenanceOptions(p);
        document.getElementById('skuMaintProductNumber').value = p.product_number || '';
        document.getElementById('skuMaintProductNumberDisplay').value = p.product_number || '';
        document.getElementById('skuMaintBom').value = p.bom_code || '';
        document.getElementById('skuMaintDesc').value = p.product_description || '';
        document.getElementById('skuMaintUnitPrice').value = p.unit_price || 0;
        document.getElementById('skuMaintInbound').value = p.last_inbound_date || '';
        document.getElementById('skuMaintOutbound').value = p.last_outbound_date || '';
        document.getElementById('skuMaintDosThreshold').value = p.dos_threshold || 180;
        document.getElementById('skuMaintIdleThreshold').value = p.idle_threshold || 180;
        document.getElementById('skuMaintRemark').value = p.remark || '';
        openModal('skuMaintenanceModal');
    }
    async function saveSkuMaintenance() {
        const productNumber = document.getElementById('skuMaintProductNumber').value.trim();
        if (!productNumber) return toast('Product Number 不能为空', 'error');
        const payload = {
            bom_code: document.getElementById('skuMaintBom').value.trim(),
            product_description: document.getElementById('skuMaintDesc').value.trim(),
            category: document.getElementById('skuMaintCategory').value.trim(),
            category_2: document.getElementById('skuMaintCategory2').value.trim(),
            unit_price: parseFloat(document.getElementById('skuMaintUnitPrice').value) || 0,
            last_inbound_date: document.getElementById('skuMaintInbound').value,
            last_outbound_date: document.getElementById('skuMaintOutbound').value,
            dos_threshold: parseInt(document.getElementById('skuMaintDosThreshold').value) || 180,
            idle_threshold: parseInt(document.getElementById('skuMaintIdleThreshold').value) || 180,
            remark: document.getElementById('skuMaintRemark').value.trim()
        };
        const d = await apiPut('/api/inventory/product/' + encodeURIComponent(productNumber) + '/maintenance', payload).catch(e => ({ error: e.message }));
        if (!d.success) return toast(d.error || 'SKU 维护保存失败', 'error');
        toast('SKU 维护已保存');
        closeModal('skuMaintenanceModal');
        await openProductDetail(productNumber);
        await loadStockFilters();
        await loadStockList();
        await loadInvDashboard();
    }
    async function uploadSkuMaintenanceImage() {
        const input = document.getElementById('skuMaintImageFile');
        const productNumber = document.getElementById('skuMaintProductNumber')?.value || '';
        if (!input?.files?.[0]) return toast('请选择图片', 'error');
        const fd = new FormData();
        fd.append('files', input.files[0], input.files[0].name);
        const data = await fetch(API + '/api/inventory/images/upload', {
            method: 'POST',
            headers: getAuthToken() ? { Authorization: 'Bearer ' + getAuthToken() } : {},
            body: fd
        }).then(r => r.json()).catch(e => ({ error: e.message }));
        if (!data.success) return toast(data.error || '图片上传失败', 'error');
        input.value = '';
        document.getElementById('skuMaintImageName').textContent = '未选择图片';
        toast(`图片已上传 ${data.uploaded?.length || 0} 张`);
        if (productNumber) await openProductDetail(productNumber);
        await loadStockList();
    }
    function exportStockList() { apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&per_page=9999`).then(d => { let csv = 'BOM编号,产品编号,描述,物料品类,适用产品,归属国家,库存,单价,总金额,最近入库,最近出库,库龄,静置天数,备注\n'; d.data.forEach(r => { csv += `"${r.bom_code}","${r.product_number || ''}","${r.product_description || ''}","${r.category || ''}","${r.category_2 || ''}","${r.instruction || ''}",${r.inventory || 0},"${r.unit_price || 0}","${r.ttl_amount || 0}","${r.last_inbound_date || ''}","${r.last_outbound_date || ''}",${r.dos || ''},${r.days_without_stock || ''},"${r.comment || ''}"\n`; }); const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }); downloadLocalBlob(blob, exportFileName('inventory', 'csv')); toast('导出成功'); }); }
    async function exportLogisticsList(filters = {}) {
        const params = new URLSearchParams(filters || {});
        return downloadApiBlob('/api/export/logistics' + (params.toString() ? '?' + params.toString() : ''), {
            fallbackName: exportFileName('logistics'),
            successText: '物流清单已导出',
            errorText: '物流清单导出失败'
        });
    }
    function openLogisticsExportModal() {
        fillSelectFromOptions('logisticsExportStatus', 'th-filter-ds', '全部物流状态');
        fillSelectFromOptions('logisticsExportType', 'th-filter-type', '全部类型');
        fillSelectFromOptions('logisticsExportCountry', 'th-filter-country', '全部需求国家');
        fillSelectFromOptions('logisticsExportPickupMonth', 'th-filter-pickup-month', '全部发货月份');
        const pickupMonth = document.getElementById('logisticsExportPickupMonth');
        if (pickupMonth) {
            const years = [...new Set(Array.from(pickupMonth.options)
                .map(o => String(o.value || '').slice(0, 4))
                .filter(y => /^\d{4}$/.test(y)))].sort().reverse();
            years.forEach(year => {
                const value = `year:${year}`;
                if (!Array.from(pickupMonth.options).some(o => o.value === value)) {
                    pickupMonth.insertAdjacentHTML('beforeend', `<option value="${value}">${year}全年</option>`);
                }
            });
        }
        openModal('logisticsExportModal');
    }
    function runLogisticsExportFromModal() {
        const filters = {
            ds: document.getElementById('logisticsExportStatus')?.value || '',
            type: document.getElementById('logisticsExportType')?.value || '',
            country: document.getElementById('logisticsExportCountry')?.value || '',
            pickup_month: document.getElementById('logisticsExportPickupMonth')?.value || ''
        };
        closeModal('logisticsExportModal');
        return exportLogisticsList(filters);
    }
    function exportLogisticsCalibration() {
        return downloadApiBlob('/api/export/logistics-calibration', {
            fallbackName: exportFileName('logistics_cal'),
            successText: '物流状态校准 Excel 已导出',
            errorText: '导出失败'
        });
    }
    function exportInvoiceDetailExcel() {
        return downloadApiBlob('/api/export/invoice-calibration', {
            fallbackName: exportFileName('invoice_detail'),
            successText: '发票明细 Excel 已导出',
            errorText: '导出失败',
            preferFallbackName: true
        });
    }
    function exportInvoiceCalibration() {
        return exportInvoiceDetailExcel();
    }
    function exportAcceptanceDetailList() {
        return downloadApiBlob('/api/export/invoice-calibration', {
            fallbackName: exportFileName('acceptance'),
            successText: '验收明细 Excel 已导出',
            errorText: '导出失败',
            preferFallbackName: true
        });
    }
    function exportCoreBackup() {
        return downloadApiBlob('/api/export/core-backup', {
            fallbackName: exportFileName('core_backup'),
            successText: '底层备份 Excel 已导出',
            errorText: '导出失败'
        });
    }
    function fillSelectFromOptions(targetId, sourceId, allText) {
        const target = document.getElementById(targetId);
        const source = document.getElementById(sourceId);
        if (!target || !source) return;
        const current = target.value;
        target.innerHTML = `<option value="">${allText}</option>` + Array.from(source.options || [])
            .filter(o => o.value)
            .map(o => `<option value="${escapeHtml(o.value)}">${escapeHtml(o.textContent || o.value)}</option>`)
            .join('');
        target.value = Array.from(target.options).some(o => o.value === current) ? current : '';
    }
    function openStockExportModal() {
        document.getElementById('stockExportWarehouse').value = currentWarehouse || '';
        fillExcelFilterFromOptions('stockExportCategory', 'filterCategory', '全部物料品类');
        fillExcelFilterFromOptions('stockExportCategory2', 'filterCat2', '全部适用产品');
        fillExcelFilterFromOptions('stockExportInstruction', 'filterInstruction', '全部归属国家');
        document.getElementById('stockExportFormat').value = 'pdf';
        openModal('stockExportModal');
    }
    function openMovementExportModal() {
        document.getElementById('movementExportWarehouse').value = currentWarehouse || '';
        document.getElementById('movementExportType').value = '';
        fillExcelFilterFromOptions('movementExportCategory', 'filterCategory', '全部物料品类');
        fillExcelFilterFromOptions('movementExportCategory2', 'filterCat2', '全部适用产品');
        fillExcelFilterFromOptions('movementExportInstruction', 'filterInstruction', '全部归属国家');
        const now = new Date();
        const first = new Date(now.getFullYear(), now.getMonth(), 1);
        const iso = d => d.toISOString().slice(0, 10);
        document.getElementById('movementExportStart').value = iso(first);
        document.getElementById('movementExportEnd').value = iso(now);
        openModal('movementExportModal');
    }
    async function downloadInventoryExcel(filters, format) {
        const params = new URLSearchParams({
            warehouse: filters.warehouse || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || ''
        });
        if (format === 'excel_images') params.set('include_images', '1');
        return downloadApiBlob('/api/export/inventory?' + params.toString(), {
            fallbackName: exportFileName(format === 'excel_images' ? 'inventory_img' : 'inventory'),
            successText: format === 'excel_images' ? '库存图片版 Excel 已导出' : '库存全量 Excel 已导出',
            errorText: '库存清单导出失败'
        });
    }
    async function runStockExportFromModal() {
        const format = document.getElementById('stockExportFormat')?.value || 'pdf';
        const filters = {
            warehouse: document.getElementById('stockExportWarehouse')?.value || '',
            category: excelFilterValue('stockExportCategory'),
            categoryLabel: excelFilterLabel('stockExportCategory', '全部物料品类'),
            category2: excelFilterValue('stockExportCategory2'),
            category2Label: excelFilterLabel('stockExportCategory2', '全部适用产品'),
            instruction: excelFilterValue('stockExportInstruction'),
            instructionLabel: excelFilterLabel('stockExportInstruction', '全部归属国家')
        };
        closeModal('stockExportModal');
        if (format === 'excel' || format === 'excel_images') {
            return downloadInventoryExcel(filters, format);
        }
        await exportAllStockListPdf(filters, format === 'pdf');
        if (format === 'html') await exportReportHtml();
        if (format === 'png') await exportReportPng();
    }
    async function runMovementExportFromModal() {
        const params = new URLSearchParams({
            warehouse: document.getElementById('movementExportWarehouse')?.value || '',
            movement_type: document.getElementById('movementExportType')?.value || '',
            category: excelFilterValue('movementExportCategory'),
            category2: excelFilterValue('movementExportCategory2'),
            instruction: excelFilterValue('movementExportInstruction'),
            start_date: document.getElementById('movementExportStart')?.value || '',
            end_date: document.getElementById('movementExportEnd')?.value || ''
        });
        closeModal('movementExportModal');
        return downloadApiBlob('/api/inventory/export/movements?' + params.toString(), {
            fallbackName: exportFileName('movements'),
            successText: '出入库流水已导出',
            errorText: '出入库流水导出失败'
        });
    }
    async function exportAllStockList() { openStockExportModal(); }
    async function exportAllStockListPdf(filters = null, autoPrint = true) {
        filters = filters || {
            warehouse: currentWarehouse || '',
            category: document.getElementById('filterCategory')?.value || '',
            category2: document.getElementById('filterCat2')?.value || '',
            instruction: document.getElementById('filterInstruction')?.value || ''
        };
        const params = new URLSearchParams({
            warehouse: filters.warehouse || '',
            q: document.getElementById('stockSearch')?.value || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || '',
            per_page: 9999
        });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        const scopeBits = [
            filters.warehouse || '全部仓库',
            filters.categoryLabel || filters.category || '全部物料品类',
            filters.category2Label || filters.category2 || '全部适用产品',
            filters.instructionLabel || filters.instruction || '全部归属国家'
        ];
        renderInventoryPdfReport('库存清单', d.data || [], scopeBits.join(' · '), autoPrint);
    }
    async function exportCategory2StockReportPdf() {
        const category2 = (document.getElementById('filterCat2')?.value || '').trim();
        if (!category2) return toast('请先在表头选择“适用产品 Category 2”筛选项', 'error');
        const params = new URLSearchParams({ category2, warehouse: currentWarehouse || '', per_page: 9999 });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        renderInventoryPdfReport(`适用产品库存清单 · ${category2}`, d.data || [], currentWarehouse || '全部仓库');
    }
    function renderInventoryPdfReport(title, rows, scopeText, autoPrint = true) {
        const totalPcs = rows.reduce((s, r) => s + Number(r.inventory || 0), 0);
        const totalValue = rows.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const missingImage = rows.filter(r => !r.image_path).length;
        const missingPrice = rows.filter(r => Number(r.unit_price || 0) <= 0).length;
        const summarize = (field, label) => {
            const map = new Map();
            rows.forEach(r => {
                const key = String(r[field] || '未分类').trim() || '未分类';
                const cur = map.get(key) || { label: key, sku: 0, pcs: 0, value: 0 };
                cur.sku += 1;
                cur.pcs += Number(r.inventory || 0);
                cur.value += Number(r.ttl_amount || 0);
                map.set(key, cur);
            });
            const body = [...map.values()].sort((a, b) => b.value - a.value).slice(0, 8).map(r => `
                <tr><td title="${escapeHtml(r.label)}">${escapeHtml(r.label)}</td><td class="num">${r.sku.toLocaleString()}</td><td class="num">${r.pcs.toLocaleString()}</td><td class="num">${fmtPct(r.pcs, totalPcs)}</td><td class="num">${formatUsd(r.value)}</td><td class="num">${fmtPct(r.value, totalValue)}</td></tr>
            `).join('');
            return `<div class="report-summary-card"><h3>${escapeHtml(label)}</h3><table><colgroup><col style="width:30%"><col style="width:12%"><col style="width:14%"><col style="width:14%"><col style="width:16%"><col style="width:14%"></colgroup><thead><tr><th>分类</th><th class="num">SKU</th><th class="num">PCS</th><th class="num">PCS占比</th><th class="num">货值</th><th class="num">货值占比</th></tr></thead><tbody>${body || '<tr><td colspan="6">暂无数据</td></tr>'}</tbody></table></div>`;
        };
        const cards = rows.map(r => {
            const img = r.image_path ? `<img class="report-inventory-top-thumb" src="${escapeHtml(imageUrl(r.image_path))}" alt="">` : '<div class="report-inventory-top-noimg">NO IMAGE</div>';
            return `<div class="report-inventory-top-item">${img}<div class="report-inventory-top-title" title="${escapeHtml(r.product_number || '')}">${escapeHtml(r.product_number || '')}</div><div><div class="report-inventory-top-desc" title="${escapeHtml(r.product_description || '')}">${escapeHtml(r.product_description || '')}</div></div><div class="report-inventory-top-meta">${escapeHtml(r.category || '-')}<span class="print-only"> / ${escapeHtml(r.category_2 || '-')} / ${escapeHtml(r.instruction || '-')}</span></div><div class="report-inventory-top-meta print-hide">${escapeHtml(r.category_2 || '-')}</div><div class="report-inventory-top-meta print-hide">${escapeHtml(r.instruction || '-')}</div><div class="report-inventory-top-metric"><b>${Number(r.inventory || 0).toLocaleString()}</b>PCS</div><div class="report-inventory-top-metric"><b>${formatUsd(r.ttl_amount || 0)}</b>$${Number(r.unit_price || 0).toFixed(2)}/pcs</div></div>`;
        }).join('');
        const area = document.getElementById('reportPrintArea');
        document.getElementById('reportPreviewModal').style.display = 'flex';
        area.dataset.exportBase = exportFileName('inventory_report', 'html').replace(/\.html$/i, '');
        document.title = `${area.dataset.exportBase}`;
        area.innerHTML = `<div class="report-header"><div><h1 class="report-title">${escapeHtml(title)}</h1><div class="report-subtitle">统计范围：${escapeHtml(scopeText)} · 生成时间：${new Date().toLocaleString('zh-CN', { hour12:false })} · 版本：${APP_VERSION}</div></div></div>
            <div class="report-section"><div class="report-kpi-grid"><div class="report-kpi"><div class="label">SKU 条目</div><div class="value">${rows.length.toLocaleString()}</div><div class="sub">当前筛选</div></div><div class="report-kpi"><div class="label">库存总件数</div><div class="value">${totalPcs.toLocaleString()}</div><div class="sub">PCS</div></div><div class="report-kpi"><div class="label">库存总货值</div><div class="value">${formatUsd(totalValue)}</div><div class="sub">USD</div></div><div class="report-kpi"><div class="label">缺图片 SKU</div><div class="value">${missingImage.toLocaleString()}</div><div class="sub">需维护</div></div><div class="report-kpi"><div class="label">缺价格 SKU</div><div class="value">${missingPrice.toLocaleString()}</div><div class="sub">需维护</div></div></div></div>
            <div class="report-section"><h2>Summary 统计</h2><div class="report-summary-grid">${summarize('category', '品类')}${summarize('category_2', '产业')}${summarize('instruction', '归属国家')}</div></div>
            <div class="report-section"><h2>库存明细</h2><div class="report-inventory-top-list">${cards || '<div class="report-note">暂无数据</div>'}</div></div>
            <div class="report-footer"><span>Generated by ${APP_VERSION}</span><span>Inventory PDF report</span></div>`;
        if (autoPrint) setTimeout(() => window.print(), 350);
    }
    async function exportReportCategory2Inventory() {
        const category2 = (document.getElementById('reportCategory2')?.value || '').trim();
        if (!category2) return toast('请选择适用产品 Category 2', 'error');
        const warehouse = document.getElementById('reportWarehouse')?.value || '';
        const params = new URLSearchParams({ category2, per_page: 9999, warehouse });
        const d = await apiGet(`/api/inventory?${params.toString()}`).catch(e => ({ error: e.message, data: [] }));
        if (d.error) return toast(d.error, 'error');
        const rows = d.data || [];
        const whText = warehouse || '全部仓库';
        renderInventoryPdfReport(`适用产品库存清单 · ${category2}`, rows, whText);
    }
    async function downloadFullExport(scope) {
        const params = new URLSearchParams({ scope });
        if (scope === 'current') params.set('warehouse', currentWarehouse);
        return downloadApiBlob(`/api/export/full?${params.toString()}`, {
            fallbackName: exportFileName(scope === 'current' ? 'full_current' : 'full_all', 'zip'),
            successText: '完整导出包已生成',
            errorText: '导出失败'
        });
    }
    async function loadStockFilters() {
        const invData = await apiGet(`/api/inventory?warehouse=${encodeURIComponent(currentWarehouse)}&per_page=9999`).catch(() => ({ data: [] }));
        const selected = {
            category: document.getElementById('filterCategory').value,
            category2: document.getElementById('filterCat2').value,
            instruction: document.getElementById('filterInstruction').value
        };
        const rows = Array.isArray(invData.data) ? invData.data : [];
        const activeRows = rows.filter(s => Number(s.inventory || 0) > 0);
        const sourceRows = activeRows.length ? activeRows : rows;
        const cats = uniqueSortedInventoryOptions(sourceRows, 'category');
        const cat2s = uniqueSortedInventoryOptions(sourceRows, 'category_2');
        const insts = uniqueSortedInventoryOptions(sourceRows, 'instruction');
        document.getElementById('filterCategory').innerHTML = '<option value="">全部</option>' + cats.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        document.getElementById('filterCat2').innerHTML = '<option value="">全部</option>' + cat2s.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        document.getElementById('filterInstruction').innerHTML = '<option value="">全部</option>' + insts.map(c => `<option>${escapeHtml(c)}</option>`).join('');
        if (document.getElementById('reportCategory2')) {
            const currentReportCat2 = document.getElementById('reportCategory2').value;
            document.getElementById('reportCategory2').innerHTML = '<option value="">选择适用产品</option>' + cat2s.map(c => `<option>${escapeHtml(c)}</option>`).join('');
            document.getElementById('reportCategory2').value = cat2s.includes(currentReportCat2) ? currentReportCat2 : '';
        }
        document.getElementById('filterCategory').value = cats.includes(selected.category) ? selected.category : '';
        document.getElementById('filterCat2').value = cat2s.includes(selected.category2) ? selected.category2 : '';
        document.getElementById('filterInstruction').value = insts.includes(selected.instruction) ? selected.instruction : '';
    }
