    let acceptancePage = 1;
    let acceptanceSearchTimer = null;
    let acceptanceSortBy = 'invoice_date';
    let acceptanceSortDir = 'desc';
    let acceptanceHeaderCountryFilter = '';
    function debouncedLoadAcceptanceList() {
        clearTimeout(acceptanceSearchTimer);
        acceptanceSearchTimer = setTimeout(loadAcceptanceList, 250);
    }
    function syncAcceptanceHeaderControls() {
        const invoiceMonthHeader = document.getElementById('acceptanceHeaderInvoiceMonthFilter');
        const pickupMonthHeader = document.getElementById('acceptanceHeaderPickupMonthFilter');
        const typeHeader = document.getElementById('acceptanceHeaderTypeFilter');
        const statusHeader = document.getElementById('acceptanceHeaderStatusFilter');
        const countryHeader = document.getElementById('acceptanceHeaderCountryFilter');
        if (invoiceMonthHeader) invoiceMonthHeader.value = document.getElementById('acceptanceMonthFilter')?.value || '';
        if (pickupMonthHeader) pickupMonthHeader.value = document.getElementById('acceptancePickupMonthFilter')?.value || '';
        if (typeHeader) typeHeader.value = document.getElementById('acceptanceTypeFilter')?.value || '';
        if (statusHeader) statusHeader.value = document.getElementById('acceptanceStatusFilter')?.value || '';
        if (countryHeader) countryHeader.value = acceptanceHeaderCountryFilter || '';
        [invoiceMonthHeader, pickupMonthHeader, typeHeader, statusHeader, countryHeader].forEach(el => listSetHasValue(el));
    }
    function updateAcceptanceHeaderFilter(field, value) {
        const map = {
            invoiceMonth: 'acceptanceMonthFilter',
            pickupMonth: 'acceptancePickupMonthFilter',
            type: 'acceptanceTypeFilter',
            status: 'acceptanceStatusFilter'
        };
        if (field === 'country') {
            acceptanceHeaderCountryFilter = value || '';
        } else if (map[field]) {
            const control = document.getElementById(map[field]);
            if (control) control.value = value || '';
        }
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function clearAcceptanceFilters() {
        document.getElementById('acceptanceSearch').value = '';
        document.getElementById('acceptanceTypeFilter').value = '';
        document.getElementById('acceptanceStatusFilter').value = '';
        document.getElementById('acceptanceMonthFilter').value = '';
        acceptanceHeaderCountryFilter = '';
        const pickupMonthFilter = document.getElementById('acceptancePickupMonthFilter');
        if (pickupMonthFilter) pickupMonthFilter.value = '';
        acceptanceSortBy = 'invoice_date';
        acceptanceSortDir = 'desc';
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function setAcceptanceSort(key) {
        if (acceptanceSortBy === key) acceptanceSortDir = acceptanceSortDir === 'asc' ? 'desc' : 'asc';
        else {
            acceptanceSortBy = key;
            acceptanceSortDir = 'asc';
        }
        acceptancePage = 1;
        loadAcceptanceList();
    }
    function updateAcceptanceSortIndicators() {
        listUpdateSortIndicators('#acceptanceTable th.sortable', acceptanceSortBy, acceptanceSortDir);
    }
    function toggleAcceptanceDetailCols() { document.getElementById('acceptanceTable')?.classList.toggle('compact'); }
    function acceptanceSortValue(row, key) {
        if (key === 'country') return String(row.consignee_country_code || '').toUpperCase();
        if (key === 'invoice_status') return String(row.invoice_status || row.acceptance_status || '').toUpperCase();
        if (key === 'net_amount') return Number(row.net_amount || 0);
        if (key === 'accepted_amount') return row.accepted_amount == null ? -Infinity : Number(row.accepted_amount || 0);
        return String(row[key] ?? '').toUpperCase();
    }
    function updateAcceptanceMonthOptions(rows) {
        const select = document.getElementById('acceptanceMonthFilter');
        const pickupSelect = document.getElementById('acceptancePickupMonthFilter');
        const invoiceHeader = document.getElementById('acceptanceHeaderInvoiceMonthFilter');
        const pickupHeader = document.getElementById('acceptanceHeaderPickupMonthFilter');
        const countryHeader = document.getElementById('acceptanceHeaderCountryFilter');
        const months = [...new Set((rows || []).map(r => String(r.invoice_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
        const pickupMonths = [...new Set((rows || []).map(r => String(r.pickup_date || '').slice(0, 7)).filter(Boolean))].sort().reverse();
        const countries = [...new Set((rows || []).map(r => String(r.consignee_country_code || '').trim().toUpperCase()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'en'));
        if (select) {
            const current = select.value || '';
            select.innerHTML = '<option value="">全部发票月份</option>' + months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            select.value = months.includes(current) ? current : '';
            listSetHasValue(select);
        }
        if (pickupSelect) {
            const currentPickup = pickupSelect.value || '';
            pickupSelect.innerHTML = '<option value="">全部发货月份</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            pickupSelect.value = pickupMonths.includes(currentPickup) ? currentPickup : '';
            listSetHasValue(pickupSelect);
        }
        if (invoiceHeader) {
            const current = document.getElementById('acceptanceMonthFilter')?.value || '';
            invoiceHeader.innerHTML = '<option value="">全部</option>' + months.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            invoiceHeader.value = months.includes(current) ? current : '';
        }
        if (pickupHeader) {
            const current = document.getElementById('acceptancePickupMonthFilter')?.value || '';
            pickupHeader.innerHTML = '<option value="">全部</option>' + pickupMonths.map(m => `<option value="${escapeHtml(m)}">${escapeHtml(m)}</option>`).join('');
            pickupHeader.value = pickupMonths.includes(current) ? current : '';
        }
        if (countryHeader) {
            countryHeader.innerHTML = '<option value="">全部</option>' + countries.map(c => `<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
            countryHeader.value = countries.includes(acceptanceHeaderCountryFilter) ? acceptanceHeaderCountryFilter : '';
            if (acceptanceHeaderCountryFilter && !countryHeader.value) acceptanceHeaderCountryFilter = '';
        }
        syncAcceptanceHeaderControls();
    }
    async function loadAcceptanceList() {
        const tbody = document.getElementById('acceptanceListBody');
        if (!tbody) return;
        const type = document.getElementById('acceptanceTypeFilter')?.value || '';
        const status = document.getElementById('acceptanceStatusFilter')?.value || '';
        const month = document.getElementById('acceptanceMonthFilter')?.value || '';
        const pickupMonth = document.getElementById('acceptancePickupMonthFilter')?.value || '';
        const search = String(document.getElementById('acceptanceSearch')?.value || '').trim().toUpperCase();
        const perPage = Number(document.getElementById('acceptancePerPage')?.value || 20);
        const params = new URLSearchParams();
        if (type) params.set('type', type);
        if (status) params.set('status', status);
        updateAcceptanceSortIndicators();
        syncAcceptanceHeaderControls();
        setTableLoading(tbody, 11);
        try {
            const data = await apiFetch(API + '/api/invoices/items?' + params.toString());
            let rows = data.items || [];
            updateAcceptanceMonthOptions(rows);
            const activeMonth = document.getElementById('acceptanceMonthFilter')?.value || month;
            if (activeMonth) {
                rows = rows.filter(r => String(r.invoice_date || '').slice(0, 7) === activeMonth);
            }
            const activePickupMonth = document.getElementById('acceptancePickupMonthFilter')?.value || pickupMonth;
            if (activePickupMonth) {
                rows = rows.filter(r => String(r.pickup_date || '').slice(0, 7) === activePickupMonth);
            }
            if (acceptanceHeaderCountryFilter) {
                rows = rows.filter(r => String(r.consignee_country_code || '').trim().toUpperCase() === acceptanceHeaderCountryFilter);
            }
            if (search) {
                rows = rows.filter(r => [r.stt_number, r.invoice_number, r.consignee_country_code, r.matched_booking_id, r.exception_reason].some(v => String(v || '').toUpperCase().includes(search)));
            }
            const dir = acceptanceSortDir === 'asc' ? 1 : -1;
            rows = rows.slice().sort((a, b) => {
                const av = acceptanceSortValue(a, acceptanceSortBy);
                const bv = acceptanceSortValue(b, acceptanceSortBy);
                if (av === bv) return 0;
                return av > bv ? dir : -dir;
            });
            const pageData = listSlicePage(rows, acceptancePage, perPage);
            const total = pageData.total;
            const pages = pageData.pages;
            acceptancePage = pageData.page;
            rows = pageData.rows;
            if (!rows.length) {
                setTableEmpty(tbody, 11, '暂无验收明细，请先在数据管理中心导入发票验收明细 Excel', 32);
            } else {
                tbody.innerHTML = rows.map(item => {
                    const statusValue = item.invoice_status || item.acceptance_status || 'pending';
                    const statusBadge = statusValue === 'verified' ? 'badge-delivered' : statusValue === 'rejected' ? 'badge-danger' : 'badge-pending';
                    const statusLabel = statusValue === 'verified' ? '已验收' : statusValue === 'rejected' ? '已拒绝' : '待验收';
                    const stt = item.stt_number || '';
                    const matched = item.matched_booking_id || '';
                    const invoiceCell = item.invoice_id
                        ? `<button type="button" class="link-btn" data-invoice-id="${Number(item.invoice_id)}" onclick="viewInvoiceDetail(Number(this.dataset.invoiceId))" style="padding:0;font-weight:700">${escapeHtml(item.invoice_number || '-')}</button>`
                        : escapeHtml(item.invoice_number || '-');
                    const sttCell = stt ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(stt)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0;font-weight:700">${escapeHtml(stt)}</button>` : '-';
                    const matchedCell = matched ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(matched)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0"><span class="badge badge-delivered">${escapeHtml(matched)}</span></button>` : '<span style="color:var(--text-muted)">未匹配</span>';
                    return `<tr>
                        <td>${invoiceCell}</td>
                        <td class="col-detail">${escapeHtml(item.invoice_date || '-')}</td>
                        <td class="col-detail">${item.invoice_type === 'warehouse' ? '仓储操作费' : '物流费用'}</td>
                        <td>${sttCell}</td>
                        <td>${matchedCell}</td>
                        <td class="col-detail">${escapeHtml(item.consignee_country_code || '-')}</td>
                        <td class="col-detail">${escapeHtml(item.pickup_date || '-')}</td>
                        <td style="text-align:right">${formatPln(item.net_amount)}</td>
                        <td style="text-align:right">${item.accepted_amount == null ? '-' : formatPln(item.accepted_amount)}</td>
                        <td><span class="badge ${statusBadge}">${statusLabel}</span></td>
                        <td class="col-detail">${escapeHtml(item.exception_reason || item.acceptance_remark || '-')}</td>
                    </tr>`;
                }).join('');
            }
            listRenderPagination('acceptancePagination', {
                total,
                page: acceptancePage,
                pages,
                lang: currentLang,
                prevAction: 'acceptancePage=Math.max(1,acceptancePage-1);loadAcceptanceList()',
                nextAction: `acceptancePage=Math.min(${pages},acceptancePage+1);loadAcceptanceList()`
            });
        } catch(e) {
            setTableError(tbody, 11, `加载失败：${e.message}`);
        }
    }
