    // ===== Invoice Functions =====
    let invoicePlnToUsd = 0.25; // 默认汇率 4 PLN = 1 USD

    async function uploadInvoice(input, type) {
        if (!input.files.length) return;
        const file = input.files[0];
        if (!file.name.toLowerCase().endsWith('.pdf')) {
            toast('请上传 PDF 文件', 'error');
            return;
        }
        const resultEl = document.getElementById('invoice-import-result')
            || document.getElementById('legacy-logistics-invoice-result');
        if (!resultEl) return toast('发票导入结果区域未找到', 'error');
        resultEl.innerHTML = '<span style="color:var(--text-muted)">正在解析...</span>';

        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        try {
            const data = await apiFetch(API + '/api/invoices/upload', { method: 'POST', body: formData });
            if (data.error) {
                resultEl.innerHTML = `<span style="color:var(--danger)">❌ ${escapeHtml(data.error)}</span>`;
                return;
            }
            resultEl.innerHTML = `<span style="color:var(--success)">✅ ${escapeHtml(invoiceTypeLabel(data.type || type))}已导入 ${data.total_items} 条明细，匹配 ${data.matched_items} 条</span>`;
            loadInvoicePage();
            loadBudget();
            loadUploadRecords();
            // 如果费用验收看板可见，也刷新
            if (document.getElementById('page-budget')?.classList.contains('active')) loadBudgetPage();
            input.value = '';
            const unifiedInvoiceName = document.getElementById('invoicePdfFileName');
            if (unifiedInvoiceName) unifiedInvoiceName.textContent = '发票 PDF';
            const autoHint = document.getElementById('invoiceAutoTypeHint');
            if (autoHint) autoHint.textContent = '自动识别发票类型';
            if (input.id === 'logistics-invoice-file') {
                setTimeout(() => exportInvoiceDetailExcel(), 350);
            }
        } catch(e) {
            resultEl.innerHTML = `<span style="color:var(--danger)">上传失败: ${escapeHtml(e.message)}</span>`;
        }
    }

    async function loadInvoicePage() {
        try {
            const data = await apiFetch(API + '/api/invoices');
            const tbody = document.getElementById('invoice-list-body');
            if (!data.length) {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无发票数据</td></tr>';
                return;
            }
            tbody.innerHTML = data.map(inv => `<tr>
                <td>${invoiceNumberLink(inv)}</td>
                <td>${escapeHtml(inv.invoice_date || '-')}</td>
                <td>${inv.invoice_type === 'logistics' ? '物流' : '仓储'}</td>
                <td style="text-align:right">${formatPln(inv.total_net)}</td>
                <td style="text-align:right">${formatUsd(Number(inv.total_net) * invoicePlnToUsd)}</td>
                <td style="text-align:center">${inv.item_count}</td>
                <td style="text-align:center">${inv.matched_count}</td>
                <td><span class="badge ${inv.status === 'verified' ? 'badge-delivered' : inv.status === 'rejected' ? 'badge-danger' : 'badge-pending'}">${inv.status === 'verified' ? '已验收' : inv.status === 'rejected' ? '已拒绝' : '待验收'}</span></td>
                <td style="white-space:nowrap">${inv.status === 'pending' ? `<button class="btn btn-primary btn-sm" onclick="verifyInvoice(${inv.id})">验收</button> <button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="rejectInvoice(${inv.id})">拒绝</button>` : '<span style="color:var(--text-muted)">-</span>'}</td>
            </tr>`).join('');

            // Update budget display
            loadBudget();
        } catch(e) {
            console.error('Failed to load invoices:', e);
        }
    }

    function invoiceNumberLink(inv) {
        if (!inv?.id) return escapeHtml(inv?.invoice_number || '-');
        return `<button type="button" class="link-btn" data-invoice-id="${Number(inv.id)}" onclick="viewInvoiceDetail(Number(this.dataset.invoiceId))" style="padding:0;font-weight:700">${escapeHtml(inv.invoice_number || '-')}</button>`;
    }

    function renderInvoiceDetailRows(items) {
        return (items || []).map(item => {
            const stt = String(item.stt_number || '').trim();
            const matched = String(item.matched_booking_id || '').trim();
            const sttCell = stt
                ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(stt)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0;font-family:monospace;font-size:12px;font-weight:700">${escapeHtml(stt)}</button>`
                : '-';
            const matchedCell = matched
                ? `<button type="button" class="link-btn" data-shipment-detail="${escapeHtml(matched)}" onclick="openShipmentEditorById(this.dataset.shipmentDetail)" style="padding:0"><span class="badge badge-delivered">✓ ${escapeHtml(matched)}</span></button>`
                : '<span style="color:var(--text-muted)">未匹配</span>';
            return `<tr>
                <td>${sttCell}</td>
                <td style="text-align:right">${formatPln(item.net_amount)}</td>
                <td style="text-align:right">${formatUsd(Number(item.net_amount) * invoicePlnToUsd)}</td>
                <td style="font-size:12px;color:var(--text-secondary)">${escapeHtml(item.ref_date || '-')}</td>
                <td>${matchedCell}</td>
            </tr>`;
        }).join('');
    }

    async function viewInvoiceDetail(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id);
            const title = document.getElementById('invoice-detail-title');
            const body = document.getElementById('invoice-detail-body');
            const modal = document.getElementById('invoice-detail-modal');
            if (modal && modal.parentElement !== document.body) document.body.appendChild(modal);

            title.textContent = `发票 ${data.invoice_number} 明细`;
            body.innerHTML = `
                <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:16px">
                    <div><div style="font-size:11px;color:var(--text-muted)">发票日期</div><div style="font-size:14px;font-weight:500">${escapeHtml(data.invoice_date || '-')}</div></div>
                    <div><div style="font-size:11px;color:var(--text-muted)">总净额 (PLN)</div><div style="font-size:14px;font-weight:500">${formatPln(data.total_net)}</div></div>
                    <div><div style="font-size:11px;color:var(--text-muted)">总净额 (USD)</div><div style="font-size:14px;font-weight:500">${formatUsd(Number(data.total_net) * invoicePlnToUsd)}</div></div>
                </div>
                <table style="width:100%">
                    <thead><tr><th>STT Number</th><th>净额 (PLN)</th><th>净额 (USD)</th><th>Ref 日期</th><th>匹配运单</th></tr></thead>
                    <tbody>${renderInvoiceDetailRows(data.items)}</tbody>
                </table>`;
            if (modal) modal.style.display = 'flex';
        } catch(e) {
            toast('加载明细失败: ' + e.message, 'error');
        }
    }

    function closeInvoiceDetail() {
        document.getElementById('invoice-detail-modal').style.display = 'none';
    }

    async function verifyInvoice(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'verified' }) });
            if (data.success) { toast('发票已验收'); loadInvoicePage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    async function rejectInvoice(id) {
        if (!confirm('确认拒绝此发票？')) return;
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'rejected' }) });
            if (data.success) { toast('发票已拒绝'); loadInvoicePage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    // ===== 费用验收看板 =====
    async function loadBudgetPage() {
        try {
            const data = await apiFetch(API + '/api/invoices/budget');
            const plnToUsd = data.pln_to_usd || 0.25;
            // 更新页面元素
            const totalEl = document.getElementById('budget-total');
            if (totalEl) totalEl.textContent = formatUsd(data.budget_usd, { minimumFractionDigits: 0 });
            
            const spentEl = document.getElementById('budget-logistics-spent');
            const plnEl = document.getElementById('budget-logistics-pln');
            if (spentEl) spentEl.textContent = formatUsd(data.logistics_usd);
            if (plnEl) plnEl.textContent = formatPln(data.logistics_pln);
            const pendingSpentEl = document.getElementById('budget-pending-spent');
            const pendingPlnEl = document.getElementById('budget-pending-pln');
            const matchRateEl = document.getElementById('budget-match-rate');
            if (pendingSpentEl) pendingSpentEl.textContent = formatUsd(data.pending_logistics_usd);
            if (pendingPlnEl) pendingPlnEl.textContent = formatPln(data.pending_logistics_pln);
            if (matchRateEl) matchRateEl.textContent = Number(data.invoice_match_rate || 0).toFixed(1) + '%';

            const remainValEl = document.getElementById('budget-remaining-val');
            const remainPctEl = document.getElementById('budget-remaining-pct');
            const remainCard = document.getElementById('budget-remaining-card');
            if (remainValEl) remainValEl.textContent = formatUsd(data.remaining_usd);
            const pct = data.budget_usd > 0 ? ((data.total_spent_usd / data.budget_usd) * 100) : 0;
            if (remainPctEl) remainPctEl.textContent = (100 - pct).toFixed(1) + '% 可用';

            // 进度条
            const bar = document.getElementById('budget-progress-bar');
            const label = document.getElementById('budget-progress-label');
            const progressText = document.getElementById('budget-progress-text');
            if (bar) {
                bar.style.width = Math.min(pct, 100) + '%';
                if (pct > 80) bar.style.background = 'linear-gradient(90deg,#f59e0b,#ef4444)';
                else if (pct > 50) bar.style.background = 'linear-gradient(90deg,#22c55e,#f59e0b)';
                else bar.style.background = 'linear-gradient(90deg,#22c55e,#16a34a)';
            }
            if (label) label.textContent = pct.toFixed(1) + '%';
            if (progressText) progressText.textContent = formatUsd(data.total_spent_usd) + ' / ' + formatUsd(data.budget_usd, { minimumFractionDigits: 0 });

            // 颜色
            if (remainCard && remainValEl) {
                if (data.remaining_usd <= 0) { remainValEl.className = 'value danger'; remainCard.style.borderColor = 'rgba(239,68,68,0.3)'; }
                else if (data.remaining_usd < 50000) { remainValEl.className = 'value warning'; remainCard.style.borderColor = 'rgba(245,158,11,0.3)'; }
                else { remainValEl.className = 'value success'; remainCard.style.borderColor = 'rgba(34,197,94,0.3)'; }
            }

            // 发票列表
            const tbody = document.getElementById('budget-invoice-list');
            if (data.invoices && data.invoices.length) {
                tbody.innerHTML = data.invoices.map(inv => `<tr>
                    <td>${invoiceNumberLink(inv)}</td>
                    <td>${escapeHtml(inv.invoice_date || '-')}</td>
                    <td>${inv.invoice_type === 'logistics' ? '物流' : '仓储'}</td>
                    <td style="text-align:right">${formatPln(inv.total_net)}</td>
                    <td style="text-align:right">${formatUsd(Number(inv.total_net) * plnToUsd)}</td>
                    <td style="text-align:center">${inv.item_count}</td>
                    <td style="text-align:center">${inv.matched_count}</td>
                    <td><span class="badge ${inv.status === 'verified' ? 'badge-delivered' : inv.status === 'rejected' ? 'badge-danger' : 'badge-pending'}">${inv.status === 'verified' ? '已验收' : inv.status === 'rejected' ? '已拒绝' : '待验收'}</span></td>
                    <td style="white-space:nowrap">
                        ${inv.status === 'pending' ? `<button class="btn btn-primary btn-sm" onclick="verifyBudgetInvoice(${inv.id})">验收</button> <button class="btn btn-ghost btn-sm" style="color:var(--danger)" onclick="rejectBudgetInvoice(${inv.id})">拒绝</button>` : '<span style="color:var(--text-muted)">-</span>'}
                    </td>
                </tr>`).join('');
            } else {
                tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:var(--text-muted);padding:24px">暂无发票数据，请上传物流费用发票</td></tr>';
            }
            await loadAcceptanceUsageAnalysis(plnToUsd);
        } catch(e) {
            console.error('Failed to load budget page:', e);
        }
    }

    function invoiceItemAmount(item) {
        const accepted = item?.accepted_amount;
        return Number(accepted === null || accepted === undefined || accepted === '' ? item?.net_amount || 0 : accepted || 0);
    }

    function chartThemeColor(token, fallback) {
        return getComputedStyle(document.documentElement).getPropertyValue(token).trim() || fallback;
    }

    function getChartTextColor() {
        return chartThemeColor('--text-secondary', '#64748b');
    }

    function getChartGridColor() {
        return chartThemeColor('--border', '#d9e2ef');
    }

    function renderAcceptanceChart(key, canvasId, labels, datasets, stacked = false) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: { labels, datasets },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    legend: { position: 'bottom', labels: { color: getChartTextColor(), boxWidth: 10 } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${formatPln(ctx.parsed.y)} PLN` } }
                },
                scales: {
                    x: { stacked, grid: { display: false }, ticks: { color: getChartTextColor() } },
                    y: { stacked, beginAtZero: true, grid: { color: getChartGridColor() }, ticks: { color: getChartTextColor(), callback: v => Number(v).toLocaleString('pl-PL') } }
                }
            }
        });
    }

    async function loadAcceptanceUsageAnalysis(plnToUsd = 0.25) {
        const body = document.getElementById('acceptanceCountryUsageBody');
        try {
            const data = await apiFetch(API + '/api/invoices/items?type=logistics');
            const items = data.items || [];
            const byMonth = {};
            const byOffice = {};
            const byCountry = {};
            items.forEach(item => {
                const amount = invoiceItemAmount(item);
                const status = item.invoice_status || item.acceptance_status || 'pending';
                const bucket = status === 'verified' ? 'verified' : 'pending';
                const month = String(item.invoice_date || item.ref_date || '').slice(0, 7) || '未归档';
                const country = String(item.consignee_country_code || '未匹配').toUpperCase();
                const office = countryOfficeOf(country);
                const officeLabel = country === '未匹配' ? '未匹配' : (office?.label || '其他代表处');
                byMonth[month] ||= { verified: 0, pending: 0 };
                byMonth[month][bucket] += amount;
                byOffice[officeLabel] ||= { verified: 0, pending: 0, total: 0 };
                byOffice[officeLabel][bucket] += amount;
                byOffice[officeLabel].total += amount;
                byCountry[country] ||= { country, office: officeLabel, verified: 0, pending: 0, total: 0, count: 0 };
                byCountry[country][bucket] += amount;
                byCountry[country].total += amount;
                byCountry[country].count += 1;
            });

            const months = Object.keys(byMonth).sort();
            renderAcceptanceChart('acceptanceMonthly', 'chart-acceptance-monthly', months, [
                { label: '已验收', data: months.map(m => byMonth[m].verified), backgroundColor: 'rgba(22,163,74,0.72)' },
                { label: '待验收', data: months.map(m => byMonth[m].pending), backgroundColor: 'rgba(217,119,6,0.72)' },
            ], true);

            const offices = Object.entries(byOffice).sort((a, b) => b[1].total - a[1].total).map(([label]) => label);
            renderAcceptanceChart('acceptanceOffice', 'chart-acceptance-office', offices, [
                { label: '费用合计', data: offices.map(o => byOffice[o].total), backgroundColor: 'rgba(37,99,235,0.72)' },
            ]);

            const countryRows = Object.values(byCountry).sort((a, b) => b.total - a.total);
            if (body) {
                body.innerHTML = countryRows.length ? countryRows.map(r => `<tr>
                    <td>${escapeHtml(r.country)}</td>
                    <td>${escapeHtml(r.office)}</td>
                    <td style="text-align:right">${formatCount(r.count)}</td>
                    <td style="text-align:right">${formatPln(r.verified)}</td>
                    <td style="text-align:right">${formatPln(r.pending)}</td>
                    <td style="text-align:right;font-weight:700">${formatPln(r.total)}</td>
                    <td style="text-align:right">${formatUsd(Number(r.total || 0) * plnToUsd)}</td>
                </tr>`).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">暂无费用明细</td></tr>';
            }
        } catch(e) {
            setTableError(body, 7, `费用分析加载失败：${e.message}`);
        }
    }

    async function viewBudgetInvoiceDetail(id) {
        return viewInvoiceDetail(id);
    }

    function closeBudgetInvoiceDetail() {
        document.getElementById('budget-invoice-detail-modal').style.display = 'none';
    }

    async function verifyBudgetInvoice(id) {
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'verified' }) });
            if (data.success) { toast('发票已验收'); loadBudgetPage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    async function rejectBudgetInvoice(id) {
        if (!confirm('确认拒绝此发票？')) return;
        try {
            const data = await apiFetch(API + '/api/invoices/' + id + '/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'rejected' }) });
            if (data.success) { toast('发票已拒绝'); loadBudgetPage(); }
            else { toast(data.error || '操作失败', 'error'); }
        } catch(e) { toast('操作失败: ' + e.message, 'error'); }
    }

    let movementPage = 1;
    let movementSearchTimer = null;
    let movementSortBy = 'movement_date';
    let movementSortDir = 'desc';
    let movementHeaderFilters = { category: '', category2: '', instruction: '' };
    function debouncedLoadMovements() {
        clearTimeout(movementSearchTimer);
        movementSearchTimer = setTimeout(loadMovementList, 250);
    }
    function setSelectOptionsKeepValue(selectId, values, placeholder = '全部') {
        const select = document.getElementById(selectId);
        if (!select) return;
        const current = select.value || '';
        const cleanValues = [...new Set((values || []).map(v => String(v || '').trim()).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'en'));
        if (current && !cleanValues.includes(current)) cleanValues.unshift(current);
        select.innerHTML = `<option value="">${escapeHtml(placeholder)}</option>` + cleanValues.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
        select.value = cleanValues.includes(current) ? current : '';
        listSetHasValue(select);
    }
    function updateMovementHeaderOptions(rows) {
        setSelectOptionsKeepValue('movementHeaderCategoryFilter', (rows || []).map(r => r.category), '全部');
        setSelectOptionsKeepValue('movementHeaderCat2Filter', (rows || []).map(r => r.category_2), '全部');
        const instructions = [];
        (rows || []).forEach(r => String(r.instructions || '').split(',').forEach(v => instructions.push(v.trim())));
        setSelectOptionsKeepValue('movementHeaderInstructionFilter', instructions, '全部');
    }
    function syncMovementHeaderControls() {
        const typeHeader = document.getElementById('movementHeaderTypeFilter');
        const warehouseHeader = document.getElementById('movementHeaderWarehouseFilter');
        const categoryHeader = document.getElementById('movementHeaderCategoryFilter');
        const cat2Header = document.getElementById('movementHeaderCat2Filter');
        const instructionHeader = document.getElementById('movementHeaderInstructionFilter');
        if (typeHeader) typeHeader.value = document.getElementById('movementTypeFilter')?.value || '';
        if (warehouseHeader) warehouseHeader.value = document.getElementById('movementWarehouse')?.value || '';
        if (categoryHeader) categoryHeader.value = movementHeaderFilters.category || '';
        if (cat2Header) cat2Header.value = movementHeaderFilters.category2 || '';
        if (instructionHeader) instructionHeader.value = movementHeaderFilters.instruction || '';
        [typeHeader, warehouseHeader, categoryHeader, cat2Header, instructionHeader].forEach(el => listSetHasValue(el));
    }
    function updateMovementHeaderFilter(field, value) {
        if (field === 'type') {
            const control = document.getElementById('movementTypeFilter');
            if (control) control.value = value || '';
        } else if (field === 'warehouse') {
            const control = document.getElementById('movementWarehouse');
            if (control) control.value = value || '';
        } else {
            movementHeaderFilters[field] = value || '';
        }
        movementPage = 1;
        loadMovementList();
    }
    function clearMovementFilters() {
        document.getElementById('movementSearch').value = '';
        document.getElementById('movementWarehouse').value = '';
        document.getElementById('movementTypeFilter').value = '';
        movementHeaderFilters = { category: '', category2: '', instruction: '' };
        const startInput = document.getElementById('movementStartDate');
        const endInput = document.getElementById('movementEndDate');
        if (startInput) startInput.value = '';
        if (endInput) endInput.value = '';
        movementSortBy = 'movement_date';
        movementSortDir = 'desc';
        movementPage = 1;
        loadMovementList();
    }
    function setMovementSort(key) {
        if (movementSortBy === key) movementSortDir = movementSortDir === 'asc' ? 'desc' : 'asc';
        else {
            movementSortBy = key;
            movementSortDir = 'asc';
        }
        movementPage = 1;
        loadMovementList();
    }
    function updateMovementSortIndicators() {
        listUpdateSortIndicators('#movementTable th.sortable', movementSortBy, movementSortDir);
    }
    function toggleMovementDetailCols() { document.getElementById('movementTable')?.classList.toggle('compact'); }
    async function loadMovementList() {
        const tbody = document.getElementById('movementListBody');
        if (!tbody) return;
        const params = new URLSearchParams({
            page: movementPage,
            per_page: document.getElementById('movementPerPage')?.value || '20',
            q: document.getElementById('movementSearch')?.value || '',
            warehouse: document.getElementById('movementWarehouse')?.value || '',
            movement_type: document.getElementById('movementTypeFilter')?.value || '',
            start_date: document.getElementById('movementStartDate')?.value || '',
            end_date: document.getElementById('movementEndDate')?.value || '',
            category: movementHeaderFilters.category || '',
            category2: movementHeaderFilters.category2 || '',
            instruction: movementHeaderFilters.instruction || '',
            sort_by: movementSortBy,
            sort_dir: movementSortDir
        });
        updateMovementSortIndicators();
        syncMovementHeaderControls();
        setTableLoading(tbody, 13);
        try {
            const data = await apiFetch(API + '/api/inventory/movements?' + params.toString());
            const rows = data.items || [];
            updateMovementHeaderOptions(rows);
            syncMovementHeaderControls();
            if (!rows.length) {
                setTableEmpty(tbody, 13, '暂无出入流水，请先在数据管理中心导入 Specyfikacja', 32);
            } else {
                tbody.innerHTML = rows.map(r => {
                    const badge = String(r.movement_type || '').toLowerCase() === 'inbound' ? 'badge-delivered' : String(r.movement_type || '').toLowerCase() === 'outbound' ? 'badge-danger' : 'badge-pending';
                    return `<tr>
                        <td>${escapeHtml(r.movement_date || '-')}</td>
                        <td><span class="badge ${badge}">${escapeHtml(r.movement_label || r.movement_type || '-')}</span></td>
                        <td class="movement-product-cell"><button type="button" class="link-btn" data-product-detail="${escapeHtml(r.product_number || '')}" onclick="openProductDetail(this.dataset.productDetail)" style="padding:0;font-weight:700">${escapeHtml(r.product_number || '-')}</button></td>
                        <td class="movement-desc-cell"><div title="${escapeHtml(r.product_description || '-')}">${escapeHtml(r.product_description || '-')}</div></td>
                        <td class="col-detail movement-dim-cell">${escapeHtml(r.category || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.category_2 || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.instructions || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.warehouses || '-')}</td>
                        <td>${escapeHtml(r.operation_id || '-')}</td>
                        <td class="col-detail">${escapeHtml(r.operation_target || '-')}</td>
                        <td style="text-align:right;font-weight:700">${Number(r.quantity || 0).toLocaleString()}</td>
                        <td class="col-detail" style="text-align:right">${Number(r.current_inventory || 0).toLocaleString()}</td>
                        <td class="col-detail" style="text-align:right">${formatUsd(r.value_usd)}</td>
                    </tr>`;
                }).join('');
            }
            const pages = Math.max(1, data.pages || 1);
            const page = data.page || movementPage;
            listRenderPagination('movementPagination', {
                total: data.total || 0,
                page,
                pages,
                lang: currentLang,
                prevAction: `movementPage=Math.max(1,${page}-1);loadMovementList()`,
                nextAction: `movementPage=Math.min(${pages},${page}+1);loadMovementList()`
            });
        } catch(e) {
            setTableError(tbody, 13, `加载失败：${e.message}`);
        }
    }
