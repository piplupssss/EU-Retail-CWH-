    // ===================================================================
    //  WMS ( 库存概览 + 库存清单 + 操作 + 上传 + 发货 )
    // ===================================================================

    let currentInvDashTab = 'breakdown';
    let pendingStockListFilters = null;
    let stockQualityFilter = '';
    const overdueState = {
        dos: { sortBy: 'ttl_amount', sortDir: 'desc', page: 1, perPage: 25, showDetails: false, filter: { keyword: '', category: '', category2: '', instruction: '' } },
        idle: { sortBy: 'ttl_amount', sortDir: 'desc', page: 1, perPage: 25, showDetails: false, filter: { keyword: '', category: '', category2: '', instruction: '' } }
    };

    function openStockListFromInventory(filters = {}) {
        const wh = document.getElementById('dashWarehouse')?.value || '';
        currentWarehouse = wh;
        pendingStockListFilters = {
            q: filters.q || '',
            category: filters.category || '',
            category2: filters.category2 || '',
            instruction: filters.instruction || '',
            quality: filters.quality || ''
        };
        stockPage = 1;
        switchPage('stocklist');
    }

    function applyPendingStockListFilters() {
        if (!pendingStockListFilters) return;
        const f = pendingStockListFilters;
        const setVal = (id, value) => {
            const el = document.getElementById(id);
            if (!el) return;
            el.value = value || '';
            el.classList.toggle('has-value', Boolean(value));
        };
        setVal('stockSearch', f.q);
        setVal('filterCategory', f.category);
        setVal('filterCat2', f.category2);
        setVal('filterInstruction', f.instruction);
        stockQualityFilter = f.quality || '';
        pendingStockListFilters = null;
    }

    function switchInvDashTab(el) {
        document.querySelectorAll('#invDashTabs .tab').forEach(t => t.classList.remove('active')); el.classList.add('active');
        currentInvDashTab = el.dataset.dtab; loadCurrentInvDashTab();
    }

    function loadCurrentInvDashTab() {
        const wh = document.getElementById('dashWarehouse').value;
        document.getElementById('inventoryBreakdownToggles').style.display = currentInvDashTab === 'breakdown' ? 'flex' : 'none';
        if (currentInvDashTab === 'breakdown') loadInventoryBreakdowns(wh);
        else if (currentInvDashTab === 'catTtl') loadCatTtl(wh);
        else if (currentInvDashTab === 'cat2Ttl') loadCat2Ttl(wh);
        else if (currentInvDashTab === 'instrTtl') loadInstrTtl(wh);
        else if (currentInvDashTab === 'dos180') loadDos180(wh);
        else if (currentInvDashTab === 'idle180') loadIdle180(wh);
    }

    async function loadInvDashboard() {
        const wh = document.getElementById('dashWarehouse').value;
        const [d, health] = await Promise.all([
            apiGet('/api/inventory/stats?warehouse=' + encodeURIComponent(wh)),
            apiGet('/api/inventory/stats/health?warehouse=' + encodeURIComponent(wh)).catch(() => ({}))
        ]);
        const scopeLabel = wh ? wh.replace(' warehouse', ' 仓库') : '全部仓库';
        const scopeChip = document.getElementById('inventoryScopeChip');
        const refreshChip = document.getElementById('inventoryRefreshChip');
        if (scopeChip) scopeChip.textContent = scopeLabel;
        if (refreshChip) refreshChip.textContent = d.last_updated_at ? `更新至 ${formatStockUpdatedAt(d.last_updated_at)}` : '随库存数据刷新';
        document.getElementById('invStatsGrid').innerHTML = `
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">SKU 总数</div><div class="value">${Number(d.total_skus || 0).toLocaleString()}</div><div class="sub">${scopeLabel} · 点击进入库存清单</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">库存总件数</div><div class="value success">${Number(d.total_pcs || 0).toLocaleString()}</div><div class="sub">PCS · 用于周度库存规模汇报</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card clickable" onclick="openStockListFromInventory()"><div class="label">库存总货值</div><div class="value accent">$${Number(d.total_value || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</div><div class="sub">USD · 用于库存货值和超期报告</div></div>
            <div class="stat-card inventory-kpi-card if-kpi-card"><div class="label">库存更新时间</div><div class="value">${formatStockUpdatedAt(d.last_updated_at) || '-'}</div><div class="sub">${scopeLabel} · 最近库存记录更新时间</div></div>`;
        const riskEl = document.getElementById('inventoryRiskSnapshot');
        if (riskEl) riskEl.innerHTML = buildInventoryRiskSnapshot(health || {});
        loadCurrentInvDashTab();
    }

    function drawInvBarChart(canvasId, labels, vals, metric) {
        const key = canvasId;
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(document.getElementById(canvasId), {
            type: 'bar',
            data: { labels, datasets: [{ data: vals, backgroundColor: TTL_COLORS, borderRadius: 4 }] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: c => metric === 'value' ? fmt$(c.raw) : Number(c.raw || 0).toLocaleString() + ' PCS' } }
                },
                scales: {
                    x: { ticks: { color: '#64748b', callback: v => metric === 'value' ? '$' + (v / 1000).toFixed(0) + 'k' : Number(v).toLocaleString() }, grid: { color: '#1e293b' } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    async function renderInventoryBreakdown({ apiUrl, field, title, valueCanvas, pcsCanvas }) {
        const wh = document.getElementById('dashWarehouse').value;
        const resp = await apiGet(apiUrl + '?warehouse=' + encodeURIComponent(wh));
        const data = resp.data || [];
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const rows = data.map(r => {
            const label = r[field] || 'N/A';
            return `<tr>
                <td style="font-weight:500">${escapeHtml(label)}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.total_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">${fmtPct(r.total_pcs || 0, totalPcs)}</td>
                <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                <td style="text-align:right">${fmtPct(r.ttl_amount || 0, totalValue)}</td>
            </tr>`;
        }).join('');
        document.getElementById('invDashContent').innerHTML = `
            <div style="display:flex;align-items:center;gap:18px;margin-bottom:16px">
                <span style="font-size:12px;color:var(--text-secondary)">总货值</span><span style="font-size:20px;font-weight:700;color:var(--accent)">${fmt$(totalValue)}</span>
                <span style="font-size:12px;color:var(--text-secondary)">总件数</span><span style="font-size:20px;font-weight:700;color:var(--success)">${totalPcs.toLocaleString()}</span>
            </div>
            <div class="charts-grid">
                <div class="chart-card"><h3>${title}与货值关系图</h3><div class="chart-container"><canvas id="${valueCanvas}"></canvas></div></div>
                <div class="chart-card"><h3>${title}与总件数关系图</h3><div class="chart-container"><canvas id="${pcsCanvas}"></canvas></div></div>
                <div class="chart-card full-width"><h3>${title} 明细</h3><div style="max-height:500px;overflow-y:auto"><table><thead><tr><th>${title}</th><th style="text-align:right">SKU数</th><th style="text-align:right">总件数</th><th style="text-align:right">件数占比</th><th style="text-align:right">总货值 (USD)</th><th style="text-align:right">货值占比</th></tr></thead><tbody>${rows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:32px">暂无数据</td></tr>`}</tbody></table></div></div>
            </div>`;
        drawInvBarChart(valueCanvas, data.map(r => r[field] || 'N/A'), data.map(r => Number(r.ttl_amount || 0)), 'value');
        drawInvBarChart(pcsCanvas, data.map(r => r[field] || 'N/A'), data.map(r => Number(r.total_pcs || 0)), 'pcs');
    }

    function inventoryBreakdownSection(def, data) {
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const rows = data.map(r => {
            const label = r[def.field] || 'N/A';
            return `<tr>
                <td style="font-weight:500">${escapeHtml(label)}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.total_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">${fmtPct(r.total_pcs || 0, totalPcs)}</td>
                <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                <td style="text-align:right">${fmtPct(r.ttl_amount || 0, totalValue)}</td>
            </tr>`;
        }).join('');
        return `<div style="margin-bottom:20px">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px">
                <h3>${def.title} 货值</h3>
                <div style="display:flex;gap:16px;font-size:12px;color:var(--text-secondary)">
                    <span>总件数 <b style="color:var(--success)">${totalPcs.toLocaleString()}</b></span>
                    <span>总货值 <b style="color:var(--accent)">${fmt$(totalValue)}</b></span>
                </div>
            </div>
            <div class="charts-grid">
                <div class="chart-card"><h3>${def.title}与货值关系图</h3><div class="chart-container"><canvas id="${def.valueCanvas}"></canvas></div></div>
                <div class="chart-card"><h3>${def.title}与总件数关系图</h3><div class="chart-container"><canvas id="${def.pcsCanvas}"></canvas></div></div>
                <div class="chart-card full-width"><h3>${def.title} 明细</h3><div style="max-height:360px;overflow-y:auto"><table><thead><tr><th>${def.title}</th><th style="text-align:right">SKU数</th><th style="text-align:right">总件数</th><th style="text-align:right">件数占比</th><th style="text-align:right">总货值 (USD)</th><th style="text-align:right">货值占比</th></tr></thead><tbody>${rows || `<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:32px">暂无数据</td></tr>`}</tbody></table></div></div>
            </div>
        </div>`;
    }

    function saveInventoryBreakdownSelection() {
        const primary = document.getElementById('inventoryPrimaryDim')?.value || 'category';
        const secondary = document.getElementById('inventorySecondaryDim')?.value || 'category_2';
        localStorage.setItem(INVENTORY_BREAKDOWN_KEY, JSON.stringify({ primary, secondary }));
    }

    function applyInventoryBreakdownSelection() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem(INVENTORY_BREAKDOWN_KEY) || 'null'); } catch {}
        const primaryEl = document.getElementById('inventoryPrimaryDim');
        const secondaryEl = document.getElementById('inventorySecondaryDim');
        if (!primaryEl || !secondaryEl) return;
        if (saved && !Array.isArray(saved)) {
            if (INVENTORY_DIMENSIONS[saved.primary]) primaryEl.value = saved.primary;
            if (INVENTORY_DIMENSIONS[saved.secondary]) secondaryEl.value = saved.secondary;
        }
        if (primaryEl.value === secondaryEl.value) {
            secondaryEl.value = primaryEl.value === 'category' ? 'category_2' : 'category';
        }
    }

    function drawInventoryShareCompare(rows, primary, totalValue, totalPcs) {
        const grouped = groupInventoryRows(rows, primary).slice(0, 14);
        const labels = grouped.map(r => r.label);
        const valuePct = grouped.map(r => totalValue ? Number(((r.ttl_amount || 0) / totalValue * 100).toFixed(2)) : 0);
        const pcsPct = grouped.map(r => totalPcs ? Number(((r.total_pcs || 0) / totalPcs * 100).toFixed(2)) : 0);
        const key = 'chartInvValuePcsShare';
        if (charts[key]) charts[key].destroy();
        charts[key] = new Chart(document.getElementById(key), {
            type: 'bar',
            data: {
                labels,
                datasets: [
                    { label: '货值占比', data: valuePct, backgroundColor: 'rgba(59,130,246,0.78)', borderColor: '#3b82f6', borderWidth: 1 },
                    { label: '件数占比', data: pcsPct, backgroundColor: 'rgba(34,197,94,0.62)', borderColor: '#22c55e', borderWidth: 1 }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: {
                        callbacks: {
                            afterBody: ctx => {
                                const row = grouped[ctx[0].dataIndex] || {};
                                const pos = getInventoryGroupPosition(row, totalValue, totalPcs);
                                return `${pos.label}: ${pos.advice}`;
                            },
                            label: c => `${c.dataset.label}: ${Number(c.raw || 0).toFixed(1)}%`
                        }
                    }
                },
                scales: {
                    x: { title: { display: true, text: '占总库存比例 %', color: '#94a3b8' }, ticks: { color: '#64748b', callback: v => v + '%' }, grid: { color: 'rgba(148,163,184,0.14)' } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    async function loadInventoryBreakdowns(wh) {
        applyInventoryBreakdownSelection();
        const primary = document.getElementById('inventoryPrimaryDim')?.value || 'category';
        const secondary = document.getElementById('inventorySecondaryDim')?.value || 'category_2';
        const pDef = INVENTORY_DIMENSIONS[primary];
        const sDef = INVENTORY_DIMENSIONS[secondary];
        document.getElementById('invDashContent').innerHTML = '<div style="color:var(--text-muted);padding:24px">加载中...</div>';
        const resp = await apiGet('/api/inventory/stats/value-pcs-matrix?warehouse=' + encodeURIComponent(wh));
        const data = resp.data || [];
        const totalValue = data.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = data.reduce((s, r) => s + Number(r.total_pcs || 0), 0);
        const primaryRows = groupInventoryRows(data, primary);
        const topValue = primaryRows[0] || {};
        const topPcs = [...primaryRows].sort((a, b) => b.total_pcs - a.total_pcs)[0] || {};
        const topConcentration = primaryRows.slice(0, 3).reduce((s, r) => s + r.ttl_amount, 0);
        const highValueLowPcs = primaryRows.filter(r => r.total_pcs > 0).sort((a, b) => b.avg_unit_value - a.avg_unit_value)[0] || {};
        document.getElementById('invDashContent').innerHTML = `
            <div class="inventory-insight-grid">
                <div class="inventory-insight"><div class="label">最高货值 ${pDef.label}</div><div class="value">${escapeHtml(topValue.label || '-')}</div><div class="sub">${fmt$(topValue.ttl_amount)} · ${fmtPct(topValue.ttl_amount || 0, totalValue)}</div></div>
                <div class="inventory-insight"><div class="label">最高件数 ${pDef.label}</div><div class="value">${escapeHtml(topPcs.label || '-')}</div><div class="sub">${Number(topPcs.total_pcs || 0).toLocaleString()} PCS · ${fmtPct(topPcs.total_pcs || 0, totalPcs)}</div></div>
                <div class="inventory-insight"><div class="label">Top 3 货值集中度</div><div class="value">${fmtPct(topConcentration, totalValue)}</div><div class="sub">前三个${pDef.short}合计 ${fmt$(topConcentration)}</div></div>
                <div class="inventory-insight"><div class="label">高单件货值</div><div class="value">${escapeHtml(highValueLowPcs.label || '-')}</div><div class="sub">平均 ${fmt$(highValueLowPcs.avg_unit_value)} / PCS</div></div>
            </div>
            ${buildInventoryDecisionCards(primaryRows, totalValue, totalPcs, pDef)}
            <div class="charts-grid">
                <div class="chart-card full-width">
                    <h3>${pDef.label} × ${sDef.label} 货值关系热力图</h3>
                    ${buildInventoryHeatmap(data, primary, secondary, totalValue)}
                </div>
                <div class="chart-card full-width">
                    <h3>${pDef.label} 货值占比 / 件数占比对比</h3>
                    <div class="inventory-ratio-note">
                        <span>蓝色高：钱主要压在这里</span>
                        <span>绿色高：数量主要堆在这里</span>
                        <span>两条都高：优先盘点和维护</span>
                    </div>
                    <div class="chart-container tall"><canvas id="chartInvValuePcsShare"></canvas></div>
                </div>
            </div>`;
        bindStockImagePreviewEvents();
        drawInventoryShareCompare(data, primary, totalValue, totalPcs);
    }

    async function loadCatTtl() {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/category-ttl', field: 'category', title: 'Category', valueCanvas: 'chartCatTtlValue', pcsCanvas: 'chartCatTtlPcs' });
    }

    function uniqueLines(text) {
        return [...new Set(String(text || '').split(/\n|,/).map(s => s.trim().toUpperCase()).filter(Boolean))];
    }
    function getManagedOptions() {
        const fallback = { category: DEFAULT_CATEGORY_OPTIONS, category2: DEFAULT_CATEGORY2_OPTIONS, instruction: DEFAULT_INSTRUCTION_OPTIONS };
        try {
            const saved = JSON.parse(localStorage.getItem(MANAGED_OPTIONS_KEY) || '{}');
            return {
                category: Array.isArray(saved.category) && saved.category.length ? saved.category : fallback.category,
                category2: Array.isArray(saved.category2) && saved.category2.length ? saved.category2 : fallback.category2,
                instruction: Array.isArray(saved.instruction) && saved.instruction.length ? saved.instruction : fallback.instruction
            };
        } catch {
            return fallback;
        }
    }
    function normalizeInventoryOption(value) {
        return String(value || '').trim().toUpperCase();
    }
    function uniqueSortedInventoryOptions(rows, field) {
        return [...new Set((rows || []).map(r => normalizeInventoryOption(r[field])).filter(Boolean))].sort();
    }
    function renderSettingsClassificationSummary(opts) {
        const el = document.getElementById('settingsClassificationSummary');
        if (!el) return;
        const preview = values => {
            const list = values || [];
            if (!list.length) return '暂无';
            const visible = list.slice(0, 8).join(' / ');
            return list.length > 8 ? `${visible} / +${list.length - 8}` : visible;
        };
        el.innerHTML = `
            <div class="settings-scan-card"><b>物料品类 Category · ${(opts.category || []).length}</b><span>${escapeHtml(preview(opts.category))}</span></div>
            <div class="settings-scan-card"><b>适用产品 Category 2 · ${(opts.category2 || []).length}</b><span>${escapeHtml(preview(opts.category2))}</span></div>
            <div class="settings-scan-card"><b>归属国家 Instruction · ${(opts.instruction || []).length}</b><span>${escapeHtml(preview(opts.instruction))}</span></div>
        `;
    }
    async function scanInventoryClassificationOptions(warehouse = '') {
        const params = new URLSearchParams({ warehouse: warehouse || '', per_page: '9999' });
        const data = await apiGet('/api/inventory?' + params.toString()).catch(() => ({ data: [] }));
        const rows = Array.isArray(data.data) ? data.data : [];
        const activeRows = rows.filter(r => Number(r.inventory || 0) > 0);
        const sourceRows = activeRows.length ? activeRows : rows;
        return {
            category: uniqueSortedInventoryOptions(sourceRows, 'category'),
            category2: uniqueSortedInventoryOptions(sourceRows, 'category_2'),
            instruction: uniqueSortedInventoryOptions(sourceRows, 'instruction')
        };
    }
    function initSettings() {
        const cat = document.getElementById('settingCategoryOptions');
        if (!cat) return;
        cat.value = '扫描中...';
        document.getElementById('settingCategory2Options').value = '扫描中...';
        document.getElementById('settingInstructionOptions').value = '扫描中...';
        scanInventoryClassificationOptions('').then(opts => {
            cat.value = opts.category.join('\n') || '暂无库存分类';
            document.getElementById('settingCategory2Options').value = opts.category2.join('\n') || '暂无适用产品';
            document.getElementById('settingInstructionOptions').value = opts.instruction.join('\n') || '暂无归属国家';
            renderSettingsClassificationSummary(opts);
        }).catch(e => {
            cat.value = '扫描失败：' + e.message;
            document.getElementById('settingCategory2Options').value = '扫描失败';
            document.getElementById('settingInstructionOptions').value = '扫描失败';
            renderSettingsClassificationSummary({ category: ['扫描失败'], category2: [], instruction: [] });
        });
        const langEl = document.getElementById('settingLang');
        const warehouseEl = document.getElementById('settingWarehouse');
        if (langEl) langEl.value = currentLang;
        if (warehouseEl) warehouseEl.value = currentWarehouse;
        applyTheme();
        loadThresholdSettings();
    }
    async function loadVersionChangelog() {
        const el = document.getElementById('versionTimeline');
        if (!el) return;
        try {
            const res = await fetch('/static/version_changelog.json', { cache: 'no-store' });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const rows = await res.json();
            el.innerHTML = rows.map((row, idx) => {
                const isLatest = idx === 0;
                const notes = Array.isArray(row.items) && row.items.length
                    ? row.items
                    : (Array.isArray(row.changes) ? row.changes : []);
                return `
                <div class="version-entry ${isLatest ? 'current' : ''}">
                    <div class="version-entry-head">
                        <div>
                            <div class="version-entry-title">${escapeHtml(row.version || '-')} · ${escapeHtml(row.time || '-')}</div>
                            <div class="version-entry-meta">${escapeHtml(row.type || '')}</div>
                        </div>
                        <span class="version-badge ${isLatest ? 'current' : ''}">${isLatest ? '最新版本' : escapeHtml(row.confidence || 'unknown')}</span>
                    </div>
                    <ul>${notes.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>
                </div>
            `}).join('');
        } catch (e) {
            el.innerHTML = `<div style="color:var(--danger);font-size:13px">版本纪要加载失败：${escapeHtml(e.message)}</div>`;
        }
    }
    let pendingSoftwareUpdate = null;
    function formatVersionDisplay(version, time) {
        const ver = String(version || '').trim();
        const releaseTime = String(time || '').trim();
        if (!ver) return '-';
        if (ver === APP_VERSION && !releaseTime) return APP_VERSION_FULL;
        return releaseTime ? `${ver} · ${releaseTime}` : ver;
    }
    function renderUpdateNotes(notes) {
        const rows = Array.isArray(notes) ? notes : [];
        return rows.length ? `<ul style="margin:8px 0 0 18px;padding:0">${rows.map(x => `<li>${escapeHtml(x)}</li>`).join('')}</ul>` : '';
    }
    async function checkSoftwareUpdate() {
        const status = document.getElementById('updateStatus');
        const currentEl = document.getElementById('updateCurrentVersion');
        const latestEl = document.getElementById('updateLatestVersion');
        const latestCard = document.getElementById('updateLatestCard');
        const btn = document.getElementById('installUpdateBtn');
        if (currentEl) currentEl.textContent = APP_VERSION_FULL;
        if (latestCard) latestCard.classList.remove('needs-update');
        if (btn) btn.style.display = 'none';
        pendingSoftwareUpdate = null;
        if (status) status.innerHTML = '正在检查更新...';
        const data = await apiGet('/api/update/check').catch(e => ({ success: false, error: e.message }));
        if (!data.success) {
            if (latestEl) latestEl.textContent = '检查失败';
            if (status) status.innerHTML = `<span style="color:var(--danger)">检查更新失败：${escapeHtml(data.error || '未知错误')}</span><br><span style="color:var(--text-muted)">请确认电脑可以访问 Qiteng的GitHub 更新源。</span>`;
            return;
        }
        if (latestEl) latestEl.textContent = data.current_ahead_of_patch_channel
            ? `补丁通道 ${formatVersionDisplay(data.latest_version, data.release_time)}`
            : formatVersionDisplay(data.latest_version, data.release_time);
        pendingSoftwareUpdate = data;
        if (!data.update_available) {
            if (latestCard) latestCard.classList.remove('needs-update');
            if (data.current_ahead_of_patch_channel) {
                if (status) status.innerHTML = `<b>当前版本无需更新。</b><br>当前版本：${escapeHtml(formatVersionDisplay(data.current_version || APP_VERSION))}<br>补丁通道：${escapeHtml(formatVersionDisplay(data.latest_version || '', data.release_time))}<br><span style="color:var(--text-muted)">当前系统版本高于补丁通道版本，无需降级安装旧补丁。</span>`;
            } else if (status) {
                status.innerHTML = `<b>当前已是最新版本。</b><br>当前版本：${escapeHtml(formatVersionDisplay(data.current_version || APP_VERSION))} · 最新版本：${escapeHtml(formatVersionDisplay(data.latest_version || APP_VERSION, data.release_time))}`;
            }
            return;
        }
        if (latestCard) latestCard.classList.add('needs-update');
        if (btn) btn.style.display = '';
        if (status) status.innerHTML = `
            <b style="color:var(--accent)">发现新版本 ${escapeHtml(data.latest_version || '')}</b>
            <div>发布时间：${escapeHtml(data.release_time || '-')}</div>
            <div>安全说明：只下载更新清单和补丁包，不上传任何业务数据。</div>
            <div>SHA256：<span style="font-family:monospace">${escapeHtml(data.sha256 || '')}</span></div>
            ${renderUpdateNotes(data.notes)}
        `;
    }
    async function installSoftwareUpdate() {
        const status = document.getElementById('updateStatus');
        const data = pendingSoftwareUpdate;
        if (!data || !data.update_available) return toast('请先检查版本更新', 'error');
        if (!confirm(`确认下载并安装 ${data.latest_version}？\n\n系统只会从 Qiteng的GitHub 下载更新包，不上传任何业务数据。升级器启动后会关闭当前服务并覆盖程序代码。`)) return;
        const btn = document.getElementById('installUpdateBtn');
        if (btn) btn.disabled = true;
        if (status) status.innerHTML = `正在下载并校验 ${escapeHtml(data.latest_version)} 更新包，请稍候...`;
        const result = await apiPost('/api/update/install', {}).catch(e => ({ success: false, error: e.message }));
        if (btn) btn.disabled = false;
        if (!result.success) {
            if (status) status.innerHTML = `<span style="color:var(--danger)">更新失败：${escapeHtml(result.error || '未知错误')}</span>`;
            return toast(result.error || '更新失败', 'error');
        }
        if (status) status.innerHTML = `<b style="color:var(--success)">${escapeHtml(result.message || '更新器已启动')}</b><br>SHA256：<span style="font-family:monospace">${escapeHtml(result.sha256 || '')}</span>`;
        toast('更新包已校验，升级器已启动');
    }
    function saveManagedOptions() {
        const opts = {
            category: uniqueLines(document.getElementById('settingCategoryOptions').value),
            category2: uniqueLines(document.getElementById('settingCategory2Options').value),
            instruction: uniqueLines(document.getElementById('settingInstructionOptions').value)
        };
        localStorage.setItem(MANAGED_OPTIONS_KEY, JSON.stringify(opts));
        loadStockFilters();
        toast('分类选项已保存');
    }
    function resetManagedOptions() {
        localStorage.removeItem(MANAGED_OPTIONS_KEY);
        initSettings();
        loadStockFilters();
        toast('已恢复默认分类');
    }

    let thresholdSortBy = 'category';
    let thresholdSortDir = 'asc';
    function setThresholdSort(key) {
        if (thresholdSortBy === key) thresholdSortDir = thresholdSortDir === 'asc' ? 'desc' : 'asc';
        else {
            thresholdSortBy = key;
            thresholdSortDir = ['sku_count', 'inventory_pcs', 'ttl_amount', 'avg_unit_price'].includes(key) ? 'desc' : 'asc';
        }
        loadThresholdSettings();
    }
    function updateThresholdSortIndicators() {
        document.querySelectorAll('[data-threshold-sort]').forEach(th => {
            th.classList.toggle('sort-asc', th.dataset.thresholdSort === thresholdSortBy && thresholdSortDir === 'asc');
            th.classList.toggle('sort-desc', th.dataset.thresholdSort === thresholdSortBy && thresholdSortDir === 'desc');
        });
    }

    async function loadThresholdSettings() {
        const body = document.getElementById('thresholdSettingsBody');
        if (!body) return;
        body.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">加载中...</td></tr>';
        const data = await apiGet('/api/inventory/settings/thresholds').catch(e => ({ error: e.message }));
        if (data.error) {
            body.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--danger);padding:24px">${escapeHtml(data.error)}</td></tr>`;
            return;
        }
        let rows = data.data || [];
        const sortKey = thresholdSortBy || 'category';
        const dir = thresholdSortDir === 'desc' ? -1 : 1;
        rows = rows.slice().sort((a, b) => {
            const numeric = ['sku_count', 'inventory_pcs', 'ttl_amount', 'avg_unit_price', 'dos_threshold', 'idle_threshold'];
            const av = numeric.includes(sortKey) ? Number(a[sortKey] || 0) : String(a[sortKey] || '').toUpperCase();
            const bv = numeric.includes(sortKey) ? Number(b[sortKey] || 0) : String(b[sortKey] || '').toUpperCase();
            if (av === bv) return 0;
            return av > bv ? dir : -dir;
        });
        updateThresholdSortIndicators();
        body.innerHTML = rows.length ? rows.map(r => `
            <tr data-threshold-category="${escapeHtml(r.category || '')}">
                <td style="font-weight:500">${escapeHtml(r.category || '')}</td>
                <td style="text-align:right">${r.sku_count || 0}</td>
                <td style="text-align:right">${Number(r.inventory_pcs || 0).toLocaleString()}</td>
                <td style="text-align:right">$${Number(r.ttl_amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td style="text-align:right">$${Number(r.avg_unit_price || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td style="text-align:center"><input class="wms-input threshold-dos" type="number" min="1" step="1" value="${r.dos_threshold || 180}" style="width:92px;text-align:center"></td>
                <td style="text-align:center"><input class="wms-input threshold-idle" type="number" min="1" step="1" value="${r.idle_threshold || 180}" style="width:92px;text-align:center"></td>
            </tr>
        `).join('') : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:24px">暂无 Product Number 主数据，请先导入供应商库存 + 维护表</td></tr>';
    }

    async function saveThresholdSettings() {
        const body = document.getElementById('thresholdSettingsBody');
        if (!body) return;
        const rows = Array.from(body.querySelectorAll('tr[data-threshold-category]')).map(tr => ({
            category: tr.dataset.thresholdCategory,
            dos_threshold: Number(tr.querySelector('.threshold-dos')?.value || 180),
            idle_threshold: Number(tr.querySelector('.threshold-idle')?.value || 180)
        }));
        const data = await apiPost('/api/inventory/settings/thresholds', { rows });
        if (data.success) {
            toast(`已更新 ${data.updated || 0} 个 Product Number`);
            await loadThresholdSettings();
            if (currentInvDashTab === 'dos180' || currentInvDashTab === 'idle180') loadInvDashboard();
        } else {
            toast(data.error || '保存失败', 'error');
        }
    }

    async function loadCat2Ttl(wh) {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/category2-ttl', field: 'category_2', title: 'Category 2', valueCanvas: 'chartCat2TtlValue', pcsCanvas: 'chartCat2TtlPcs' });
    }

    async function loadInstrTtl(wh) {
        await renderInventoryBreakdown({ apiUrl: '/api/inventory/stats/instruction-ttl', field: 'instruction', title: 'Instruction', valueCanvas: 'chartInstrTtlValue', pcsCanvas: 'chartInstrTtlPcs' });
    }

    function overdueSortValue(row, field, kind) {
        if (field === 'warehouse') return String(row.warehouse || '').toUpperCase();
        if (field === 'bom_code') return String(row.bom_code || '').toUpperCase();
        if (field === 'product_number') return String(row.product_number || '').toUpperCase();
        if (field === 'product_description') return String(row.product_description || '').toUpperCase();
        if (field === 'category') return String(row.category || '').toUpperCase();
        if (field === 'category_2') return String(row.category_2 || '').toUpperCase();
        if (field === 'instruction') return String(row.instruction || '').toUpperCase();
        if (field === 'inventory') return Number(row.inventory || 0);
        if (field === 'unit_price') return Number(row.unit_price || 0);
        if (field === 'ttl_amount') return Number(row.ttl_amount || 0);
        if (field === 'days') return Number(row[kind === 'idle' ? 'idle_days' : 'dos'] || 0);
        if (field === 'threshold') return Number(row[kind === 'idle' ? 'idle_threshold' : 'dos_threshold'] || 0);
        if (field === 'overdue_days') return Number(row.overdue_days || 0);
        return '';
    }

    function setOverdueSort(kind, field) {
        const state = overdueState[kind];
        if (state.sortBy === field) state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
        else {
            state.sortBy = field;
            state.sortDir = ['warehouse','bom_code','product_number','product_description','category','category_2','instruction'].includes(field) ? 'asc' : 'desc';
        }
        renderOverdueView(kind);
    }

    function updateOverdueFilter(kind, field, value) {
        overdueState[kind].filter[field] = value || '';
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function resetOverdueFilter(kind) {
        overdueState[kind].filter = { keyword: '', category: '', category2: '', instruction: '' };
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function updateOverduePerPage(kind, value) {
        overdueState[kind].perPage = Number(value || 25);
        overdueState[kind].page = 1;
        renderOverdueView(kind);
    }

    function toggleOverdueDetails(kind, checked) {
        overdueState[kind].showDetails = Boolean(checked);
        renderOverdueView(kind);
    }

    function changeOverduePage(kind, page) {
        const rows = getFilteredOverdueRows(kind);
        const maxPage = Math.max(1, Math.ceil(rows.length / overdueState[kind].perPage));
        overdueState[kind].page = Math.min(Math.max(1, Number(page || 1)), maxPage);
        renderOverdueView(kind);
    }

    function getFilteredOverdueRows(kind) {
        const rows = overdueState[kind].rows || [];
        const filter = overdueState[kind].filter;
        const keyword = (filter.keyword || '').trim().toUpperCase();
        const filtered = rows.filter(r => {
            if (filter.category && (r.category || '') !== filter.category) return false;
            if (filter.category2 && (r.category_2 || '') !== filter.category2) return false;
            if (filter.instruction && (r.instruction || '') !== filter.instruction) return false;
            if (keyword) {
                const hay = [r.warehouse, r.bom_code, r.product_number, r.product_description, r.category, r.category_2, r.instruction].join(' ').toUpperCase();
                if (!hay.includes(keyword)) return false;
            }
            return true;
        });
        const state = overdueState[kind];
        return filtered.sort((a, b) => {
            const av = overdueSortValue(a, state.sortBy, kind);
            const bv = overdueSortValue(b, state.sortBy, kind);
            const result = typeof av === 'number' && typeof bv === 'number'
                ? av - bv
                : String(av).localeCompare(String(bv), 'zh-Hans-CN', { numeric: true, sensitivity: 'base' });
            return state.sortDir === 'asc' ? result : -result;
        });
    }

    function overdueHeader(kind, field, label, style = '') {
        const state = overdueState[kind];
        const arrow = state.sortBy === field ? (state.sortDir === 'asc' ? ' ↑' : ' ↓') : '';
        return `<th class="upload-record-sort ${state.sortBy === field ? 'active' : ''}" style="${style}" data-overdue-sort="${field}" data-overdue-kind="${kind}">${label}${arrow}</th>`;
    }

    function overdueOptions(rows, field) {
        return [...new Set(rows.map(r => r[field]).filter(Boolean))].sort((a, b) => String(a).localeCompare(String(b), 'zh-Hans-CN'));
    }

    function renderOverdueFilters(kind, rows) {
        const state = overdueState[kind];
        const cats = overdueOptions(rows, 'category');
        const cat2s = overdueOptions(rows, 'category_2');
        const instructions = overdueOptions(rows, 'instruction');
        return `<div class="overdue-report-toolbar">
            <input class="wms-input" placeholder="搜索编码 / 描述 / 仓库" value="${escapeHtml(state.filter.keyword || '')}" data-overdue-filter="keyword" data-overdue-kind="${kind}">
            <select class="wms-select" data-overdue-filter="category" data-overdue-kind="${kind}">
                <option value="">全部物料品类</option>${cats.map(v => `<option value="${escapeHtml(v)}" ${state.filter.category === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <select class="wms-select" data-overdue-filter="category2" data-overdue-kind="${kind}">
                <option value="">全部适用产品</option>${cat2s.map(v => `<option value="${escapeHtml(v)}" ${state.filter.category2 === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <select class="wms-select" data-overdue-filter="instruction" data-overdue-kind="${kind}">
                <option value="">全部归属国家</option>${instructions.map(v => `<option value="${escapeHtml(v)}" ${state.filter.instruction === v ? 'selected' : ''}>${escapeHtml(v)}</option>`).join('')}
            </select>
            <label class="overdue-report-toggle"><input type="checkbox" ${state.showDetails ? 'checked' : ''} data-overdue-details="${kind}"> 详细列</label>
            <select class="wms-select" data-overdue-per-page="${kind}" style="min-width:98px">
                ${[10,25,50,100].map(v => `<option value="${v}" ${state.perPage === v ? 'selected' : ''}>${v} 条/页</option>`).join('')}
            </select>
            <button class="btn btn-secondary btn-sm" data-overdue-reset="${kind}">清除筛选</button>
            <button class="btn btn-primary btn-sm" data-overdue-export="${kind}">导出 Excel</button>
        </div>`;
    }

    function drawOverdueCategoryChart(kind, rows) {
        const key = kind === 'idle' ? 'chartIdle180' : 'chartDos180';
        const canvas = document.getElementById(key);
        if (!canvas) return;
        if (charts[key]) charts[key].destroy();
        const catMap = {};
        rows.forEach(r => {
            const k = r.category || 'UNSPECIFIED';
            const cur = catMap[k] || { value: 0, pcs: 0 };
            cur.value += Number(r.ttl_amount || 0);
            cur.pcs += Number(r.inventory || 0);
            catMap[k] = cur;
        });
        const labels = Object.keys(catMap).sort((a, b) => catMap[b].value - catMap[a].value).slice(0, 10);
        charts[key] = new Chart(canvas, {
            type: 'bar',
            data: {
                labels,
                datasets: [
                    { label: kind === 'idle' ? '长期未使用货值' : 'DOS 超期货值', data: labels.map(k => catMap[k].value), xAxisID: 'xValue', backgroundColor: kind === 'idle' ? 'rgba(245,158,11,0.68)' : 'rgba(239,68,68,0.68)', borderColor: kind === 'idle' ? '#f59e0b' : '#ef4444', borderWidth: 1, borderRadius: 4 },
                    { label: '超期数量 PCS', data: labels.map(k => catMap[k].pcs), xAxisID: 'xPcs', backgroundColor: 'rgba(34,197,94,0.50)', borderColor: '#22c55e', borderWidth: 1, borderRadius: 4 }
                ]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: { callbacks: { label: c => c.dataset.xAxisID === 'xPcs' ? `${c.dataset.label}: ${Number(c.raw || 0).toLocaleString()} PCS` : `${c.dataset.label}: ${fmt$(c.raw)}` } }
                },
                scales: {
                    xValue: { position: 'bottom', ticks: { color: '#64748b', callback: v => '$' + (v / 1000).toFixed(0) + 'k' }, grid: { color: 'rgba(148,163,184,0.14)' } },
                    xPcs: { position: 'top', ticks: { color: '#22c55e', callback: v => Number(v).toLocaleString() }, grid: { drawOnChartArea: false } },
                    y: { ticks: { color: '#94a3b8' }, grid: { display: false } }
                }
            }
        });
    }

    function renderOverdueTable(kind, rows) {
        const state = overdueState[kind];
        const totalRows = rows.length;
        const maxPage = Math.max(1, Math.ceil(totalRows / state.perPage));
        if (state.page > maxPage) state.page = maxPage;
        const start = (state.page - 1) * state.perPage;
        const pageRows = rows.slice(start, start + state.perPage);
        const dayField = kind === 'idle' ? 'idle_days' : 'dos';
        const thresholdField = kind === 'idle' ? 'idle_threshold' : 'dos_threshold';
        const empty = kind === 'idle' ? '暂无超过阈值的长期未使用物料' : '暂无超过阈值的库龄超期物料';
        const detailHeaders = state.showDetails ? `
                ${overdueHeader(kind, 'category_2', '适用产品')}
                ${overdueHeader(kind, 'instruction', '归属国家')}
                <th>${kind === 'idle' ? '最近出库' : '最近入库'}</th>
                ${overdueHeader(kind, 'threshold', kind === 'idle' ? '提醒线' : '超期线', 'text-align:center')}
        ` : '';
        const detailColspan = state.showDetails ? 15 : 11;
        return `<div style="overflow-x:auto"><table>
            <thead><tr>
                <th>Photo</th>
                ${overdueHeader(kind, 'warehouse', '仓库')}
                ${overdueHeader(kind, 'bom_code', 'BOM 编号')}
                ${overdueHeader(kind, 'product_number', '产品编号')}
                ${overdueHeader(kind, 'product_description', '产品描述')}
                ${overdueHeader(kind, 'category', '物料品类')}
                ${overdueHeader(kind, 'inventory', '库存', 'text-align:right')}
                ${overdueHeader(kind, 'unit_price', '单价', 'text-align:right')}
                ${overdueHeader(kind, 'ttl_amount', '总货值', 'text-align:right')}
                ${overdueHeader(kind, 'days', kind === 'idle' ? '未使用天数' : '库龄', 'text-align:center;color:var(--warning)')}
                ${overdueHeader(kind, 'overdue_days', '超期天数', 'text-align:center;color:var(--danger)')}
                ${detailHeaders}
            </tr></thead>
            <tbody>${pageRows.length === 0 ? `<tr><td colspan="${detailColspan}" style="text-align:center;color:var(--text-muted);padding:40px">${empty}</td></tr>` : pageRows.map(r => {
                const imagePath = r.image_path || '';
                const imageArg = jsArg(imagePath);
                const remarkArg = jsArg(r.product_description || '');
                const thumb = imagePath ? `<img class="thumb stock-thumb thumb-clickable" src="${escapeHtml(imageUrl(imagePath))}" data-image-path="${escapeHtml(imagePath)}" onclick="showImage(${imageArg}, ${remarkArg})" ondblclick="showImage(${imageArg}, ${remarkArg})" onmouseenter="showImagePopover(event, ${imageArg}, ${remarkArg})" onmousemove="moveImagePopover(event)" onmouseleave="hideImagePopover()" loading="lazy" title="点击查看大图">` : '<span style="color:var(--text-muted);font-size:12px">-</span>';
                const detailCells = state.showDetails ? `
                    <td>${escapeHtml(r.category_2 || '')}</td>
                    <td>${escapeHtml(r.instruction || '')}</td>
                    <td>${escapeHtml(kind === 'idle' ? (r.last_outbound_date || '') : (r.last_inbound_date || ''))}</td>
                    <td style="text-align:center">${Number(r[thresholdField] || 180).toLocaleString()} 天</td>
                ` : '';
                return `<tr>
                    <td>${thumb}</td>
                    <td>${escapeHtml(r.warehouse || '')}</td>
                    <td style="font-weight:500">${escapeHtml(r.bom_code || '')}</td>
                    <td>${escapeHtml(r.product_number || '')}</td>
                    <td style="min-width:260px;max-width:360px;white-space:normal;line-height:1.35">${escapeHtml(r.product_description || '')}</td>
                    <td><span class="badge badge-confirmed">${escapeHtml(r.category || '')}</span></td>
                    <td style="text-align:right">${Number(r.inventory || 0).toLocaleString()}</td>
                    <td style="text-align:right">${r.unit_price != null ? '$' + Number(r.unit_price).toFixed(2) : ''}</td>
                    <td style="text-align:right;font-weight:500">${fmt$(r.ttl_amount)}</td>
                    <td style="text-align:center"><span class="badge badge-pending">${Number(r[dayField] || 0).toLocaleString()} 天</span></td>
                    <td style="text-align:center;color:var(--danger);font-weight:600">${Number(r.overdue_days || 0).toLocaleString()}</td>
                    ${detailCells}
                </tr>`;
            }).join('')}</tbody>
        </table></div>
        <div class="overdue-pagination">
            <span>显示 ${totalRows ? start + 1 : 0}-${Math.min(start + state.perPage, totalRows)} / ${totalRows} 条</span>
            <div class="overdue-pagination-actions">
                <button class="btn btn-secondary btn-sm" ${state.page <= 1 ? 'disabled' : ''} data-overdue-page="${state.page - 1}" data-overdue-kind="${kind}">上一页</button>
                <span>第 ${state.page} / ${maxPage} 页</span>
                <button class="btn btn-secondary btn-sm" ${state.page >= maxPage ? 'disabled' : ''} data-overdue-page="${state.page + 1}" data-overdue-kind="${kind}">下一页</button>
            </div>
        </div>`;
    }

    function renderOverdueView(kind) {
        const data = overdueState[kind].rows || [];
        const filtered = getFilteredOverdueRows(kind);
        const totalVal = filtered.reduce((s, r) => s + Number(r.ttl_amount || 0), 0);
        const totalPcs = filtered.reduce((s, r) => s + Number(r.inventory || 0), 0);
        const avgOverdue = filtered.length ? filtered.reduce((s, r) => s + Number(r.overdue_days || 0), 0) / filtered.length : 0;
        const severe = filtered.filter(r => Number((kind === 'idle' ? r.idle_days : r.overdue_days) || 0) >= (kind === 'idle' ? 365 : 90));
        const title = kind === 'idle' ? '长期未使用' : 'DOS 超期';
        const chartTitle = kind === 'idle' ? '长期未使用：货值与数量按物料品类' : 'DOS 超期：货值与数量按物料品类';
        document.getElementById('invDashContent').innerHTML = `
            <div class="inventory-risk-grid" style="margin-bottom:16px">
                <div class="inventory-risk-card"><div class="risk-label">${title} SKU</div><div class="risk-value" style="color:var(--warning)">${filtered.length}</div><div class="risk-sub">当前筛选结果 / 原始 ${data.length} SKU</div></div>
                <div class="inventory-risk-card"><div class="risk-label">${title}货值</div><div class="risk-value" style="color:var(--danger)">${fmt$(totalVal)}</div><div class="risk-sub">${Number(totalPcs).toLocaleString()} PCS 需要跟进</div></div>
                <div class="inventory-risk-card"><div class="risk-label">${kind === 'idle' ? '365+ 未出库' : '严重超期'}</div><div class="risk-value" style="color:var(--danger)">${severe.length}</div><div class="risk-sub">${kind === 'idle' ? '建议业务确认是否保留、转移或清理' : '超期 90 天以上，建议优先盘点'}</div></div>
                <div class="inventory-risk-card"><div class="risk-label">平均超期天数</div><div class="risk-value">${avgOverdue.toFixed(0)} 天</div><div class="risk-sub"><button class="btn btn-secondary btn-sm" onclick="downloadOverdueReport('${kind}')">导出${kind === 'idle' ? '静置' : '超期库存'}报告</button></div></div>
            </div>
            <div class="chart-card" style="margin-bottom:16px"><h3>${chartTitle}</h3><div class="chart-container"><canvas id="${kind === 'idle' ? 'chartIdle180' : 'chartDos180'}"></canvas></div></div>
            <div class="table-section">
                <div class="overdue-report-titlebar"><h3>${title}明细清单</h3><span style="font-size:12px;color:var(--text-muted)">筛选、排序、分页只影响页面展示；导出包含完整明细。</span></div>
                ${renderOverdueFilters(kind, data)}
                ${renderOverdueTable(kind, filtered)}
            </div>`;
        bindStockImagePreviewEvents();
        drawOverdueCategoryChart(kind, filtered);
    }

    async function loadDos180(wh) {
        const d = await apiGet('/api/inventory/stats/dos180?warehouse=' + encodeURIComponent(wh));
        overdueState.dos.rows = d.data || [];
        renderOverdueView('dos');
    }

    async function loadIdle180(wh) {
        const d = await apiGet('/api/inventory/stats/idle180?warehouse=' + encodeURIComponent(wh));
        overdueState.idle.rows = d.data || [];
        renderOverdueView('idle');
    }

    Object.assign(window, {
        setOverdueSort,
        updateOverdueFilter,
        resetOverdueFilter,
        updateOverduePerPage,
        toggleOverdueDetails,
        changeOverduePage
    });

    document.addEventListener('click', (event) => {
        const sortEl = event.target.closest('[data-overdue-sort]');
        if (sortEl) {
            setOverdueSort(sortEl.dataset.overdueKind, sortEl.dataset.overdueSort);
            return;
        }
        const resetEl = event.target.closest('[data-overdue-reset]');
        if (resetEl) {
            resetOverdueFilter(resetEl.dataset.overdueReset);
            return;
        }
        const pageEl = event.target.closest('[data-overdue-page]');
        if (pageEl) {
            changeOverduePage(pageEl.dataset.overdueKind, pageEl.dataset.overduePage);
            return;
        }
        const exportEl = event.target.closest('[data-overdue-export]');
        if (exportEl) downloadOverdueReport(exportEl.dataset.overdueExport);
    });
    document.addEventListener('input', (event) => {
        const el = event.target.closest('[data-overdue-filter]');
        if (el && el.tagName === 'INPUT') updateOverdueFilter(el.dataset.overdueKind, el.dataset.overdueFilter, el.value);
    });
    document.addEventListener('change', (event) => {
        const el = event.target.closest('[data-overdue-filter]');
        if (el && el.tagName !== 'INPUT') updateOverdueFilter(el.dataset.overdueKind, el.dataset.overdueFilter, el.value);
        const perPageEl = event.target.closest('[data-overdue-per-page]');
        if (perPageEl) updateOverduePerPage(perPageEl.dataset.overduePerPage, perPageEl.value);
        const detailsEl = event.target.closest('[data-overdue-details]');
        if (detailsEl) toggleOverdueDetails(detailsEl.dataset.overdueDetails, detailsEl.checked);
    });

    async function downloadOverdueReport(kind) {
        const wh = document.getElementById('dashWarehouse').value;
        const params = new URLSearchParams({ kind });
        if (wh) params.set('warehouse', wh);
        return downloadApiBlob('/api/inventory/export/overdue?' + params.toString(), {
            fallbackName: `${APP_VERSION}_${kind}_overdue.xlsx`,
            successText: '超期报告已导出',
            errorText: '导出失败'
        });
    }
    window.downloadOverdueReport = downloadOverdueReport;
