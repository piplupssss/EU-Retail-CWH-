// Shared report rendering helpers. Keep these display-only.
function reportMonthLabel(month) {
    const m = String(month || '').trim();
    if (m === 'annual') return `${new Date().getFullYear()}全年`;
    const yearHit = m.match(/^year:(\d{4})$/);
    if (yearHit) return `${yearHit[1]}全年`;
    const hit = m.match(/^(\d{4})-(\d{2})$/);
    if (!hit) return m || '未选择月份';
    return `${hit[1]}年${Number(hit[2])}月`;
}

function reportBarRows(rows, labelFn, valueFn, color = '#3b82f6', suffix = '') {
    const max = Math.max(...rows.map(r => Number(valueFn(r) || 0)), 1);
    return `<div class="report-bars">${rows.map(r => {
        const value = Number(valueFn(r) || 0);
        const pct = Math.max(2, Math.round(value / max * 100));
        return `<div class="report-bar-row">
            <div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(labelFn(r))}">${escapeHtml(labelFn(r))}</div>
            <div class="report-bar-track"><div class="report-bar-fill" style="width:${pct}%;background:${color}"></div></div>
            <div style="text-align:right;font-weight:700">${formatCount(value)}${suffix}</div>
        </div>`;
    }).join('')}</div>`;
}

function reportTopRows(rows, kind) {
    const empty = `<tr><td colspan="6" style="text-align:center;color:#94a3b8">暂无数据</td></tr>`;
    return (rows || []).slice(0, 8).map(r => `<tr>
        <td>${escapeHtml(r.warehouse || '')}</td>
        <td>${escapeHtml(r.bom_code || '')}</td>
        <td>${escapeHtml(r.product_number || '')}</td>
        <td>${escapeHtml(r.product_description || '')}</td>
        <td style="text-align:right">${formatCount(r.inventory || 0)}</td>
        <td style="text-align:right">${formatCount(kind === 'idle' ? r.idle_days : r.dos)} 天</td>
    </tr>`).join('') || empty;
}

function reportInventoryTopCards(rows, kind) {
    const top = [...(rows || [])]
        .sort((a, b) => Number(b.ttl_amount || 0) - Number(a.ttl_amount || 0) || Number(b.overdue_days || 0) - Number(a.overdue_days || 0))
        .slice(0, 5);
    if (!top.length) return '<div style="color:#94a3b8;font-size:12px;padding:18px 0">暂无需要提醒的物料</div>';
    const dayField = kind === 'idle' ? 'idle_days' : 'dos';
    const dayLabel = kind === 'idle' ? '未使用' : '库龄';
    return `<div class="report-inventory-top-list">${top.map(r => {
        const img = r.image_path
            ? `<img class="report-inventory-top-thumb" src="${escapeHtml(imageUrl(r.image_path))}" alt="">`
            : '<div class="report-inventory-top-noimg">无图</div>';
        return `<div class="report-inventory-top-item">
            ${img}
            <div>
                <div class="report-inventory-top-title">${escapeHtml(r.product_number || r.bom_code || '-')}</div>
                <div class="report-inventory-top-desc">${escapeHtml(r.product_description || '无描述')}</div>
                <div class="report-inventory-top-meta">${escapeHtml(r.warehouse || '-')} · BOM ${escapeHtml(displayBomCode(r.bom_code || '-'))} · ${escapeHtml(r.category || '-')}</div>
            </div>
            <div class="report-inventory-top-metric"><b>${r.unit_price != null ? '$' + Number(r.unit_price || 0).toFixed(2) : '-'}</b>单价</div>
            <div class="report-inventory-top-metric"><b>${formatUsdWhole(r.ttl_amount)}</b>货值</div>
            <div class="report-inventory-top-metric"><b>${formatCount(r.inventory)}</b>PCS</div>
            <div class="report-inventory-top-metric warn"><b>${formatCount(r[dayField])}</b>${dayLabel}天</div>
        </div>`;
    }).join('')}</div>`;
}

function buildReportLogisticsBreakdown(shipments) {
    const officeMap = new Map();
    const countryMap = new Map();
    shipments.forEach(s => {
        const country = demandCountryOfShipment(s) || 'N/A';
        const office = countryOfficeOf(country);
        const add = (map, key, base) => {
            const row = map.get(key) || { ...base, count: 0, weight: 0, volume: 0, price: 0 };
            row.count += 1;
            row.weight += Number(s.total_weight || 0);
            row.volume += Number(s.total_volume || 0);
            row.price += Number(s.price_without_vat || 0);
            map.set(key, row);
        };
        add(officeMap, office.key, { office: office.label, officeOrder: office.order || 99 });
        add(countryMap, country, {
            office: office.label,
            officeOrder: office.order || 99,
            country,
            countryName: ISO2_TO_NAME[country] || country
        });
    });
    const byVolume = (a, b) => (a.officeOrder - b.officeOrder) || (b.count - a.count) || String(a.countryName || a.office).localeCompare(String(b.countryName || b.office), 'zh-Hans-CN');
    return {
        offices: [...officeMap.values()].sort((a, b) => (a.officeOrder - b.officeOrder) || (b.count - a.count)),
        countries: [...countryMap.values()].sort(byVolume)
    };
}

function reportLogisticsRows(rows, totalOrders, showOffice = true) {
    const emptyCols = showOffice ? 7 : 6;
    if (!rows.length) return `<tr><td colspan="${emptyCols}" style="text-align:center;color:#94a3b8">暂无当月物流数据</td></tr>`;
    return rows.map(r => `<tr>
        ${showOffice ? `<td>${escapeHtml(r.office || '')}</td>` : ''}
        <td>${escapeHtml(r.countryName || r.office || '')}</td>
        <td style="text-align:right">${formatCount(r.count)}</td>
        <td style="text-align:right">${totalOrders ? (r.count / totalOrders * 100).toFixed(1) : '0.0'}%</td>
        <td style="text-align:right">${Number(r.weight || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })}</td>
        <td style="text-align:right">${Number(r.volume || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
        <td style="text-align:right">${formatUsdWhole(r.price)}</td>
    </tr>`).join('');
}

function reportTopCountryCards(rows, totalOrders) {
    const top = [...(rows || [])].sort((a, b) => Number(b.count || 0) - Number(a.count || 0)).slice(0, 3);
    if (!top.length) return '<div style="color:#94a3b8;font-size:12px;margin-top:10px">暂无当月国家要货数据</div>';
    return `<div class="report-top-country-list">${top.map((r, idx) => `
        <div class="report-top-country">
            <span class="rank">${idx + 1}</span>
            <div>
                <div class="name">${escapeHtml(r.countryName || r.country || '')}</div>
                <div class="meta">${escapeHtml(r.office || '')}</div>
            </div>
            <div class="value">${formatCount(r.count)}单<br><span class="meta">${totalOrders ? (r.count / totalOrders * 100).toFixed(1) : '0.0'}%</span></div>
        </div>
    `).join('')}</div>`;
}

function reportEuropeMapSvg(countryRows, geoData) {
    if (!geoData || !geoData.features || !countryRows.length) return '<div style="color:#94a3b8;font-size:12px;margin-top:12px">暂无地图数据</div>';
    const byIso3 = new Map(countryRows.map(r => [ISO2_TO_3[r.country], r]).filter(([iso3]) => iso3));
    const values = [...byIso3.values()].map(r => Number(r.count || 0));
    const max = Math.max(...values, 1);
    const width = 390, height = 245;
    const bounds = { minLon: -15, maxLon: 45, minLat: 34, maxLat: 72 };
    const project = ([lon, lat]) => {
        const x = (lon - bounds.minLon) / (bounds.maxLon - bounds.minLon) * width;
        const y = (bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat) * height;
        return [x, y];
    };
    const ringPath = ring => ring.map((pt, idx) => {
        const [x, y] = project(pt);
        return `${idx ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ') + ' Z';
    const featurePath = feature => {
        const geo = feature.geometry || {};
        if (geo.type === 'Polygon') return geo.coordinates.map(ringPath).join(' ');
        if (geo.type === 'MultiPolygon') return geo.coordinates.flatMap(poly => poly.map(ringPath)).join(' ');
        return '';
    };
    const colorFor = count => {
        if (!count) return '#e5e7eb';
        const ratio = Math.max(0.12, Number(count || 0) / max);
        const hue = 205 - ratio * 140;
        return `hsl(${hue},72%,${62 - ratio * 24}%)`;
    };
    const paths = geoData.features.filter(f => EUROPE_IDS.has(f.id)).map(f => {
        const row = byIso3.get(f.id);
        return `<path d="${featurePath(f)}" fill="${colorFor(row?.count || 0)}" stroke="#ffffff" stroke-width="0.8"><title>${escapeHtml(row ? `${row.countryName}: ${row.count} orders` : (f.properties?.name || f.id))}</title></path>`;
    }).join('');
    const top = [...countryRows].sort((a, b) => b.count - a.count).slice(0, 5);
    const legend = top.map(r => `<div style="display:flex;justify-content:space-between;gap:8px;font-size:10px;color:#334155"><span>${escapeHtml(r.countryName)}</span><b>${formatCount(r.count)}</b></div>`).join('');
    return `<div style="margin-top:14px;border:1px solid #e2e8f0;border-radius:8px;padding:10px;background:#f8fafc">
        <svg viewBox="0 0 ${width} ${height}" width="100%" height="245" role="img" aria-label="各国订单信息一览地图">${paths}</svg>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;align-items:start;margin-top:8px">
            <div style="font-size:10px;color:#64748b;line-height:1.5">颜色越深表示当月订单数越高，口径与右侧国家明细一致。</div>
            <div style="display:grid;gap:4px">${legend}</div>
        </div>
    </div>`;
}

function reportMonthlyTrendBlock(rows) {
    const data = (rows || []).slice(-6);
    if (!data.length) return '<div style="color:#94a3b8;font-size:12px">暂无月度趋势数据</div>';
    const max = Math.max(...data.map(r => Number(r.count || 0)), 1);
    const bars = data.map(r => {
        const h = Math.max(8, Number(r.count || 0) / max * 92);
        return `<div style="display:flex;flex-direction:column;align-items:center;gap:5px;justify-content:flex-end;height:132px">
            <div style="font-size:10px;color:#334155;font-weight:700">${formatCount(r.count)}</div>
            <div style="width:24px;height:${h.toFixed(0)}px;background:#3b82f6;border-radius:5px 5px 0 0"></div>
            <div style="font-size:10px;color:#64748b;white-space:nowrap">${escapeHtml(r.month || '')}</div>
        </div>`;
    }).join('');
    const table = data.map(r => `<tr>
        <td>${escapeHtml(r.month || '')}</td>
        <td style="text-align:right">${formatCount(r.count)}</td>
        <td style="text-align:right">${Number(r.weight || 0).toLocaleString(undefined, { maximumFractionDigits: 1 })}</td>
        <td style="text-align:right">${Number(r.volume || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>
        <td style="text-align:right">${formatUsdWhole(r.price)}</td>
    </tr>`).join('');
    return `<div style="display:grid;grid-template-columns:1fr 1.25fr;gap:16px;align-items:end">
        <div style="display:flex;gap:14px;align-items:flex-end;justify-content:space-around;border:1px solid #e2e8f0;border-radius:8px;background:#f8fafc;padding:10px 8px">${bars}</div>
        <table class="report-table"><thead><tr><th>月份</th><th style="text-align:right">订单数</th><th style="text-align:right">重量 kg</th><th style="text-align:right">体积 m³</th><th style="text-align:right">费用</th></tr></thead><tbody>${table}</tbody></table>
    </div>`;
}

function buildDashboardCountryRows(shipments) {
    const countryMap = {};
    (shipments || []).forEach(s => {
        const country = demandCountryOfShipment(s);
        if (!country) return;
        if (!countryMap[country]) countryMap[country] = { country, count: 0, weight: 0, price: 0, delivery_days: [] };
        countryMap[country].count += 1;
        countryMap[country].weight += Number(s.total_weight || 0);
        countryMap[country].price += Number(s.price_without_vat || 0);
        if (s.actual_delivery_date && s.pickup_date) {
            const days = calcWorkdays(s.pickup_date.split(' ')[0], s.actual_delivery_date.split(' ')[0]);
            if (days !== '-') countryMap[country].delivery_days.push(Number(days));
        }
    });
    return Object.values(countryMap).map(d => {
        const avg = d.delivery_days.length ? d.delivery_days.reduce((s, v) => s + v, 0) / d.delivery_days.length : null;
        return {
            country: d.country,
            count: d.count,
            weight: d.weight,
            price: d.price,
            avg_delivery_days: avg == null ? null : Math.round(avg * 10) / 10
        };
    }).sort((a, b) => String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN'));
}
