// Shared logistics display helpers. Keep these display-only.
const STATUS_LABEL_KEYS = {
    '已交付': 'delivered',
    '待核实': 'pendingVerify',
    '运输中': 'inTransit',
    '异常单': 'exception',
};

const STATUS_COLORS = {
    '已交付': '#22c55e',
    '待核实': '#a855f7',
    '运输中': '#f59e0b',
    '异常单': '#ef4444',
};

function statusLabel(status) {
    return t(STATUS_LABEL_KEYS[status] || status);
}

const TYPE_COLORS = {
    'warehouse_central': '#f59e0b',
    'warehouse_furniture': '#06b6d4',
    'direct': '#a78bfa',
};

const TYPE_LABELS = {
    'warehouse_central': '中央仓发出',
    'warehouse_furniture': '家具仓发出',
    'direct': '调拨',
};

const TYPE_LABEL_KEYS = {
    'warehouse_central': 'centralWarehouseOutbound',
    'warehouse_furniture': 'furnitureWarehouseOutbound',
    'direct': 'directShipment',
};

function typeLabel(type, fallback) {
    return t(TYPE_LABEL_KEYS[type] || '') || fallback || TYPE_LABELS[type] || type;
}

// Shared country and representative-office display helpers.
// Keep these as display metadata only; shipment import/classification stays in backend services.
const ISO2_TO_3 = {
    'DE':'DEU','FR':'FRA','PL':'POL','ES':'ESP','CZ':'CZE','RO':'ROU','LT':'LTU',
    'IT':'ITA','BG':'BGR','SI':'SVN','HU':'HUN','AT':'AUT','GR':'GRC','PT':'PRT',
    'SE':'SWE','FI':'FIN','HR':'HRV','NL':'NLD','BE':'BEL','DK':'DNK','IE':'IRL',
    'SK':'SVK','EE':'EST','LV':'LVA','NO':'NOR','CH':'CHE','GB':'GBR','UK':'GBR','RU':'RUS',
    'UA':'UKR','MD':'MDA','ME':'MNE','RS':'SRB','MK':'MKD','AL':'ALB','BA':'BIH',
    'IS':'ISL','LU':'LUX','MT':'MLT','CY':'CYP','GI':'GIB','FO':'FRO','GL':'GRL','AX':'ALA',
    'SM':'SMR','MC':'MCO','AD':'AND','LI':'LIE','VA':'VAT','JE':'JEY','GG':'GGY',
    'IM':'IMN','SJ':'SJM',
};

const ISO2_TO_NAME = {
    'DE':'Germany','FR':'France','PL':'Poland','ES':'Spain','CZ':'Czechia','RO':'Romania',
    'LT':'Lithuania','IT':'Italy','BG':'Bulgaria','SI':'Slovenia','HU':'Hungary',
    'AT':'Austria','GR':'Greece','PT':'Portugal','SE':'Sweden','FI':'Finland',
    'HR':'Croatia','NL':'Netherlands','BE':'Belgium','LU':'Luxembourg','SK':'Slovakia',
    'UA':'Ukraine','DK':'Denmark','NO':'Norway','IS':'Iceland','EE':'Estonia',
    'LV':'Latvia','GB':'United Kingdom','UK':'United Kingdom','CH':'Switzerland',
    'RS':'Serbia','IE':'Ireland','FO':'Faroe Islands','GL':'Greenland','AX':'Aland Islands',
};

const COUNTRY_OFFICES = [
    { key: 'poland', label: '波兰代表处', short: 'PL Office', color: 'rgba(59,130,246,0.72)', countries: ['PL','UA','CZ','SK','SE','FI','NO','DK','IS','FO','GL','AX','EE','LV','LT'] },
    { key: 'germany', label: '德国代表处', short: 'DE Office', color: 'rgba(34,197,94,0.68)', countries: ['DE','AT','CH'] },
    { key: 'france', label: '法国代表处', short: 'FR Office', color: 'rgba(245,158,11,0.70)', countries: ['GB','UK','FR','NL','BE','LU','IE'] },
    { key: 'south_europe', label: '南欧代表处', short: 'South EU', color: 'rgba(236,72,153,0.68)', countries: ['ES','PT','IT'] },
    { key: 'eastern_europe', label: '东欧多国代表处', short: 'East EU', color: 'rgba(139,92,246,0.68)', countries: ['HU','SI','GR','RO','HR','RS','BG'] },
];

const COUNTRY_TO_OFFICE = COUNTRY_OFFICES.reduce((map, office, idx) => {
    office.countries.forEach(code => { map[String(code).toUpperCase()] = { ...office, order: idx }; });
    return map;
}, {});

const EUROPE_IDS = new Set([
    'ALA','ALB','AND','AUT','BEL','BGR','BIH','CHE','CZE','DEU','DNK','ESP',
    'EST','FIN','FRA','FRO','GBR','GRC','HRV','HUN','IMN','IRL','ISL','ITA',
    'JEY','KOS','LTU','LUX','LVA','MDA','MNE','MKD','NLD','NOR','POL','PRT','GRL',
    'ROU','SMR','SRB','SVK','SVN','SWE','VAT','CYP','MLT'
]);

function countryOfficeOf(countryCode) {
    return COUNTRY_TO_OFFICE[String(countryCode || '').toUpperCase()] || {
        key: 'other',
        label: '其他代表处',
        short: 'Other',
        color: 'rgba(100,116,139,0.58)',
        order: 99,
        countries: []
    };
}
