    // ===== 物流看板 =====
    async function loadDashboard() {
        await Promise.all([
            loadSummary(),
            loadStatusChart(),
            loadTypeChart(),
            loadCountryChart(),
            loadMonthlyChart()
        ]).catch(e => console.error('Dashboard load error:', e));
    }


    async function loadSummary() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/summary' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const updateTimeEl = document.getElementById('update-time');
        if (updateTimeEl) {
            updateTimeEl.textContent = data.latest_logistics_upload || '--';
        }
        const grid = document.getElementById('stats-grid');
        grid.innerHTML = `
            <div class="stat-card clickable" onclick="drillDown(null, t('allShipments'))">
                <div class="label">${t('totalShipments')}</div>
                <div class="value accent">${data.total_shipments}</div>
                <div class="sub">${t('viewAll')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('已交付', t('deliveredShipments'))">
                <div class="label">${t('delivered')}</div>
                <div class="value success">${data.delivered}</div>
                <div class="sub">${tf('ratioClick', { pct: data.total_shipments ? Math.round(data.delivered / data.total_shipments * 100) : 0 })}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('待核实', t('pendingVerifyShipments'))" style="border-color:rgba(168,85,247,0.3)">
                <div class="label">${t('pendingVerify')}</div>
                <div class="value" style="color:#a855f7">${data.pending_verify}</div>
                <div class="sub">${t('etaReached')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('运输中', t('inTransitShipments'))">
                <div class="label">${t('inTransit')}</div>
                <div class="value" style="color:#f59e0b">${data.in_transit}</div>
                <div class="sub">${t('clickToView')}</div>
            </div>
            <div class="stat-card clickable" onclick="drillDown('异常单', t('exceptionShipments'))">
                <div class="label">${t('exception')}</div>
                <div class="value danger">${data.exception}</div>
                <div class="sub">${t('shipOverdue')}</div>
            </div>
            `;
    }

    function doughnutValueLabelPlugin(sourceData, labelFn, total) {
        return {
            id: 'doughnutValueLabels',
            afterDatasetsDraw(chart) {
                const { ctx } = chart;
                const meta = chart.getDatasetMeta(0);
                ctx.save();
                ctx.font = '700 11px Inter, sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                meta.data.forEach((arc, idx) => {
                    const raw = Number(chart.data.datasets[0].data[idx] || 0);
                    if (!raw) return;
                    const pct = total ? raw / total : 0;
                    if (pct < 0.045) return;
                    const pos = arc.tooltipPosition();
                    const text = `${labelFn(sourceData[idx])} ${raw} · ${Math.round(pct * 100)}%`;
                    ctx.lineWidth = 4;
                    ctx.strokeStyle = 'rgba(15,23,42,0.85)';
                    ctx.strokeText(text, pos.x, pos.y);
                    ctx.fillStyle = '#ffffff';
                    ctx.fillText(text, pos.x, pos.y);
                });
                ctx.restore();
            }
        };
    }

    async function loadBudget() {
        try {
            const data = await apiFetch(API + '/api/invoices/budget');
            const spentEl = document.getElementById('budget-spent');
            const remainEl = document.getElementById('budget-remaining');
            if (spentEl) {
                const spentUsd = data.logistics_usd || 0;
                const remainUsd = data.remaining_usd || 250000;
                spentEl.textContent = '$' + spentUsd.toLocaleString();
                remainEl.textContent = '$' + remainUsd.toLocaleString();
                // Change color if over budget
                if (remainUsd <= 0) {
                    spentEl.className = 'value danger';
                } else if (remainUsd < 50000) {
                    spentEl.className = 'value warning';
                }
            }
        } catch(e) {
            console.error('Failed to load budget:', e);
        }
    }

    async function loadStatusChart() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/status_distribution' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const total = data.reduce((s, d) => s + Number(d.count || 0), 0);
        const ctx = document.getElementById('chart-status').getContext('2d');
        if (charts.status) charts.status.destroy();
        charts.status = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => `${statusLabel(d.shipment_status)} ${fmtPct(d.count, total)}`),
                datasets: [{
                    data: data.map(d => d.count),
                    backgroundColor: data.map(d => STATUS_COLORS[d.shipment_status] || '#64748b'),
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        const label = data[idx].shipment_status;
                        drillDown(label, statusLabel(label));
                    }
                },
                plugins: {
                    legend: { position: 'right', labels: { color: '#94a3b8', padding: 12, font: { size: 12 } } },
                    tooltip: { callbacks: { label: (ctx) => `${statusLabel(data[ctx.dataIndex].shipment_status)}: ${ctx.raw} ${t('orderUnit')} (${fmtPct(ctx.raw, total)})` } }
                },
                cutout: '55%'
            },
            plugins: [doughnutValueLabelPlugin(data, d => statusLabel(d.shipment_status), total)]
        });
    }

    async function loadTypeChart() {
        const month = selectedLogisticsMonth();
        const data = await apiFetch(API + '/api/dashboard/type_distribution' + (month ? `?month=${encodeURIComponent(month)}` : ''));
        const total = data.reduce((s, d) => s + Number(d.count || 0), 0);
        const ctx = document.getElementById('chart-type').getContext('2d');
        if (charts.type) charts.type.destroy();
        charts.type = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: data.map(d => `${typeLabel(d.shipment_type, d.label)} ${fmtPct(d.count, total)}`),
                datasets: [{
                    data: data.map(d => d.count),
                    backgroundColor: data.map(d => TYPE_COLORS[d.shipment_type] || '#64748b'),
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        const type = data[idx].shipment_type;
                        const label = typeLabel(type, data[idx].label);
                        drillDownType(type, label);
                    }
                },
                plugins: {
                    legend: { position: 'right', labels: { color: '#94a3b8', padding: 12, font: { size: 12 } } },
                    tooltip: { callbacks: { label: (ctx) => `${typeLabel(data[ctx.dataIndex].shipment_type, data[ctx.dataIndex].label)}: ${ctx.raw} ${t('orderUnit')} (${fmtPct(ctx.raw, total)})` } }
                },
                cutout: '55%'
            },
            plugins: [doughnutValueLabelPlugin(data, d => typeLabel(d.shipment_type, d.label), total)]
        });
    }

    let europeMap = null;
    let geoJsonLayer = null;
    let countryLabelLayer = null;
    let countryRankingData = null;

    function populateMonthFilter(months) {
        if (!months || !months.length) return;
        const select = document.getElementById('map-month-filter');
        const current = select.value;
        while (select.options.length > 1) select.remove(1);
        months.forEach(m => {
            const opt = document.createElement('option');
            opt.value = m;
            opt.textContent = m;
            select.appendChild(opt);
        });
        select.value = current;
    }

    function syncCountryOfficeControls() {
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const wrap = document.getElementById('country-office-filter-wrap');
        if (wrap) {
            wrap.style.display = '';
            wrap.style.opacity = sortMode === 'office_single' ? '1' : '0.45';
            wrap.style.pointerEvents = sortMode === 'office_single' ? 'auto' : 'none';
        }
    }

    function sortedCountryBarData(rows) {
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const selectedOffice = document.getElementById('country-office-filter')?.value || 'poland';
        const withOffice = rows.map(r => ({ ...r, office: countryOfficeOf(r.country) }));
        const byCountDesc = (a, b) => {
            const countDiff = Number(b.count || 0) - Number(a.count || 0);
            if (countDiff) return countDiff;
            return String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN');
        };
        if (sortMode === 'office_single') {
            return withOffice.filter(r => r.office.key === selectedOffice).sort(byCountDesc);
        }
        if (sortMode === 'office_group') {
            return withOffice.sort((a, b) => {
                const officeDiff = Number(a.office.order || 99) - Number(b.office.order || 99);
                return officeDiff || byCountDesc(a, b);
            });
        }
        return withOffice.sort(byCountDesc);
    }
    Object.assign(window, { syncCountryOfficeControls, sortedCountryBarData });

    async function loadCountryChart() {
        syncCountryOfficeControls();
        const selectedBefore = document.getElementById('map-month-filter')?.value || '';
        let resp;
        if (selectedBefore) {
            resp = await apiFetch(API + '/api/dashboard/country_ranking?month=' + encodeURIComponent(selectedBefore));
        } else {
            resp = await apiFetch(API + '/api/dashboard/country_ranking');
            populateMonthFilter(resp.available_months || []);
        }
        const selectedAfterPopulate = document.getElementById('map-month-filter')?.value || selectedBefore;
        if (selectedAfterPopulate && !selectedBefore) {
            resp = await apiFetch(API + '/api/dashboard/country_ranking?month=' + encodeURIComponent(selectedAfterPopulate));
        }
        const filtered = (resp.data || [])
            .map(d => ({
                country: String(d.country || '').trim().toUpperCase(),
                count: Number(d.count || 0),
                weight: Number(d.weight || 0),
                price: Number(d.price || 0),
                avg_delivery_days: d.avg_delivery_days == null ? null : Number(d.avg_delivery_days)
            }))
            .filter(d => d.country && d.count > 0)
            .sort((a, b) => String(ISO2_TO_NAME[a.country] || a.country).localeCompare(String(ISO2_TO_NAME[b.country] || b.country), 'zh-Hans-CN'));

        countryRankingData = filtered;

        const totalCount = filtered.reduce((s, d) => s + d.count, 0);
        const maxCount = Math.max(...filtered.map(d => d.count), 1);

        const dataByISO3 = {};
        const nameByISO3 = {};
        filtered.forEach(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (iso3) {
                dataByISO3[iso3] = d;
                nameByISO3[iso3] = ISO2_TO_NAME[d.country] || d.country;
            }
        });

        const sortedCounts = Object.values(dataByISO3).map(d => d.count).sort((a, b) => a - b);
        const minCount = sortedCounts[0] || 1;
        const logMin = Math.log(minCount);
        const logMax = Math.log(maxCount);
        const logRange = logMax - logMin || 1;

        function getColor(count) {
            if (!count) return 'rgba(30,41,59,0.4)';
            const ratio = (Math.log(count) - logMin) / logRange;
            const hue = 190 - ratio * 190;
            const sat = 60 + ratio * 30;
            const light = 30 + ratio * 20;
            return `hsl(${hue},${sat}%,${light}%)`;
        }

        if (!europeMap) {
            europeMap = L.map('europe-map', {
                center: [50, 15],
                zoom: 4,
                minZoom: 3,
                maxZoom: 6,
                zoomControl: true,
                attributionControl: false,
                maxBounds: [[35, -15], [72, 45]],
            });
        }

        if (geoJsonLayer) europeMap.removeLayer(geoJsonLayer);
        if (countryLabelLayer) europeMap.removeLayer(countryLabelLayer);

        const geoRes = await fetch('/static/europe.geojson');
        const geoData = await geoRes.json();
        const europeFeatures = geoData.features.filter(f => EUROPE_IDS.has(f.id));

        geoJsonLayer = L.geoJSON({ type: 'FeatureCollection', features: europeFeatures }, {
            style: (feature) => {
                const d = dataByISO3[feature.id];
                return {
                    fillColor: getColor(d ? d.count : 0),
                    weight: 1,
                    opacity: 1,
                    color: 'rgba(148,163,184,0.3)',
                    fillOpacity: 0.85,
                };
            },
            onEachFeature: (feature, layer) => {
                const iso3 = feature.id;
                const d = dataByISO3[iso3];
                const count = d ? d.count : 0;
                const name = nameByISO3[iso3] || feature.properties.name || iso3;
                const pct = totalCount ? Math.round(count / totalCount * 100) : 0;

                let tooltipHtml = `<div class="tt-name">${name}</div>`;
                if (d && count > 0) {
                    tooltipHtml += `<div class="tt-count">${count} ${t('orderUnit')}</div>`;
                    tooltipHtml += `<div style="color:var(--text-secondary);font-size:11px">${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg</div>`;
                    if (d.avg_delivery_days != null) {
                        tooltipHtml += `<div style="color:var(--text-secondary);font-size:11px">${t('avgDelivery')}: ${Number(d.avg_delivery_days).toFixed(1)} ${t('workdays')}</div>`;
                    }
                    tooltipHtml += `<div class="tt-pct">${pct}%</div>`;
                } else {
                    tooltipHtml += `<div style="color:var(--text-muted)">${t('noData')}</div>`;
                }

                layer.bindTooltip(tooltipHtml, { className: 'map-tooltip', direction: 'auto', autoPan: true });

                if (count > 0) {
                    const clickCountry = d?.clickCountry || d?.country;
                    layer.on('click', () => {
                        if (clickCountry) drillDownCountry(clickCountry);
                    });
                    layer.setStyle({ cursor: 'pointer' });
                }
            }
        }).addTo(europeMap);

        countryLabelLayer = L.layerGroup().addTo(europeMap);
        const labelFeatures = europeFeatures.filter(f => dataByISO3[f.id]);
        labelFeatures.forEach(feature => {
            const d = dataByISO3[feature.id];
            const countryName = nameByISO3[feature.id] || feature.properties.name || feature.id;
            const layer = geoJsonLayer.getLayers().find(l => l.feature && l.feature.id === feature.id);
            if (!layer) return;
            const bounds = layer.getBounds();
            if (!bounds || !bounds.isValid()) return;
            L.marker(bounds.getCenter(), {
                interactive: false,
                icon: L.divIcon({
                    className: 'map-country-label',
                    html: `${escapeHtml(countryName)}${d ? ` · ${d.count}` : ''}`,
                    iconSize: null
                })
            }).addTo(countryLabelLayer);
        });

        // 柱状图
        const metric = document.getElementById('country-bar-metric')?.value || 'count';
        const metricConfig = {
            count: { label: t('shipmentCount'), format: v => `${Number(v || 0).toLocaleString()} ${t('orderUnit')}` },
            weight: { label: t('weightLabel'), format: v => `${Number(v || 0).toLocaleString()} kg` },
            price: { label: '费用', format: v => '$' + Number(v || 0).toLocaleString() },
            avg_delivery_days: { label: t('avgDelivery'), format: v => v == null ? '-' : `${Number(v || 0).toFixed(1)} ${t('workdays')}` }
        };
        const metricInfo = metricConfig[metric] || metricConfig.count;
        const barData = sortedCountryBarData(filtered);
        const barLabels = barData.map(d => ISO2_TO_NAME[d.country] || d.country);
        const barTotal = barData.reduce((s, d) => s + Number(d[metric] || 0), 0);
        const sortMode = document.getElementById('country-bar-sort')?.value || 'all_desc';
        const barColors = barData.map(d => {
            const iso3 = ISO2_TO_3[d.country];
            if (sortMode !== 'all_desc') return d.office?.color || 'rgba(100,116,139,0.5)';
            return iso3 ? getColor(d.count) : 'rgba(100,116,139,0.5)';
        });

        const barCtx = document.getElementById('chart-country-bar').getContext('2d');
        if (charts.countryBar) charts.countryBar.destroy();
        charts.countryBar = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: barLabels,
                datasets: [{
                    label: metricInfo.label,
                    data: barData.map(d => Number(d[metric] || 0)),
                    backgroundColor: barColors,
                    borderRadius: 4,
                    barPercentage: 0.7,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                onClick: (e, elements) => {
                    if (elements.length) {
                        const idx = elements[0].index;
                        drillDownCountry(barData[idx].country);
                    }
                },
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (ctx) => `${metricInfo.label}: ${metricInfo.format(ctx.raw)}${metric === 'avg_delivery_days' ? '' : ` (${fmtPct(ctx.raw, barTotal)})`}`,
                            afterLabel: (ctx) => {
                                const d = barData[ctx.dataIndex];
                                let extra = `${d.office?.label || '其他代表处'}\n${t('shipmentCount')}: ${Number(d.count || 0).toLocaleString()} ${t('orderUnit')}\n${t('weightLabel')}: ${Number(d.weight).toLocaleString()} kg`;
                                if (d.avg_delivery_days != null) {
                                    extra += '\n' + t('avgDelivery') + ': ' + d.avg_delivery_days + ' ' + t('workdays');
                                }
                                return extra;
                            }
                        }
                    }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { color: '#94a3b8', font: { size: 11 }, maxRotation: 45 } },
                    y: { grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8', callback: v => metricInfo.format(v).replace(' ' + t('orderUnit'), '') }, beginAtZero: true, title: { display: true, text: metricInfo.label, color: '#94a3b8' } }
                }
            }
        });

        const pieWrap = document.getElementById('country-office-pie-wrap');
        if (charts.countryOfficePie) {
            charts.countryOfficePie.destroy();
            charts.countryOfficePie = null;
        }
        if (pieWrap) pieWrap.style.display = sortMode === 'office_single' && barData.length ? 'block' : 'none';
        if (sortMode === 'office_single' && barData.length) {
            const selectedOffice = barData[0].office;
            const pieTitle = document.getElementById('country-office-pie-title');
            if (pieTitle) pieTitle.textContent = `${selectedOffice?.label || '代表处'}内部订单对比`;
            const pieTotal = barData.reduce((s, d) => s + Number(d.count || 0), 0);
            const pieCtx = document.getElementById('chart-country-office-pie').getContext('2d');
            charts.countryOfficePie = new Chart(pieCtx, {
                type: 'doughnut',
                data: {
                    labels: barData.map(d => ISO2_TO_NAME[d.country] || d.country),
                    datasets: [{
                        data: barData.map(d => Number(d.count || 0)),
                        backgroundColor: TTL_COLORS,
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    onClick: (e, elements) => {
                        if (elements.length) drillDownCountry(barData[elements[0].index].country);
                    },
                    plugins: {
                        legend: { position: 'right', labels: { color: '#94a3b8', padding: 10, font: { size: 11 } } },
                        tooltip: { callbacks: { label: ctx => `${ctx.label}: ${Number(ctx.raw || 0).toLocaleString()} ${t('orderUnit')} (${fmtPct(ctx.raw, pieTotal)})` } }
                    },
                    cutout: '52%'
                },
                plugins: [doughnutValueLabelPlugin(barData, d => ISO2_TO_NAME[d.country] || d.country, pieTotal)]
            });
        }
    }

    async function loadMonthlyChart() {
        const data = await apiFetch(API + '/api/dashboard/monthly_trend');
        applyMonthlyMetricSelection();
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        if (!selected.length) {
            document.querySelector('#monthlyMetricToggles input[value="count"]').checked = true;
            selected.push('count');
        }
        const metricConfig = {
            count: { label: t('shipmentCount'), field: 'count', type: 'bar', yAxisID: 'y', color: 'rgba(59,130,246,0.65)', border: '#3b82f6', order: 4, format: v => Number(v || 0).toLocaleString() },
            weight: { label: t('weightKg'), field: 'weight', type: 'line', yAxisID: 'y1', color: 'rgba(245,158,11,0.14)', border: '#f59e0b', order: 3, format: v => Number(v || 0).toLocaleString() + ' kg' },
            volume: { label: '体积 m³', field: 'volume', type: 'line', yAxisID: 'y2', color: 'rgba(6,182,212,0.12)', border: '#06b6d4', order: 2, format: v => Number(v || 0).toLocaleString(undefined, { maximumFractionDigits: 2 }) + ' m³' },
            price: { label: '费用', field: 'price', type: 'line', yAxisID: 'y3', color: 'rgba(34,197,94,0.12)', border: '#22c55e', order: 1, format: v => '$' + Number(v || 0).toLocaleString() }
        };
        const datasets = selected.map(key => {
            const cfg = metricConfig[key];
            return {
                label: cfg.label,
                data: data.map(d => Number(d[cfg.field] || 0)),
                type: cfg.type,
                backgroundColor: cfg.color,
                borderColor: cfg.border,
                borderWidth: cfg.type === 'line' ? 2 : 0,
                pointRadius: cfg.type === 'line' ? 4 : 0,
                pointBackgroundColor: cfg.border,
                borderRadius: cfg.type === 'bar' ? 6 : 0,
                fill: cfg.type === 'line',
                yAxisID: cfg.yAxisID,
                order: cfg.order,
                metricKey: key
            };
        });
        const ctx = document.getElementById('chart-monthly').getContext('2d');
        if (charts.monthly) charts.monthly.destroy();
        charts.monthly = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.map(d => d.month),
                datasets
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#94a3b8' } },
                    tooltip: { callbacks: { label: ctx => `${ctx.dataset.label}: ${metricConfig[ctx.dataset.metricKey]?.format(ctx.raw) || ctx.raw}` } }
                },
                scales: {
                    x: { grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8' } },
                    y: { display: selected.includes('count'), position: 'left', grid: { color: 'rgba(51,65,85,0.3)' }, ticks: { color: '#94a3b8' }, title: { display: true, text: t('shipmentCount'), color: '#94a3b8' } },
                    y1: { display: selected.includes('weight'), position: 'right', grid: { display: false }, ticks: { color: '#f59e0b', callback: v => Number(v).toLocaleString() + ' kg' }, title: { display: true, text: t('weightKg'), color: '#f59e0b' } },
                    y2: { display: selected.includes('volume'), position: 'right', grid: { display: false }, ticks: { color: '#06b6d4', callback: v => Number(v).toLocaleString() + ' m³' }, title: { display: true, text: '体积', color: '#06b6d4' } },
                    y3: { display: selected.includes('price'), position: 'right', grid: { display: false }, ticks: { color: '#22c55e', callback: v => '$' + Number(v).toLocaleString() }, title: { display: true, text: '费用', color: '#22c55e' } }
                }
            }
        });
    }

    function saveMonthlyMetricSelection() {
        const selected = [...document.querySelectorAll('#monthlyMetricToggles input:checked')].map(i => i.value);
        localStorage.setItem('vn12_monthly_metrics', JSON.stringify(selected.length ? selected : ['count']));
    }

    function applyMonthlyMetricSelection() {
        let saved = null;
        try { saved = JSON.parse(localStorage.getItem('vn12_monthly_metrics') || 'null'); } catch {}
        if (!Array.isArray(saved) || !saved.length) return;
        document.querySelectorAll('#monthlyMetricToggles input').forEach(input => {
            input.checked = saved.includes(input.value);
        });
    }
