// Shared list helpers. Keep business-specific filtering in page modules.
function listSetHasValue(el, value = undefined) {
    if (!el) return;
    const actual = value === undefined ? el.value : value;
    el.classList.toggle('has-value', Boolean(actual));
}

function listSetSelectValueState(id, value) {
    const el = document.getElementById(id);
    if (!el) return;
    el.value = value || '';
    listSetHasValue(el);
}

function listClearControls(ids = []) {
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        el.value = '';
        el.classList.remove('has-value');
    });
}

function listUpdateSortIndicators(selector, sortBy, sortDir, datasetKey = 'sort') {
    document.querySelectorAll(selector).forEach(th => {
        const key = th.dataset?.[datasetKey];
        th.classList.toggle('sort-asc', key === sortBy && sortDir === 'asc');
        th.classList.toggle('sort-desc', key === sortBy && sortDir === 'desc');
    });
}

function listPageCount(total, perPage) {
    return Math.max(1, Math.ceil(Number(total || 0) / Math.max(1, Number(perPage || 20))));
}

function listClampPage(page, pages) {
    return Math.min(Math.max(1, Number(page || 1)), Math.max(1, Number(pages || 1)));
}

function listSlicePage(rows, page, perPage) {
    const safeRows = Array.isArray(rows) ? rows : [];
    const safePage = listClampPage(page, listPageCount(safeRows.length, perPage));
    const size = Math.max(1, Number(perPage || 20));
    return {
        page: safePage,
        pages: listPageCount(safeRows.length, size),
        total: safeRows.length,
        rows: safeRows.slice((safePage - 1) * size, safePage * size)
    };
}

function listPaginationHtml({ total = 0, page = 1, pages = 1, prevAction = '', nextAction = '', lang = 'zh' } = {}) {
    const safePage = listClampPage(page, pages);
    const safePages = Math.max(1, Number(pages || 1));
    const info = lang === 'en'
        ? `${Number(total || 0).toLocaleString()} records, page ${safePage}/${safePages}`
        : `共 ${Number(total || 0).toLocaleString()} 条，第 ${safePage}/${safePages} 页`;
    const prev = lang === 'en' ? 'Previous' : '上一页';
    const next = lang === 'en' ? 'Next' : '下一页';
    return `<span style="font-size:12px;color:var(--text-secondary)">${info}</span><div class="pagination" style="margin:0"><button class="page-btn" onclick="${prevAction}" ${safePage <= 1 ? 'disabled' : ''}>${prev}</button><button class="page-btn" onclick="${nextAction}" ${safePage >= safePages ? 'disabled' : ''}>${next}</button></div>`;
}

function listRenderPagination(containerId, options) {
    const el = document.getElementById(containerId);
    if (el) el.innerHTML = listPaginationHtml(options);
}

function fillExcelFilterFromOptions(targetId, sourceId, allText = '全部') {
    const target = document.getElementById(targetId);
    const source = document.getElementById(sourceId);
    if (!target || !source) return;
    const current = new Set(Array.from(target.querySelectorAll('input[type="checkbox"]:checked')).map(o => o.value).filter(Boolean));
    const options = Array.from(source.options || []).filter(o => o.value).map(o => ({ value: o.value, label: o.textContent || o.value }));
    target.classList.add('excel-filter');
    target.dataset.allText = allText;
    target.innerHTML = `<button type="button" class="excel-filter-trigger" onclick="toggleExcelFilter(event, '${targetId}')">${escapeHtml(allText)}</button>
        <div class="excel-filter-menu" onclick="event.stopPropagation()">
            <input class="wms-input excel-filter-search" placeholder="搜索..." oninput="filterExcelOptions('${targetId}', this.value)">
            <div class="excel-filter-actions">
                <button class="btn btn-secondary btn-sm" type="button" onclick="setExcelFilter('${targetId}', true)">全选</button>
                <button class="btn btn-secondary btn-sm" type="button" onclick="setExcelFilter('${targetId}', false)">清空</button>
            </div>
            <div class="excel-filter-options">
                ${options.map(o => `<label class="excel-filter-option" data-filter-text="${escapeHtml(String(o.label).toUpperCase())}"><input type="checkbox" value="${escapeHtml(o.value)}" ${(!current.size || current.has(o.value)) ? 'checked' : ''} onchange="updateExcelFilterLabel('${targetId}')"> <span>${escapeHtml(o.label)}</span></label>`).join('')}
            </div>
        </div>`;
    updateExcelFilterLabel(targetId);
}

function toggleExcelFilter(event, id) {
    event.stopPropagation();
    document.querySelectorAll('.excel-filter.open').forEach(el => { if (el.id !== id) el.classList.remove('open'); });
    document.getElementById(id)?.classList.toggle('open');
}

function setExcelFilter(id, checked) {
    const el = document.getElementById(id);
    if (!el) return;
    el.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
    updateExcelFilterLabel(id);
}

function filterExcelOptions(id, value) {
    const el = document.getElementById(id);
    const q = String(value || '').trim().toUpperCase();
    if (!el) return;
    el.querySelectorAll('.excel-filter-option').forEach(option => {
        option.style.display = !q || (option.dataset.filterText || '').includes(q) ? '' : 'none';
    });
}

function excelFilterValue(id) {
    const el = document.getElementById(id);
    if (!el) return '';
    const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
    const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
    return (!values.length || values.length === all.length) ? '' : values.join(',');
}

function excelFilterLabel(id, allText = '全部') {
    const el = document.getElementById(id);
    if (!el) return allText;
    const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
    const values = all.filter(o => o.checked).map(o => o.closest('label')?.querySelector('span')?.textContent || o.value).filter(Boolean);
    if (!values.length || values.length === all.length) return allText;
    return values.length > 3 ? `${values.slice(0, 3).join(' / ')} 等 ${values.length} 项` : values.join(' / ');
}

function updateExcelFilterLabel(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const btn = el.querySelector('.excel-filter-trigger');
    if (btn) btn.textContent = excelFilterLabel(id, el.dataset.allText || '全部');
}

document.addEventListener('click', (event) => {
    if (!event.target.closest('.excel-filter')) {
        document.querySelectorAll('.excel-filter.open').forEach(el => el.classList.remove('open'));
    }
});

function fillCheckMultiFromOptions(targetId, sourceId) {
    const target = document.getElementById(targetId);
    const source = document.getElementById(sourceId);
    if (!target || !source) return;
    const current = new Set(Array.from(target.querySelectorAll('input[type="checkbox"]:checked')).map(o => o.value).filter(Boolean));
    target.innerHTML = Array.from(source.options || [])
        .filter(o => o.value)
        .map(o => `<label class="checkline"><input type="checkbox" value="${escapeHtml(o.value)}" ${(!current.size || current.has(o.value)) ? 'checked' : ''}> ${escapeHtml(o.textContent || o.value)}</label>`)
        .join('');
}

function setMultiCheck(id, checked) {
    const el = document.getElementById(id);
    if (!el) return;
    el.querySelectorAll('input[type="checkbox"]').forEach(cb => { cb.checked = checked; });
}

function multiCheckValue(id) {
    const el = document.getElementById(id);
    if (!el) return '';
    const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
    const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
    const total = all.length;
    return (!values.length || values.length === total) ? '' : values.join(',');
}

function multiCheckLabel(id, allText = '全部') {
    const el = document.getElementById(id);
    if (!el) return allText;
    const all = Array.from(el.querySelectorAll('input[type="checkbox"]'));
    const values = all.filter(o => o.checked).map(o => o.value).filter(Boolean);
    const total = all.length;
    if (!values.length || values.length === total) return allText;
    return values.length > 3 ? `${values.slice(0, 3).join('-')}等${values.length}项` : values.join('-');
}
