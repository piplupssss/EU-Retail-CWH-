// Shared display-only formatting helpers. Keep these pure and side-effect free.
function fmt$(value) {
    return value != null
        ? '$' + Number(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
        : '$0';
}

function fmtPct(value, total) {
    return total > 0 ? (value / total * 100).toFixed(1) + '%' : '-';
}

function formatNumber(value, options = {}) {
    return Number(value || 0).toLocaleString(undefined, options);
}

function formatCount(value) {
    return formatNumber(value);
}

function formatPln(value) {
    return Number(value || 0).toLocaleString('pl-PL', { minimumFractionDigits: 2 });
}

function formatUsd(value, options = {}) {
    const minimumFractionDigits = options.minimumFractionDigits ?? 2;
    const maximumFractionDigits = options.maximumFractionDigits ?? minimumFractionDigits;
    return '$' + Number(value || 0).toLocaleString('en-US', { minimumFractionDigits, maximumFractionDigits });
}

function formatUsdWhole(value) {
    return formatUsd(value, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}
