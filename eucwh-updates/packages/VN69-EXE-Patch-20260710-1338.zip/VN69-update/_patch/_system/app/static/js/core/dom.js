    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, ch => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[ch]));
    }
    function jsArg(value) {
        return JSON.stringify(String(value ?? ''));
    }
    function demandCountryOfShipment(s) {
        return String(s?.demand_country || s?.consignee_country_code || '').trim().toUpperCase();
    }
    function consigneeCountryOfShipment(s) {
        return String(s?.consignee_country_code || '').trim().toUpperCase();
    }
    function shipmentCountryDisplay(s) {
        const demand = demandCountryOfShipment(s);
        const consignee = consigneeCountryOfShipment(s);
        if (demand && consignee && demand !== consignee) {
            return `<span class="country-override" title="需求国家：${escapeHtml(demand)}；收货国家：${escapeHtml(consignee)}">${escapeHtml(demand)} → ${escapeHtml(consignee)} 收货</span>`;
        }
        return escapeHtml(demand || consignee || '');
    }

    const SIDEBAR_COLLAPSE_KEY = 'vn60_sidebar_collapsed';
    function applySidebarCollapse(forceCollapsed = null) {
        const collapsed = forceCollapsed === null ? localStorage.getItem(SIDEBAR_COLLAPSE_KEY) === '1' : forceCollapsed === true;
        document.body.classList.toggle('sidebar-collapsed', collapsed);
        const btn = document.getElementById('sidebarToggleBtn');
        if (btn) {
            btn.textContent = collapsed ? '›' : '☰';
            btn.title = collapsed ? '展开导航' : '折叠导航';
            btn.setAttribute('aria-label', btn.title);
        }
    }
    function toggleSidebarCollapse() {
        const next = document.body.classList.contains('sidebar-collapsed') ? '0' : '1';
        localStorage.setItem(SIDEBAR_COLLAPSE_KEY, next);
        applySidebarCollapse();
        setTimeout(() => {
            if (document.getElementById('page-logistics')?.classList.contains('active')) {
                Object.values(charts || {}).forEach(chart => chart?.resize?.());
            }
        }, 180);
    }
    function expandSidebarOnEntry() {
        localStorage.setItem(SIDEBAR_COLLAPSE_KEY, '0');
        applySidebarCollapse(false);
    }

    function showToast(msg, type = 'error') {
        toast(msg, type === 'success' ? 'success' : type === 'error' ? 'error' : 'info');
    }

    function toast(msg, type = 'success') { const t = document.getElementById('toast'); t.textContent = msg; t.className = 'toast toast-' + type + ' show'; setTimeout(() => t.classList.remove('show'), 3000); }
    function openModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.style.display = '';
        el.classList.add('show');
        applyFallbackEnglish(el);
    }
    function closeModal(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('show');
        el.style.display = '';
    }
    function resolveTarget(target) {
        return typeof target === 'string' ? document.getElementById(target) : target;
    }
    function setElementHtml(target, html) {
        const el = resolveTarget(target);
        if (el) el.innerHTML = html;
    }
    function tableStateRow(colspan, message, tone = 'muted', padding = 24) {
        const stateClass = tone === 'error' ? 'is-error' : 'is-muted';
        return `<tr class="table-state-row ${stateClass}"><td colspan="${Number(colspan) || 1}" style="--state-padding:${Number(padding) || 24}px">${message}</td></tr>`;
    }
    function setTableLoading(target, colspan, message = '加载中...', padding = 24) {
        setElementHtml(target, tableStateRow(colspan, escapeHtml(message), 'muted', padding));
    }
    function setTableEmpty(target, colspan, message, padding = 24) {
        setElementHtml(target, tableStateRow(colspan, escapeHtml(message), 'muted', padding));
    }
    function setTableError(target, colspan, message, padding = 24) {
        setElementHtml(target, tableStateRow(colspan, escapeHtml(message), 'error', padding));
    }
    function setPanelLoading(target, message = '加载中...', padding = 28) {
        setElementHtml(target, `<div style="padding:${Number(padding) || 28}px;color:var(--text-secondary)">${escapeHtml(message)}</div>`);
    }
    function setPanelError(target, title, detail = '', hint = '') {
        setElementHtml(target, `<div style="padding:28px;color:var(--danger);line-height:1.8"><b>${escapeHtml(title)}</b>${detail ? `<br>${escapeHtml(detail)}` : ''}${hint ? `<br><span style="color:var(--text-secondary)">${escapeHtml(hint)}</span>` : ''}</div>`);
    }
    function applyUnifiedUi(scope = document) {
        const root = scope && scope.querySelectorAll ? scope : document;
        root.querySelectorAll('div[style*="overflow-x:auto"], div[style*="overflow-x: auto"]').forEach(div => {
            if (div.querySelector(':scope > table')) div.classList.add('ui-table-scroll');
        });
        root.querySelectorAll('.table-section > table').forEach(table => {
            if (table.parentElement?.classList.contains('ui-table-scroll')) return;
            const wrap = document.createElement('div');
            wrap.className = 'ui-table-scroll';
            table.parentNode.insertBefore(wrap, table);
            wrap.appendChild(table);
        });
        root.querySelectorAll('.table-section, .chart-card, .stat-card, .settings-panel, .report-card, .import-section').forEach(el => {
            el.classList.add('ui-surface');
        });
    }
    function showImage(path, remark = '') {
        if (!path) return;
        hideImagePopover();
        const img = document.getElementById('imgModalSrc');
        img.classList.remove('zoomed');
        img.src = imageUrl(path);
        document.getElementById('imgModalHint').textContent = remark ? `备注：${remark}` : '单击背景关闭';
        document.getElementById('imgModal').classList.add('show');
    }
    document.addEventListener('click', (evt) => {
        const img = evt.target.closest('[data-detail-image]');
        if (!img) return;
        evt.preventDefault();
        evt.stopPropagation();
        if (evt.stopImmediatePropagation) evt.stopImmediatePropagation();
        showImage(img.dataset.imagePath || '', img.dataset.remark || '');
    }, true);
    function closeImageModal() { document.getElementById('imgModal').classList.remove('show'); document.getElementById('imgModalSrc').classList.remove('zoomed'); }
    function showImagePopover(evt, path, remark = '') {
        if (!path) return;
        const pop = document.getElementById('imagePopover');
        const img = document.getElementById('imagePopoverSrc');
        const remarkEl = document.getElementById('imagePopoverRemark');
        img.src = imageUrl(path);
        remarkEl.textContent = remark || '无备注';
        pop.classList.add('show');
        moveImagePopover(evt);
    }
    function moveImagePopover(evt) {
        const pop = document.getElementById('imagePopover');
        if (!pop.classList.contains('show')) return;
        const margin = 18;
        let left = evt.clientX + margin;
        let top = evt.clientY + margin;
        const rect = pop.getBoundingClientRect();
        if (left + rect.width > window.innerWidth - 12) left = evt.clientX - rect.width - margin;
        if (top + rect.height > window.innerHeight - 12) top = window.innerHeight - rect.height - 12;
        pop.style.left = Math.max(12, left) + 'px';
        pop.style.top = Math.max(12, top) + 'px';
    }
    function hideImagePopover() {
        const pop = document.getElementById('imagePopover');
        if (pop) pop.classList.remove('show');
    }
    function bindStockImagePreviewEvents() {
        const containers = [
            document.getElementById('stockTableBody'),
            document.getElementById('invDashContent')
        ].filter(Boolean);
        containers.forEach(container => {
            if (container.dataset.previewBound === '1') return;
            container.dataset.previewBound = '1';
            container.addEventListener('mouseover', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                showImagePopover(evt, img.dataset.imagePath, img.dataset.remark || '');
            });
            container.addEventListener('mousemove', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                moveImagePopover(evt);
            });
            container.addEventListener('mouseout', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                const next = evt.relatedTarget;
                if (next && img.contains(next)) return;
                hideImagePopover();
            });
            container.addEventListener('click', (evt) => {
                const productTarget = evt.target.closest('[data-product-detail]');
                if (productTarget && container.contains(productTarget)) {
                    evt.preventDefault();
                    evt.stopPropagation();
                    openProductDetail(productTarget.dataset.productDetail || '');
                    return;
                }
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                evt.preventDefault();
                showImage(img.dataset.imagePath, img.dataset.remark || '');
            });
            container.addEventListener('dblclick', (evt) => {
                const img = evt.target.closest('.stock-thumb, .inventory-action-thumb');
                if (!img || !container.contains(img)) return;
                evt.preventDefault();
                showImage(img.dataset.imagePath, img.dataset.remark || '');
            });
        });
    }

    function bindStockListImagePreviewEvents() {
        const tbody = document.getElementById('stockTableBody');
        if (!tbody || tbody.dataset.stockListPreviewBound === '1') return;
        tbody.dataset.stockListPreviewBound = '1';
        tbody.addEventListener('mouseover', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            showImagePopover(evt, img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('mousemove', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            moveImagePopover(evt);
        });
        tbody.addEventListener('mouseout', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            const next = evt.relatedTarget;
            if (next && img.contains(next)) return;
            hideImagePopover();
        });
        tbody.addEventListener('click', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            evt.preventDefault();
            showImage(img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('dblclick', (evt) => {
            const img = evt.target.closest('.stock-thumb');
            if (!img || !tbody.contains(img)) return;
            evt.preventDefault();
            showImage(img.dataset.imagePath, img.dataset.remark || '');
        });
        tbody.addEventListener('click', (evt) => {
            const target = evt.target.closest('[data-product-detail]');
            if (!target || !tbody.contains(target)) return;
            const productNumber = target.dataset.productDetail || '';
            evt.preventDefault();
            evt.stopPropagation();
            openProductDetail(productNumber);
        });
    }
    document.addEventListener('click', (evt) => {
        const target = evt.target.closest('[data-product-detail]');
        if (!target) return;
        if (target.closest('#stockTableBody') || target.closest('#invDashContent')) return;
        const productNumber = target.dataset.productDetail || '';
        if (!productNumber) return;
        evt.preventDefault();
        openProductDetail(productNumber);
    });
    // ===== 时钟 =====
    function updateClock() {
        const now = new Date();
        const opts = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZoneName: 'short' };
        document.getElementById('clock').textContent = now.toLocaleString(currentLang === 'en' ? 'en-GB' : 'zh-CN', opts);
    }
    setInterval(updateClock, 1000);
    document.addEventListener('DOMContentLoaded', () => { applyTheme(); applyLanguage(); expandSidebarOnEntry(); });
