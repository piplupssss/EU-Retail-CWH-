# Engineering Stabilization Plan

Last updated: 2026-07-08 CEST

This plan keeps cleanup work aligned with the VN65+ direction: make the system
easier to maintain, safer to package, and less likely to regress core business
rules. It is not a UI redesign plan.

## Current Baseline

- Raw project size: 90.3 MB
- Raw VN8 size: 11.7 MB
- Scanned project source size excluding caches/generated artifacts: 32.2 MB
- Scanned VN8 source size excluding caches/generated artifacts: 6.9 MB
- Clean program package plan from `release_manifest.json`: 97 files, 1.9 MB before embedded runtime
- Excluded by clean-package rules in current source: 28 files, 5.0 MB

Largest maintenance hotspots:

- `app/static/css/pages.css`
- `app/static/index.html`
- `app/static/js/pages/inventory-dashboard.js`
- `app/static/js/pages/reports.js`
- `app/static/js/pages/shipment-list.js`
- `app/static/version_changelog.json`
- `app/static/js/pages/logistics-dashboard.js`
- `app/static/js/pages/stock-list.js`
- `app/inventory_service.py`
- `app/static/css/components.css`
- `app/static/js/pages/data-management.js`
- `app/static/js/app.js`

Largest package-risk sources:

- Uploaded supplier Excel/PDF files under `app/data/uploads/`
- Local SQLite databases under `app/data/`
- SQLite backups under `app/data/backups/`
- Runtime product images under `app/static/images/`
- Old parallel project copies under sibling folders such as `claw/` and `eu-retail-cwh-system/`

## Completed Foundation

- Version, build time, update source, and security note are centralized in `app/static/release_info.json`.
- `release_config.py` uses neutral fallback values; the real runtime version metadata is expected to come from `app/static/release_info.json`.
- Backend update service reads release metadata through `app/release_config.py`.
- Frontend reads the same release metadata on startup.
- Export fallback filenames use `APP_VERSION` instead of a hard-coded old version.
- `release_manifest.json` defines clean program package include/exclude rules.
- `tools/validate_release_manifest.py` validates the manifest and checks clean-package violations.
- `tools/smoke_check.py` provides read-only core route coverage.
- `tools/engineering_gate.py` now runs the local engineering gate: Python syntax, JSON syntax, release metadata consistency, JavaScript syntax, release manifest validation, update-package dry-run contract validation, and optional read-only smoke checks.
- `tools/build_clean_package.py` now builds a clean program-only package directory from `release_manifest.json`, running the engineering gate first and validating the output directory afterward.
- `tools/build_update_package.py` now assembles GitHub-compatible update packages from the clean program package. Dry-run mode validates the release path without emitting `latest.json`; real package mode requires a Windows `upgrade_to_*.exe` and writes SHA256 metadata.
- `tools/build_update_package.py` uses a temporary clean-program staging directory, so it no longer races with `tools/build_clean_package.py --clean` over `artifacts/clean_program`.
- `tools/workspace_hygiene.py` now reports workspace bloat candidates without deleting anything, separating regeneratable outputs, runtime business data, release staging, and old parallel project copies.
- `routes_core_backup.py` has been reduced to an HTTP-only route layer; workbook generation, ZIP creation, backup restore parsing, image restore, and table upserts now live in `core_backup_service.py`.
- `routes_inventory_movements.py` has been reduced to an HTTP-only route layer; list filtering, sorting, export row preparation, and movement workbook generation now live in `inventory_movement_service.py`.
- Invoice upload import logic now lives in `invoice_service.py`; invoice type detection, PDF parsing, acceptance preservation, shipment matching, and database writes are separated from the HTTP upload route.
- `db.py` first-pass split is underway: Flask connection/session helpers now live in `db_connections.py`, point-in-time SQLite backup creation now lives in `db_backup.py`, schema SQL now lives in `db_schema.py`, reusable column-migration helpers now live in `db_migrations.py`, and WMS post-schema data normalization now lives in `db_normalization.py`. `app.db` still re-exports the old function names for compatibility.
- Frontend blob download, filename parsing, and fallback download naming now share helpers in `app/static/js/core/api.js`.
- Export downloads now use short Windows-safe filenames by default; long filter labels stay inside exported files instead of being embedded in the downloaded filename.
- Frontend list control helpers now live in `app/static/js/core/list-utils.js`; logistics, inventory, movement, and acceptance list pages share sort indicator, filter-state, pagination, and page-slicing helpers where safe.
- Frontend export filter controls now share multi-select helpers in `app/static/js/core/list-utils.js`; stock export, movement export, and report inventory filters no longer depend on `stock-list.js` owning shared UI helpers.
- Frontend table and modal state helpers now live in `app/static/js/core/dom.js`; selected list pages and Product No detail use shared loading, empty, and error renderers where behavior is equivalent.
- Frontend inventory utilities now live in `app/static/js/core/inventory-utils.js`; inventory constants, stock update time formatting, image path resolution, BOM Code display rules, inventory grouping, and risk-level helpers are shared outside the inventory dashboard page script.
- Frontend display formatting helpers now live in `app/static/js/core/format-utils.js`; shared money, PLN, USD, count, and percentage formatting stays pure and keeps existing display output stable.
- Report page number and whole-USD formatting now calls `app/static/js/core/format-utils.js` directly instead of wrapping shared helpers locally.
- Report display helpers now live in `app/static/js/core/report-utils.js`; month labels, report bar rows, inventory Top cards, logistics report rows, report map SVG, trend blocks, and dashboard country rows are no longer embedded in `reports.js`.
- Inventory dashboard presentation helpers now live in `app/static/js/core/inventory-dashboard-utils.js`; heatmap, decision cards, priority panels, action rows, risk snapshots, and health panels are no longer embedded in `inventory-dashboard.js`.
- Frontend logistics display helpers now live in `app/static/js/core/logistics-utils.js`; status/type labels and colors are shared by logistics dashboard and reports without changing business status rules.
- Frontend logistics country metadata now lives in `app/static/js/core/logistics-utils.js`; ISO2/ISO3 mapping, Europe map IDs, and representative-office mapping are shared by logistics dashboard, reports, and invoice dashboard instead of being owned by one page script.
- `tools/engineering_gate.py` now checks that every `app/static/js/core/*.js` helper is loaded by `app/static/index.html`, preventing a helper split from passing syntax checks but failing at runtime because the script tag was forgotten.

## Phase A: Packaging Guardrails

Goal: make it hard to accidentally ship user data, old executables, update cache,
or source files.

Actions:

- Keep `release_manifest.json` as the source of truth for clean program packages.
- Run `python3 tools/build_clean_package.py --clean` for program-only source packages.
- The builder runs `tools/engineering_gate.py` before copying files unless explicitly skipped.
- The builder validates the generated package directory with the release manifest after copying.
- Run `python3 tools/build_update_package.py --dry-run` before GitHub update releases to validate the clean program package and derived release URL. This uses temporary clean-program staging and does not overwrite `artifacts/clean_program`.
- Run `python3 tools/build_update_package.py --updater-exe <path-to-upgrade_to_vnxx.exe>` only when a real Windows updater executable is available. This emits `artifacts/update_packages/latest.json` and a ZIP with one top-level directory.
- Keep `python3 tools/validate_release_manifest.py --package-root <package_dir>` for any package generated outside this builder.
- Add the builder or validator to any future GitHub release workflow.
- Keep business backups data-only: `core_backup_no_images.xlsx` plus `images/`.
- Use `python3 tools/workspace_hygiene.py --markdown docs/VN65_WORKSPACE_HYGIENE.md --json docs/VN65_WORKSPACE_HYGIENE.json` before manual cleanup so old outputs, runtime data, and parallel project folders are not mixed together.

Success criteria:

- Program package contains application code and runtime only.
- Business data is restored separately.
- Package validation fails if it contains `.db`, uploaded source files, images, old EXE files, old BAT/VBS launchers, ZIPs, or updater cache.
- GitHub update package generation fails unless the updater EXE exists and the ZIP contains exactly one `upgrade_to_*.exe`.
- Current clean program source package output: `artifacts/clean_program/VN65_clean_program`, 97 files, 1.9 MB, 0 package violations.
- Workspace hygiene reports identify cleanup candidates by risk class before anything is removed.

## Phase B: Backend Service Split

Goal: keep routes thin and move business logic into testable services.

Priority order:

1. `routes_core_backup.py` - completed first split
   - Workbook generation now lives in `core_backup_service.py`.
   - Full-package ZIP creation now lives in `core_backup_service.py`.
   - Import/restore parsing now lives in service functions.
   - HTTP upload/download response handling remains in the route.

2. `routes_inventory_movements.py` - completed first split
   - Movement query, filtering, sorting, and pagination now live in `inventory_movement_service.py`.
   - Movement export workbook generation now lives in `inventory_movement_service.py`.
   - HTTP response formatting remains in the route.

3. `db.py`
   - Completed first pass: database connection/session helpers moved to `db_connections.py`.
   - Completed first pass: point-in-time SQLite backup helper moved to `db_backup.py`.
   - Completed first pass: schema SQL moved to `db_schema.py`.
   - Completed first pass: repeated column migration helpers moved to `db_migrations.py`.
   - Completed first pass: WMS post-schema normalization moved to `db_normalization.py`.
   - Next: only split the remaining shipment/invoice migration block if new work touches it; otherwise shift priority to the larger frontend hotspots.
   - Avoid changing table structure during this phase.

4. Invoice acceptance logic
   - Completed first pass: invoice upload parsing, invoice type detection, preserved acceptance fields, shipment matching, and database import now live in `invoice_service.py`.
   - Keep acceptance workbook building and calibration import in separate services.
   - Maintain the current Excel schema.

Success criteria:

- Route files mostly contain endpoint definitions and request/response code.
- Service functions can be called by smoke tests or targeted unit tests without HTTP.
- Existing import/export/calibration outputs stay byte-compatible where format matters.

## Phase C: Frontend Structure Cleanup

Goal: reduce repeated list, modal, export, and filter logic without another UI reset.

Priority order:

1. Shared list utilities
   - Completed first pass: filter-state class toggling, sort indicators, simple previous/next pagination, page counts, page clamping, and front-end page slicing are centralized in `app/static/js/core/list-utils.js`.
   - Completed second pass: Excel-style multi-select filters and checkbox multi-select helpers are centralized in `app/static/js/core/list-utils.js`.
   - Logistics, inventory, movement, and acceptance pages now use shared helpers where behavior is equivalent.
   - Keep current logistics, inventory, movement, and acceptance page behavior. Do not change the approved list layouts during cleanup.

2. Shared modal helpers
   - Completed first pass: Product No detail and selected list/recycle-bin states now use shared loading, empty, and error helpers from `app/static/js/core/dom.js`.
   - Next: shipment detail, export dialog, confirmation dialog, and risk prompt.

3. Shared export helpers
   - Completed first pass: API blob download, local blob download, filename parsing, and fallback file naming are centralized in `app/static/js/core/api.js`.
   - Completed second pass: `stock-list.js` no longer wraps `downloadApiBlob` through a local duplicate `downloadBlobEndpoint` helper.
   - Logistics, inventory, movement, full backup, overdue report, and report HTML/PNG downloads now reuse the shared helpers.

4. Shared inventory utilities
   - Completed first pass: inventory constants, stock update time formatting, image path resolution, and BOM Code display rules are centralized in `app/static/js/core/inventory-utils.js`.
   - Completed second pass: inventory dimension definitions, group aggregation, group positioning, and risk-level classification are centralized in `app/static/js/core/inventory-utils.js`.
   - Inventory dashboard, stock list, and reports reuse the same helper definitions.
   - Keep these helpers pure; do not move supplier refresh, inventory calibration, or SKU relationship rules into frontend utilities.

5. Shared display formatting utilities
   - Completed first pass: shared money, PLN, USD, count, and percentage formatters are centralized in `app/static/js/core/format-utils.js`.
   - Completed second pass: report page local money/count wrappers were removed; report rendering now uses shared formatting helpers directly.
   - Invoice dashboard, acceptance list, and report center now reuse the shared display helpers for repeated amount cells and summaries.
   - Keep these helpers display-only; do not move inventory calculation, Excel parsing, or business validation into frontend formatting utilities.

6. Shared report rendering utilities
   - Completed first pass: report month labels, report bar rows, inventory Top cards, logistics report rows, report map SVG, trend blocks, and dashboard country rows are centralized in `app/static/js/core/report-utils.js`.
   - `reports.js` now keeps report options, API loading, live Leaflet/Chart rendering, and export orchestration while pure report HTML helpers live in core.
   - Keep these helpers display-only; do not move PDF/HTML/PNG export flows, API calls, inventory calculations, or Excel export rules into frontend report utilities.

7. Shared inventory dashboard presentation utilities
   - Completed first pass: heatmap, inventory decision cards, risk snapshot cards, priority panels, action rows, and health panels are centralized in `app/static/js/core/inventory-dashboard-utils.js`.
   - `inventory-dashboard.js` now keeps inventory data loading, tab behavior, Chart rendering, overdue table flows, and settings persistence while pure dashboard HTML helpers live in core.
   - Keep these helpers display-only; do not move supplier refresh, calibration, inventory calculation, or stock-list navigation rules into this layer.

8. Shared logistics display utilities
   - Completed first pass: logistics status/type labels and colors are centralized in `app/static/js/core/logistics-utils.js`.
   - Logistics dashboard and reports now use the same display helpers without relying on page script side effects.
   - Completed second pass: country code mapping, Europe map IDs, and representative-office mapping are centralized in `app/static/js/core/logistics-utils.js`.
   - Logistics dashboard, reports, and invoice dashboard now share the same representative-office display metadata.
   - Keep these helpers display-only; do not move shipment import, verification, or manual status protection logic into frontend utilities.

9. CSS reduction
   - Move repeated page-specific rules from `pages.css` into component-level classes.
   - Do not redesign approved logistics/inventory list layouts.

Success criteria:

- Logistics list and inventory list remain visually unchanged unless a bug is fixed.
- New list pages reuse shared helpers instead of copying logic.
- `pages.css` shrinks over time instead of growing with every patch.

## Phase D: Test Gates

Goal: prevent high-risk regressions before packaging.

Required gates:

- Primary command before package/update work:
  `EUCWH_SMOKE_USER=<user> EUCWH_SMOKE_PASS=<password> python3 tools/engineering_gate.py`
- If smoke credentials are unavailable, run:
  `python3 tools/engineering_gate.py --skip-smoke`
- The gate currently covers Python syntax, JSON syntax, release metadata consistency, JavaScript syntax, frontend core script loading, release manifest validation, update-package dry-run contract validation, and read-only smoke checks when credentials are present.
- For clean program package generation, run:
  `EUCWH_SMOKE_USER=<user> EUCWH_SMOKE_PASS=<password> python3 tools/build_clean_package.py --clean`
- For GitHub update package validation without emitting a release ZIP, run:
  `EUCWH_SMOKE_USER=<user> EUCWH_SMOKE_PASS=<password> python3 tools/build_update_package.py --dry-run`
- For a real GitHub update package, run:
  `EUCWH_SMOKE_USER=<user> EUCWH_SMOKE_PASS=<password> python3 tools/build_update_package.py --updater-exe <path-to-upgrade_to_vnxx.exe>`
- Keep `python3 tools/validate_release_manifest.py --package-root <package_dir>` for validating a finished Windows package directory.
- For read-only workspace bloat analysis, run:
  `python3 tools/workspace_hygiene.py --markdown docs/VN65_WORKSPACE_HYGIENE.md --json docs/VN65_WORKSPACE_HYGIENE.json`

Future targeted tests:

- Core backup export/import preserves manual logistics statuses.
- Supplier inventory refresh only updates stock quantity for existing SKU.
- BOM Code `/` or empty uses Product Number for image matching and does not create false SKU relationships.
- Excel export/import schemas remain stable.

## Non-Negotiable Constraints

- Do not change database structure as part of cleanup unless explicitly planned.
- Do not change Excel import/export field names or sheet order during cleanup.
- Do not change image matching rules during packaging or structure cleanup.
- Do not overwrite manual logistics statuses during imports or backup restore.
- Do not package business data into clean program releases.
- Do not require Windows users to install Python.

## Next Recommended Work

Continue with low-risk frontend cleanup: reduce `pages.css`, `index.html`, and
large page scripts by extracting shared page sections and component styles. Keep
the approved list layouts stable, and verify with the same engineering gate
before any package or update work.
