# VN12 Windows Codex Full Handover

Last updated: 2026-05-28 CEST

This document is for continuing development on the user's Windows PC with Codex.

## User And Project Context

- User: Qiteng Liu, Huawei Europe/RHQ retail materials/logistics context.
- Internal identifier shown in app: Qiteng Liu 84405995.
- Work email previously used: qitengliu@h-partners.com.
- The app is a local warehouse/logistics dashboard for retail materials.
- It must run locally on the user's work computer. Uploads and data processing should stay local.
- The work computer may restrict uploading files to external websites, so offline/local operation matters.
- The user wants to continue developing this project with Codex on Windows.

## Current Version State

- Current version family: VN12.
- Current status: VN12 stage 3/debug development, not yet Windows packaging stage.
- Fourth-stage Windows offline/exe packaging is intentionally paused.
- Current local app URL on Mac: http://127.0.0.1:5001/
- Login:
  - Username: Qiteng
  - Password: 84405995
- Delete uploaded source file password in Data Maintenance Center:
  - Q84405995

## Important Backups

- Main debug checkpoint:
  - backups/VN12_stage3_debug_20260518_235141.zip
  - backups/VN12_stage3_debug_20260518_235141/project
- Earlier VN11 baseline:
  - backups/VN11_20260505_0003_pre_improvements_20260516.zip
  - backups/VN11_20260505_0003_pre_improvements_20260516/project
- Backup index:
  - BACKUP_INDEX.md

## Core Business Rules

### Inventory Identity

- Inventory standard/key: Product Number.
- Warehouse inventory is keyed by:
  - Warehouse + Product Number
- Product Number means the warehouse/CWH actual SKU/product number.
- Bom Code means HQ/material BOM code.
- The same physical item can have different Product Numbers because Instruction/country prefixes are added, for example:
  - RHQ_
  - DE_
  - PL_
- Example:
  - Bom Code: 97150203
  - Product Numbers: RHQ_97150203, DE_97150203, PL_97150203
- Inventory must not be grouped by Bom Code.
- Images are matched by Bom Code filename.

### Image Rules

- Image matching key: Bom Code.
- Image filename should equal Bom Code, with image extension.
- Example:
  - 97150203.jpg
  - 51006155.png
- Product Number can vary by instruction, but the picture remains Bom Code based.

### Category Rules

- Category, Category 2, and Instruction should be treated case-insensitively and normalized to uppercase.
- Category examples:
  - Acrylic Prop
  - Dummy
  - Furniture
  - Gift
  - Prop
  - Security system
  - Tools/accessories
  - Training materials
  - Uniform
  - wooden overlay
- Category 2 examples:
  - Audio
  - IOT
  - Other
  - Phone
  - Tablet
  - Wearable
- Instruction examples:
  - DE
  - Italy
  - PL
  - RHQ
  - UK
  - ES

## Inventory Upload Design

Inventory upload is a two-file import:

1. Supplier inventory file
2. Inventory maintenance file

The old Stock List upload is disabled because it conflicts with Product Number based inventory.

### Supplier Inventory File

Example:
- artifacts/templates/supplier_inventory_sample.xlsx

Supplier may send an original Excel with report title/merged rows before the real header. The importer auto-detects the header row.

Required columns:
- Product Number
- Instruction
- Category
- Category 2
- Product Description
- Sum of Quantity

Other seen columns:
- Unit of Measure
- Held Code

### Inventory Maintenance File

Example:
- artifacts/templates/inventory_maintenance_template.xlsx

Required columns:
- Product Number
- Bom Code
- Unit Price
- Last Inbound Date
- Last Outbound Date
- Remark
- DOS Threshold
- Idle Threshold

### Inventory Import Behavior

- Supplier inventory gives current stock quantity.
- Maintenance file gives Bom Code, price, dates, remark, and thresholds.
- Files join by Product Number.
- Import refreshes/calibrates current inventory snapshot.
- It is not append-only transaction import.
- Uploading the correct file again refreshes inventory.
- If a wrong inventory file is imported, safest recovery is re-upload the correct supplier inventory + maintenance file or restore from backup.

## Logistics Upload Design

Logistics files are imported from eSchenker Excel exports.

Current logic:
- New Booking ID: insert.
- Existing Booking ID/STT: update Excel/base logistics fields.
- Protected verification fields are preserved:
  - actual_delivery_date
  - delivery_locked
  - manual_status
  - last_checked

This was fixed because earlier logic deleted/reinserted unlocked duplicates, risking loss of manual/auto verification state.

Version 2 file with 10 additional rows:
- The system reads all rows in version 2.
- Existing rows are updated safely.
- Only new Booking IDs are inserted.
- Database should not duplicate old rows.

Date parsing note:
- European date strings such as 03.01.2026 10:00 are parsed before MIN_DATE filtering.

## Invoice Upload Design

- Invoice upload is currently for logistics invoices.
- Warehouse/operation fee invoices are planned for later.
- Re-uploading the same invoice number updates invoice rows.
- If the invoice content is unchanged, preserve verified status.
- If content changes, safer behavior is pending status.
- Invoice data links to shipment by STT/Booking ID.

## Data Maintenance Center

Navigation now has one data import entry:
- Data Maintenance Center

It has tabs:
- Logistics Data
- Inventory & Images
- Invoice Acceptance

It also shows current uploaded source files:
- filename
- type
- size
- modified time
- linked shipment records
- linked invoice records
- file status
- delete source file button

Deleting a source file:
- Requires password Q84405995.
- Deletes only the source file.
- Does not rollback business data.

Important distinction:
- Delete source file != undo import.
- Proper rollback needs import batches/change logs or database restore.

## Dashboards

### Logistics Dashboard

Implemented:
- Status distribution with percentages.
- Type distribution with percentages.
- Country demand distribution with percentages.
- Monthly shipment trend with selectable metrics:
  - shipment count
  - weight
  - volume
  - cost
- Monthly metric selection is remembered.

### Inventory Dashboard

Implemented:
- One selectable breakdown view:
  - Category
  - Category 2
  - Instruction
- Similar UX to monthly shipment trend.
- DOS and Idle remain separate tabs.
- Category/Category2/Instruction charts include:
  - value chart
  - PCS chart
  - detail table with value share and PCS share
- DOS/Idle support category-specific thresholds.
- DOS/Idle export reports include value and PCS.

### Cost Acceptance Dashboard

Implemented:
- Annual budget view.
- Accepted logistics amount.
- Pending logistics amount.
- Remaining budget.
- Invoice matching rate.
- Invoice list and detail.

Warehouse and operation fee modules are not complete and are planned later.

## Lists

### Shipment List

Implemented:
- Shows acceptance/verification status.
- Shows accepted amount for verified shipments.
- Hovering accepted amount can show invoice number.

### Inventory List

Implemented:
- Condensed columns for short fields:
  - Bom Code
  - image
  - Product No
  - Category
  - Category 2
  - Instruction
  - Inventory
- Product Description remains wider.
- Remark column added.
- Hover image preview with remark.
- Click/double-click image opens large modal.
- Large modal defaults to 96vw x 92vh contain.
- Background click and X close modal.
- Pagination size selector: 20/50/100.

### Cost List

Implemented:
- Single aggregated API for invoice items instead of one request per invoice.
- Status filter:
  - all
  - pending
  - verified
  - rejected
- Summary includes total, matched count, pending/verified counts, PLN and USD totals.

## Settings

Implemented:
- Category option maintenance.
- Category 2 option maintenance.
- Instruction option maintenance.
- Category-based DOS and idle threshold maintenance.
- Default language.
- Default warehouse.
- Theme toggle moved to top right next to language toggle:
  - dark/night
  - light/day
- One-click export controls.

## Exports

One-click full export endpoint:
- /api/export/full

ZIP contains:
- inventory.csv
- logistics_shipments.csv
- invoice_acceptance.csv
- README.txt
- images/

inventory.csv columns:
- Warehouse
- Bom Code
- Product Number
- Product Description
- Category
- Category 2
- Instruction
- Inventory
- Unit Price
- TTL Amount
- Last Inbound
- Last Outbound
- DOS
- Idle Days
- Comment
- Photo File

Image files are not embedded into CSV. Photo File points to images/<filename> in the ZIP.

## Current Data Snapshot At Migration Time

At the time this handover was written, local DB counts were:
- Shipments: 209
- Invoice headers: 1
- Invoice items: 33
- Product master rows: 20
- Warehouse inventory rows: 20
- SKU images matched: 10

## Windows Packaging Lessons From Previous Attempts

Important mistakes to avoid:

- Do not rely on online pip install on the user's Windows work PC.
- Offline wheelhouse previously missed platform-specific packages such as:
  - tzdata
  - colorama
- Previous package had ModuleNotFoundError: app because layout/run.py import path was wrong.
- User prefers exe if the work PC has no Python.
- If using embedded Python, ensure app package is in the same root as run.py or sys.path is correctly set.
- setup_offline.bat and start_vn8.bat must be tested on a clean Windows machine or VM.
- Package should keep program and data separable.

## Recommended Windows Development Setup

For Codex development on Windows:

1. Extract the full migration ZIP.
2. Open the extracted vn8 folder in Windows Codex.
3. If Python is installed:

```bat
cd vn8
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

4. Open:

```text
http://127.0.0.1:5001/
```

5. Login:

```text
Username: Qiteng
Password: 84405995
```

## Recommended Next Development Priorities

Do not package exe yet until debug safety is stronger.

Suggested next steps:

1. Add import batch tables:
   - import_batches
   - import_changes
2. For each upload, record:
   - upload time
   - file name
   - type
   - inserted count
   - updated count
   - skipped/error count
   - affected keys
3. Add upload history detail view.
4. Add safe rollback:
   - invoice delete is safe
   - image delete is safe
   - logistics can undo newly inserted rows
   - logistics updates need before-change snapshot
   - inventory should use pre-import backup restore
5. Add data quality checks:
   - missing Product Number
   - missing maintenance rows
   - missing images
   - duplicate BOM/Product Number anomalies
   - unmatched invoice STTs
   - zero/blank cost fields
6. After debug safety, create Windows dev package and then exe/offline package.

## Files/Folders To Preserve

Preserve these for full continuity:
- app/
- app/data/warehouse.db
- app/data/wms.db
- app/data/uploads/
- app/static/images/
- artifacts/
- build_spreadsheets/
- backups/
- BACKUP_INDEX.md
- IMPROVEMENT_REQUESTS.md
- deploy_windows.md
- run.py
- start.bat
- start_embedded.bat
- requirements.txt
- docs/

Do not rely on WAL/SHM files. Checkpoint DB before migration and exclude:
- *.db-wal
- *.db-shm

## Current Important Local Paths On Mac

Project root:
- /Users/qitengliu/Documents/Codex/Projects/ClawWarehouseLogistics/vn8

Full handover document:
- docs/WINDOWS_CODEX_HANDOVER_FULL.md

Backups:
- backups/

